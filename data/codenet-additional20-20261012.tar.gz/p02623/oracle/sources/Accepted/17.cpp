#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define endl "\n"
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll n,m,k;
    cin>>n>>m>>k;
    vector<ll>a(n),b(m);
    for(ll i=0;i<n;i++)cin>>a[i];
    for(ll i=0;i<m;i++)cin>>b[i];
    ll ans=0;
    ll cur=0;
    ll t=0;
    while(cur<n && t+a[cur]<=k){
        ans++;
        t+=a[cur++];
    }
    ll Max=ans;
    if(cur)cur--;
    for(ll i=0;i<m;){
        if(t+b[i]<=k){
            ans++;
            Max=max(Max,ans);
            t+=b[i++];
            continue;
        }
        else{
            if(cur>=0)t=max(0ll,t-a[cur--]);
            else break;
            ans--;
        }
    }
    cout<<Max;
    return 0;
}

