n,m,k=map(int,input().split())
a=list(map(int,input().split()))
b=list(map(int,input().split()))
s=0
pa,pb=[0,a[0]],[0,b[0]]
for i in range(1,n):
    pa.append(pa[-1]+a[i])
for i in range(1,m):
    pb.append(pb[-1]+b[i])
ac,bc=0,0
x,y=0,0
while ac<=n and pa[ac]<=k:
    ac+=1
    x=1

if x: ac-=1

while bc<=m and  pa[ac]+pb[bc]<=k:
    bc+=1
    y=1
if y: bc-=1
ans=ac+bc

for i in range(ac-1,-1,-1):
    for j in range(bc+1,m+1):
        if pa[i]+pb[j]>k: break
        bc=j
        ans=max(ans,i+j)
print(ans)
