from itertools import chain


def solve():
    N, M, K = map(int, input().split())

    A = map(int, input().split())
    *B, = map(int, input().split())

    answer = 0

    sum_b = sum(B)
    idx_b = M
    remain = K

    for i, a in enumerate(chain([0], A)):
        remain -= a
        if remain < 0:
            break

        while sum_b > remain:
            if idx_b < 0:
                break
            idx_b -= 1
            b = B[idx_b]
            sum_b -= b

        answer = max(answer, i + idx_b)

    return answer


def main():
    print(solve())


if __name__ == "__main__":
    main()
