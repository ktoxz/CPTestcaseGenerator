import numpy as np
import sys
input = sys.stdin.buffer.readline

N, M, K = map(int, input().split())
cumA = np.zeros(N+1, dtype=np.int64)
cumA[1:] = np.array(input().split(), dtype=np.int64).cumsum()
cumB = np.zeros(M+1, dtype=np.int64)
cumB[1:] = np.array(input().split(), dtype=np.int64).cumsum()
# print(cumA)
# print(cumB)

cumA = cumA[cumA <= K]
cumB = cumB[cumB <= K]
ans = np.searchsorted(cumA, K - cumB, side='right') - 1
ans += np.arange(len(cumB))
print(ans.max())