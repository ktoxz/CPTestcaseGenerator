#include <iostream>
#include <cmath>

int subserch(long long* B,long long i, int left,int right){
 //std::cout<<"subserch "<<left<<" "<<right<<std::endl;
 if(std::abs(left-right)<=3){
  for(int j=left;j<right;j++){
   if(B[j]>i){
    return j-1;
   }
  }
  return right-1;
 }
 int mid=left+right;
 mid/=2;
 if(B[mid]<i){
  return subserch(B,i,mid+1,right);
 }else if(B[mid]>i){
  return subserch(B,i,left,mid);
 }else{
  return mid;
 }
}

int serch(long long* B,long long M,int i){
 int left=0;
 int right=M;
 return subserch(B,i,left,right);
 
}

int main(){
 int N,M,K;
 std::cin>>N>>M>>K;

 long long* A=new long long[N];
 long long* B=new long long[M];
 for(int i=0;i<N;i++){
  std::cin>>A[i];
 }
 for(int i=0;i<M;i++){
  std::cin>>B[i];
 }
 for(int i=1;i<M;i++){
  B[i]=B[i-1]+B[i];
 }


 //std::cout<<"hoge\n";
 int forn=0;
 int ans=0;
 int tmp=0;
 for(int i=0;i<=N;i++){
  tmp=serch(B,M,K-forn);
  //std::cout<<i<<" "<<tmp<<std::endl;
  tmp+=i+1;
  if(ans<tmp){
   ans=tmp;
  }
  if(i==N){
   break;
  }
  forn+=A[i];
  if(forn>K){
   break;
  }
  
 }
 
 std::cout<<ans<<std::endl;

 return 0;
}