from itertools import accumulate
from bisect import bisect

n, m, k = map(int, input().split())
a = [*map(int, input().split())]
b = [*map(int, input().split())]
ca = [*accumulate(a, initial=0)]
cb = [*accumulate(b, initial=0)]
print(max(i - 1 + bisect(cb, k - x) for i, x in enumerate(ca) if x <= k))
