NMK=input().split(" ")
N=int(NMK[0])
M=int(NMK[1])
K=int(NMK[2])

def list2int(List):
    out=[]
    for i in range(len(List)):
        out.append(int(List[i]))
    return out

A=list2int(input().split(" "))
B=list2int(input().split(" "))

time=0
A_idx=0
B_idx=0
cnt=0
while(True):
    if(A_idx<len(A) and B_idx<len(B)):
        if(A[A_idx]<B[B_idx]):
            time+=A[A_idx]
            A_idx+=1
        elif(A[A_idx]==B[B_idx]):
            flag=""
            while(len(flag)<0):
                if(A_idx+1<len(A) and B_idx+1<len(B)):
                    if(A[A_idx+1]<B[B_idx]):
                        flag=="A"
                        break
                    elif(B[B_idx+1]<B[B_idx]):
                        flag=="B"
                        break
                    elif(A[A_idx]==B[B_idx]):
                        continue
            if(flag=="A"):
                time+=A[A_idx]
                A_idx+=1
            else:
                time+=B[B_idx]
                B_idx+=1
        else:
            time+=B[B_idx]
            B_idx+=1
    elif(A_idx>=len(A) and B_idx<len(B)):
        time+=B[B_idx]
        B_idx+=1
    elif(B_idx>=len(B) and A_idx<len(A)):
        time+=A[A_idx]
        A_idx+=1
    else:
        break
    if(time>K):
        break
    else:
        cnt+=1

print(cnt)