  #pragma GCC optimize("O3")
                #pragma comment(linker, "/stack:200000000")
                #pragma GCC optimize("unroll-loops")
                 
                #include <algorithm>
                #include <bitset>
                #include <cassert>
                #include <chrono>
                #include <cmath>
                #include <complex>
                #include <cstdio>
                #include <cstdlib>
                #include <cstring>
                #include <ctime>
                #include <deque>
                #include <functional>
                #include <iomanip>
                #include <iostream>
                #include <iterator>
                #include <limits>
                #include <climits>
                #include <list>
                #include <map>
                #include <numeric>
                #include <queue>
                #include <random>
                #include <ratio>
                #include <set>
                #include <sstream>
                #include <stack>
                #include <string>
                #include <unordered_map>
                #include <unordered_set>
                #include <utility>
                #include <vector>
                using namespace std;
                 
                typedef long long ll;
                typedef long double LD;
                #define int ll
                #define double LD
                #define pb push_back
                #define mp make_pair
                #define REP(i,n) for (int i = 0; i < n; i++)
                #define loop(i,n) for (int i = 0; i < n; i++)
                #define FOR(i,a,b) for (int i = a; i < b; i++)
                #define REPD(i,n) for (int i = n-1; i >= 0; i--)
                #define FORD(i,a,b) for (int i = a; i >= b; i--)
                #define remax(a,b) a = max(a,b)
                #define remin(a,b) a = min(a,b)
                #define mem(a, b) memset(a, b, sizeof a)
                #define append push_back
                #define all(v) v.begin(),v.end()
                #define F first
                #define S second
                #define print(x) cout << (x) << endl
                #define PRECISION(x) cout << fixed << setprecision(x)
                #define FAST_IO ios::sync_with_stdio(0); cin.tie(0); cout.tie(0)
                #define N 1010
                #define pb push_back
                const double PI=acos(-1);
                const int MOD = 1000000007;
                const int FMOD = 998244353;
                const double eps = 1e-9;
                 
                mt19937 RNG(chrono::steady_clock::now().time_since_epoch().count()); 
     			
     			int add(int a,int b)
     			{
     			    if((a+b)>MOD)
     			    {
     			        return a+b-MOD;
     			    }
     			    return a+b;
     			}
     			signed main()
     			{
     				int n,m,s;
     				cin>>n>>m>>s;
     				int a[n+m];
     				loop(i,n+m)
     				cin>>a[i];
     				
     				sort(a,a+n+m);
     				int ans=0,sum=0;
     				loop(i,n+m)
     				{
     					add(sum,a[i]);
     					ans++;
     					if(add(sum,a[i])>s)
     					break;
     				
					}
					cout<<ans;
				}