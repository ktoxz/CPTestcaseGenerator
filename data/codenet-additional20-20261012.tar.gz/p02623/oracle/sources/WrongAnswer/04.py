from bisect import bisect_right as br


def main():
    n, m, k = map(int, input().split())
    A = list(map(int, input().split()))
    B = list(map(int, input().split()))
    tmp = 0
    a = 0
    b = 0
    Sb = [B[0]]
    for i in range(1, m):
        Sb.append(Sb[-1] + B[i])
    Sa = [A[0]]
    for i in range(1, n):
        Sa.append(Sa[-1] + A[i])
    mx = 0
    for j in range(n):
        index = br(Sb, k - Sa[j]) - 1
        tmp = Sa[j] + Sb[index] if index > 0 else Sa[j]
        if tmp <= k:
            mx = max(mx, j + 1 + min(index + 1, m))
    print(mx)
    return


if __name__ == "__main__":
    main()
