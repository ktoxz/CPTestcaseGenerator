n,m,k = list(map(int,input().split()))
a = list(map(int,input().split()))
b = list(map(int,input().split()))
c = 0
 
while k >= 0:
  if len(a) == 0 and len(b) == 0:
    break;
  elif len(a) == 0:
    k -= b.pop(0)
  elif len(b) == 0:
    k -= a.pop(0)    
  else:
    k -= a.pop(0) if a[0] > b[0] else b.pop(0)
  c += 1
  
print(c)