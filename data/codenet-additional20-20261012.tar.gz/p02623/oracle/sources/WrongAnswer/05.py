x = input().split()
y = input().split()
z = input().split()
s = 0
import sys
for nn in range(400000):
    if int(x[2]) < 0:
        print(int(s-1))
        sys.exit()
    if int(y[0]) <= int(z[0]) :
        x[2] = int(x[2]) - int(y[0])
        del y[0]  
        y.append(1000000001) 
        s += 1
    else:
        x[2] = int(x[2]) - int(z[0])
        del z[0]
        z.append(1000000001)
        s += 1