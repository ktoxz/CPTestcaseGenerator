n,m,k=map(int,input().split())
A=[int(i) for i in input().split()]+[10**9]
B=[int(i) for i in input().split()]+[10**9]
a=b=ans=0
for _ in range(n+m):
    if A[a]<B[b]:
        k-=A[a]
        a+=1
    else:
        k-=B[b]
        b+=1
    if k<0:
        print(ans)
        exit()
    ans+=1    
print(ans)