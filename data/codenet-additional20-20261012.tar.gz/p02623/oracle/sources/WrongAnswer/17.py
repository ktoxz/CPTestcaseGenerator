import sys

input_data = []
input_pointer = 0

output_data = []

def input_scan():
    global input_data
    input_data = sys.stdin.readlines()
    input_data = [x[:-1] for x in input_data]

def next_line():
    global input_pointer
    global input_data
    if input_pointer < len(input_data):
        input_pointer += 1
        return input_data[input_pointer - 1]
    else:
        return ""

def append_output(string):
    global output_data
    output_data.append(string)

def print_output():
    global output_data
    output_data.append("")
    sys.stdout.write("\n".join(output_data))

# problem A
# a = int(input())
# append_output(str(a + a * a + a * a * a))
# print_output()

# problem B
# input_scan()
# s = next_line()
# t = next_line()
# print(sum([1 for x, y in zip(list(s), list(t)) if x != y]))

input_scan()
[n, m, k] = [int(x) for x in next_line().split(" ")]
stack_a = list(reversed([int(x) for x in next_line().split(" ")]))
stack_b = list(reversed([int(x) for x in next_line().split(" ")]))

total_books = 0

while k > 0:
    if len(stack_a) > 0 and len(stack_b) > 0:
        min_val = min(stack_a[-1], stack_b[-1])
        if min_val > k:
            break

        k -= min_val
        total_books += 1
        if min_val == stack_a[-1]:
            stack_a.pop()
            continue

        if min_val == stack_b[-1]:
            stack_b.pop()

    elif len(stack_a) > 0 and stack_a[-1] <= k:
        k -= stack_a[-1]
        stack_a.pop()
        total_books += 1
    elif len(stack_b) > 0 and stack_b[-1] <= k:
        k -= stack_b[-1]
        stack_b.pop()
        total_books += 1
    else:
        break

append_output(str(total_books))
print_output()
