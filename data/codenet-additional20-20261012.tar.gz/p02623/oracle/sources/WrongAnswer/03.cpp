#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define rep(i,n) for(int i=0;i<n;i++)
#define Rep(i,n) for(int i=1;i<=n;i++)
const ll MOD = 1000000007;
long long modinv(long long a, long long m=MOD) {
    long long b = m, u = 1, v = 0;
    while (b) {
        long long t = a / b;
        a -= t * b; swap(a, b);
        u -= t * v; swap(u, v);
    }
    u %= m; 
    if (u < 0) u += m;
    return u;
    /*MODの割り算の際に
    a/＝b;
    を
    a *= modinv(b,MOD);
    とする。
        */
}

const int MAXM = 200001;

ll A[MAXM],B[MAXM];

int main(){
    ll N,M,K;cin >> N >> M >> K;

    rep(i,N)cin >> A[i];
    rep(i,M)cin >> B[i];
    ll count = 0;
    ll a=0,b=0;
    bool a_ok = true, b_ok = true;
    while(1) {
        if((A[a] > B[b] || !a_ok) && b_ok){
            K-=B[b];
            b++;
            if(b>=M)b_ok = false;
        }else if(a_ok){
            K-=A[a];
            a++;
            if(a>=N)a_ok = false;
        }
        if(!a_ok && !b_ok){
            count++;
            break;
        }
        if(K<0){ 
            break;
        }
        count++;
    }
    cout << count << endl;

    return 0;
}