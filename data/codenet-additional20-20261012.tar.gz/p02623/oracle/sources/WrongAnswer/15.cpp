#include "bits/stdc++.h"

using namespace std;

void Main() {
    long long N, M, K;
    cin >> N >> M >> K;
    vector<long long> A(N, 0LL), B(M, 0LL);
    vector<long long> accA(N, 0LL), accB(M, 0LL);
    for (long long i = 0; i < N; ++i) {
        cin >> A[i];
        if (i == 0) {
            accA[i] = A[i];
        }
        else {
            accA[i] = accA[i - 1] + A[i];
        }
    }
    for (long long j = 0; j < M; ++j) {
        cin >> B[j];
        if (j == 0) {
            accB[j] = B[j];
        }
        else {
            accB[j] = accB[j - 1] + B[j];
        }
    }

    auto itA = upper_bound(accA.begin(), accA.end(), K);
    if (itA == accA.begin()) {
        // no choice from A
        auto itB = upper_bound(accB.begin(), accB.end(), K);
        if (itB == accB.begin()) {
            cout << 0 << endl;
        }
        else {
            cout << (1 + distance(accB.begin(), prev(itB))) << endl;
        }
        return;
    }

    long long ans = 0LL;
    for (itA = prev(itA); itA != accA.begin(); --itA) {
        long long kA = (*itA);
        auto itB = upper_bound(accB.begin(), accB.end(), K - kA);
        if (itB != accB.begin()) {
            long long books = 2 + distance(accA.begin(), itA) + distance(accB.begin(), prev(itB));
            ans = max(ans, books);
        }
        else {
            long long books = 1 + distance(accA.begin(), itA);
            ans = max(ans, books);
        }
    }
    // case : itA == accA.begin()
    long long kA = (*itA);
    auto itB = upper_bound(accB.begin(), accB.end(), K - kA);
    if (itB != accB.begin()) {
        long long books = 2 + distance(accA.begin(), itA) + distance(accB.begin(), prev(itB));
        ans = max(ans, books);
    }
    else {
        long long books = 1 + distance(accA.begin(), itA);
        ans = max(ans, books);
    }

    cout << ans << endl;
}

int main() {
    std::cout << std::fixed << std::setprecision(15);
    Main();
    return 0;
}
