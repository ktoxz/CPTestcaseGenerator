import numpy as np
n, m, k = [int(n) for n in input().split()]
A = [int(n) for n in input().split()]
B = [int(n) for n in input().split()]

A = [a for a in np.cumsum([0] + A) if a <= k]
B = [b for b in np.cumsum([0] + B) if b <= k]
n_read = 0
for i, a in enumerate(A[::-1]):
    for j, b in enumerate(B[::-1]):
        if a + b <= k:
            n_read = len(A) + len(B) - i  - j - 2
            break
    if a + b <= k:
        break
print(n_read)