int main(void)
{
    int n,a;
    for(int i=n;i<n-1;i--){
        a *= n;
    }
    for(int i=2;i<n;i++){
        a *= 9;
    }
    printf("%d",a%(10000000000+7));
}