import math

n = int(input())

if n == 1 :
    print(0)
else :
    ans = (math.factorial(n)*pow(10, n-2))%(pow(10, 9)+7)
    print(ans)
