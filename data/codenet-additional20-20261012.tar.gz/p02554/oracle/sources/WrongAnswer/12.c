#include <stdio.h>

int main(void){
  long long n,mod=1000000007,a[1000005],nc[1000005];
  scanf("%lld",&n);
  a[0]=0;
  a[1]=0;
  nc[1]=1;
  nc[2]=2;
  for(int i=2;i<=n;i++){
    if(i%2==0){
      if(i!=2) nc[i]=(nc[i-1]*2)%mod;
      a[i]=(a[i-1]*i*8+nc[i])%mod;
    }
    if(i%2==1){
      nc[i]=(nc[i-1]*i/(i/2+1))%mod;
      a[i]=(a[i-1]*i*8+nc[i]*2)%mod;
    }
  }
  printf("%lld",a[n]);
  return 0;
}
