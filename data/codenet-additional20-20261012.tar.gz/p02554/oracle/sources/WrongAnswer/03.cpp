#include <iostream>
#include<bits/stdc++.h>
#include <algorithm> 
#include<map>
#include<string>
#include<unordered_map>
#include <set>
#include<cmath>
#include<math.h>
#include <unordered_set>
#include<float.h>
#define all(v) v.begin(), v.end()
using namespace std;
typedef long long ll;
const long long mod = 1000000007;
const long long N = 100001;
vector<int> graph[N];
bool vis[N];

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	long long n,k;
	cin >> n;
	vector<ll>arr;
	ll ans;
	ans = ((n)*(n - 1))%mod;
	for (int i = 0; i < n - 2; i++) {
		ans = ((ans%mod) * 10) % mod;
	}
	cout << ans%mod;
	
	return 0;
}