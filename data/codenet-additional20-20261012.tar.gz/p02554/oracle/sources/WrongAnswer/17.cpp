#include <bits/stdc++.h>
#define rep(i,n) for (int i = 0; i < (n); ++i)
using namespace std;
using ll = long long;
using P = pair<int,int>;

const int INF = 1e9 + 7;

int main(){
	ll n;
	cin >> n;
	if(n == 1) cout << 0 << endl;
	else if(n == 2) cout << 2 << endl;
	else{
		ll ans = n%INF*(n-1)%INF/2%INF;
		rep(i,n-2) ans = ans*10%INF;
		cout << ans%INF << endl;
	}
}

// cout << fixed << setprecision(15) <<  << endl;