#include <stdio.h>
#include <string.h>
#include <stdlib.h>
 
long long ppow(int x, int y){
    long long z;
    z = 1;
    long long i;
    for(i = 0; i < y; i ++){
        z = (z * x)%1000000007;
    }
    return z;
}

int main() {
    int n;
    scanf("%d", &n);
    printf("%lld", (ppow(10, n)  - ppow(9, n) - ppow(9, n) + ppow(8, n))% 1000000007);
    return 0;
}