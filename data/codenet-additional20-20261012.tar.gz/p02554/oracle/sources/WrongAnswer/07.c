#include<stdio.h>
 int main(void)
 {
   int a;
   printf("%d",a%10*10*10*10*10*10*10*10*10*7);

   return 0;
 }
