N = int(input())
DP = [[0]*4 for _ in range(N)]
MOD = 10**9+7
for i in range(N):
    if i == 0:
        DP[i][0] = 8
        DP[i][1] = 1
        DP[i][2] = 1
        DP[i][3] = 0
        continue
    DP[i][0] = (DP[i-1][0] * 8) % MOD
    DP[i][1] = (DP[i-1][1] * 9) %MOD + (DP[i-1][0]) % MOD
    DP[i][2] = (DP[i-1][2] * 9) % MOD + ( DP[i-1][0]) % MOD
    DP[i][3] = (DP[i-1][3] * 10)% MOD + DP[i-1][1] % MOD+ DP[i-1][2] % MOD

print(DP[-1][3]%MOD)