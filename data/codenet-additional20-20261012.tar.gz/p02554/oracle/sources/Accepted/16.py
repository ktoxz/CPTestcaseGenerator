import sys
import math,bisect
sys.setrecursionlimit(10 ** 5)
from collections import defaultdict
from itertools import groupby,accumulate
from heapq import heapify,heappop,heappush
from collections import deque,Counter,OrderedDict
def I(): return int(sys.stdin.readline())
def neo(): return map(int, sys.stdin.readline().split())
def Neo(): return list(map(int, sys.stdin.readline().split()))
mod = 10**9+7
N = I()
p,q,r = 1,1,1
if N == 1:
    print(0)
    exit()
for i in range(N):
    p = (p*10)%mod
    q = (q*9)%mod
    r = (r*8)%mod
print((p-2*q+r)%mod)
