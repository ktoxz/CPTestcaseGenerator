#include<stdio.h>
int main(){
  long long a=1,b=1,c=1,n,i,M=1e9+7;
  scanf("%lld",&n);
  for(i=0;i<n;i++){
    a=(a*10)%M;
    b=(b* 9)%M;
    c=(c* 8)%M;
  }
  printf("%lld\n",(a+2*(M-b)+c)%M);
  return 0;
}
  
