#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
//if(strcmp(s[i],"AC")==0)
//if(s[l]=='#')
/*小文字判定
if((moji>= 'a') && (moji<='z')){
    printf("a\n");
    return 0;
  }
  */
//文字列中の一文字⇒数字の時は s[i]-'0'
int W_Length(char *str){
	int length = 0;
	while(*str++ != '\0')
		length++;
	return length;
}

void swap(long long int *a, long long int *b){
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}
//swap(&a, &b)

double deg(double theta){//deg to theta
return theta*(2*3.14159265359)/360;
}

long long int cmp( const void *p, const void *q ) {
    return *(long long int*)p - *(long long int*)q;
}//ちいさい順
//qsort(a,n,sizeof(long long int),cmp);


int cmp_s(const void * left, const void * right)
{
	char *left_char = (char *)left;
  char *right_char = (char *)right;
  return strcmp(left_char, right_char);
}
//qsort(s,n,sizeof(s[0]),cmp_s);
//char s[n][11]

long long int GCD(long long int a, long long int b){
  long long int L=a,S=b;
  while(1){
    if(S>L){
      L=S+L;
      S=L-S;
      L=L-S;
    }
    if(L%S==0){
      return S;
    }
    L=L%S;
  }
  
}

long long int LCM(long long int a, long long int b){
  return a*b/(GCD(a,b));
}

int main (void)
{
	long long int n,i,tem,k,a[210000],max,j=1,count=0;
scanf("%lld",&n);
  a[0]=1;
  a[1]=2;
  a[2]=1;
  for(i=0;i<n;i++){
    a[0]=a[0]*10;
      a[1]=a[1]*9;
      a[2]=a[2]*8;
    a[0]=a[0]%1000000007;
    a[1]=a[1]%1000000007;
    a[2]=a[2]%1000000007;
  }
  tem=a[0]-a[1]+a[2];
  if(tem<0){
    tem+=1000000007;
  }
  tem=tem%1000000007;
  printf("%lld\n",tem);
return 0;
}
