import math

a = int(input())

if a==1:
  print(0)
elif a==2:
  print(2)
else:
  
  num = (10**a)-(9**a)-(9**a)+(8**a)
  
  print(int(num % ((10**9)+7)))
