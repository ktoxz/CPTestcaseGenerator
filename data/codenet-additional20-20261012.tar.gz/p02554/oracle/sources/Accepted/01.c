#include<stdio.h>
//累乗(power)a^n(mod10^9+7)
long long power(long long a,long long n){
  long long count=a,sum=1;
  while(n>0){
    if(n%2==1)
      sum*=count;
    count*=count;
    count%=1000000007;
    sum%=1000000007;
    n/=2;
  }
  return sum;
}

int main(){
  int n;
  scanf("%d",&n);
  long long ans = 0;
  ans = power( 10, n );
  ans -= power( 9 , n );
  ans -= power( 9 , n );
  ans += power( 8 , n );
  while(ans < 0)
    ans += 1000000007;
  printf("%lld\n",ans);
  return 0;
}
