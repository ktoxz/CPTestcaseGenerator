#include <stdio.h>

#define MOD_BY 1000000007

int add(int a, int b) {
	return a + b - MOD_BY * (a + b >= MOD_BY);
}

int N;

int memo[1234567][2][2];

int kugyu(int pos, int zero, int nine) {
	int answer = 0;
	int i;
	if (pos >= N) return zero && nine;
	if (memo[pos][zero][nine]) return ~memo[pos][zero][nine];
	for (i = 0; i <= 9; i++) {
		answer = add(answer, kugyu(pos + 1, zero || i == 0, nine || i == 9));
	}
	return ~(memo[pos][zero][nine] = ~answer);
}

int main(void) {
	if (scanf("%d", &N) != 1) return 1;
	printf("%d\n", kugyu(0, 0, 0));
	return 0;
}
