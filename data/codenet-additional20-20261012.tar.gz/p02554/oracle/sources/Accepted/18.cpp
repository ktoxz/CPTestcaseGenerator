#include<bits/stdc++.h>
using namespace std;
int n;
long long dp[1000010][2][2];
const int mod=1e9+7;
int main(){
	cin>>n;
	dp[1][0][1]=1;
	dp[1][1][0]=1;
	dp[1][0][0]=8;
	for(int i=2;i<=n;i++){
		dp[i][0][0]+=dp[i-1][0][0]*8;
		dp[i][0][0]%=mod;
		dp[i][1][1]+=dp[i-1][0][1];
		dp[i][1][1]+=dp[i-1][1][0];
		dp[i][1][1]+=dp[i-1][1][1]*10;
		dp[i][1][1]%=mod;
		dp[i][0][1]+=dp[i-1][0][1]*9;
		dp[i][0][1]+=dp[i-1][0][0];
		dp[i][0][1]%=mod;
		dp[i][1][0]+=dp[i-1][1][0]*9;
		dp[i][1][0]+=dp[i-1][0][0];
		dp[i][1][0]%=mod;
	}
	//cout<<dp[2][0][0]<<endl;
	cout<<dp[n][1][1]<<endl;	
} 