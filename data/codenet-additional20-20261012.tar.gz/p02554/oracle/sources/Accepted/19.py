n = int(input())
ans = 10 ** n - ((10 - 1) ** n) * 2 + (10 - 2) ** n
if n > 1:
    print(ans % (10**9 + 7))
else:
    print(0)