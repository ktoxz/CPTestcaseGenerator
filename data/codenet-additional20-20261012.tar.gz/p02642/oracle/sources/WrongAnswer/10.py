from collections import Counter

input()
s = set(map(int, input().split()))
t = {k for k, v in Counter(s).items() if v == 1} 
r = int(1 in t)
if 1 not in s:
  for x in t:
    i = 2
    while i * i <= x:
      if x % i == 0 and  {i, x // i} & s:
        break
      i += 1
    else:
      r += 1
print(r)
