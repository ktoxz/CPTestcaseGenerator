#include <stdio.h>
#include <stdlib.h>

int compare_int(const void *a, const void *b)
{
    return *(int*)a - *(int*)b;
}


int main(void)
{
  int i, j, n, a[1000000], count = 0;
  
  scanf("%d", &n);
  count = n;
  
  for( i = 0; i < n; i++ ){
      scanf("%d", &a[i]);
  }
  
  qsort(a, n, sizeof(int), compare_int);
  
    for ( i = 0; i < n; i++ ){
        if( a[i] == a[i+1] ){
            count--;
            continue;
        }
        for ( j = 0; j < i; j++ ){
            if( a[i] % a[j] == 0 ){
                count--;
                break;
            }
            if( a[i] <= a[j] * 2 ){
                break;
            }
        }
    }
  
  printf("%d\n", count);
  return 0;
}