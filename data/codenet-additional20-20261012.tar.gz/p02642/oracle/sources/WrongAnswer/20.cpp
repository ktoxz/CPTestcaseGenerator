#include<bits/stdc++.h>
using namespace std;

bool fctrs(int x,int*a,int n) {
    int i = 1;
    while(i*i <= x) {
        if(!(x % i)){
            if(binary_search(a,a+n,i))
                return false;
            if(x/i != i && x!=x/i)
                if(binary_search(a,a+n,x/i))
                    return false;
        }
        i++;
    }
    return true;
}
int main(){
    int n,cnt=0;
    cin>>n;
    int a[n];
    map<int,int> m;
    for(int i=0;i<n;i++){
        cin>>a[i];
        m[a[i]]++;
    }
    if(n==1){
        cout<<0<<endl;
        return 0;
    }
    sort(a,a+n);
    for(int i=n-1;i>-1;i--){
        if(m[a[i]]==1 && fctrs(a[i],a,n))
            cnt++;
    }
    cout<<cnt<<endl;
    return 0;
}
