import math
ni = input()
N = int(ni)
num = input().rstrip().split(" ")
numbers=[]
for i in num:
    numbers.append(int(i))
numbers.sort()
ans = set(numbers)
for i in numbers:
    list =[]
    k = i
    k += i
    while k<200000:
        list.append(k)
        k +=i
    t = set(list)
    ans = ans.difference(t)
print(len(ans))    