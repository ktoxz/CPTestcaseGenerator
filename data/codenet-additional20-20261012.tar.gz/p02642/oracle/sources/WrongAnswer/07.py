M=10**6+1
A=[0]*M
_,*l=sorted(map(int,open(0).read().split()))
for i in l:
    A[i]+=1
    if A[i]==1:
      for j in range(2*i,M,i):A[j]+=9
print(A.count(1))