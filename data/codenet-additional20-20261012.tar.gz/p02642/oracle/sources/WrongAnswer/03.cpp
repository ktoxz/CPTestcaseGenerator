#include<iostream>
#include<vector>
#include<cmath>
#include<string>
#include<algorithm>
#include<map>
#include<utility>
#include<cstdio>
#include<bits/stdc++.h>

using namespace std;
using ll = long long;
const long long INF = 1LL<<60;

vector<ll> load[100005];

typedef pair<ll,ll> Pair;

int main(){

ll N;
vector<ll> furui(1e6);

cin >> N;

vector<ll> A(N);

for(ll i = 0;i < N;++i) cin >> A[i];

for(ll i = 1;i <= 1e6;++i) furui[i] = i;

std::sort(A.begin(), A.end());
A.erase(std::unique(A.begin(), A.end()), A.end());

for(ll j : A) cout << j << endl;

for(ll i : A){
    for(ll j = 1;j <= furui.size();++j){
        if(furui[i] == -1 or furui[j] == i) continue;
        else if(furui[j] % i == 0) furui[j] = -1; 
    }
}

ll count = 0;

for(ll i = 0;i <A.size();++i){

    if(furui[A[i]] != -1 && furui[A[i]] != A[i]) count++;

}

cout << count << endl;

return 0;

}   
