import numpy as np


N = int(input())
A = list(map(int,input().split()))

'''
N = 2*10**4
A = np.random.randint(1,10**6,N)
'''

A = np.sort(np.array(A))
middle_N = np.where(A>A[N-1]//2)[0][0]
middle_num = A[middle_N]
ok_list = np.array([])
ans = 0

for i in range(N):
    a = A[i]
    check_list = ok_list[ np.where(ok_list<middle_num) ]
    if set(  a%check_list==0 ) == {False} or i==0:
        if i>=N-1 or A[i+1]!=a:
            ok_list = np.append(ok_list, a)


print(len(ok_list))
