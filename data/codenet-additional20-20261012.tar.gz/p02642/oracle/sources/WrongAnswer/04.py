N = int(input())
A = input().split()
A = [int(a) for a in A]

if len(list(set(A))) == 1:
    print(0)
    exit()

count = 0
found = False
for i in range(N):
    for j in range(N):
        if i != j:
            if A[i] % A[j] == 0:
                found = True
                break
            else:
                continue
        else:
            continue
    if not found:
        count = count + 1
    found = False
        


print(count)