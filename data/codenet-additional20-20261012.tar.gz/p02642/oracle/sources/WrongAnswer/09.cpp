#include <bits/stdc++.h>
using namespace std;
using ll = long long;
// #define int ll

typedef vector<int> vi;
typedef vector<bool> vb;
typedef pair<int,int> pii;
typedef vector<pair<int,int> > vpii;
typedef vector<vector<bool> > vvb;
typedef map<int, bool> mib;

typedef long long ll;
typedef vector<long long> vl;
typedef pair<long long,long long> pll;
typedef vector<pair<long long,long long> > vpll;

typedef vector<string> vs;

typedef long double ld;

#define _GLIBCXX_DEBUG

#define REP(i,n) for (int i = 0; i < (n); ++i)
#define REPD(i,n) for (int i = (n-1); i >= 0; --i)
#define FORE(i, s, n) for (int i = (s); i <= (int)(n); i++)
#define debug(x) cerr << #x << ": " << x << '\n'
#define debug2(x, y) cerr << #x << ": " << x << ", " << #y << ": " << y << '\n'
#define debug3(x, y, z) cerr << #x << ": " << x << ", " << #y << ": " << y << ", " << #z << ": " << z << '\n'
#define hyphen() cerr << "--\n"

#define ALL(vec) (vec).begin(), (vec).end()
#define REVALL(vec) (vec).rbegin(), (vec).rend()

static const int dy[4] = {0,1,0,-1}, dx[4] = {1,0,-1,0};

#define fst first
#define snd second
#define pb push_back
#define mp(x,y) make_pair((x),(y))

const int MOD = (int)1e9 + 7;
const int INF = numeric_limits<int>::max();

signed main() {
    int N;

    cin >> N;

    vector<int> As(N);
    REP(i, N) {
        cin >> As.at(i);
    }

    // エラトステネスの篩っぽいことをする!
    sort(ALL(As));
    // int max_a = As.at(N-1);

    // Aiが残っているかどうか
    vb Alive(N, true);

    REP(i, N) {
        if (!Alive.at(i)) {
            continue;
        }

        int a = As.at(i);
        FORE(j, i+1, N-1) {
            // 同じものが存在する場合は元のiを消す
            int B = As.at(j);

            if (2 * a > B) {
                break;
            }

            if (a == B) {
                Alive.at(i) = false;
            }

            if (B % a == 0) {
                Alive.at(j) = false;
            }
        }
    }

    // 残っているものを数える
    int ans = 0;
    REP(i, N) {
        if (Alive.at(i)) {
            ans++;
        }
    }

    cout << ans << endl;
}
