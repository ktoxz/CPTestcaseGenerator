from collections import Counter
N=int(input())
list = list(map(int, input().split()))
list.sort()
ans=0
counter = Counter(list)
if(counter[list[0]]==N):
  print("0")

else:
  for i in range (0,N):
    res=0
    for j in range(0,N):
      if(i!=j):
        if(list[i] % list[j]==0):
          res+=1
          break
    if(0<res):
      ans+=1

  print(N-ans)