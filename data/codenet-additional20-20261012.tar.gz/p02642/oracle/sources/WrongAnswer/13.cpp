#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define rep(i,n) for(int i=0;i<n;i++)
#define Rep(i,n) for(int i=1;i<=n;i++)
const ll MOD = 1000000007;
long long modinv(long long a, long long m=MOD) {
    long long b = m, u = 1, v = 0;
    while (b) {
        long long t = a / b;
        a -= t * b; swap(a, b);
        u -= t * v; swap(u, v);
    }
    u %= m; 
    if (u < 0) u += m;
    return u;
    /*MODの割り算の際に
    a/＝b;
    を
    a *= modinv(b,MOD);
    とする。
        */
}
int N;
const int MAXN = 200001;
const int MAXA = 1000001;
int dp[MAXA]; //dp[i][j] iをjで割ったあまり
int A[MAXN];

bool ok[MAXN];
bool same[MAXA];
int main(){
    cin >> N;
    rep(i,N)cin >> A[i];
    sort(A,A+N);
    rep(i,MAXA){        
        same[i] = false;
        dp[i] = false;
    }


    int ans = 0;
    rep(i,N-1){
        if(A[i] == 1){
            return 0;
        }
        if(A[i] == A[i+1] && !same[A[i]]){
            same[A[i]] = true;
            ans--;
        }
    }

    // cout << ans << endl;

    
    rep(i,N) {
        if(!dp[A[i]]){
            ans++;
            int counter = 0;
            while(1) {
                counter++;
                int tmp = A[i]*counter;
                dp[tmp] = true;
                if(A[i]*(counter+1) > (MAXA-1))break;
            }
        }
    }

    // cout << same[1000000] << endl;
    cout << max(0,ans) << endl;
    return 0;
}