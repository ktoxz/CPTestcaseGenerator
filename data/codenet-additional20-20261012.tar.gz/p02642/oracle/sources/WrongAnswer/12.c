#include <stdio.h>
#include <stdlib.h>

#define MAX 1000100

int n;
int f[MAX];
int g[MAX];

int main( int argc, char *argv[] )
{
    int a;

    scanf( "%d", &n );
    for( int i=0; i<n; i++ ) {
        scanf( "%d", &a );
        if( f[a] ) g[a] = 1;
        f[a] = 1;
    }

    for( int i=2; i<MAX; i++ ) {
        if( f[i] == 0 ) continue;
        int k = i * 2;
        while( k < MAX ) {
            f[k] = 0;
            k += i;
        }
    }

    int count = 0;
    for( int i=0; i<MAX; i++ )
        if( f[i] && !g[i] ) count ++;

    printf( "%d\n", count );
}
