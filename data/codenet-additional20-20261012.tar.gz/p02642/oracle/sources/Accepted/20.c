#include <stdio.h>
n,i,a[210000],b[1100000],A=0;
#define r for(i=0;i<n;i++)
int main(){
	scanf("%d",&n);r scanf("%d",a+i);r b[a[i]]++;
	r{	int flag=b[a[i]]==1;
		if(a[i]!=1)flag&=b[1]==0;
		for(int d=2;d*d<=a[i];d++)if(a[i]%d==0)flag&=b[d]==0&&b[a[i]/d]==0;
		if(flag)A++;
	}
	
	printf("%d",A);
}