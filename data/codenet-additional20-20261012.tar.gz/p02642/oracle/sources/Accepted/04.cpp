#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define rep_range(i, s, e) for (int i = (s); i < (int)(e); i++)
#define rep_rev(i, s, e) for (int i = (s)-1; i >= (int)(e); i--)
#define sort_vec(v) sort((v).begin(),(v).end())
typedef int64_t lint;
// lint mod = 998244353;
// lint mod = 1000000007;
template< typename T1, typename T2 >
inline bool chmax(T1 &a, T2 b) { return a < b && (a = b, true); }
template< typename T1, typename T2 >
inline bool chmin(T1 &a, T2 b) { return a > b && (a = b, true); }

int app() {
  int n;
  cin>>n;

  vector<int> a(n);
  rep(i,n){
    cin>>a[i];
  }

  sort(a.begin(),a.end());
  set<int> s;
  int ans=0;
  rep(i,n){
    if(i+1<n&&a[i]==a[i+1]){
      s.insert(a[i]);
      continue;
    }
    int ai=a[i];
    bool hit=false;
    rep_range(f,1,1000){
      if(ai%f==0){
        if(s.count(f)==1||s.count(ai/f)==1){
          hit=true;
          break;
        }
      }
    }
    if(!hit)ans++;

    s.insert(a[i]);
  }

  return ans;
}

int main(){cout<<app()<<endl;return 0;}
