#include<bits/stdc++.h>

int main(){
    using namespace std;
    unsigned long N;
    cin >> N;
    vector<unsigned long> A(N);
    for(auto&& i : A)cin >> i;
    unsigned long Amax{1 + *max_element(begin(A), end(A))};
    vector<unsigned long> B(Amax);
    for(const auto& i : A)++B[i];
    vector<unsigned long> sieve(Amax, 1);
    for(unsigned long i{2}; i < Amax; ++i)if(sieve[i])for(unsigned long j{1}; j * i < Amax; ++j){
        sieve[j * i] = 0;
        B[j * i] += B[j];
    }
    unsigned long ans{0};
    for(const auto& i : A)if(B[i] == 1)++ans;
    cout << ans << endl;
    return 0;
}