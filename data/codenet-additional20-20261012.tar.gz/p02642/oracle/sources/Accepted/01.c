#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
int compare_int(const void *a, const void *b){
    return *(int*)a - *(int*)b;
}

int main(void){
	int n;
	int *a;
	int *x;
	scanf("%d", &n);
	a = (int *)malloc(sizeof(int) * n);
	for(int i=0; i<n; i++){
		scanf("%d", &a[i]);
	}
	qsort(a, n, sizeof(int), compare_int);
	int max = a[n-1];
	x = (int *)malloc(sizeof(int) * max+1);
	for(int j=1; j<max+1; j++){
		x[j] = 2;
	}
	for(int k=0; k<n; k++){
		if(x[a[k]] == 2){
			x[a[k]]--;
			int l = a[k]+a[k];
			while(l<=max){
				x[l] = 0;
				l += a[k];
			}
		}
		else if(x[a[k]] == 1){
			x[a[k]]--;
		}
	}
	int ans = 0;
	for(int i=0; i<n; i++){
		if(x[a[i]] >= 1){
			ans++;
		}
	}
	printf("%d\n", ans);
	return 0;
}