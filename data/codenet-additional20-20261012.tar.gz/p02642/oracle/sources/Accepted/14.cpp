#include <bits/stdc++.h>
using namespace std;

const int M = 1e6 + 1;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n;
    cin >> n;
    int occurences[M] = {}, ans = 0;

    while (n--) {
        int x;
        cin >> x;
        occurences[x]++;
    }

    for (int i = 1; i <= M; i++)
        if (occurences[i])
            for (int j = i + i; j <= M; j += i)
                occurences[j] = 0;
    for (int x : occurences)
        ans += (x == 1);

    cout << ans << '\n';
}
