#include<stdio.h>
int lb(int l,int r,long long n,long long *d){
  int m=(l+r)/2;
  if(l==r)return m;
  return n<=d[m]?lb(l,m,n,d):lb(m+1,r,n,d);
}
int ub(int l,int r,long long n,long long *d){
  int m=(l+r)/2;
  if(l==r)return m;
  return n<d[m]?ub(l,m,n,d):ub(m+1,r,n,d);
}
long long R=1,C=1,H[2000010],N[2000010];
//評価関数（いまはMIN）
int hyouka(int a,int b){
  if(C<b)return 1;
  if(C<a||b==0)return 0;
  return N[H[a]]<N[H[b]]?1:0;
}
//挿入関数
void hin(long long a){
  int i=C++;
  for(N[H[0]=R]=a;hyouka(0,i/2);i/=2)H[i]=H[i/2];
  H[i]=R++;
}
//取り出す関数
int hout(){
  int rt=H[1],i,j=2,k=H[--C];
  for(i=1;hyouka(i,C);i=j)H[i]=H[j=i*2+1-hyouka(i*2,i*2+1)];
  H[j/2]=k;
  return rt;
}
int main(){
  long long n,d[200010],i,j,k,l,a,ans=0,f[200010]={};
  scanf("%lld",&n);
  for(i=0;i<n;i++){
    scanf("%lld",&a);
    hin(a);
  }
  for(i=0;i<n;i++)d[i]=N[hout()];     
  for(i=0;i<n;i++){
    k=lb(0,n,d[i],d);
    l=ub(0,n,d[i],d);
    if(k+1!=l)f[i]=1;
    for(j=2;1;j++){
      k=lb(0,n,d[i]*j,d);
      //printf("%lld %lld %lld\n",k,d[i],d[k]);
      if(k==n)break;
      if(d[k]==d[i]*j)f[k]=1;
    }
    //printf("%lld\n",d[i]);
  NEXT:;
  }
  for(i=0;i<n;i++){
    if(f[i]==0)ans++;
  }
  printf("%lld\n",ans);
  return 0;
}
