#include<bits/stdc++.h>
using namespace std;
#define ll long long
int pref[500100] ;
int suff[500100] ;
int mp[500100] ;
int mp2[500100] ;
int main()
{
    int n,q;
    cin >> n >> q ;
    int ara[n+10];
    for(int i=1; i<=n; i++)
    {
        int val;
        cin >> val;
        ara[i] = val;
        if(!mp[val])
        {
            pref[i] = pref[i-1]+1;
        }
        else pref[i] = pref[i-1] ;
        mp[val]++;
    }
    for(int i=n; i>=1; i--)
    {
        int val;

        val = ara[i];
        if(!mp2[val])
        {
            suff[i] = suff[i+1]+1;
        }
        else suff[i] = suff[i+1] ;
        mp2[val]++;
    }
    while(q--)
    {
        int lft , rgt ;
        cin >> lft >> rgt ;
        int ans = pref[rgt] - pref[lft] + 1;
        int ans2 = suff[lft] - suff[rgt] + 1;
        cout << (max(ans,ans2)) << endl;
    }
}
