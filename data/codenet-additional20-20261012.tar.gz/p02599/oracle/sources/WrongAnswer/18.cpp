#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using Graph = vector<vector<int>>;
using WGraph = vector<vector<pair<int, ll>>>;

template<class T>inline bool chmax(T &a, const T &b) { if (b > a) { a = b; return true; } return false; }
template<class T>inline bool chmin(T &a, const T &b) { if (b < a) { a = b; return true; } return false; }

constexpr int dx[4] = {-1, 0, 0, 1}, dy[4] = {0, -1, 1, 0};
constexpr int INF = 1e9;
constexpr int MOD = 1e9 + 7;
constexpr long long LINF = 1e18;
constexpr double EPS = 1e-10;
constexpr double PI = M_PI;

void solve() {
    int N, Q;
    cin >> N >> Q;
    vector<int> c(N);
    for (int i=0; i<N; ++i) cin >> c[i];

    vector<int> cntL(N), cntR(N);
    set<int> st;
    for (int i=0; i<N; ++i) {
        st.insert(c[i]);
        cntL[i] = i + 1 - (int)st.size();
    }
    st.clear();
    for (int i=N-1; i>=0; --i) {
        st.insert(c[i]);
        cntR[i] = N - i - (int)st.size();
    }

    vector<int> res(Q);
    for (int i=0; i<Q; ++i) {
        int l, r;
        cin >> l >> r;
        --l, --r;
        res[i] = r - l + 1 - min(cntL[r] - cntL[l], cntR[l] - cntR[r]);
    }
    for (int x : res) cout << x << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout << fixed << setprecision(20);

    solve();

    return 0;
}
