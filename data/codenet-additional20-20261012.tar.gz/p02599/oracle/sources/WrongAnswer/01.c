#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <stdlib.h>

int main(void)
{

	int n,q;
	scanf("%d %d",&n,&q);
	assert(1<=n&&n<=5*pow(10,5));
	assert(1<=q&&q<=5*pow(10,5));
	
	int *c;
	c=(int *)malloc(sizeof(int)*(n));
	int l,r;
	
	int *answer;
	answer=(int *)malloc(sizeof(int)*q);
	int i,j,k;
	int count;
	for(i=0;i<n;i++)
	{
		scanf("%d",&c[i]);
		assert(1<=c[i]&&c[i]<=n);
	}
	for(i=0;i<q;i++)
	{
		count=0;
		scanf("%d %d",&l,&r);
		assert(1<=l&&l<=r&&r<=n);
		
		for(k=0;k<n;k++)
		{
			for(j=l-1;j<r;j++)
			{
				if(k==c[j])
				{
					count++;
					break;
				}
			}
		}
		answer[i]=count;
	}
	for(i=0;i<q;i++)
	{
		printf("%d\n",answer[i]);
	}
	
	free(answer);
	free(c);
	return 0;
}