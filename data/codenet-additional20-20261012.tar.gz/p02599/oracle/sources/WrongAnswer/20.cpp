#include <bits/stdc++.h>
using namespace std;
const int N = 3e4 + 5;
const int M = 1e6 + 5;
const int Q = 2e5 + 5;
int cnt[M] = {};
int arr[N] = {};
int ans[Q] = {};
int tot = 0;
struct query {
    int b, l, r, id;
} ask[Q];
inline bool cmp(const query &a, const query &b) {
    return a.b == b.b ? ((a.b & 1) ? a.r > b.r : a.r < b.r) : a.b < b.b;
}
inline void add(const int &x) {
    tot += (++cnt[arr[x]] == 1);
}
inline void del(const int &x) {
    tot -= (--cnt[arr[x]] == 0);
}
int main() {
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int n, m;
    cin >> n >> m;
    int B = ceil(sqrt(n));
    for (int i = 1; i <= n; i++)
        cin >> arr[i];
    int l, r;
    for (int i = 1; i <= m; i++) {
        cin >> l >> r;
        ask[i] = {l / B, l, r, i};
    }
    sort(ask + 1, ask + 1 + m, cmp);
    l = 1, r = 0;
    for (int i = 1; i <= m; i++) {
        while (ask[i].l < l) add(--l);
        while (r < ask[i].r) add(++r);
        while (l < ask[i].l) del(l++);
        while (ask[i].r < r) del(r--);
        ans[ask[i].id] = tot;
    }
    for (int i = 1; i <= m; i++)
        cout << ans[i] << '\n';
    return 0;
}