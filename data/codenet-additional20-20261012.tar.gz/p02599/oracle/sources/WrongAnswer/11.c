#include<stdio.h>
int R=1,C=1,H[2000010],N[2000010],L[1000010];
//評価関数（いまはMIN）
int hyouka(int a,int b){
  if(C<b)return 1;
  if(C<a||b==0)return 0;
  return (N[H[a]]<N[H[b]]||N[H[a]]==N[H[b]]&&L[H[a]]>L[H[b]])?1:0;
}
//挿入関数
void hin(int a){
  int i=C++;
  for(N[H[0]=R]=a;hyouka(0,i/2);i/=2)H[i]=H[i/2];
  H[i]=R++;
}
//取り出す関数
int hout(){
  int rt=H[1],i,j=2,k=H[--C];
  for(i=1;hyouka(i,C);i=j)H[i]=H[j=i*2+1-hyouka(i*2,i*2+1)];
  H[j/2]=k;
  return rt;
}
int n,B[500010]={0};
//BITのadd関数
//i番めの数値にnを足す
void badd(int i,int a){for(;i<=n;i+=i&-i)B[i]+=a;}
//BITのsum関数
//1からi番めの数の総和を返す
int  bsum(int i){
  int s=0;
  for(;i;i-=i&-i)s+=B[i];
  return s;
}
int main(){
  int m,i,p[500010],a[500010],r,ans[500050],j;
  scanf("%d %d",&n,&m);
  for(i=0;i<n;i++)scanf("%d",&a[i]);
  for(i=0;i<=n;i++)p[i]=-1;
  for(i=0;i<m;i++){
    scanf("%d %d",&L[R],&r);
    hin(r);
  }
  for(i=r=0;i<n;i++){
    j=hout();//printf("%d %d\n",L[j],N[j]);
    while(N[j]>r){//printf("p,%d\n",p[a[r]]);
      if(p[a[r]]+1)badd(p[a[r]],-1);//printf("%d\n",r);
      p[a[r]]=r+1;//printf("a\n");
      badd(r+1,1);//printf("r+1,%d\n",r+1);
      //printf("sum %d\n",bsum(r+1));
      r++;
    }
    //printf("N,L,j,%d %d %d\n",bsum(N[j]),bsum(L[j]-1),j);
    ans[j]=bsum(N[j])-bsum(L[j]-1);//printf("ans %d %d %d\n",N[j],L[j],ans[j]);
  }
  for(i=0;i<m;i++)printf("%d\n",ans[i+1]);
  return 0;
}
