import numpy as np

N, Q = input().split()
cn = np.array(input().split(), np.int64)

for _ in range(int(Q)):
  i, j = input().split()
  if i == j:
    print(1)
  print(np.unique(cn[int(i)-1: int(j)]).size)
