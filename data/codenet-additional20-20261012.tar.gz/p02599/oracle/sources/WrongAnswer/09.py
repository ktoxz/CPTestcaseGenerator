n,q=map(int,input().split())
table=[[0 for _ in range(n)] for _ in range(n+1)]
C=list(map(int,input().split()))
for i in range(1,n+1):
    c=C[i-1]-1
    table[i]=table[i-1][:]
    table[i][c]+=1

print(0)
for _ in range(q):
    l,r=map(int,input().split())
    ans=list(map(lambda x,y: x==y,table[r],table[l-1]))
    print(n-sum(ans))