#include<bits/stdc++.h>

using namespace std;
mt19937_64 rng(58);

#define UNSET_RIGHTMOST_BIT(n)  (n &= n - 1)

// sum the first n elements of original array (0 to n-1)
template <typename T>
T fenwick_prefix_sum(T* f, int n) {
  T sum = 0;
  for (; n > 0; UNSET_RIGHTMOST_BIT(n)) sum += f[n - 1];
  return sum;
}

// sum in [begin, end)
template <typename T>
T fenwick_range_sum(T* f, int begin, int end) {
  return fenwick_prefix_sum(f, end) - fenwick_prefix_sum(f, begin);
}

// update the fenwick tree for A[idx] += val, A.length = f_size
template <typename T>
void fenwick_inc_point(T* f, int f_size, int idx, T val) {
  for (; idx < f_size; idx |= (idx + 1)) f[idx] += val;
}

// Point Update, Range Query
template <typename T>
struct Fenwick {
  vector<T> ft;
  Fenwick(int sz): ft(sz, 0) {}
  T sum(int n) { T sum = 0; for (; n > 0; n &= n - 1) sum += ft[n - 1]; return sum; } // sum of [0, n) (not including n)
  T sum(int begin, int end) { return sum(end) - sum(begin); } // sum of [begin, end) (not including end)
  void inc(int idx, T val) { for (; idx < ft.size(); idx |= (idx + 1)) ft[idx] += val; }
  T at(int idx) { return sum(idx, idx + 1); }
  void set(int idx, T val) { inc(idx, val - at(idx)); }
};


int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    int n, q;
    cin >> n >> q;
    vector<int> color(n);

    for (int i=0; i<n; i++)
        cin >> color[i];

    vector<tuple<int, int, int>> queries(q);
    for (int i=0; i<q; i++) {
        int l, r;
        cin >> l >> r;
        queries[i] = {r-1, l-1, i};
    }
    sort(queries.begin(), queries.end());
    vector<int> ans(q);

    Fenwick<int> ft(n);
    vector<int> last(n + 1, -1);
    int idx = 0;
    for (int i=0; i<n; i++) {
        int c = color[i];
        if (last[c] >= 0) {
            ft.set(last[c], 0);
        }
        last[c] = i;
        ft.set(i, 1);
        for (; idx<n && get<0>(queries[idx]) == i; idx++) {
            int r = get<0>(queries[idx]);
            int l = get<1>(queries[idx]);
            int o = get<2>(queries[idx]);
            ans[o] = ft.sum(l, r + 1);
        }
    }
    for (auto a : ans) cout << a << endl;
}