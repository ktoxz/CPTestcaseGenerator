import numpy as np

n, q = map(int, input().split())
c = np.array(input().split(), dtype = np.int64)
l = np.array([0 for i in range(q)], dtype = np.int64)
r = np.array([0 for i in range(q)], dtype = np.int64)
cnt = 0
wk = []
print(c)

for i in range(q):
    L, R = map(int, input().split())
    l[i] = L
    r[i] = R
for i in range(q):
    wk = []
    cnt = 0
    for j in range(r[i] - l[i] + 1):
        if c[l[i] + j -1] not in wk:
            cnt += 1
            wk.append(c[l[i] + j -1])
    print(cnt)
