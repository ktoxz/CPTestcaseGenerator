from collections import Counter

def solve(h, w, a):
    c = Counter(list("".join(a)))
    d = Counter(list(map(lambda num: num % 4, c.values())))
    if (h % 2 == 0) and (w % 2 == 0):
        return "Yes" if list(d.keys()) == [4] else "No"
    if (h % 2 == 1) and (w % 2 == 1):
        for k in [1, 3]:
            if k in d:
                if d[k] != 1:
                    return "No"
        if 1 in d and 3 in d:
            return "No"
        if (2 in d) and d[2] > sum(x // 2 for x in [h,w]):
            return "No"
    else:
        for k in [1, 3]:
            if k in d:
                return "No"
        if (2 in d) and d[2] > sum((x % 2 == 0) * (x // 2) for x in [h,w]):
            return "No"
    return "Yes"

h, w = map(int, input().split())
a = [input() for r in range(h)]
print(solve(h, w, a))
