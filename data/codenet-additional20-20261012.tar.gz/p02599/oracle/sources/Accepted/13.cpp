#define _USE_MATH_DEFINES
#include <bits/stdc++.h>
using namespace std;
#define FOR(i,m,n) for(int i=(m);i<(n);++i)
#define REP(i,n) FOR(i,0,n)
#define ALL(v) (v).begin(),(v).end()
using ll = long long;
const int INF = 0x3f3f3f3f;
const ll LINF = 0x3f3f3f3f3f3f3f3fLL;
const double EPS = 1e-8;
const int MOD = 1000000007;
// const int MOD = 998244353;
const int dy[] = {1, 0, -1, 0}, dx[] = {0, -1, 0, 1};
const int dy8[] = {1, 1, 0, -1, -1, -1, 0, 1}, dx8[] = {0, -1, -1, -1, 0, 1, 1, 1};
template <typename T, typename U> inline bool chmax(T &a, U b) { return a < b ? (a = b, true) : false; }
template <typename T, typename U> inline bool chmin(T &a, U b) { return a > b ? (a = b, true) : false; }
struct IOSetup {
  IOSetup() {
    cin.tie(nullptr);
    ios_base::sync_with_stdio(false);
    cout << fixed << setprecision(20);
  }
} iosetup;

struct Mo {
  Mo(const vector<int> &left, const vector<int> &right) : left(left), right(right) {
    n = left.size();
    int width = sqrt(n);
    order.resize(n);
    iota(ALL(order), 0);
    sort(ALL(order), [&](int a, int b) {
      return left[a] / width != left[b] / width ? left[a] < left[b] : ((left[a] / width) & 1 ? right[a] < right[b] : right[a] > right[b]);
    });
  }

  int process() {
    if (ptr == n) return -1;
    int idx = order[ptr++];
    while (left[idx] < nl) add(--nl);
    while (nr < right[idx]) add(nr++);
    while (nl < left[idx]) del(nl++);
    while (right[idx] < nr) del(--nr);
    return idx;
  }

  void add(int idx) const;

  void del(int idx) const;

private:
  vector<int> left, right, order;
  int n, ptr = 0, nl = 0, nr = 0;
};

const int N = 500000;
int cnt[N] = {}, ans = 0;
vector<int> c;

void Mo::add(int idx) const {
  if (cnt[c[idx]] == 0) ++ans;
  ++cnt[c[idx]];
}

void Mo::del(int idx) const {
  --cnt[c[idx]];
  if (cnt[c[idx]] == 0) --ans;
}

int main() {
  int n, q; cin >> n >> q;
  c.resize(n);
  REP(i, n) cin >> c[i], --c[i];
  vector<int> l(q), r(q);
  REP(i, q) cin >> l[i] >> r[i], --l[i];
  Mo mo(l, r);
  vector<int> kind(q);
  REP(_, q) {
    int idx = mo.process();
    kind[idx] = ans;
  }
  REP(i, q) cout << kind[i] << '\n';
  return 0;
}
