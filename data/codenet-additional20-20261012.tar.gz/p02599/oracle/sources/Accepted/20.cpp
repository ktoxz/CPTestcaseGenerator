#include <bits/stdc++.h>
using namespace std;
using VI = vector<int>;
#define rep(i, n) for (int i = 0; i < (n); i++)

int main() {
  cin.tie(nullptr); ios_base::sync_with_stdio(false);

  int n, q; cin >> n >> q;
  VI c(n); rep(i, n) cin >> c[i];
  vector<pair<int, int>> lr(q); rep(i, q) cin >> lr[i].first >> lr[i].second;
  rep(i, q) lr[i].first--;

  const int sq = 700;
  vector<tuple<int, int, int>> lri(q);
  rep(i, q) lri[i] = make_tuple(lr[i].first / sq, lr[i].second, i);
  sort(lri.begin(), lri.end());

  VI ans(q);

  VI cnt(n+1);
  int prev = -1;
  int lx, rx; lx = rx = get<0>(lri[0]);
  int sum = 0;
  VI changed;
  for (auto [ls, r, i] : lri) {



    // ここのコメントを外すとhandmade03-05, random06がWAになる

    if (ls != prev) {
      for (auto cx : changed) cnt[cx] = 0;
      changed.clear();
      lx = rx = r;
      prev = ls;
      sum = 0;
    }



    int l = lr[i].first;
    assert(r == lr[i].second); assert(rx <= r);
    int cx;
    while (rx < r) {
      assert(cnt[c[rx]] >= 0);
      if (cnt[cx=c[rx++]]++ == 0) sum += 1, changed.push_back(cx);
    }
    while (lx > l) {
      assert(cnt[c[lx-1]] >= 0);
      if (cnt[cx=c[--lx]]++ == 0) sum += 1, changed.push_back(cx);
    }
    while (lx < l) {
      assert(cnt[c[lx]] >= 1);
      if (--cnt[c[lx++]] == 0) sum -= 1;
    }
    ans[i] = sum;
  }
  rep(i, q) cout << ans[i] << "\n";
}
