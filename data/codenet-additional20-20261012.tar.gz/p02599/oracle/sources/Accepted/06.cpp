#include <bits/stdc++.h>

struct BIT
{
    std::array<std::vector<std::int32_t>, 2> dat;
    std::int32_t unity_sum = 0;

    BIT(std::size_t n)
    {
        dat[0].assign(n + 1, unity_sum);
        dat[1].assign(n + 1, unity_sum);
    }

    inline void add(std::int32_t a, std::int32_t b, std::int32_t x)
    {
        sub_add(0, a, x * -(a - 1));
        sub_add(1, a, x);
        sub_add(0, b, x * (b - 1));
        sub_add(1, b, x * (-1));
    }

    inline std::int32_t sum(std::int32_t a, std::int32_t b) {
        return sub_sum(0, b - 1) + sub_sum(1, b - 1) * (b - 1)
             - sub_sum(0, a - 1) - sub_sum(1, a - 1) * (a - 1);
    }

  private:

    // 1-origin, [a, b)
    inline void sub_add(std::int32_t p, std::int32_t a, std::int32_t x)
    {
        for (std::int32_t i=a; i < dat[p].size(); i += i & -i)
        {
            dat[p][i] = dat[p][i] + x;
        }
    }

    inline std::int32_t sub_sum(std::int32_t p, std::int32_t a)
    {
        std::int32_t res = unity_sum;
        for (std::int32_t i = a; i > 0; i -= i & -i)
        {
            res = res + dat[p][i];
        }
        return res;
    }
};

int main()
{
    std::size_t N, Q;
    std::cin >> N >> Q;

    std::vector<std::int32_t> C(N);
    for(auto& c : C)
    {
        std::cin >> c;
    }

    std::vector<std::int32_t> Ls(Q);
    std::vector<std::int32_t> Rs(Q);
    std::vector<std::int32_t> ids(Q);

    for(std::size_t i=0; i<Q; ++i)
    {
        std::cin >> Ls[i] >> Rs[i];
        Ls[i] -= 1;
        ids[i] = i;
    }
    std::sort(ids.begin(), ids.end(), [&](const auto i, const auto j) {
                return Rs[i] < Rs[j];
            });

    BIT bit(N+5);

    std::vector<std::int32_t> prev(1100000, -1);
    std::vector<std::int32_t> res(Q, 0);

    int r = 0;
    for(const auto i : ids)
    {
        for(; r < Rs[i]; ++r)
        {
            bit.add(prev.at(C.at(r)) + 2, r+2, 1);
            prev.at(C.at(r)) = r;
        }

        int tmp = bit.sum(Ls[i]+1, Ls[i]+2);
        res[i] = std::max(res[i], tmp);
    }

    for(const auto& a : res)
    {
        std::cout << a << std::endl;
    }


    return 0;
}
