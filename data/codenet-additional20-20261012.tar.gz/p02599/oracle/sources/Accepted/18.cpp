#include <bits/stdc++.h>
 
using namespace std ;
 
const int MAX = 2e7 , MAXN = 5e5 + 10 ;
 
int L[MAX] , R[MAX] , tree[MAX] , arr[MAXN] , version[MAXN] ;
int nodes = 0 , n , q;
 
int leaf(int value)
{
	int p = ++nodes ;
	L[p] = R[p] = 0 ; //null
	tree[p] = value ;
	return p;
}
 
int parent(int lef , int rig)
{
	int p = ++nodes ;
	L[p] = lef , R[p] = rig ;
	tree[p] = tree[lef] + tree[rig] ;
	return p ;
}
 
int build(int l , int r)
{
	if(l == r)
		return leaf(0) ;
	int mid = (l + r) >> 1 ;
	return parent(build(l , mid) , build(mid + 1 , r)) ;
}
 
int update(int node , int l , int r , int idx , int val)
{
	if(l == r)
		return leaf(tree[node] + val) ;
	int mid = (l + r) >> 1 ;
	if(idx <= mid)
		return parent(update(L[node] , l , mid , idx , val) , R[node]) ;
	else
		return parent(L[node] , update(R[node] , mid + 1 , r , idx , val)) ;
}
 
int query(int node , int l , int r , int from , int to)
{
	if(from > r || to < l)
		return 0 ;
	if(l >= from && r <= to)
		return tree[node] ;
	int mid = (l + r) >> 1 ;
	int a = query(L[node] , l , mid , from , to) ;
	int b = query(R[node] , mid+1 , r , from , to) ;
	return (a + b) ;
}
 
vector<int>v[MAXN] ;

int main()
{
	ios_base::sync_with_stdio(0) ;
	cin.tie(0) ;
	cin>>n>>q ;
	for(int i = 1 ; i <= n ; ++i)
		cin>>arr[i] ;
	version[0] = build(0 , n) ;
	for(int i = 1 ; i <= n ; ++i)
	{
		int idx ;
		if(v[arr[i]].size())
			idx = v[arr[i]].back() ;
		else
			idx = 0 ;
		version[i] = update(version[i-1] , 0 , n , idx , 1) ;
		v[arr[i]].push_back(i) ;
	}
	int l , r ;
	while(q--)
	{
		cin>>l>>r ;
		cout<<query(version[r] , 0 , n , 0 , l-1) - query(version[l-1] , 0 , n , 0 , l-1)<<"\n" ;
	}
	return 0 ;
} 