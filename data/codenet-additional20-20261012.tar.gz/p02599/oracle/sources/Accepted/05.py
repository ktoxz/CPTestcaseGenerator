(n,q),c,*z=[[*map(int,t.split())]for t in open(0)]
a=[0]*q
j,*b=t=[0]*9**6
for i in sorted(range(q),key=lambda x:z[x][1]):
 l,r=z[i]
 while j<r:
  d=c[j];j+=1;x,y,b[d]=b[d]+1,j+1,j
  while x<=n:t[x]+=1;x+=x&-x
  while y<=n:t[y]-=1;y+=y&-y
 while l:a[i]+=t[l];l-=l&-l
print(*a)