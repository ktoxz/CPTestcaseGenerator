#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define rep(i,s,f) for(i=s;i<f;i++)
#define print(v) for(auto &z:v) cout<<z<<' ';cout<<'\n'
#define db cout<<"db: "
#define pb push_back
#define pii pair<int,int>
#define F first
#define S second
#define B begin()
#define E end()
#define all(v) v.B,v.E
#define sz(v) (int)((v).size())
#define vi vector<int>
#define vii vector<pair<int,int>>
#define boost ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define clk1 clock_t start_time=clock()
#define clk2 cout<<(clock()-start_time)/(double)CLOCKS_PER_SEC
#define clean(arr) memset(arr,0,sizeof(arr))
#define mod 1000000007
#define mod2 998244353
#define space 500005
//<<fixed << setprecision(9)

int arr[space];
int cnt[space];
int distinct;

const int block_size=700;

struct Query
{
    int l, r, idx;
    bool operator<(Query other) const
    {
        if(l/block_size != other.l/block_size) return l<other.l;
        return ((l/block_size)&1) ? r<other.r : r>other.r ;
    }
};

void add(int x)
{
    cnt[arr[x]]++;
    if(cnt[arr[x]]==1) distinct++;
}
void remove(int x)
{
    cnt[arr[x]]--;
    if(cnt[arr[x]]==0) distinct--;
}

int main()
{
    int n,i,j,t;
    boost;

    cin>>n>>t;

    rep(i,1,n+1) cin>>arr[i];

    Query Q[t];
    int ans[t];
    rep(i,0,t)
    {
        int l,r;
        cin>>l>>r;
        Q[i]={l,r,i};
    }
    sort(Q,Q+t);

    int cur_l = 1;
    int cur_r = 0;
    
    for (Query q : Q)
    {
        while (cur_l > q.l) {
            cur_l--;
            add(cur_l);
        }
        while (cur_r < q.r) {
            cur_r++;
            add(cur_r);
        }
        while (cur_l < q.l) {
            remove(cur_l);
            cur_l++;
        }
        while (cur_r > q.r) {
            remove(cur_r);
            cur_r--;
        }
        ans[q.idx] = distinct;
    }

    rep(i,0,t)cout<<ans[i]<<'\n';

    return 0;
}