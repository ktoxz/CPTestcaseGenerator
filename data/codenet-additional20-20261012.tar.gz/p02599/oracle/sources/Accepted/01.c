#include <stdio.h>

typedef struct {
	int key, id;
} data;

void merge_sort(data x[], int n)
{
	static data y[500001] = {};
	if (n <= 1) return;
	merge_sort(&(x[0]), n/2);
	merge_sort(&(x[n/2]), (n+1)/2);
	
	int i, p, q;
	for (i = 0, p = 0, q = n/2; i < n; i++) {
		if (p >= n/2) y[i] = x[q++];
		else if (q >= n) y[i] = x[p++];
		else y[i] = (x[p].key < x[q].key)? x[p++]: x[q++];
	}
	for (i = 0; i < n; i++) x[i] = y[i];
}

void add_BIT(int N, int BIT[], int i, int k)
{
	while (i <= N) {
		BIT[i] += k;
		i += (i & -i);
	}
}

int sum_BIT(int BIT[], int r)
{
	int sum = 0;
	while (r > 0) {
		sum += BIT[r];
		r -= (r & -r);
	}
	return sum;
}

int main()
{
	int i, N, Q, c[500001], l[500001], r[500001];
	scanf("%d %d", &N, &Q);
	for (i = 1; i <= N; i++) scanf("%d", &(c[i]));
	for (i = 1; i <= Q; i++) scanf("%d %d", &(l[i]), &(r[i]));
	
	data d[500001];
	for (i = 0; i < Q; i++) {
		d[i].key = l[i+1];
		d[i].id = i + 1;
	}
	merge_sort(d, Q);
	
	int k, right[500001], p[500001];
	for (i = 1; i <= N; i++) {
		right[i] = N + 1;
		p[i] = 0;
	}
	for (i = N, k = d[0].key; i >= k; i--) {
		if (p[c[i]] != 0) right[i] = p[c[i]];
		p[c[i]] = i;
	}
	
	int BIT[500001] = {}, ans[500001];
	for (i = 1; i <= N; i++) if (p[i] != 0) add_BIT(N, BIT, p[i], 1);
	for (i = 0; i < Q; i++) {
		for (; k < d[i].key; k++) {
			add_BIT(N, BIT, k, -1);
			if (right[k] != N + 1) add_BIT(N, BIT, right[k], 1);
		}
		ans[d[i].id] = sum_BIT(BIT, r[d[i].id]);
	}

	for (i = 1; i <= Q; i++) printf("%d\n", ans[i]);
	fflush(stdout);
	return 0;
}