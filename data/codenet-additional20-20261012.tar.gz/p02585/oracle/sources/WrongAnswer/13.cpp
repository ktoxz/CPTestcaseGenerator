#include <algorithm>
#include <iomanip>
#include <iostream>
#include <vector>

long count(
    int k,
    const std::vector<int>& positions,
    std::vector<int>& values,
    int start)
{
  auto location = positions[start] - 1;
  long sum = values[location];
  long result = sum;
  int count = 1;
  for (; count < k && location != start; ++count) {
    location = positions[location] - 1;
    sum += values[location];
    result = std::max(result, sum);
  }
  if (count >= k) return result;

  const auto rem = k % count;
  sum = sum * (k / count - 1);
  result = sum;
  for (int i = 0; i < count + rem; ++i) {
    location = positions[location] - 1;
    sum += values[location];
    result = std::max(result, sum);
  }
  return result;
}

long solve(
    int n,
    int k,
    const std::vector<int>& positions,
    std::vector<int>& values)
{
  long result = std::numeric_limits<long>::min();
  for (int i = 0; i < n; ++i) {
    result = std::max(result, count(k, positions, values, i));
  }
  return result;
}

int main()
{
  int n, k;
  std::cin >> n >> k;
  std::vector<int> positions(n);
  std::vector<int> values(n);
  for (auto& p : positions) {
    std::cin >> p;
  }
  for (auto& v : values) {
    std::cin >> v;
  }

  std::cout << std::setprecision(20);
  std::cout << solve(n, k, positions, values) << std::endl;
}
