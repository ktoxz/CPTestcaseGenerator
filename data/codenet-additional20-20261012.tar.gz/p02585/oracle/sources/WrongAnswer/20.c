#include<stdio.h>
#define MAX 5002
#define MIN -100000000000000
typedef long long ll;

ll max(ll a,ll b){
    if(a>b) return a;
    else return b;
}

int main(){
    ll N,K;
    scanf("%lld %lld",&N,&K);
    ll numOfLoop = K/N,maxArg = MIN;
    ll P[MAX],C[MAX],sum = 0;
    for(ll i=1;i<=N;i++)
        scanf("%lld",P+i);
    for(ll i=1;i<=N;i++){
        scanf("%lld",C+i);
        sum += C[i];
        maxArg = max(maxArg,C[i]);
    }

    ll max_ = MIN;

    for(ll i=1;i<=N;i++){
        ll tmp = i;
        ll keep = 0;
       for(ll j=1;j<=K%N;j++){
             tmp = P[tmp];
             keep += C[tmp];
             max_ = max(keep,max_);
        }
    }
    max_ = max(max_,maxArg);
    ll ans;
    if(sum < 0)
        ans = max_;
    else
        ans = sum*numOfLoop + max_;
    printf("%lld",ans);
}
