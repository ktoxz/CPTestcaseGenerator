a=[list(map(int,input().split(" "))) for i in range(3)]
ans=[0]*a[0][0]
for i in range(a[0][0]):
  num =i
  count =0
  summ =0
  summax =0
  summaxnum =0
  for j in range(min(a[0][0],a[0][1])):
    num = a[1][num]-1
    count+=1
    summ += a[2][num]
    if count == 1:
      summax=summ
      summaxnum =count
    if summax < summ:
      summax=summ
      summaxnum =count
    if num==i:
      break
  if summ<0:
    ans[i]=summax
  elif a[0][1]%count>=summaxnum:
    ans[i]=summax+summ*(a[0][1]//count)
  else:
    ans[i]=summax+summ*(a[0][1]//count -1)    
print(max(ans))