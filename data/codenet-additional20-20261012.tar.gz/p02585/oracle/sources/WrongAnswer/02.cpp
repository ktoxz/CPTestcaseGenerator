#include <bits/stdc++.h>
#define rep(i,n) for (int i = 0; i < (int)(n); i++)
#define REP(i,n) for (int i = 1; i < (int)(n); i++)
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define debug(var) do{cout << #var << " : "; view(var);}while(0)
template<class T> bool chmin(T &a, T b) {if(a>b) {a=b;return 1;}return 0;}
template<class T> bool chmax(T &a, T b) {if(a<b) {a=b;return 1;}return 0;}
using namespace std;
template<class T> void view(T e) {cout << e << endl;}
template<class T> void view(const vector<T> &v) {for(const auto &e : v){cout << e << " ";} cout << endl;}
template<class T> void view(const vector<vector<T>> &vv) {for(const auto &v : vv){view(v);}}
using vint = vector<int>;
using vvint = vector<vector<int>>;
using ll = long long;
using vll = vector<ll>;
using vvll = vector<vector<ll>>;
using P = pair<int,int>;
const int inf = 1e9;
const ll inf_l = 1e18+100;
const int MAX = 1e5;

int main() {
    int n, k; cin >> n >> k;
    vint p(n), c(n);
    rep(i,n) {
        int x; cin >> x;
        x--;
        p[i] = x;
    }
    rep(i,n) cin >> c[i];
    vll v(n);
    vint ct(n);
    rep(i,n) {
        for (int j = p[i]; ; j = p[j]) {
            v[i] += c[j];
            ct[i]++;
            if (j == i) break;
        }
    }
    ll ans = -inf_l;
    rep(i,n) {
        ll sum = 0;
        int n_loop, rem;
        if (k % ct[i] == 0) {
            n_loop = k / ct[i] - 1;
            rem = ct[i];
        } else {
            n_loop = k / ct[i];
            rem = k % ct[i];
        }
        if (v[i] > 0 && n_loop > 0) {
            sum += v[i] * n_loop;
            ans = max(ans,sum);
        }
        int cur = i;
        while (rem--) {
            cur = p[cur];
            sum += c[cur];
            ans = max(ans,sum);
        }
    }
    cout << ans << endl;
}
