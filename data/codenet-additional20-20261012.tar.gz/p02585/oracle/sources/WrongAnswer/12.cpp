
#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main() {
	ios::sync_with_stdio(false);
    cin.tie(0);
    ll x,k,d;
    cin>>x>>k>>d;
    if(d == 0)
    {
        cout<<x<<endl;
        return 0;
    }
    if(x == 0)
    {
        if(k&1)
        {
            cout<<d<<endl;
            return 0;
        }
        cout<<0<<endl;
        return 0;
    }
    if(k == 0)
    {
        cout<<x<<endl;
        return 0;
    }
    if(x == k && k == d)
    {
        if(k&1)
        {
            cout<<0<<endl;
            return 0;
        }
        cout<<k<<endl;
        return 0;
    }
    ll tmp = x/d;
    if(tmp>k)
    {
        cout<<x - (k*d)<<endl;
        return 0;
    }
    
    ll ans = x%d;
    cout<<ans+((k%tmp)*d)<<endl;
}