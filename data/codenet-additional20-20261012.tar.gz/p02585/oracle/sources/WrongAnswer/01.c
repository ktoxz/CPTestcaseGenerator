#include <stdio.h>
int n,p[5000],u[5000];
long long k,c[5000];

long check(int i) {
   int j,ni,jj,jjj,kkk;
   long long s,all,kk,cc[5000],t;
  
   ni=1;u[i]=0;s=c[i];
   for (j=p[i];u[j];j=p[j]) {
      u[j]=0;
      s+=c[j];
      ni++;
   }
   if (k>ni && s>0) {
      all=s*(k/ni);
      kk=k-(k/ni)*ni;
   } else if (k>ni) {
      all=0;
      kk=ni;
   } else {
      all=0;
      kk=k;
   }
   t=cc[i]=c[i];
   for (j=p[i];j!=i;j=p[j]) {
      cc[j]=c[j];
      if (t<cc[j]) t=cc[j];
   }
   for (jj=1;jj<kk;jj++) {
      jjj=jj;
      for (j=i;jjj>0;jjj--) j=p[j];
      jjj=i;
      for (kkk=0;kkk<ni;j=p[j],jjj=p[jjj],kkk++) {
         cc[jjj]+=c[j];
         if (t<cc[jjj]) t=cc[jjj];
      }
   }
   return t+all;
}

int main(){
   int i,f;
   long long ans,x;

   scanf("%ld %ld",&n,&k);
   for (i=0;i<n;i++) {
       scanf("%d",&p[i]);
       p[i]--;
   }
   for (i=0;i<n;i++) scanf("%lld",&c[i]);
   for (i=0;i<n;i++) u[i]=1;
   for (f=i=0;i<n;i++)
      if (u[i]) {
         x=check(i);
         if (!f) {
            ans=x;
            f=1;
         } else if (ans<x) ans=x;
      }
   printf("%lld\n",ans);
   return 0;
}
