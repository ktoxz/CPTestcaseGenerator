/*	                           
							 * * 
						   *     * 
						 *	       * 
					   *	         * 
                     *     _ooOoo_     * 
                   *      o8888888o      * 
                 *        88" . "88        * 
                *         (| -_- |)         * 
               *       *  0\  =  /0  *       * 
               *       *__0/`---'\0__*       * 
               *     .'  \\|     |//  `.     * 
                *   /  \\|||  :  |||//  \   * 
                 * /  _||||| -:- |||||-  \ * 
                   |   | \\\  -  /// |   |
                   | \_|  ''\---/''  |   |
                   \  .-\__  `-`  ___/-. /
                 ___`. .'  /--.--\  `. . __
              ."" '<  `.___\_<|>_/___.'  >'"".
             | | :  `- \`.;`\ _ /`;.`/ - ` : | |
             \  \ `-.   \_ __\ /__ _/   .-` /  /
        ======`-.____`-.___\_____/___.-`____.-'======
                           `=---='
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                   佛祖保佑       永无BUG
                        author：Richie 
*/

#include<stdio.h>
#include<string.h>	
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#define LOCAL
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define ROF(i,a,b) for(int i=(a);i>=(b);i--)
#define max(p,q) ((p)>(q)?(p):(q))
#define min(p,q) ((p)<(q)?(p):(q)) 
#define ll long long
#define N 500001
#define mod 998244353

int cmp(const void *a,const void *b);
void print_array(int *a,int n);
void read_array(int *a,int n);
void init();
ll fast(ll x);
ll exgcd(ll a,ll b,ll *x,ll *y);
ll getInv(int a);
ll gcd(ll a,ll b);

int p[5005];
int c[5005]; 
int main(){
    int n,k;
    scanf("%d %d",&n,&k);
    ll ans=-10000000000;
    read_array(p,n);
    read_array(c,n); 
    
    FOR(i,1,n){
    	int next=p[i];
    	int l=1;
    	ll max=c[next];
    	ans=max(ans,max);
    	while(l<k&&next!=i){
    		next=p[next];
    		max+=c[next];
    		ans=max(ans,max);
    		l++;
		}
		if(l<k&&max>=0){
			max*=k/l;
	    	int t=k%l;
	    	while(t>0){
		        next=p[next];
		        max+=c[next];
		        ans=max(ans,max);       
		        t--;
			}
		}
	}
    printf("%lld\n",ans);
	return 0;
}



ll gcd(ll a,ll b){
	int t;
	while(b!=0){
		t=a%b;
		a=b;
		b=t;
	}
	return a;
}

ll fast(ll x){									//逆元 费马小定理/欧拉定理 适用范围：一般在mod是个素数的时候用
	int y=mod-2;
	ll res=1;
	while(y){
		if(y&1)res=res*x%mod;
		x=x*x%mod; 
		y>>=1;
	}
	return res;
}

ll exgcd(ll a,ll b,ll *x,ll *y)					//扩展欧几里得算法 
{
    if(b==0)
    {
        *x=1,*y=0;
        return a;
    }
    ll ret=exgcd(b,a%b,y,x);
    *y-=a/b*(*x);
    return ret;
}
ll getInv(int a)								//求a在mod下的逆元，不存在逆元返回-1 
{
    ll x,y;
    ll d=exgcd(a,mod,&x,&y);
    return d==1?(x%mod+mod)%mod:-1;
}

void init(void){
	#ifdef LOCAL
		freopen("P2678_2.in","r",stdin);
		freopen("data.txt","w",stdout);
	#endif
}

int cmp(const void *a,const void *b){
	return *(int*)a-*(int*)b;					//升序排列 
} 

void print_array(int *a,int n){
	FOR(i,1,n){
		if(i!=n)printf("%d ",a[i]);
		else printf("%d",a[i]);
	}
} 

void read_array(int *a,int n){
	FOR(i,1,n)scanf("%d",&a[i]);
}


