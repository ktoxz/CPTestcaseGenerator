#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
typedef long long ll;
#define rep(i,n) for(ll i=0; i<(ll)(n); i++)
#define max(l,r) ((l)>(r)?l:r)
#define min(l,r) ((l)<(r)?l:r)
#define swap(l,r) {ll tp=l;l=r;r=tp;}
const ll MOD = 1000000007;

ll scr[5050][5050];
int cnt[5050];
int main(){
    int n, k;
    scanf("%d%d", &n, &k);
    int p[5050];
    ll c[5050];
    rep(i, n) scanf("%d", &p[i]);
    rep(i, n) p[i]--;
    rep(i, n) scanf("%lld", &c[i]);
    rep(i, n+1) rep(j, n+1) scr[i][j] = -(MOD*MOD);
    
    rep(i, n){
        int idx = i;
        cnt[i] = 0;
        scr[idx][cnt[i]] = c[p[idx]];
        while(p[idx] != i) {
            idx = p[idx];
            cnt[i]++;
            scr[i][cnt[i]] = c[p[idx]];
            scr[i][cnt[i]] += scr[i][cnt[i]-1];
        }
    }
    ll ans = -(MOD*MOD);
    rep(i, n){
        if(cnt[i]+1 >= k){
            rep(j, k){
                ans = max(ans, scr[i][j]);
            }
        }else{
            if(scr[i][cnt[i]] <= 0){
                rep(j, cnt[i]+1){
                    ans = max(ans, scr[i][j]);
                }
            }else{
                ll tmp = scr[i][cnt[i]] * (k/(cnt[i]+1));
                ans = max(ans, tmp);
                int tmpk = k % (cnt[i]+1);
                rep(j, cnt[i]){
                    ans = max(ans, tmp - scr[i][cnt[i]] + scr[i][j]);
                }
                rep(j, tmpk){
                    ans = max(ans, tmp + scr[i][j]);
                }
            }
        }
    }

    printf("%lld\n", ans);
    /*rep(i,n){
        rep(j, cnt[i]+1){
            printf("%d ", scr[i][j]);
        }
        puts("");
    }*/
}