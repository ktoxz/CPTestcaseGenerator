#include <stdio.h>

int main(void) {

  long n,k,cur,move,first,loop,score,max,score_first,max_first,score_loop,set,ans;
  scanf("%ld %ld", &n, &k);
  long p[n+1],c[n+1],list[n+1];
  for (long i = 1; i <= n; i++) {
    scanf("%ld", &p[i]);
  }
  for (long i = 1; i <= n; i++) {
    scanf("%ld", &c[i]);
  }
  for (long start = 1; start <= n; start++) {
    for (long i = 1; i <= n; i++) {
      list[i] = -1;
    }
    list[start] = 0;
    cur = start;
    move = 0;
    while (1) {
      cur = p[cur];
      move++;
      if (list[cur] == -1 ) {
        list[cur] = move;
      } else {
        first = list[cur];
        break;
      }
    }
    loop = move-first;
    move = k;
    if (move <= first) {
      cur = start;
      score = 0;
      for (long i = 1; i <= move; i++) {
        cur = p[cur];
        score += c[cur];
        if (i == 1 || score > max) {
          max = score;
        }
      }
    } else {
      if (first == 0) {
        first = 1;
      }
      cur = start;
      score_first = 0;
      for (long i = 1; i <= first; i++) {
        cur = p[cur];
        score_first += c[cur];
        if (i == 1 || score_first > max_first) {
          max_first = score_first;
        }
      }
      score_loop = 0;
      for (long i = 1; i <= loop; i++) {
        cur = p[cur];
        score_loop += c[cur];
      }
      move -= first;
      if (score_loop > 0) {
        set = move/loop-1;
        if (set < 0) {
          set = 0;
        }
        move -= loop*set;
        score = score_first+score_loop*set;
        max = score;
        for (long i = 1; i <= move; i++) {
          cur = p[cur];
          score += c[cur];
          if (score > max) {
            max = score;
          }
        }
      } else {
        score = score_first;
        max = score;
        if (move > loop) {
          move = loop;
        }
        for (long i = 1; i <= move; i++) {
          cur = p[cur];
          score += c[cur];
          if (score > max) {
            max = score;
          }
        }
      }
      if (max_first > max) {
        max = max_first;
      }
    }
    if (start == 1 || max > ans) {
      ans = max;
    }
  }
  printf("%ld\n", ans);

  return 0;
}