#include <stdio.h>

int main(){
  int N,K;
  long long int P[10000],C[10000];
  long long int ans=-6000000000000000000LL;
  scanf("%d %d",&N,&K);
  for(int i=1;i<=N;i++)
    scanf("%lld",P+i);
  for(int i=1;i<=N;i++)
    scanf("%lld",C+i);

  for(int i=1;i<=N;i++){
    int next_i=P[i];
    int L=1;
    long long int S=C[next_i];
    if(S>ans) ans=S;
    while(L<K && next_i!=i){
      next_i=P[next_i];
      S+=C[next_i];
      if(S>ans) ans=S;
      L++;
    }
    if(S>=0LL && L<K){
      S*=(long long int)((K-L)/L);
      int T=K%L+L;
      while(T>0){
        next_i=P[next_i];
        S+=C[next_i];
        if(S>ans) ans=S;        
        T--;
      }
    }
  }
  printf("%lld\n",ans);
  return 0;
}
