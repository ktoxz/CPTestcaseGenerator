#ifndef DEBUG
#    pragma GCC optimize("O3,no-stack-protector")
#    pragma GCC optimize("unroll-loops")

#    if __cplusplus < 201703L
#        pragma GCC target("avx")
#    else
#        pragma GCC target("avx2")
#    endif

#endif

#define _USE_MATH_DEFINES
#include <bits/stdc++.h>
#define dump(x) cout << x << endl
typedef int64_t Int;
typedef long double Ld;

using namespace std;
using Graph = vector<vector<Int>>;

const Ld pi = M_PI;
const Int MOD = 1000000007;
const Int INF = 1LL << 62;

Int Floor(Int a, Int b) {
    return (a - (a % b)) / b;
}

Int ser(Int n, Int k, const vector<Int> &p, const vector<Int> &c, Int index) {
    Int cycle_size = 0;
    Int cycle_score = 0;

    Int i = index;
    Int ma = -INF;
    while (true) {
        cycle_size++;
        i = p[i];
        cycle_score += c[i];
        if (cycle_size <= k) {
            ma = max(ma, cycle_score);
        }
        if (i == index) {
            break;
        }
    }

    if (cycle_score <= 0) {
        return ma;
    } else {
        Int ret = (k / cycle_size - 1) * cycle_score;
        Int tem = ret;
        i = index;
        ma = -INF;
        Int ro = cycle_size + (k % cycle_size);
        for (Int j = 0; j < ro; j++) {
            i = p[i];
            tem += c[i];
            ret = max(ret, tem);
        }

        return ret;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    Int n, k;
    cin >> n >> k;
    vector<Int> p(n), c(n);
    for (Int i = 0; i < n; i++) {
        cin >> p[i];
        p[i]--;
    }
    for (Int i = 0; i < n; i++) {
        cin >> c[i];
    }

    Int ans = -INF;
    for (Int i = 0; i < n; i++) {
        ans = max(ans, ser(n, k, p, c, i));
    }

    cout << ans << endl;

    return 0;
}