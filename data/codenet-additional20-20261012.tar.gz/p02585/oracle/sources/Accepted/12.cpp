#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
int64_t MOD=1000000007;
const long long INF = 1LL<<60;

int main() {
  int64_t N,K,ans=-1*INF; cin>>N>>K;
  vector<int64_t> P(N);
  rep(i,N) cin>>P.at(i);
  rep(i,N) P.at(i)--;
  vector<int64_t> C(N);
  rep(i,N) cin>>C.at(i);

  rep(i,N){
    vector<bool> seen(N,true);
    vector<int64_t> S,T;
    int64_t k=i,sum=0;
    while(seen.at(k)){
      seen.at(k)=false;
      S.push_back(C.at(k));
      sum+=C.at(k);
      k=P.at(k);
    }
    int64_t t=S.size(),r=K/t,q=K%t,MAX=-1*INF,NMAX,MAX2=-1*INF;
    rep(i,t){
      T.push_back(S.at(i));
      if(i>0) T.at(i)+=T.at(i-1);
      if(T.at(i)>MAX){
        MAX=T.at(i);
        NMAX=i+1;
      }
    }
    if(q==0) ans=max(ans,MAX+sum*(r-1));
    else{
      if(q<NMAX){
        rep(i,q) MAX2=max(MAX2,T.at(i));
        if(sum<0) ans=max(ans,MAX);
        else{
          auto temp=max(MAX+sum*(r-1),MAX2+sum*r);
          ans=max(ans,temp);
        }
      }
      else{
        if(sum<0) ans=max(ans,MAX);
        else ans=max(ans,MAX+sum*r);
      }
    }
  }
  cout<<ans;
}