N=int(input())
List='abcdefghijklmnopqrstuvdxyz'

Ans=''

while N>=1:
    Amari=N%26
    
    if Amari==0:
        Ans='z'+Ans
    else:
        Ans=List[Amari-1]+Ans
        
    N=(N-1)//26
    
print(Ans)