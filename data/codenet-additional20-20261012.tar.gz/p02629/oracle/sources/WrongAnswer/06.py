def to_i(n, i):
    if (int(n/i)):
        return to_i(int(n/i), i)+chr(n%i+96)
    return chr(n%i+96)


n = int(input())
print(to_i(n, 26))