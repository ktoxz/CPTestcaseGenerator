import sys
n = int(input())
m = n

alphabet = [chr(i) for i in range(97, 97+26)]

keta = 0
while True:
    if n < 26**(keta):
        break
    keta += 1
ans = ''

for i in range(keta-1, -1, -1):
    have = m // (26 ** i)
    ans += alphabet[have-1]
    m -= 26 ** i * have
    
print(ans)


