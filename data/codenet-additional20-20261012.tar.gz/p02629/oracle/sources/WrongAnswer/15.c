    #include <stdio.h>
    #include <math.h>
    
    void f(long long int n)
    {
        if (n <= 26)
        {
    
                n = n % 26;
        if (!n)
        n = 26;
            printf("%c", 'a' + n);
            return;
        }
        f (n / 26);
        n = n % 26;
        if (!n)
        n = 26;
        printf("%c", 'a' + n);
    }
    
    
    int main(void){
        long long int i, n, x, y, a, b, tmp;
        scanf("%lld", &n);

        a = 1;
        while (1){
        if (pow(26, a) < n)
            n-=pow(26,a);
        else
            break;
            a++;
        }
                if (n == 1)
        {
            for (i = 0; i < a; i++)
            printf("a");
            return (0);
        }
        f(n - 1); 
    }
