#include<bits/stdc++.h>
using namespace std;
int const nax = 3e5 + 10;
long long lim = 1e18 + 7;
long long p[nax];

int main () {
    long long n;

    cin >> n;

    long long cur = 0;
    int step = 0;

    while (true) {
        long long bef = cur;
        ++ step;
        if (cur > lim / 26) {-- step; break;}
        cur *= 26;
        cur += 26;
        if (cur >= n) {
            cur = bef;
            -- step;
            break;
        }
    }
    //printf("step = %d", step);

    for (int j = step ; j >= 0 ; -- j) {
        long long my_pow = 1;
        for (int i = 1 ; i <= j ; ++ i) my_pow *= 26LL;
     //   printf("%d %lld", j, my_pow);
        int to_add = min(26LL, n / my_pow);
        printf("%c", 'a' + to_add - 1);
        n -= my_pow * (to_add);
    }



}
