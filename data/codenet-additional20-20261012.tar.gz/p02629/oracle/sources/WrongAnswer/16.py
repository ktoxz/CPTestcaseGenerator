n = int(input())
l = []

div = n
while div != 0:
    l.append(div % 26)
    div = div // 26

print("".join(map(lambda x: chr(x+64), reversed(l))).lower())