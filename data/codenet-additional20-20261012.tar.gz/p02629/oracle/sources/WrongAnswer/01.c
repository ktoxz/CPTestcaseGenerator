    #include<stdio.h>
    #include<string.h>
    int main()
    {
       long long int n;
       scanf("%lld",&n);
       long long int j=0,r;
       char ch[12];
       while(n!=0){
        r=(n%26);
        if(r==0){
            ch[j]='z';
            j++;
        }
        else{
        ch[j]='a'+(r-1);
        j++;
        }
        n=n/26;
       }
       ch[j]='\0';
    for(int i=j-1;i>=0;i--){
        printf("%c",ch[i]);
    }
        return 0;
    }
