#include <stdio.h>
#include <string.h>

char *inttoaa(char *s, int n)
{
char *p = s, *q = s;

while(n > 0){
const char *const aa = "zabcdefghijklmnopqrstuvwxy";
int r = n % 26;

n = n / 26 - !r;
*p ++ = aa[r];
}
*p = '\0';
while(p > q){
char c = * -- p;

*p = *q;
*q ++ = c;
}
return s;
}

int main(void)
{
char s[20];
int i;

scanf("%d", &i);
inttoaa(s, i);
printf("%s \n", s);
return 0;
}