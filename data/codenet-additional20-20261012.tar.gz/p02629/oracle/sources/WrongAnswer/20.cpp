#include<bits/stdc++.h>
//#define int long long int
#define ld long double
#define getFaster ios_base::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL)
#define rep(i,init,n) for(int i=init;i<n;i++)
#define rev(i,n,init) for(int i=n;i>=init;i--)
#define MAXN 200005
#define MOD2 998244353
#define MOD1 1e9+7
#define f first
#define s second
#define endl '\n'
#define pii pair<int,int>
#define piii pair<pii,int>
#define precise(i) cout<<fixed<<setprecision(i)
#define codejam cout<<"Case #"<<ii+1<<": ";
#define impossible cout<<"IMPOSSIBLE"<<endl;
#define error(s) throw runtime_error(s)
#define data data1
// std::mt19937_64 rng(std::chrono::steady_clock::now().time_since_epoch().count());
// int myRand(int R) {
// 	int val=rng() % R;
//       assert(val>=0);
//       return val;
// }
using namespace std;
const long double PI = atan(1.0)*4;
const int64_t INF=3e18;
const int32_t LOG=21;
const int MOD=MOD1;

int pow26[100];
int32_t main()
{ 
      getFaster;
      int tests=1;
      //cin>>tests;
      rep(ii,0,tests)
      { 
           int n;
           cin>>n; 
           int len=1;
           int cur=26;
           pow26[0]=1;
           pow26[1]=26;
           while(cur<n)
           {
                 n-=cur;
                 cur*=26;
                 len++;
                 pow26[len]=cur;
           }

           string ans="";
           rep(i,1,len+1)
           {
                rep(j,0,26)
                {
                      if(pow26[len-i]<n)
                      {
                            n-=pow26[len-i];
                      }
                      else
                      {
                            ans+=(char)(j+'a');
                            break;
                      }
                }
           }
           cout<<ans<<endl;
      }      
      return 0;                         
}

/*
 TIPS:
 1.) Check for corner cases (like 0 is exception case)
 2.) Check for global memory sizes,memory refreshments and its complexity 
 3.) Check for sorting criteria (if used 1-based indexing)
 4.) Check for numbers overflow (while multiplying and doing MOD)
 5.) Check for typecasting issues like int to float( while dividing numbers)
*/