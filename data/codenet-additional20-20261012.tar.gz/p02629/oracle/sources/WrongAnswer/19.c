#include<stdio.h>
int main(){
  long long n,i,r=0,s[100010];
  scanf("%lld",&n);
  for(i=0;n;i++){
    s[r++]=n%26;
    n/=26;
  }
  while(r--)printf("%c",(char)(s[r]+'a'-1));
  printf("\n");
  return 0;
}
