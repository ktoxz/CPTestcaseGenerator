sus = int(input())
cuc,fef = 'abcdefghijklmnopqrstuvwxyz',''
while sus:
  fef += cuc[sus%26-1]; sus//=26
print(fef[::-1])