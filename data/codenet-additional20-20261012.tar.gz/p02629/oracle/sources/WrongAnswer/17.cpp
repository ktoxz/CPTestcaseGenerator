#include<bits/stdc++.h>
#define for_int(i,a,b) for(int i=(a);i<=(b);++i)
#define rep_int(i,a,b) for(int i=(a);i>=(b);--i)
#define for_ll(i,a,b) for(ll i=(a);i<=(b);++i)
#define rep_ll(i,a,b) for(ll i=(a);i>=(b);--i)
#define ull unsigned long long
#define ll long long
#define db double
#define HPMAX 1005
#define KMP_MAX 1005
#define prime_MAX 1e6+5
#define quick_pow_mod 1e9+7
#define PII pair<int,int>
using namespace std;
//快读
ll read() {
	char c = getchar();
	ll x = 0, f = 1;
	for (; !isdigit(c); c = getchar())
		if (c == '-')
			f = -1;
	for (; isdigit(c); c = getchar())
		x = x * 10 + c - 48;
	return x * f;
}
ll n;
ll power(ll x, ll n) {
	ll ans = 1;
	for (ll i = 1; i <= n; ++i)
		ans *= x;
	return ans;
}
int main() {
	n = read();
	ll cnt = 1, sum = 26;
	while (sum < n) sum *= 26, cnt++;
	string s;
	for (ll i = 1; i <= cnt; ++i)
		s += 'a';
	sum /= 26;
	for (ll i = 0; i < s.size(); ++i) {
		for (ll j = 1; j <= 26; ++j) {
			sum *= j;
			if (sum > n) { sum /= j; cnt = j - 1;  break; }
			else if (sum == n) { sum /= j; cnt = j; break; }
			sum /= j;
		}
		s[i] = s[i] + cnt - 1;
		n -=cnt*sum; 
		sum /= 26;
		if (!sum||n==0) break;
	}
	cout << s << endl;
	return 0;
}