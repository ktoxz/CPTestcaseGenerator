#include <stdio.h>

void con(long int a,long int x){
    long int s;
    long int q;

    s = a/x;
    q = a%x;

    printf("%c",'a'+s);

    if(x != 1)
        con(q,x/26);
}

void ans(long int a,long int x){

    if(a > x)
        ans(a-x,x*26);
    else {
        con(a-1,x/26);
    }
}

int main(){

    long int n;

    scanf("%ld",&n);

    ans(n,26);

    printf("\n");


    return 0;
}