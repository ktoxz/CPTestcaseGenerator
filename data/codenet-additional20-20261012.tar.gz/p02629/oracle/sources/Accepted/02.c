#include<stdio.h>
 
int main(void) {
  char name[12];
  unsigned long long id;
  scanf("%llu", &id);
  int i;
  int tmp;
  int len=0;
  for(i=0; id > 0; i++) {
    tmp = id % 26;
    if(tmp == 0) {
      name[i] = 'z';
    }
    else {
      name[i] = (char)(tmp - 1 + 'a');
    }
    id = id / 26;
    len++;
    if(tmp == 0) {
      id--;
    }
  }
  for(i=len-1; i >= 0; i--) {
    printf("%c", name[i]);
  }
  printf("\n");
  return 0;
}