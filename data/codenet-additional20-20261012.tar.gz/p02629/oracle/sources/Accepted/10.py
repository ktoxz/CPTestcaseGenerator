n = int(input())

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
            'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
ans = ''


if n <= 26**1:
    # a-z
    for cnt in range(26):
        if n-1 == cnt:
            ans += alphabet[cnt]
elif 26**1 < n <= 26**2 + 26**1:
    # aa-zz
    for cnt in range(26):
        if 26*(cnt+1) < n <= 26*(cnt+2):
            ans += alphabet[cnt]
            n -= 26*(cnt+1)
    for cnt in range(26):
        if n-1 == cnt:
            ans += alphabet[cnt]
elif 26**2 + 26**1 < n <= 26**3 + 26**2 + 26**1:
    # aaa-zzz
    for cnt in range(26):
        if (26**2)*(cnt+1) < n <= (26**2)*(cnt+2)+26:
            ans += alphabet[cnt]
            n -= (26**2)*(cnt+1)
    for cnt in range(26):
        if 26*(cnt+1) < n <= 26*(cnt+2):
            ans += alphabet[cnt]
            n -= 26*(cnt+1)
    for cnt in range(26):
        if n-1 == cnt:
            ans += alphabet[cnt]
elif 26**3 + 26**2 + 26**1 < n <= 26**4 + 26**3 + 26**2 + 26**1:
    # aaaa-zzzz
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaa-zzzzz
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaa-zzzzzz
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaa-zzzzzzz
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaaaa-zzzzzzzz
    for cnt in range(26):
        if (26 ** 7) * (cnt + 1) < n <= (26 ** 7) * (cnt + 2) + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 7) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaaaaa-zzzzzzzzz
    for cnt in range(26):
        if (26 ** 8) * (cnt + 1) < n <= (26 ** 8) * (cnt + 2) + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 8) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 7) * (cnt + 1) < n <= (26 ** 7) * (cnt + 2) + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 7) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaaaaaa-zzzzzzzzzz
    for cnt in range(26):
        if (26 ** 9) * (cnt + 1) < n <= (26 ** 9) * (cnt + 2) + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 9) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 8) * (cnt + 1) < n <= (26 ** 8) * (cnt + 2) + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 8) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 7) * (cnt + 1) < n <= (26 ** 7) * (cnt + 2) + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 7) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**11 + 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaaaaaaa-zzzzzzzzzzz
    for cnt in range(26):
        if (26 ** 10) * (cnt + 1) < n <= (26 ** 10) * (cnt + 2) + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 10) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 9) * (cnt + 1) < n <= (26 ** 9) * (cnt + 2) + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 9) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 8) * (cnt + 1) < n <= (26 ** 8) * (cnt + 2) + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 8) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 7) * (cnt + 1) < n <= (26 ** 7) * (cnt + 2) + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 7) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]
elif 26**11 + 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1 < n <= 26**12 + 26**11 + 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26**1:
    # aaaaaaaaaaaaa-zzzzzzzzzzzz
    for cnt in range(26):
        if (26 ** 11) * (cnt + 1) < n <= (26 ** 11) * (cnt + 2) + 26**10 + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 11) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 10) * (cnt + 1) < n <= (26 ** 10) * (cnt + 2) + 26**9 + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 10) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 9) * (cnt + 1) < n <= (26 ** 9) * (cnt + 2) + 26**8 + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 9) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 8) * (cnt + 1) < n <= (26 ** 8) * (cnt + 2) + 26**7 + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 8) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 7) * (cnt + 1) < n <= (26 ** 7) * (cnt + 2) + 26**6 + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 7) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 6) * (cnt + 1) < n <= (26 ** 6) * (cnt + 2) + 26**5 + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 6) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 5) * (cnt + 1) < n <= (26 ** 5) * (cnt + 2) + 26**4 + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 5) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 4) * (cnt + 1) < n <= (26 ** 4) * (cnt + 2) + 26**3 + 26**2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 4) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 3) * (cnt + 1) < n <= (26 ** 3) * (cnt + 2) + 26 ** 2 + 26:
            ans += alphabet[cnt]
            n -= (26 ** 3) * (cnt + 1)
    for cnt in range(26):
        if (26 ** 2) * (cnt + 1) < n <= (26 ** 2) * (cnt + 2) + 26:
            ans += alphabet[cnt]
            n -= (26 ** 2) * (cnt + 1)
    for cnt in range(26):
        if 26 * (cnt + 1) < n <= 26 * (cnt + 2):
            ans += alphabet[cnt]
            n -= 26 * (cnt + 1)
    for cnt in range(26):
        if n - 1 == cnt:
            ans += alphabet[cnt]

print(ans)
