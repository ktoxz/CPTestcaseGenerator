#include<bits/stdc++.h>
using namespace std;
int main()
{
  long long int n;
  scanf("%lld", &n);
  string s="zabcdefghijklmnopqrstuvwxy",res="";
  while(n>26)
  {
    res=s[n%26]+res;
    if(n%26==0)
    n=n/26-1;
    else
    n=n/26;
  }
  res=s[n%26]+res;
  printf("%s", res.c_str());
}