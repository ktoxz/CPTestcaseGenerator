#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
using uint = unsigned int;
using ull = unsigned long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;

/* [💭] [💡] [🎈] */

using namespace std;

int main() {
    cin.tie(nullptr);
    cout.tie(nullptr);
    ios_base::sync_with_stdio(false);

    ll c;
    cin >> c;
    string str;
    while (c > 0) {
        ll rem = c % 26;
        if (rem == 0) {
            str += 'z';
            c = (c / 26) - 1;
        } else {
            str += (char) ((rem - 1) + 'a');
            c = c / 26;
        }
    }
    reverse(str.begin(), str.end());
    cout << str;

    return 0;
}