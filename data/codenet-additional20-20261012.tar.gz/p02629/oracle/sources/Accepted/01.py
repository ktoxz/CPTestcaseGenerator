
def resolve():
    lower = "abcdefghijklmnopqrstuvwxyz"
    N = int(input())

    ans = ""
    while N:
        N -= 1
        idx = N%26
        ans += lower[idx]
        N //= 26
    print(ans[::-1])

if __name__ == "__main__":
    resolve()
