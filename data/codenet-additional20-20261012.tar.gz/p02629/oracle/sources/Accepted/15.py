N = int(input())
Min = 1
Max = 26
Count = 0
Flag = True
while Flag:
    Count += 1
    if Min<=N<=Max:
        Disp = ['']*Count
        Flag = False
        Num = N-Min
        for T in range(1,Count+1):
            Disp[-T] = chr(97+Num%26)
            Num = Num//26
    else:
        Min = Max+1
        Max += pow(26,Count+1)
print(''.join(Disp))