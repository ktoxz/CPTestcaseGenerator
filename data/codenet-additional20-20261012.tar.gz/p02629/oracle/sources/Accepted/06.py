'''
.append(要素) リストに要素を追加
.extend(リスト) リストを連結する
.insert(場所,要素) 指定した場所に要素追加
del 配列名[場所]
-1で末尾で末尾から一つ前
sort()
sorted(reverse=true)
配列の初期化
配列名=[a]*n+[b]*m
Decimal()
'''

from sys import stdin
from itertools import accumulate, dropwhile, takewhile, groupby
import bisect
import copy
import math
from functools import reduce
from operator import mul
from collections import Counter
import itertools
import fractions
import sys


def tes(n):
    return int((26**(n+1)-1)/(26-1))


n = int(stdin.readline().rstrip())
b = n
data1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
         'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
data2 = []
for el in range(1, 16):
    data2.append('a'*el)
d = []
pos = 0
for el in range(12):
    d.append(tes(el))
for el in range(len(d)):
    if n < d[el]:
        pos = el-1
        break
num = d[pos]
diff = n-num
de = []
counter = 16
while True:
    de.append(diff % 26)
    diff = int(diff/26)
    counter -= 1
    if counter == 0:
        break
stri = data2[pos]
res = ''
count = 0
for el in stri:
    res += data1[de[count]]
    count += 1
print(''.join(list(reversed(res))))
