#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <tuple>
#include <cassert>

using namespace std;

#define all(c) (c).begin(), (c).end()
#define iter(c) __typeof((c).begin())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb(e) push_back(e)
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define rep(i,n)   FOR(i,0,n)
#define mp(a,b) make_pair((a), (b))
#define mt(a,b,c) make_tuple((a),(b),(c))

typedef long long ll;

int main(){
    long long n; cin >> n;
    long long pw = 1;
    long long ima = 0;
    long long c = 1;

    while(1){
        if(ima + pw * 26 >= n) break;
        c++;
        pw = pw * 26;
        ima = ima + pw;
    }
  //  cout << c << endl;
  //  cout << pw << endl;
   // cout << n - ima << endl;
    ll ppw = 1; rep(i,c-1) ppw *= 26;
    n = n - ima - 1;
  // cout << ppw << endl;
    string s;
    rep(i,c){
        long long ch = n / ppw;
        n = n % ppw;
        s += ((char)ch) + 'a';
        ppw = ppw / 26;
    }
    cout << s << endl;
    return 0;
}