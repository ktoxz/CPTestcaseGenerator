#include<bits/stdc++.h>
using namespace std;
typedef int64_t ll;
typedef long double ld;
const ll MOD=1000000007;
#define rep(i,n) for(ll i=0;i<(ll)(n);i++)
long long gcd(long long a,long long b){
    ll gcdmax=max(a,b);
    ll gcdmin=min(a,b);
    while(true){
        if(gcdmax%gcdmin==0)break;
        else gcdmax%=gcdmin;
        swap(gcdmin,gcdmax);
    }
    return gcdmin;
}
ll powerup(ll N,ll P,ll M){
    if(P==0)return 1;
    else if(P%2==0){
        ll t=powerup(N,P/2,M);
        return t*t%M;
    }
    else return N*powerup(N,P-1,M)%M;
}
vector<ll> find_divisor(ll N){
  ll k=1;
  while(k*k<=N){
    k++;
  }
  vector<ll> A(1);
  rep(i,k){
    if(i==1)A.at(0)=1;
    else if(i>=2){
      if(N%i==0)A.push_back(i);
    }
  }
  ll t=0;
  t=A.size();
  rep(i,t){
    if(A.at(t-i-1)*A.at(t-i-1)!=N)A.push_back(N/A.at(t-1-i));
  }
  return A;
}
int main()
{
  ll N;
  cin>>N;
  ll red=0;
  ll green=0;
  ll blue=0;
  string S;
  cin>>S;
  rep(i,N){
    if(S[i]=='R')red++;
    else if(S[i]=='B')blue++;
    else green++;
  }
  ll ans=red*green*blue;
  rep(i,N-2){
    rep(j,N){
      if(i+2*j+3<=N){
        if(S[i]!=S[i+j+1]&&S[i]!=S[i+2*j+2]){
          if(S[i+j+1]!=S[i+2*j+2])ans--;
        }
      }
    }
  }
  cout<<ans<<endl;
}
