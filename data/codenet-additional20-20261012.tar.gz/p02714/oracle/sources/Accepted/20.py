N = int(input())
S = input()
r = 0
g = 0
b = 0

for c in S:
    if c == 'R':
        r += 1
    elif c == 'G':
        g += 1
    else:
        b += 1

ans = r * g * b

cnt = 0
for d in range(1, (N - 3) // 2 + 1 + 1):
    i = 0
    while i + 2 * d < N:
        if not (S[i] == S[i + d]) and  not (S[i + d] == S[i + 2*d]  ) and not (S[i + 2 * d] == S[i]):
            cnt += 1
        i += 1

ans -= cnt

print(ans)
