#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdint.h>
#include<stdbool.h>
#include<tgmath.h>
#include<sys/queue.h>
#include<time.h>
#define ll long long
#define min(a, b) ((a) > (b) ? (b) : (a))
#define max(a, b) ((a) > (b) ? (a) : (b))
#define miin(a, b, c) min((a), min((b), (c)))
#define maax(a, b, c) max((a), max((b), (c)))
#define mod 1000000007

int n, t[4444][4] = {};
char s[4444];

main(){
    scanf("%d", &n);
    scanf("%s", s);
    for(int i=n-1; i>=0; i--){
        for(int j=0;j<3;j++)t[i][j] = t[i+1][j];
        t[i][s[i]=='R'?0:s[i]=='G'?1:2]++;
    }
    ll nyan = 0;
    for(int i=0; i<n; i++){
        for(int j = i+1; j<n; j++){
            if(s[i] != s[j]){
                //r,g
                if(s[i]+s[j] == 'R'+'G'){
                    nyan += t[j+1][2] - ((2*j-i)<n && s[2*j-i]=='B');
                }
                //g,b
                if(s[i]+s[j] == 'G'+'B'){
                    nyan += t[j+1][0] - ((2*j-i)<n && s[2*j-i]=='R');
                }
                //b,r
                if(s[i]+s[j] == 'B'+'R'){
                    nyan += t[j+1][1] - ((2*j-i)<n && s[2*j-i]=='G');
                }
            }
        }
    }
    printf("%lld\n", nyan);
}