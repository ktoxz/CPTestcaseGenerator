#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
int a[200000];
ll boom[3];
int main()
{
    ios::sync_with_stdio(false);
    ll n;
    cin>>n;
    string s;
    cin>>s;
    for(int i=0; i<n; i++)
        if(s[i]=='R') boom[0]++;
        else if(s[i]=='G') boom[1]++;
        else boom[2]++;
    ll sum=boom[0]*boom[1]*boom[2];
    for(int i=0; i<n; i++)
        for(int j=1; j<n; j++)
        {
            if(i+2*j>=n) break;
            if(s[i]!=s[i+j]&&s[i]!=s[i+2*j]&&s[i+j]!=s[i+2*j])
                sum--;
        }
    if(sum<0) sum=0;
    cout<<sum<<endl;
}

