num = int(input())
s = list(input())

red_index = [i for i in range(1,len(s)+1) if s[i-1] == 'R']
gre_index = [i for i in range(1,len(s)+1) if s[i-1] == 'G']
blu_index = [i for i in range(1,len(s)+1) if s[i-1] == 'B']
ans = len(red_index) * len(gre_index) * len(blu_index)

delete = 0
for i in range(1,(num // 2) + 1):
  for st in range(num):
    if st+2*i <= num -1:
      check = [s[st], s[st + i], s[st + 2*i]]
      if len(set(check)) == 3:
        delete += 1
print(ans-delete)