#include <limits>
#include <initializer_list>
#include <utility>
#include <bitset>
#include <tuple>
#include <type_traits>
#include <functional>
#include <string>
#include <array>
#include <deque>
#include <list>
#include <queue>
#include <stack>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <iterator>
#include <algorithm>
#include <complex>
#include <random>
#include <numeric>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <regex>
#include <cassert>
#include <cstddef>
#define endl codeforces
#define ALL(v) std::begin(v), std::end(v)
#define ALLR(v) std::rbegin(v), std::rend(v)
using ll = std::int64_t;
using ull = std::uint64_t;
using pii = std::pair<int, int>;
using tii = std::tuple<int, int, int>;
using pll = std::pair<ll, ll>;
using tll = std::tuple<ll, ll, ll>;
template <typename T> using vec = std::vector<T>;
template <typename T> using vvec = vec<vec<T>>;
template <typename T> const T& var_min(const T &t) { return t; }
template <typename T> const T& var_max(const T &t) { return t; }
template <typename T, typename... Tail> const T& var_min(const T &t, const Tail&... tail) { return std::min(t, var_min(tail...)); }
template <typename T, typename... Tail> const T& var_max(const T &t, const Tail&... tail) { return std::max(t, var_max(tail...)); }
template <typename T, typename... Tail> void chmin(T &t, const Tail&... tail) { t = var_min(t, tail...); }
template <typename T, typename... Tail> void chmax(T &t, const Tail&... tail) { t = var_max(t, tail...); }
template <typename T> const T& clamp(const T &t, const T &low, const T &high) { return std::max(low, std::min(high, t)); }
template <typename T> void chclamp(T &t, const T &low, const T &high) { return t = clamp(t, low, high); }
template <typename T> T make_v(T init) { return init; }
template <typename T, typename... Tail> auto make_v(T init, std::size_t s, Tail... tail) { auto v = std::move(make_v(init, tail...)); return vec<decltype(v)>(s, v); }
template <typename T, std::size_t Head, std::size_t ...Tail> struct multi_dem_array { using type = std::array<typename multi_dem_array<T, Tail...>::type, Head>; };
template <typename T, std::size_t Head> struct multi_dem_array<T, Head> { using type = std::array<T, Head>; };
template <typename T, std::size_t ...Args> using mdarray = typename multi_dem_array<T, Args...>::type;
namespace init__ { struct InitIO { InitIO() { std::cin.tie(nullptr); std::ios_base::sync_with_stdio(false); std::cout << std::fixed << std::setprecision(30); } } init_io; }

std::array<ll, 4010> arr[4];

int main() {
    ll n;
    std::string s;
    std::cin >> n >> s;
    char carr[3] = { 'R', 'G', 'B', };
    ll ans = 0;
    for (ll i = 0; i < n; i++) {
        char ca[2];
        {
            char c = s[i];
            ll idx = 0;
            for (ll i = 0; i < 3; i++) if (carr[i] != c) ca[idx++] = carr[i];
        }

        auto get_idx = [&](char c) {
            for (ll i = 0;; i++) if (ca[i] == c) return i;
        };
        for (auto &&a : arr) std::fill(ALL(a), 0);
        for (ll j = 0; j < n; j++) {
            if (s[i] == s[j]) continue;
            ll offset = (j < i ? 0 : 2);
            arr[get_idx(s[j]) + offset][std::abs(i - j)]++;
        }

        ll sum[4] = {};
        for (ll j = 0; j < n; j++) {
            ans -= arr[0][j] * arr[3][j];
            ans -= arr[1][j] * arr[2][j];
            for (ll k = 0; k < 4; k++) sum[k] += arr[k][j];
        }
        ans += sum[0] * sum[3] + sum[1] * sum[2];
    }
    std::cout << ans << '\n';
    return 0;
}
