#include <stdio.h>
#include <string.h>
#define maxn 4010
#define LL long long
LL sum;
char s[maxn];
int r[maxn],g[maxn],b[maxn],n;
void count(char a,char b,char c,int *p){//abc
	int i,j,k;
	for(i=1;i<=n;i++)
		for(k=i+1;k<=n;k++)
			if(s[i]==a&&s[k]==c){
				if((i+k)%2==0){
					j=(i+k)/2;
					if(s[j]==b)sum+=p[k-1]-p[i]-1;
					else sum+=p[k-1]-p[i];
				}else sum+=p[k-1]-p[i];
			}
}
int main(){
	int i;
	scanf("%d%s",&n,s+1);
	for(i=1;i<=n;i++){
		r[i]=r[i-1],g[i]=g[i-1],b[i]=b[i-1];
		if(s[i]=='R')r[i]+=1;
		else if(s[i]=='G')g[i]+=1;
		else if(s[i]=='B')b[i]+=1;
	}
	count('R','G','B',g);
	count('B','G','R',g);
	count('R','B','G',b);
	count('G','B','R',b);
	count('B','R','G',r);
	count('G','R','B',r);
	printf("%lld\n",sum);
	return 0;
}