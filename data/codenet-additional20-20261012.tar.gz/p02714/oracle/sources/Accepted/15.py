n=int(input())
s=input()
p=s.count('R')*s.count('G')*s.count('B')
for j in range(1,n-1):
    for i in range(1,min(j,n-j-1)+1):
        x,y,z=s[j-i],s[j],s[j+i]
        if x!=y and y!=z and z!=x:
            p-=1
print(p)