n = int(input())
s = input()
if n <= 2:
  print(0)
  quit()
r,g,b = 0,0,0
for i in range(n):
  r += 1*(s[i]=="R")
  g += 1*(s[i]=="G")
  b += 1*(s[i]=="B")
ans = r*g*b

for i in range(n-2):
  for j in range(i+1,n):
    l = [i,j,2*j-i]
    if l[2] >= n:
      break
    r,g,b = 0,0,0
    for k in l:
      r += 1*(s[k]=="R")
      g += 1*(s[k]=="G")
      b += 1*(s[k]=="B")
    if r*g*b == 1:
      ans -= 1
print(ans)