from collections import Counter
import copy
from itertools import combinations


def A(x):
  return 1000 - x % 1000 if x % 1000 != 0 else 0


def B(n, ss):
  keys_values = Counter(ss)
  orders = ['AC', 'WA', 'TLE', 'RE']
  for order in orders:
    if order in keys_values:
      print("{} x {}".format(order, keys_values[order]))
    else:
      print("{} x {}".format(order, 0))


def _get_num_black(c_list, r_list, h, w, g):
  num_black = 0
  for i in range(h):
    if i in r_list:
      continue
    for j in range(w):
      if j in c_list:
        continue
      num_black += (1 if g[i][j] == '#' else 0)
  return num_black


def C(h, w, k, g):
  num_choice = 0
  for i in range(k + 1):
    for j in range(k - i + 1):
      for c_list in list(combinations(range(w), j)):
        for r_list in list(combinations(range(h), i)):
          if _get_num_black(c_list, r_list, h, w, g) == k:
            num_choice += 1
  return num_choice


def C2(H, W, K, g):
  """All copied."""
  c = []
  for i in range(H):
    c.append([])
    for j in range(W):
      c[i].append(g[i][j])

  ans = 0
  for h in range(H + 1):
    for w in range(W + 1):
      for h2 in combinations(list(range(H)), h):
        for w2 in combinations(list(range(W)), w):
          paint = copy.deepcopy(c)
          for h3 in h2:
            for i in range(W):
              paint[h3][i] = "r"
          for i in range(H):
            for w3 in w2:
              paint[i][w3] = "r"
          count_black = 0
          for i in range(H):
            count_black += paint[i].count("#")
            #print(count_black,paint[i])
          if count_black == K:
            ans += 1

  return ans


def C3(h, w, k, g):
  """
  - Change the calculation of count_black.
  - Change the name of variables.
  - Change the expression of combinations.
  """
  num_choice = 0
  for i in range(h + 1):
    for j in range(w + 1):
      for c_list in list(combinations(range(w), j)):
        for r_list in list(combinations(range(h), i)):
          if _get_num_black(c_list, r_list, h, w, g) == k:
            num_choice += 1
  return num_choice


def main():
  h, w, k = map(int, input().split())
  g = []
  for i in range(h):
    g.append(input())
  print(C3(h, w, k, g))


if __name__ == '__main__':
  main()
