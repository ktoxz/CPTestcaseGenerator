import copy
import itertools
from itertools import product

def main():
    # productを使ってパターンを列挙して考える方法
    H, W, K = map(int, input().split())
    # あとで足し算で計算するので#は1にそれ以外は0へ
    C = [[1 if v == '#' else 0 for v in input()] for _ in range(H)]
    ans = 0
    # 塗り直すか塗り直さないかの01のパターンを出す
    HC = list(product([0,1], repeat=H))
    WC = list(product([0,1], repeat=W))
    # 選んだところは0に塗り直す
    c = copy.deepcopy(C)
    for hc in HC:
        for wc in WC:
            cnt = 0
            for hi, h in enumerate(hc):
                if h == 1:
                    for w in range(W):
                        c[hi][w] = 0
            for wi, w in enumerate(wc):
                if w == 1:
                    for h in range(H):
                        c[h][wi] = 0
            # flatten
            cnt = sum(list(itertools.chain.from_iterable(c)))
            if cnt == K:
                ans += 1
            c = copy.deepcopy(C)
    print(ans)

if __name__ == '__main__':
    main()
