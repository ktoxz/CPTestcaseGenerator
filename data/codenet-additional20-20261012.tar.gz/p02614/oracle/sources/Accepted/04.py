import itertools
h, w, k = map(int, input().split())
s = []

total = 0
hcnt = [0 for i in range(h)]
wcnt = [0 for i in range(w)]
for i in range(h):
  c = input()
  hcnt[i] = c.count('#')
  total += c.count('#')
  s.append(c)

for i in range(w):
  cnt = 0
  for j in range(h):
    if s[j][i] == '#':
      cnt += 1
  wcnt[i] = cnt

ans = 0
for i in itertools.product([0,1], repeat=h):
  for j in itertools.product([0,1], repeat=w):
    cnt = 0
    for a in range(h):
      for b in range(w):
        if i[a] == 1 and j[b] == 1:
          if s[a][b] == '#':
            cnt += 1
    if cnt == k:
      ans += 1
print (ans)
