#include <bits/stdc++.h>                                           
 
#define int long long
//#pragma GCC optimize("Ofast")
//#pragma comment(linker, "/stack:200000000")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4")
 
 
#define file(s) freopen(s".in","r",stdin); freopen(s".out","w",stdout);
#define forev(i, b, a) for(int i = (b); i >= (a); --i)
#define forn(i, a, b) for(int i = (a); i <= (b); ++i)
#define all(x) x.begin(), x.end()
#define sz(s) (int)s.size()
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define s second
#define f first
 
 
using namespace std;
 
 
typedef pair < long long, long long > pll;    
typedef pair < int, int > pii;
typedef unsigned long long ull;         
typedef vector < pii > vpii;
typedef vector < int > vi;
typedef long double ldb;  
typedef long long ll;  
typedef double db;                             
 
 
const int inf = 1e9, maxn = 4e5 + 148, mod = 998244353, N = 11;
const int dx[] = {1, -1, 0, 0}, dy[] = {0, 0, 1, -1}, block = 555;
const pii base = mp(1171, 3307), Mod = mp(1e9 + 7, 1e9 + 9);
const db eps = 1e-12, pi = 3.14159265359;
const ll INF = 1e18;

int h, w, k, a[N][N], ans;
bool badx[N], bady[N];
char c;

main () {
	cin >> h >> w >> k;
	for (int i = 1; i <= h; ++i)
		for (int j = 1; j <= w; ++j) {
			cin >> c;
			a[i][j] = c == '#';
		}


	vi v;
	for (int i = 1; i <= h + w; ++i)
		v.pb(i);

	for (int mask = 0; mask < (1 << sz(v)); ++mask) {
		memset(badx, 0, sizeof(badx));		
		memset(bady, 0, sizeof(bady));
		for (int i = 0; i < sz(v); ++i)
			if (mask & (1 << i)) {
				if (v[i] <= h)
					badx[v[i]] = 1;
				else
					bady[v[i] - h] = 1;
			}

		int sum = 0;
		for (int i = 1; i <= h; ++i)
			for (int j = 1; j <= w; ++j)
				if (!badx[i] && !bady[j])
					sum += a[i][j];

		if (sum == k)
			ans++;

	}

	cout << ans << endl;
}
	
        	
//check for the constants

                                                                                   	

