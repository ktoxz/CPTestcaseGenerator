#include <stdio.h>

static const unsigned char TABLE_BITS_COUNT[] = {
  0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4,
  1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
  1, 2, 2, 3, 2, 3, 3, 4, 2, 3, 3, 4, 3, 4, 4, 5,
  2, 3, 3, 4, 3, 4, 4, 5, 3, 4, 4, 5, 4, 5, 5, 6
};

static const unsigned char TABLE_TRAILING_ZEROS[] = { 0, 1, 6, 2, 7, 5, 4, 3 };

static int
parse_int(int delim) {
  int neg = 0;
  int c = getc_unlocked(stdin);

  if (c == '-') {
    c = getc_unlocked(stdin);
    neg = 1;
  } else if (c == '+') {
    c = getc_unlocked(stdin);
  }

  int n = 0;
  while (c != delim && c != EOF) {
    n = (n * 10) + (c - '0');
    c = getc_unlocked(stdin);
  }

  if (neg != 0) {
    return -n;
  }

  return n;
}

static void
read_until(
  int delim,
  void (*func)(int, int, void*),
  void *args)
{
  int c = getc_unlocked(stdin);
  for (int i = 0; c != delim && c != EOF; i++) {
    func(i, c, args);
    c = getc_unlocked(stdin);
  }
}

static void
read_until_func(int i, int c, void *args) {
  unsigned char *x = args;
  if (c == '#') {
    *x |= (1 << i);
  }
}

static unsigned int
fold_bitflag(
  unsigned int  n,
  unsigned int  init,
  unsigned int  (*func)(unsigned int, unsigned int, void*),
           void *args)
{
  unsigned int flg;

  while (1) {
    flg = n & ((~n) + 1);
    if (flg == 0) {
      break;
    }
    init = func(init, flg, args);
    n ^= flg;
  }

  return init;
}

typedef struct {
  unsigned char *ary;
           int   col;
} fold_bitflag_args_t;

static unsigned int
fold_bitflag_func(
  unsigned int  acc,
  unsigned int  x,
  void *args)
{
  unsigned char *ary = ((fold_bitflag_args_t *)args)->ary;
           int   col = ((fold_bitflag_args_t *)args)->col;
  unsigned char  i   = TABLE_TRAILING_ZEROS[((x * 0x1d) >> 5) & 0x07];
  return acc + TABLE_BITS_COUNT[ary[i] & col];
}

static void
abc173_c(void)
{
  int h, w, k;
  unsigned char ary[6] = {};

  h = parse_int(' ');
  w = parse_int(' ');
  k = parse_int('\n');
  for (int i = 0; i < h; i++) {
    read_until('\n', read_until_func, &ary[i]);
  }

  unsigned int ans = 0;
  for (int row = 0; row < 1 << h; row++) {
    for (int col = 0; col < 1 << w; col++) {
      fold_bitflag_args_t args = { ary, col };
      unsigned int cnt = fold_bitflag(row, 0, fold_bitflag_func, &args);
      if (cnt == k) {
        ans += 1;
      }
    }
  }
  printf("%d\n", ans);
}

int
main(void)
{
  abc173_c();
  return 0;
}
