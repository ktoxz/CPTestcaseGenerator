#include<stdio.h>
#define rep(i,l,r) for(ll i=l;i<r;i++)
typedef long long ll;
int main() {
	ll h,w,k;
	scanf("%lld%lld%lld", &h, &w,&k);
	char map[7][7];
	rep(i, 0, h) {
		scanf("%s", map[i]);
	}
	ll ans = 0;
	rep(i, 0, 1<<h) {
		rep(j, 0, 1<<w) {
			ll sum = 0;
			rep(k, 0, h) {
				rep(l, 0, w) {
					if (!(i & (1 << k)) && !(j & (1 << l)) && map[k][l] == '#') sum++;
				}
			}
			if (sum == k) ans++;
		}
	}
	printf("%lld", ans);
	return 0;
}