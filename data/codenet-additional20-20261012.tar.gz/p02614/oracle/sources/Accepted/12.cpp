#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ii = pair<int, int>;
using vi = vector<int>;
#define all(v) (v).begin(), (v).end()
#define sz(v) (int) (v).size()

int main(int argc, char* argv[]) {
  ios::sync_with_stdio(0); cin.tie(0);
  int h, w, k;
  cin >> h >> w >> k;
  vector<vector<char>> mat(h, vector<char>(w));
  int black = 0;
  for (int i = 0; i < h; i++)
    for (int j = 0; j < w; j++) {
      cin >> mat[i][j];
      black += mat[i][j] == '#';
    }
  int res = 0;
  for (int i = 0; i < (1 << h); i++) 
  for (int j = 0; j < (1 << w); j++) {
    int cnt = 0;
    for (int a = 0; a < h; a++) 
    for (int b = 0; b < w; b++) {
      if (((i & (1 << a)) || (j & (1 << b))) && mat[a][b] == '#')
        ++cnt;
    }
    res += black - cnt == k;
  }   
  cout << res << '\n';
  return 0;
}