#include <bits/stdc++.h>

using namespace std;
#define rep(i, n) for(int i = 0; i < (int)n; i++)
#define ll long long
#define ul unsigned long long

template<class T> inline bool chmin(T& a, T b) { if (a > b) { a = b; return true; } return false; }
template<class T> inline bool chmax(T& a, T b) { if (a < b) { a = b; return true; } return false; }



int main() {
        int H,W,K;
        cin >>H >> W >> K;
        ll result=0;
        char masu[H][W];
        bool hcheck[H];
        bool wcheck[H];
        rep(i,H)
                rep(j,W)
                cin >> masu[i][j];
        int h=1;
        int w=1;
        rep(i,H) h=h*2;
        rep(i,W) w=w*2;

        rep(i,h)
                rep(j,w){
                //cout << "i:"<<i << ", j:"<<j <<endl;
                int black=0;
                rep(k,H){
                        if((i>>k)&1) hcheck[k]=false;
                        else hcheck[k]=true;
                }
                rep(k,W){
                        if((j>>k)&1) wcheck[k]=false;
                        else wcheck[k]=true;
                }
                rep(k,H)rep(l,W) if(hcheck[k]&&wcheck[l]&&masu[k][l]=='#') black++;
                //cout << "  black:" << black << endl;
                if(black==K) result++;
        }

        cout << result << endl;
}