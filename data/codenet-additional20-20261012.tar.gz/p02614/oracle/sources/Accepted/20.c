#include<stdio.h>
int main(){
  char c[6][7];
  int h,w,i,j,k,x,y,t=0,b;
  scanf("%d%d%d",&h,&w,&k);
  for(i=0;i<h;i++)scanf("%s",c[i]);
  for(i=0;i<1<<h;i++)for(j=0;j<1<<w;j++){
    b=0;
    for(x=0;x<h;x++)if(i&(1<<x))for(y=0;y<w;y++)b+=j&(1<<y)&&c[x][y]=='#';
    t+=b==k;
  }
  printf("%d",t);
}
