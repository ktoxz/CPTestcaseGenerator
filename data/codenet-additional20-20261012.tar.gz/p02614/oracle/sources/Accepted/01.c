#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

int main(void) {
    int H, W;
    int K;
    int C[6][6];
    int pt = 0;

    scanf("%d %d %d", &H, &W, &K);

    for(int i = 0; i < H; i++) {
        char t[7];
        scanf("%s", t);
        for(int j = 0; j < W; j++) {
            if(t[j] == '.') {
                C[i][j] = 0;
            }
            else {
                C[i][j] = 1;
            }
        }
    }

    for(int i = 0; i < pow(2, H); i++) {
        for(int j = 0; j < pow(2, W); j++) {

            int cnt = 0;
            for(int x = 0; x < H; x++) {
                for(int y = 0; y < W; y++) {
                    if((C[x][y] == 1) && (((i >> x) & 0x01) == 0x00) && (((j >> y) & 0x01) == 0x00)) {
                        cnt++;
                    }
                }
            }

            if(cnt == K) {
                pt++;
            }
        }
    }

    printf("%d\n", pt);
    
    return 0;
}
