from copy import deepcopy
from itertools import product

h, w, k = map(int, input().split())
board   = [ [ c for c in input() ] for _ in range(h) ]

s = 0

def num_to_bit_boolean(n):
    return [ bool(n & b) for b in [ 1, 2, 4, 8, 16, 32 ] ]

def del_row_col(rows_num, cols_num, board):
    global s
    # print(num_to_bit_boolean(rows_num))
    # print(num_to_bit_boolean(cols_num))

    for bit, row in zip(num_to_bit_boolean(rows_num), range(h)):
        if bit:
            board[row] = [ '.' ] * w

    for row in board:
        for bit, col in zip(num_to_bit_boolean(cols_num), range(w)):
            if bit:
                row[col] = '.'

    if count_black(board) == k:
        s += 1

    return board

def count_black(board):
    return sum( row.count('#') for row in board )

if count_black(board) == k:
    print(1)
    exit(0)

for row, col in product(range(2 ** h), range(2 ** w)):
    del_row_col(row, col, deepcopy(board))

print(s)