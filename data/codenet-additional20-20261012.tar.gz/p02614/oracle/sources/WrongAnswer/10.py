H, W, K = [int(n) for n in input().split()]
for _ in range(K):
  a = 1
print(1)