import numpy as np

in_=input().split()
H=int(in_[0])
W=int(in_[1])
K=int(in_[2])

c=np.zeros([H,W])
for i in range(H):
  in_=input()
  for j in range(len(in_)):
    if(in_[j]=='#'):
      c[i][j]=1
#print(c)
K_count=0
test=c
if(np.sum(test)==K):
  print(1)
else:
  N=2**(H+W)
  for n in range(N):
    test=np.array(c)
    num=bin(n)[2:]
    num='{:0>12}'.format(num)
    num=num[12-(H+W):]
    count=0
    for i in num[:H]:
      if(i=='0'):
        test[count]=np.zeros([1,W])
      count+=1
    
    count=0
    for i in num[H:]:
      if(i=='0'):
        test[:,count]=np.zeros([H])
      count+=1
    if(np.sum(test)==K):
      K_count+=1
      #print('OK')
    #print(test)
  print(K_count)