#include<bits/stdc++.h>
using namespace std;
int i, j, k, n, m, ac, tle, wa, re;
char c[5];
int main(){
/*    scanf("%d", &n);
    for(i=1; i<=n; i++){
    	scanf("%s", c+1);
    	if(c[1]=='A'&&c[2]=='C') ac++;
    	else if(c[1]=='T'&&c[2]=='L'&&c[3]=='E') tle++;
    	else if(c[1]=='W'&&c[2]=='A') wa++;
    	else if(c[1]=='R'&&c[2]=='E') re++;
	}
	printf("AC x %d\nWA x %d\nTLE x %d\nRE x %d", ac, wa, tle, re);*/
    cout << "0";
    return 0;
}
