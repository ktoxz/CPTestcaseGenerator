#include <stdio.h>

int main()
{
    int i, i2, j, j2, tmp, tmp2;
    int h, w, k;
    int black = 0;
    int solution = 0;
    char matrix[6][6];

    scanf ("%d%d%d", &h, &w, &k);

    getchar();

    for (i = 0; i < h; i++) {
        for (j = 0; j < w; j++) {
            scanf("%c", &matrix[i][j]);
            if (matrix[i][j] == '#')
                black++;
        }
        getchar();
    }

    if (black == k)
        solution++;
    
    for (j = 0; j < w; j++) {
        tmp = black;
        for (i2 = 0; i2 < h; i2++) {
            if (matrix[i2][j] == '#')
                tmp--;
        }
        if (tmp == k)
            solution++;
    }
    
    for (i = 0; i < h; i++) {
        tmp = black;
        for (j2 = 0; j2 < w; j2++) {
            if (matrix[i][j2] == '#')
                tmp--;
        }
        if (tmp == k)
            solution++;
        for (j = 0; j < w; j++) {
            tmp2 = tmp;
            for (i2 = 0; i2 < h; i2++) {
                if (i2 != i) {
                    if (matrix[i2][j] == '#')
                        tmp2--;
                }
            }
            if (tmp2 == k)
                solution++;
        }
    }

    printf("%d\n", solution);

    return 0;
}