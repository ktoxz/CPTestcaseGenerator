import numpy as np
import itertools

h, w, k = list(map(int, input().split()))
def convert(char):
  if char == '.':
    return 0
  else:
    return 1

def add_elements(c, row, column):
  s = 0
  for i in range(h):
    for j in range(w):
      if (i not in row) and (j not in column):
        s += c[i,j]
  return s

c = np.empty((h, w))

ans = 0

for i in range(h):
  line = list(map(convert, list(input())))
  c[i,:] = np.array(line)

for i in range(h+1):
  for j in range(w+1):
    rows = list(itertools.combinations(range(h),i))
    columns = list(itertools.combinations(range(h),j))
    for row in rows:
      for column in columns:
        s = add_elements(c, row, column)
        if s == k:
          ans += 1

print(ans)

