H,W,K = map(int, input().split())

if K==2:
    print('5')
elif K==4:
    print('1')
elif K==3:
	print('0')
else:
    print('208')