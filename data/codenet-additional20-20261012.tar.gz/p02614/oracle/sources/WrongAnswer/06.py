S =input()
if S[1] =='B':
    print('R')
else:
    print('B')