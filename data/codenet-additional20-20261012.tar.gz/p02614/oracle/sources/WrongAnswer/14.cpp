#include <bits/stdc++.h>
#define REP(i, a, n) for(int i = a; i < n; i++)
using namespace std;

int n, ans;
 
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	freopen("in.txt", "r", stdin);

	cin >> n;
	int p[n];
	REP(i, 0, n) cin >> p[i];
	sort(p, p + n);
	REP(i, 1, n) ans += p[n-i/2-1];
	cout << ans;
}