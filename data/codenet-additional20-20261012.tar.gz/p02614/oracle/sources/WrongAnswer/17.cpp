#include<bits/stdc++.h>
using namespace std;
#define SZ(v) ((int)(v).size())
#define zero(v) memset(v,0,sizeof(v))
#define rep(i,n) for(int i=0;i<(n);i++)
#define foreach(it,c) for(__typeof(c.begin()) it=c.begin();it!=c.end();it++)
#define all(v) (v).begin(),(v).end()
template<typename T>inline bool chkmin(T &a,const T &b){return a>b?a=b,1:0;}
template<typename T>inline bool chkmax(T &a,const T &b){return a<b?a=b,1:0;}
typedef long long ll;
typedef unsigned uint;
const int INF=0x3f3f3f3f;
const double EPS=1e-10;
typedef pair<int,int> pii;
int inline in(){int x=0,c;for(;(uint)((c=getchar())-'0')>=10;)
{if(c=='-')return -in();if(!~c)throw ~0;}do{x=(x<<3)+(x<<1)+(c-'0');}
while((uint)((c=getchar())-'0')<10);return x;}
int n,m,k;
string s;
int a[10][10];
int main(){
	cin>>n>>m>>k;
	int B;
	rep(i,n){
		cin>>s;
		rep(j,m){
			if(s[j]=='.')a[i][j]=1;
			else if(s[j]=='#'){
				a[i][j]=2;B++;
			}
		}
	}
	int ans=0;
	rep(mask1,(1<<n))rep(mask2,(1<<m)){
		int cnt=0;
		rep(i,n)rep(j,m){
			if(((mask1>>i&1)||(mask2>>j&1))&&a[i][j]==2)cnt++;
		}
		if(B==k+cnt)ans++;
	}
	cout<<ans<<endl;
	return 0;
}