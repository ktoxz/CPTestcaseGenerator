from collections import Counter
import copy
from itertools import combinations


def A(x):
  return 1000 - x % 1000 if x % 1000 != 0 else 0


def B(n, ss):
  keys_values = Counter(ss)
  orders = ['AC', 'WA', 'TLE', 'RE']
  for order in orders:
    if order in keys_values:
      print("{} x {}".format(order, keys_values[order]))
    else:
      print("{} x {}".format(order, 0))


def C(h, w, k, g):

  def _get_num_black(c_list, r_list):
    num_black = 0
    for i in range(h):
      if i in r_list:
        continue
      for j in range(w):
        if j in c_list:
          continue
        num_black += (1 if g[i][j] == '#' else 0)
    return num_black

  num_choice = 0
  for i in range(k + 1):
    for j in range(k - i + 1):
      comb_c = list(combinations(range(w), j))
      comb_r = list(combinations(range(h), i))
      for c_list in comb_c:
        for r_list in comb_r:
          num_black = _get_num_black(c_list, r_list)
          if num_black == k:
            num_choice += 1
          # print(h, i, comb_r, w, j, comb_c, num_black, k)
  return num_choice


def main():
  h, w, k = map(int, input().split())
  g = []
  for i in range(h):
    g.append(input())
  print(C(h, w, k, g))


if __name__ == '__main__':
  main()
