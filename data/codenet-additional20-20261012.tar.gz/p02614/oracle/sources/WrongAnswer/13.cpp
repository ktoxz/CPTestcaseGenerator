#include <bits/stdc++.h>
using namespace std;

int h,w,s,k,ans,sum;

int main()
{
	cin>>h>>w>>k;
	char a[h+5][w+5]={0};
    int r[h+1]={0},c[w+1]={0};
    
	for(int i=1;i<=h;i++)
	 for(int j=1;j<=w;j++)
	 {
	 	cin>>a[i][j];
	 	if(a[i][j]=='#')
	 	{
	 		s++;
	 		r[i]++;
		 }
	 }
	
    for(int j=1;j<=w;j++)
     for(int i=1;i<=w;i++)
      if(a[j][i]=='#') c[i]++;
	  
	  
	for(int i=1;i<=h;i++)
	 for(int j=1;j<=w;j++)
	{
		sum=0;
		if(a[i][j]=='#') sum=r[i]+c[j]-1;
		else sum=r[i]+c[j];
		
		if(s-sum==k) ans++;
		continue;
	}
	
	for(int i=1;i<=h;i++)
	 if(s-r[i]==k) ans++;
	
	for(int i=1;i<=w;i++)
	 if(s-c[i]==k) ans++;
	
	for(int i=1;i<=h-1;i++)
	 for(int j=i+1;j<=h;j++)
	  if(s-r[i]-r[j]==k) ans++;
	
	for(int i=1;i<=w-1;i++)
	 for(int j=i+1;j<=w;j++)
	  if(s-c[i]-c[j]==k) ans++;
	
	cout<<ans<<endl;
	return 0;
	
	return 0;
}