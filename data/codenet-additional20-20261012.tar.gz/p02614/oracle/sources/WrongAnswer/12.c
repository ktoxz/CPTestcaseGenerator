#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

#define rep(i, n) for(int i=0; i<(n); ++i)
#define max  200001

//qsort(str, n, sizeof(int), up_comp);
int up_comp(const void *a, const void *b){return *(int*)a - *(int*)b;}
int down_comp(const void *a, const void *b){return *(int*)b - *(int*)a;}
int int_sort( const void * a , const void * b ) {return strcmp(( char * )a , ( char * )b );}
int count_digit(int a){int i=0;while(a!=0){a=a/10;i++;}return i;}
int euclid( int a, int b ){int temp;if(a<b){temp=a;a=b;b=temp;}if(b<1)return -1;if(a%b==0) return b;return euclid(b,a%b);}

int main(void){
 
    int h, w, k, cnt=0, ans=0;
    char c[6][6], cmp[2]="#";
    
    scanf("%d%d%d", &h, &w, &k);
    rep(i, h){
        rep(j, w){
            scanf("%s", &c[i][j]);
        }
    }
    
    rep(i, h){
        //行入れ替え
        rep(a, w){
            c[i][a]='%';
        }
        rep(j, w){
            //列入れ替え
            rep(b, h){
                c[b][j]='%';
            }
            //カウント
            rep(i, h){
                rep(j, w){
                    if (c[i][j]=='#') {
                        cnt++;
                    }
                }
            }
            if (cnt==k) {
                ans++;
            }
        }
    }
    
    printf("%d", ans);
    
    return 0;
}

