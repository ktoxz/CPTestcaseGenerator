#include <iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<cmath>
#include<numeric>
using namespace std;
typedef long long ll;

#define REP(i, n) for(ll i = 0; i < n; i++)
#define REPR(i, n) for(ll i = n; i >= 0; i--)
#define FOR(i, m, n) for(ll i = m; i < n; i++)
#define INF 2e9
#define ALL(v) v.begin(), v.end()
#define  DESC std::greater<int>() //sort 3rd arg



int main()
{
	int h, w, k;
	cin >> h >> w >> k;
	vector<int>v;
	vector<int>copy;
	REP(i, h) {
		REP(j, w) {
			char tmp;
			cin >> tmp;
			if (tmp == '#') {
				v.push_back(1);
			}
			else {
				v.push_back(0);
			}
			
		}
	}
	
	copy = v;
	int ans = 0;

	for (int i = -1; i < h;i++) {
		for (int j = -1; j < w;j++) {
			v = copy;
			if (i >= 0) { //該当行ゼロ化
				for (int st = i * w; st < i*w+w;st++) {
					v[st] = 0;
				}
			}

			if (j >= 0) {//該当列ゼロ化
				for (int st = j; st <v.size();st+=w) {
					v[st] = 0;
				}
			}

			int sum =accumulate(v.begin(), v.end(), 0);
			if (sum == k) {
				ans++;
			}
		}
	}

	cout << ans << endl;
	return 0;
}

