def main():
    R, C, K = map(int, input().split())
    V = {}
    for _ in range(K):
        r, c, v = map(int, input().split())
        V[(r - 1, c - 1)] = v
    dp = [(0, 0, 0, 0) for _ in range(C)]
    for r in range(R):
        p0, p1, p2, p3 = 0, 0, 0, 0
        for c in range(C):
            m = max(dp[c])
            if (r, c) in V:
                v = V[(r, c)]
                n0, n1, n2, n3 = max(m, p0), max(p1, max(p0, m) + v), max(p2, p1 + v), max(p3, p2 + v)
            else:
                n0, n1, n2, n3 = max(m, p0), p1, p2, p3
            dp[c] = (n0, n1, n2, n3)
            p0, p1, p2, p3 = n0, n1, n2, n3

    return max(dp[-1])

print(main())
