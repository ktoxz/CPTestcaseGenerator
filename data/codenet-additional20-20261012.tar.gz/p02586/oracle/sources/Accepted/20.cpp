#include<bits/stdc++.h>
#include <iostream>
#include <numeric>
#include <math.h>
#define ll long long 
#define ull long
#define mpa make_pair
#define pb push_back
#define ff first
#define pii pair<ll,ll>
#define dd long long
#define trace(x) cerr << #x << " : " << x << endl
#define ss second
#define boost ios_base::sync_with_stdio(0)
#define forp(i,a,b) for(ll i=a;i<=b;i++)
#define rep(i,n)    for(ll i=0;i<n;++i)
#define ren(i,n)    for(ll i=n-1;i>=0;i--)
#define forn(i,a,b) for(ll i=a;i>=b;i--)
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(typeof((c).begin()) i = (c).begin(); i != (c).end();
#define sc(x) scanf("%lld",&x)
#define clr(x,val) memset(x,val,sizeof(x))
#define pr(x) printf("%lld\n",x) 
#define gc getchar
#define pdd pair<dd,dd>
#define prec(x) cout<<fixed<<setprecision(x)
#define fre freopen("input.txt","r",stdin),freopen("output.txt","w",stdout)
using namespace std;
ll dp[3005][3005][4];
ll memo[3005][3005][4];
ll val[3005][3005];
ll r,c;
ll solve(ll i,ll j,ll k){
	if(i>r or j>c or k>3)return 0;
	if(memo[i][j][k])return dp[i][j][k];
	memo[i][j][k]=1;
	ll res=0;
	res=solve(i,j+1,k);
	res=max(res,solve(i+1,j,0));
	if(k<3)res=max(res,solve(i,j+1,k+1)+val[i][j]);
	if(k<3)res=max(res,solve(i+1,j,0)+val[i][j]);	
	return dp[i][j][k]=res;
	
}
int main(){
   boost;
   ll k;  
   cin>>r>>c>>k;
   while(k--){
   	  ll x,y,v;
   	  cin>>x>>y>>v;
   	  val[x][y]=v;
    }
    cout<<solve(0,0,0)<<endl;
   
   
}
   
	
 
    
