#include <bits/stdc++.h>

#define repu(i,a,b) for(int i=a;i<=b;i++)
#define rep(i,a)    for(int i=0;i<a;i++)
#define ll long long
using namespace std;

int main() {
    int r, c, k;
    cin>>r>>c>>k;
    // long long a[r+1][c+1],b[r+1][c+1][4];
    vector<vector<ll>> a(r+1,vector<ll>(c+1,0LL));
    vector<vector<vector<ll>>> b(r+1,vector<vector<ll>>(c+1,vector<ll>(4,0LL)));
    rep(i,k)
    {
        int x, y, z;
        cin>>x>>y>>z;
        a[x][y]=z;
    }
    repu(i,1,r)
    {
        repu(j,1,c)
        {
            b[i][j][3]=max({b[i][j-1][3],b[i][j][3],max({b[i-1][j][3],b[i-1][j][1],b[i-1][j][0]})+a[i][j],b[i][j-1][2]+a[i][j]});
            b[i][j][2]=max({b[i][j-1][2],b[i][j][2],max({b[i-1][j][3],b[i-1][j][1],b[i-1][j][0]})+a[i][j],b[i][j-1][1]+a[i][j]});
            b[i][j][1]=max({b[i][j-1][1],b[i][j][1],max({b[i-1][j][3],b[i-1][j][1],b[i-1][j][0]})+a[i][j],b[i][j-1][0]+a[i][j]});
        }
    }
    // cout<<b[1][4][3]<<endl;
    cout<<max({b[r][c][3],b[r][c][2],b[r][c][1],b[r][c][0]})<<endl;
}