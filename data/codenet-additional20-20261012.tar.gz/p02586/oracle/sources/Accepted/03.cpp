#include <bits/stdc++.h>
using namespace std;

// 型定義
typedef long long ll;
typedef pair<ll, ll> P;

// forループ
#define REP(i,n) for(ll i=0; i<(ll)(n); ++i)

// 定数宣言
const int INF = 1e9;
const int MOD = 1e9+7;
const ll LINF = 1e18;

// グラフ表現
using Graph = vector<vector<int>>;

// グラフの辺表現
using Edge = map<pair<int,int>,int>;

// n次元配列の初期化。第２引数の型のサイズごとに初期化していく。
template<typename A, size_t N, typename T>
void Fill(A (&array)[N], const T &val){
    std::fill( (T*)array, (T*)(array+N), val );
}

// 最大公約数
ll gcd(ll a,ll b){
   if (a%b == 0) return(b);
   else return(gcd(b, a%b));
}

// 最小公倍数
ll lcm(ll a, ll b){
    return a/gcd(a, b) * b;
}

ll A[3010][3010];
ll dp[3010][3010][4];

int main()
{
    cout << fixed << setprecision(15);
    ll R, C, K;
    cin >> R >> C >> K;

    Fill(A, 0);
    Fill(dp, 0);

    REP(i, K){
        ll r, c, v;
        cin >> r >> c >> v;

        A[r-1][c-1] = v;
    }

    for(ll i=0; i<=R; i++){
        for(ll j=0; j<=C; j++){
            // 今のマス目を入れた場合の更新を行う
            for(ll k=2; k>=0; k--){
                dp[i][j][k+1] = max(dp[i][j][k+1], dp[i][j][k] + A[i][j]);
            }
            for(ll k=0; k<=3; k++){
                dp[i+1][j][0] = max(dp[i+1][j][0], dp[i][j][k]);
                dp[i][j+1][k] = max(dp[i][j+1][k], dp[i][j][k]);
            }
        }
    }

    cout << dp[R][C-1][0] << endl;

    return 0;
}