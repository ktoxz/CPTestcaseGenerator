#include <bits/stdc++.h>
        
#define pb push_back
#define ll long long
#define f first
#define s second
#define ld long double
#define fa fflush(stdout); 
#define mp make_pair
using namespace std;
void data() {
    #ifdef NURS
        freopen("main.in", "r", stdin);
        freopen("main.out", "w", stdout);
    #endif
  //  ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);;                                                      
} 
const int N = 1e5 + 100;
const ll mod = 1e9 + 7;
const ll big = 1e16;
const int p = 37;

ll dp[3105][3105][10];
ll was[3105][3105];
int main() 
{
	data();
	#define int ll
	ios_base::sync_with_stdio(0),cin.tie(0),cout.tie(0);;                                                       
	int r, c, k;
	cin >> r >> c >> k;
	int row[k + 1], col[c + 1], sum[k + 1];
	for (int i = 1; i <= k; i++)
	{
		cin >> row[i] >> col[i] >> sum[i];
		was[row[i]][col[i]] += sum[i];
	}
	for (int i = 1; i <= r; i++)
	{
		for (int j = 1; j <= c; j++)
		{
			dp[i][j][0] = -1;
			dp[i][j][1] = -1;
			dp[i][j][2] = -1;
			dp[i][j][3] = -1;
		}
	}
	dp[1][1][0] = 0;
	if (was[1][1])
	{
		dp[1][1][1] = was[1][1];
	}             
	for (int i = 1; i <= r ;i++)
	{
		for (int j = 1; j <= c; j++)
		{
			for (int k = 0; k <= 3; k++)
			{
				if (dp[i][j][k] != -1)
				{
					if (i + 1 <= r)
					{
						if (was[i + 1][j])
						{
							dp[i + 1][j][1] = max(dp[i + 1][j][1], dp[i][j][k] + was[i + 1][j]);
						}
						dp[i + 1][j][0] = max(dp[i + 1][j][k], dp[i][j][k]);
					}
					if (j + 1 <= c)
					{
						if (was[i][j + 1] && k + 1 <= 3)
						{
							dp[i][j + 1][k + 1] = max(dp[i][j + 1][k + 1], dp[i][j][k] + was[i][j + 1]);
						}
						dp[i][j + 1][k] = max(dp[i][j + 1][k], dp[i][j][k]);
					}
				}
			}
		}
	}
	ll ans = 0;
	for (int i = 0; i <= 3 ;i++)
	{
		ans = max(ans, dp[r][c][i]);
	}
	cout << ans;
}
