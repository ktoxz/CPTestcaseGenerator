# -*- coding: utf-8 -*-
import sys
from collections import defaultdict
R,C,K=map(int, sys.stdin.readline().split())

value=defaultdict(lambda: 0)
for _ in range(K):
    r,c,v=map(int, sys.stdin.readline().split())
    value[(r,c)]=v

dp=defaultdict(lambda: float("-inf")) 
#初期化  dp[(左から何列目,その行で何個アイテムを拾った)]
dp[(1,0)]=0
#1,1のマスにアイテムがあるなら
if 0<value[(1,1)]:
    dp[(1,1)]=value[(1,1)]

for r in range(1,R+1):
    for c in range(2,C+1):
        #今のマスまでで3個取得=max(左のマスまでで3個取得, 左のマスまでで2個取得+v)
        dp[(c,3)]=max( dp[(c-1,3)], dp[(c-1,2)]+value[(r,c)] )
        #今のマスまでで2個取得=max(左のマスまでで2個取得, 左のマスまでで1個取得+v)
        dp[(c,2)]=max( dp[(c-1,2)], dp[(c-1,1)]+value[(r,c)] )
        #今のマスまでで1個取得=max(左のマスまでで1個取得, 左のマスまでで0個取得+v, 下のマスからの繰り上がり+v )
        dp[(c,1)]=max( dp[(c-1,1)], dp[(c-1,0)]+value[(r,c)], dp[(c,0)]+value[(r,c)] )
        #今のマスまでで0個取得=max(左のマスまでで0個取得, 下のマスからの繰り上がり+v )
        dp[(c,0)]=max( dp[(c-1,0)], dp[(c,0)] )

    #dpの値を上の行にコピー
    new_dp=defaultdict(lambda: float("-inf")) 
    for c in range(1,C+1):
        max_v=float("-inf")
        for k in range(0,4):
            max_v=max(max_v,dp[(c,k)])
        new_dp[(c,0)]=max_v

    dp=new_dp

print dp[(C,0)]
