from itertools import *
import numpy as np
R,C,K = map(int,input().split())
I = sorted([list(map(int,input().split())) for k in range(K)])
S = np.zeros((R,C),np.int32)
A = []

for r,c,v in I:
  S[r-1][c-1] = v

for C in permutations((R-1)*"0"+(C-1)*"1",R+C-2):
  x = 0
  y = 0
  z = S[0][0]
  
  for c in C:
    if c=="0":
      x+=1
      z+=S[x][y]
    else:
      y+=1
      z+=S[x][y]
  
  A+=[z]

print(max(A))