#include<bits/stdc++.h>
using namespace std;
#define ll long long int 
vector<vector<vector<ll>>> dp(3005,vector<vector<ll>>(3005,vector<ll>(3,-INT_MAX)));
ll dfs(vector<vector<ll>>& g,ll i,ll j,ll k,ll r,ll c){
	if(i<0||i>=r||j<0||j>=c||k>3)
	return 0;
	if(dp[i][j][k]!=-INT_MAX)
	return dp[i][j][k];
	dp[i][j][k]=max(max(g[i][j]+dfs(g,i+1,j,0,r,c),g[i][j]+dfs(g,i,j+1,k+1,r,c)),max(dfs(g,i+1,j,0,r,c),dfs(g,i,j+1,k,r,c)));
//	if(k<3)
//	dp[i][j][k]=max(dp[i][j][k],g[i][j]+dfs(g,i,j+1,k+1,r,c));
	return dp[i][j][k];
}
int main(){
	ll r,c,k,x,y,z;
	cin>>r>>c>>k;
	vector<vector<ll>> g(r,vector<ll>(c,0));
	for(int i=0;i<k;i++){
		cin>>x>>y>>z;
		g[x-1][y-1]=z;
	}
	ll ans=0;
	ans=dfs(g,0,0,0,r,c);
	cout<<ans<<endl;
}