#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string>

#define rep(i, a, b) for ( int i = (a); i < (b); i++ )
#define per(i, a, b) for ( int i = (b)-1; i >= (a); i--)
#define pb push_back
#define mp make_pair
#define bg begin()
#define en end()
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
#define sz(v) (int)(v).size()

using namespace std;

typedef long long ll;
typedef long double ld;

using P = pair<int, int>;
template<typename T>
struct Edge {
    int u, v;
    T cost;
    Edge(int u, int v, T c) : u(u), v(v), cost(c) {}
    bool operator< (const Edge &e) const {return cost < e.cost;}
};

static const long long MOD = 1000000007;
static const long long LINF = (ll)(1e18+99);
static const int INF = 1e9+99;
const int MAX = 3005;


ll ans;
ll dp[MAX][MAX][4];

int main(void) {
    int R, C, K;
    cin >> R >> C >> K;
    vector<vector<ll>> M(R+5, vector<ll> (C+5, 0));
    rep(i, 0, K) {
        int r, c;
         ll v;
         cin >> r >> c >> v;
         M[r][c] = v;
    }

    rep(i, 1, R+1) rep(j, 1, C+1) {
        rep(k, 0, 4) {
            dp[i][j][k] = max(dp[i-1][j][3]+M[i][j], dp[i][j-1][k-1]+M[i][j]);
        }
    }

    ans = dp[R][C][3];
    
    cout << ans << endl;
    return 0;
}



