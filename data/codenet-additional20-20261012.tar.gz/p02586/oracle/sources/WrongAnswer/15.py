# coding: utf-8
import numpy as np
import itertools

def main():
    R, C, K = map(int, input().split())
    matrix = np.zeros((R, C))
    for k in range(K):
        r_i, c_i, v_i = map(int, input().split())
        matrix[r_i-1, c_i-1] = v_i
    
    dp = np.zeros((4, R, C))
    for r, c in itertools.product(range(R), range(C)):
        if r == 0:
            dp[0, r, c] = 0
            dp[1, r, c] = max(matrix[r, c], dp[1, r, c-1])
            dp[2, r, c] = max(dp[1, r, c-1] + matrix[r, c], dp[2, r, c-1])
            dp[3, r, c] = max(dp[2, r, c-1] + matrix[r, c], dp[3, r, c-1])
        else:
            dp[0, r, c] = max([dp[0, r, c-1], dp[0, r-1, c], dp[1, r-1, c], dp[2, r-1, c], dp[3, r-1, c]])
            dp[1, r, c] = max([dp[0, r, c-1] + matrix[r, c], dp[1, r, c-1], dp[0, r-1, c] + matrix[r, c], dp[1, r-1, c] + matrix[r, c], dp[2, r-1, c] + matrix[r, c], dp[3, r-1, c] + matrix[r, c]])
            dp[2, r, c] = max(dp[1, r, c-1] + matrix[r, c], dp[2, r, c-1])
            dp[3, r, c] = max(dp[2, r, c-1] + matrix[r, c], dp[3, r, c-1])
    print(int(max([dp[0, R-1, C-1], dp[1, R-1, C-1], dp[2, R-1, C-1], dp[3, R-1, C-1]])))
    
main()
