import sys
R, C, K = list(map(int, input().split()))

d = [[[0] * (C) for _ in range(R)] for _ in range(4)]
t = [[0] * (C) for _ in range(R)]

for i in range(K):
    r,c,v = list(map(int, input().split()))
    t[r-1][c-1] = v

for i in range(R):
    for j in range(C):
        if (i == 0 and j != 0) or (d[0][i-1][j] < d[0][i][j-1]):
            k = 0
            for l in range(3):
                if d[l+1][i][j-1] < k:
                    d[l+1][i][j] = k
                    k = d[l+1][i][j-1]

                if d[l+1][i][j-1] < t[i][j]:
                    k = d[l+1][i][j-1]
                    d[l+1][i][j] = t[i][j]

            d[0][i][j] = t[i][j] + d[0][i][j-1] - k
        elif (j == 0 and i != 0) or (d[0][i-1][j] > d[0][i][j-1]):
            d[0][i][j] = t[i][j] + d[0][i-1][j]
            d[1][i][j] = t[i][j]
        elif i == 0 and j == 0:  
            d[0][i][j] = t[i][j]
            d[1][i][j] = t[i][j]

a = 0
for i in range(4):
    a = max(a, d[i][-1][-1])
print(a)
