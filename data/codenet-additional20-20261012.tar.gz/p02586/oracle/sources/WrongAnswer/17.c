long V[3030][3030],dp[3030][3030][5];
main(R,C,K){
	scanf("%d%d%d",&R,&C,&K);
	for(int i=0;i<K;i++)
	{
		int r,c,v;
		scanf("%d%d%d",&r,&c,&v);
		V[r][c]=v;
	}
	for(int i=0;i<=R;i++)for(int j=0;j<=C;j++)for(int k=0;k<4;k++)
	{
		for(int r=0;r<2;r++)
		{
			int v=V[i+r][j+1-r];
			int nk=r?0:v?k+1:k;
			if(dp[i+r][j+1-r][nk]<dp[i][j][k]+v)dp[i+1][j+1-r][nk]=dp[i][j][k]+v;
		}
		if(dp[i][j][k+1]<dp[i][j][k])dp[i][j][k+1]=dp[i][j][k];
	}
	printf("%ld\n",dp[R][C][3]);
}