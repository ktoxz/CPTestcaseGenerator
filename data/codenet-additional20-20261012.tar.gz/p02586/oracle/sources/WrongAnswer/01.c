#include <stdio.h>
typedef long long ll;
#define rep(i,n) for(ll i=0; i<(ll)(n); i++)
#define max(l,r) ((l)>(r)?l:r)

int dp[3030][3030][5] = {0};
int mp[3030][3030] = {0};
int main(){
    int R, C, K;
    scanf("%d%d%d", &R, &C, &K);
    rep(i, K) {
        int x, y, v;
        scanf("%d%d%d", &x, &y, &v);
        mp[x][y] = v;
    }

    rep(i, R) {
        rep(j, C) {
            rep(k, 4) {
                if(mp[i+1][j+1] > 0) {
                    if(k > 0) dp[i+1][j+1][k] = max(dp[i+1][j+1][k], dp[i+1][j][k-1] + mp[i+1][j+1]);
                    if(i > 0) dp[i+1][j+1][1] = max(dp[i+1][j+1][1], dp[i][j+1][k] + mp[i+1][j+1]);
                }
                dp[i+1][j+1][k] = max(dp[i+1][j+1][k], dp[i+1][j][k]);
                if(i > 0) dp[i+1][j+1][0] = max(dp[i+1][j+1][0], dp[i][j+1][k]);
                
            }
        }
    }

    ll ans = 0;
    rep(i, 4) ans = max(ans, dp[R][C][i]);
    printf("%lld", ans);
}