#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<ll, ll> P;

//static const int MAX_N = 3000;
//static const int MAX_M = 3000;
//static const int INF = 1000000001;

int R, C;

int dx[] = {0, 1};
int dy[] = {1, 0};
//int check[MAX_N][MAX_M];

/*void start_up(){
    for (int i = 0; i < MAX_N; i++) {
        for (int j = 0; j < MAX_M; j++) {
            d[i][j] = 0;
            //check[i][j] = 0;
        }
    }
}*/

/*ll bfs(vector<vector<ll>> input, vector<vector<ll>> d, P s, P g)
{
    queue<P> q;
    q.push(s);
    //check[s.first][s.second] = 1;
    vector<vector<int>> r_check(R, vector<int>(C, 0));
    while(!q.empty()) {
        //cout << "ao!" << endl;
        P tmp = q.front();
        q.pop();
        if (tmp.first == g.first && tmp.second == g.second) break;
        for (int i = 0; i < 2; i++) {
            int x = tmp.first + dx[i];
            int y = tmp.second + dy[i];
            if (x < R && y < C) {
                if (r_check.at(x).size() <= 3) {
                    d[x][y] = d[tmp.first][tmp.second] + input.at(x).at(y);
                    q.push({x, y});
                    r_check.at(x).push_back(y);
                } else {
                    sort(r_check.at(x).begin(), r_check.at(x).end(),greater<ll>());
                    d[x][y] = d[x - 1][tmp.second];
                    for (int j = 0; j < 3; j++) d[x][y] += input.at(r_check.at(x).at(j)).at(y);
                }
            }
        }
    }
    return d[g.first][g.second];
}*/

int main(){
    //start_up();
    int K;
    cin >> R >> C >> K;

    // 島、もしくは迷路の地形を2次元配列でinputする
    vector<vector<ll>> input(R, vector<ll>(C, 0));
    for (int i = 0; i < K; i++) {
        int tmp_r, tmp_c;
        cin >> tmp_r >> tmp_c;
        tmp_r--;
        tmp_c--;
        cin >> input.at(tmp_r).at(tmp_c);
    }

    vector<vector<ll>> d(R, vector<ll>(C, 0));
    vector<vector<int>> r_check(R, vector<int>());

    d.at(0).at(0) = input.at(0).at(0);
    if (input.at(0).at(0) != 0) r_check.at(0).push_back(0);

    for (int i = 0; i < R; i++) {
        for (int j = 0; j < C; j++) {
            if (i == 0 && j == 0) continue;
            if (i == 0) {
                if (input.at(0).at(j) != 0) {
                    r_check.at(0).push_back(j);
                    if (r_check.at(0).size() <= 3){
                        d.at(0).at(j) = d.at(0).at(j - 1) + input.at(0).at(j);
                        //cout << "B" << endl;
                    } else {
                        vector<ll> tmp;
                        for (auto itr : r_check.at(i)) tmp.push_back(input.at(0).at(itr));
                        sort(tmp.begin(), tmp.end(), greater<ll>());
                        //if (i > 0) d.at(i).at(j) = d.at(i - 1).at(j);
                        for (int k = 0; k < 3; k++) d.at(0).at(j) += tmp.at(k);
                        //cout << tmp.at(0) << endl;
                    }
                } else d.at(0).at(j) = d.at(0).at(j - 1);
            }
            else {
                if (input.at(i).at(j) != 0) {
                    r_check.at(i).push_back(j);
                    if (r_check.at(i).size() <= 3) {
                        if (j > 0) d.at(i).at(j) = max(d.at(i - 1).at(j), d.at(i).at(j - 1)) + input.at(i).at(j);
                        else d.at(i).at(j) = d.at(i - 1).at(j) + input.at(i).at(j);
                        //cout << "A" << endl;
                    } else {
                        vector<ll> tmp;
                        for (auto itr : r_check.at(i)) tmp.push_back(input.at(i).at(itr));
                        sort(tmp.begin(), tmp.end(), greater<ll>());
                        //if (i > 0)
                        d.at(i).at(j) = d.at(i - 1).at(j);
                        for (int k = 0; k < 3; k++) d.at(i).at(j) += tmp.at(k);
                        //cout << tmp.at(0) << endl;
                    }
                } else {
                    if (j > 0) d.at(i).at(j) = max(d.at(i - 1).at(j), d.at(i).at(j - 1)) + input.at(i).at(j);
                    else d.at(i).at(j) = d.at(i - 1).at(j) + input.at(i).at(j);
                }
            }
            //cout << d.at(i).at(j) << endl;
        }
    }
    //cout << bfs(input, d, {0, 0}, {R - 1, C - 1}) << endl;
    cout << d.at(R - 1).at(C - 1) << endl;
    return 0;
}