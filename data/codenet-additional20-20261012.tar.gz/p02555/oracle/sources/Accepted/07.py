import math

S = int(input())
p = 0
n = 1

while S - n * 3 >= 0:
  p += math.factorial(S - n * 2 - 1) // (math.factorial(n - 1) * math.factorial(S - n * 3))
  n += 1

print(p % (10 ** 9 + 7))