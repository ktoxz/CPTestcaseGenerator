#include <stdio.h>

long modpow(long a, long n, long mod){
	if (n == 0) {
		return 1;
	}
	long answer;
	if (n%2 == 0) {
		answer = modpow(a, n/2, mod);
		answer *= answer;
	} else {
		answer = modpow(a, n-1, mod);
		answer *= a;
	}
	answer %= mod;
	return answer;
}
long modCombination(long n, long r, long mod) {
  long answer;
  if (n-r < r) {
    r = n-r;
  }
  long nu = 1;
  long de = 1;
  for (long i = 1; i <= r; i++) {
    nu *= n+1-i;
    nu %= mod;
    de *= i;
    de %= mod;
  }
  answer = nu;
  answer *= modpow(de,mod-2,mod);
  answer %= mod;
  return answer;
}

int main(void) {

  long n;
  scanf("%ld", &n);
  long mod = 1000000007;
  long ans = 0,rem;
  for (long len = 1; len <= n/3; len++) {
    rem = n-len*3;
    ans += modCombination(rem+len-1,len-1,mod);
    ans %= mod;
  }
  printf("%ld\n", ans);

  return 0;
}