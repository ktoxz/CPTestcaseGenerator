def sum(i):
	if nums[i] != -1: return nums[i]

	else:
		nums[i] = 0 if i <= 2 else 1
		for k in range(3, i - 2):
			nums[i] += sum(k)
		return nums[i]

S = int(input())
nums = []
if S >= 0: nums.append(0)
if S >= 1: nums.append(0)
if S >= 2: nums.append(0)

for i in range(3, S + 1): nums.append(-1)

print(sum(S) % 1000000007)