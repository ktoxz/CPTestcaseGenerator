def ncr(n, r, p): 
    
     
    num = den = 1 
    for i in range(r): 
        num = (num * (n - i)) % p 
        den = (den * (i + 1)) % p 
    return (num * pow(den,  
            p - 2, p)) % p 
S = int(input())
l,rem = divmod(S,3)
MOD = 10**9 + 7
ans = 0
for i in range(0,l+1):
  ans = (ans + ncr(S-2*i-1,S-3*i,MOD))%MOD
print(ans)
