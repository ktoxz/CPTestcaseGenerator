#include <bits/stdc++.h>
using namespace std;

#define REP(i, begin, end) for (__typeof(end) i = (begin) - ((begin) > (end)); i != (end) - ((begin) > (end)); i += 1 - 2 * ((begin) > (end)))
#define ALL(c) c.begin(), c.end()
#define SZ(c) (int) c.size()
#define DBG1(x) cout<<#x<<" = "<<x<<"\n"
#if USE_CP_REDIR
#define CP \
    freopen("input.txt","r", stdin); \
    freopen("output.txt","w", stdout);
#endif

using ll = long long;
const ll MOD = 1'000'000'007;
const int MN = 200'000;
int DP[MN+1];

ll mod_add(ll a, ll b)
{
    return (((a % MOD) + (b % MOD)) % MOD);
}

ll mod_mul(ll a, ll b){
    return (((a % MOD) * (b % MOD)) % MOD);
}

/* Iterative Function to calculate (x^y)%p  
in O(log y) */
long long mod_exp(long long x, long long y) 
{ 
    long long res = 1; // Initialize result 
  
    x = x % MOD; // Update x if it is more than or 
    // equal to p 
  
    while (y > 0) { 
        // If y is odd, multiply x with result 
        if (y & 1) 
            res = (res * x) % MOD; 
  
        // y must be even now 
        y = y >> 1; // y = y/2 
        x = (x * x) % MOD; 
    } 
    return res; 
} 

ll go(ll n){
    if(n < 3) return 0;
    if(DP[n] != -1) return DP[n];
    ll ans = 1;
    for(ll i = n-3; i >= 1; i--){
        ans = mod_add(ans, go(i));
    }
    DP[n] = ans;
    return ans;
}

int main()
{
ios::sync_with_stdio(false);
#ifdef CP
    CP;
#endif
    int S;
    cin >> S;
    memset(DP, -1, sizeof DP);
    if(S < 3){
        cout << 0 << endl;
    }else{
        ll ans;
        ans = go(S);
        cout << ans << endl;
    }
}