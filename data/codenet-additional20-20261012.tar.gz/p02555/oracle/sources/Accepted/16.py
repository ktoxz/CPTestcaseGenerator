S=int(input())
A=[0]*(S+1)
for i in range(S+1):
    if i==0:
        A[i]=1
    elif i==1 or i==2:
        A[i]=0
    else:
        A[i]=A[i-1]+A[i-3]
print(A[S]%(10**9+7))