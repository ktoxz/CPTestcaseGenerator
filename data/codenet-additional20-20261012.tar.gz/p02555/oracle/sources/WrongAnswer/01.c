#include<stdio.h>
#define mod 1000000007
//累乗(power)a^n(mod10^9+7)
long long power(long long a,long long n){
  long long count=a,sum=1;
  while(n>0){
    if(n%2==1)
      sum*=count;
    count*=count;
    count%=mod;
    sum%=mod;
    n/=2;
  }
  return sum;
}

//nCr(mod10^9+7)
long long int comb(long long int n,long long int r){
  long long x=1,y=1,i;
  for(i=0;i<r;i++){
    x*=n-i;
    y*=r-i;
    x%=mod;
    y%=mod;
  }
  //power(y,10^9+7-2)
  y=power(y,mod-2);
  return (x*y)%mod;
}

int main(){
  int s , i , j;
  long long ans = 0;
  scanf("%d", &s);
  for( i = 1 ; i <= s/3 ; i++){
    ans += power( i , s - 3 * i );
    for( j = i - 1 ; j > 0 ; j-- ){
      ans -= j * comb( i , i - j ) - 1;
    }
    ans %= mod;
  }
  printf("%lld\n",ans);
  return 0;
}
