S = int(input())
mod = 10**9+7
s = S%3
n = int((S-s)/3)
ss = 0
for i in range(n):
    jj = 1
    for j in range(n-i,2*i+s+n):
        if n-i==1:
            jj = 1
        else:
            jj *= j
    jj %=mod
    kk = 1
    for k in range(1,n-i):
        if n-i == 1:
            kk=1
        else:
            kk *= k
            
        
    
    ss += ((jj/kk)%mod)
print(int(ss%mod))