#include <stdio.h>
#include <stdlib.h>

int main(void){
    int s;
    int i, j;

    scanf("%d", &s);

    if(s <= 2)
        printf("0\n");
    else{
        unsigned long int result = 0;
        double result2 = 0.0;
        for(i = 1; i <= (s / 3); i++){
            int r = s - i * 3;
//            unsigned long int h = (unsigned long int) 1;
            double h = 1.0;

            if(r == 0){
                result2 +=  1.0;
            }
            else{
                for(j = 1; j <= r; j++){
                    h *= (double) (j + i - 1) / (double)j;
                }
//
//                for(j = 1; j <= r; j++){
//                    h /= (unsigned long int) j;
//                }
                result2 += h;
            }
            result = (unsigned long int)result2 % (unsigned long int)(1e9 + 7);
        }
        printf("%ld\n", result);
    }




    return 0;
}