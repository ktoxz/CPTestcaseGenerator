#include <bits/stdc++.h>
using namespace std;
long long n;
long long a[1100000],b[1100000];
long long maxn[3],minx[3] = {0,1100000000,1100000000};
int main()
{
	cin >> n;
	for(int i=1; i<=n; i++)
	{
		cin >> a[i] >> b[i];
		if((a[i] > maxn[1] && b[i] > maxn[2]) || (abs(a[i] - minx[1]) + abs(b[i] - minx[2]) > abs(maxn[1] - minx[1]) + abs(maxn[2] - minx[2])))
			maxn[1] = a[i], maxn[2] = b[i];
		if((a[i] < minx[1] && b[i] < minx[2]) || (abs(maxn[1] - a[i]) + abs(minx[2] - b[i]) > abs(maxn[1] - minx[1]) + abs(maxn[2] - minx[2])))
			minx[1] = a[i], minx[2] = b[i];
		//cout << minx[1] << " " << minx[2] << " " << maxn[1] << " " << maxn[2] << endl;
	}
	cout << abs(maxn[1] - minx[1]) + abs(maxn[2] - minx[2]) << endl;
}