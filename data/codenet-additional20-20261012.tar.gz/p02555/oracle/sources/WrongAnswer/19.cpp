#include <cstdio>
#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define REP(i,a,b) for(int i=a;i<b;++i)
#define SIZE 1000002
#define MOD 1000000007

using namespace std;

int main(){
	
	int n;
	cin>>n;
	int val=n/3;

	ll ans=0;
	REP(i,1,val+1){
		int rem = n%i;
		if(rem==0) ans++;
		else if(rem==1) ans+=i;
		else ans+=i*(i-1)/2;
	}
	cout<<ans%MOD;
} 