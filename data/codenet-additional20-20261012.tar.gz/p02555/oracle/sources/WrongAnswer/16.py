a=int(input())
f=3
b=[]
if f<=a-1:
    b.append(1)
for i in range(a):
    if f>=a-1:
        break
    if a-f<3:
        continue
    else:
        b.append(f)
        f+=1
print(len(b)%((10**9)+7))