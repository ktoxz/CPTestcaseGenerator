s = int(input())
mod = 10**9+7
a,b = divmod(s,3)

k = str(3+b)+'3'*(a-1)
n = len(k)

# dp[i][j][l]
# i桁目までみたとき、
# j=0:k未満であることが確定していない。j=1:k未満であることが確定している。
# l:桁和がlである数の個数。
 
dp = [[[0 for _ in range(s+1)] for _ in range(2)] for _ in range(n+1)]
dp[0][0][0] = 1

cnt = 0

for i in range(n):
  for j in range(s+1):
    # k未満であることが確定していれば、i桁目は0～9の数字がとれる。
    for l in range(10):
      if j+l<=s:
        dp[i+1][1][j+l] += dp[i][1][j]
    # k未満であることが確定していない場合、i桁目を0～k[i]-1にすればk未満であることが確定する。
    for l in range(int(k[i])):
      if j+l<=s:
        dp[i+1][1][j+l] += dp[i][0][j]
    # k未満であることが確定していない場合、i桁目をk[i]にすればk未満であることは確定しない。
    if j+int(k[i]) <= s: 
      dp[i+1][0][(j+int(k[i]))] += dp[i][0][j]
# 0が解答にカウントされているので、0の分を除くため-1する。
print((dp[n][0][s]+dp[n][1][s]-1)%mod)
# print(dp)