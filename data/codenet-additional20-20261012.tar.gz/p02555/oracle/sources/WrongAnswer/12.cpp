#include <bits/stdc++.h>
using namespace std;
int main() 
{
	int x,c=1;
	cin>>x;
	if(x<3)
	cout<<"0";
	else for(int i=3;i<=x-3;i++){ 
	c=c+1;
	cout<<c;
	} 
	return 0;
 } 
