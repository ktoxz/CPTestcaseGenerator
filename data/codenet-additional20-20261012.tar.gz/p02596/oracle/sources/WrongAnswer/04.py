K = int(input())
s = 7
if K % 2 == 0:
    ans = -1
else:
    for i in range(1, 7):
        if s % K == 0:
            ans = i 
            break
        else:
            ans = -1

        s += 7 * (10 ** i)


print(ans)