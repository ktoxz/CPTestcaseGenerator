#include "bits/stdc++.h"
using namespace std;
int main(){
    int N;
    string C;
    cin >> N >> C;
    auto b=C.begin();
    cout << count(b,b+count(b,C.end(),'R'),'W');
}