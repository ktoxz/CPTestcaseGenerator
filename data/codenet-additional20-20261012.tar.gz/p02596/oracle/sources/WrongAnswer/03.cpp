#include <iostream>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <stack>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <cctype>
#include <functional>
#include <string>
#include <cstring>
#include <sstream>
#include <deque>
#define fir first
#define sec second
using namespace std;

typedef long long ll;
typedef pair<ll,ll> P;
typedef pair<P,int> Q;

const int inf1=2e9+9;
const ll inf2=8e18+9;
const ll mol=1e9+7;
const int maxn=1e6+9;
const ll maxx=1e12+9;

int k;
int vis[maxn];

int main()
{
    cin>>k;
    int num=7,cnt=1;
    while(!vis[num]&&num) vis[num]=1,cnt++,num=(num*10+7)%k;
    if(!num) cout<<cnt<<endl;
    else cout<<-1<<endl;
}
