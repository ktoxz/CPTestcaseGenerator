def Repsept():
    
    num = int(input())

    mod_value = 1

    count = 1

    if num % 2 != 0:

        while mod_value != 0:
            value = 7*(pow(10, count)-1)/9
            
            mod_value = value % num

            if mod_value != 0:
                count = count + 1

                if count >= 300:
                    break

        if count < 300:
            print(count)
        
        else:
            print(num-1)
        
    else:
    
        print(-1)

if __name__ == '__main__':
    Repsept()

