K = int(input())
if K % 10 in [2,4,5,8,0]:
    print(-1)
else:
    sevens = [int(("7"*i)) % K for i in range(1,K)]
    try:
        print(sevens.index(0))
    except Exception as e:
        print(-1)