#include <stdio.h>
int fact(int n){
  if (n==1)
  return 1;
  else
  return n*fact(n-1);
}

int main(void)
{
fact(1000000);
return 0;
}
