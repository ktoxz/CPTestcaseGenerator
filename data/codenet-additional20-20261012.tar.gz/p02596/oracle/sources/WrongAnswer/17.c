#include <stdio.h>

int main(void)
{
  int i, n;
  int no = -1;

  int c[] = {7, 77, 777, 7777, 77777, 777777, 7777777, 77777777, 777777777};

  scanf("%d", &n);

  i = 0;

  while(i < 9) {
    if ((c[i] % n) == 0)
      no = i + 1;
    i++;
  }
  printf("%d\n", no);

  return 0;
}