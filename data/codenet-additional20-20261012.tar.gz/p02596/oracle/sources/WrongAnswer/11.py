T=int(input())
if T%7==0:
  K=T/7
else: K=T
A=int(10%K)
cnt=1
while A != 1:
  cnt+=1
  A=int((10*A)%K)
print(int(cnt))