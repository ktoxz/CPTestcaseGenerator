#include <stdio.h>

int main() {
	
	int k;
	scanf("%d", &k);
	
	// R_n: repunit数
	// 7R_n は2, 5の倍数でない
	if (k % 2 == 0 || k % 5 == 0)
	{
		printf("-1");
		return 0;
	}
	
	int a = 0, n; // a = a[0]
	
	for (n = 1; n < k; n++)
	{
		a = (10 * a + 7) % k; //a[n]
		if (a == 0)
		{
			printf("%d", n);
			return 0;
		}
		
	}
	
	return 0;
}

