
// Problem : C - Repsept
// Contest : AtCoder - AtCoder Beginner Contest 174
// URL : https://atcoder.jp/contests/abc174/tasks/abc174_c
// Memory Limit : 1024 MB
// Time Limit : 2000 ms
// Powered by CP Editor (https://github.com/cpeditor/cpeditor)

#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define endl '\n'
int main()
{
	ll i,j,k,m,n,t;
	cin>>n;
	{
		ll r=7;
		ll ctr=1;
		map<ll,ll> mp;
		while(r!=0)
		{
			r=r*10+7;
			r%=n;
			if(mp[r])
			{
				ctr=-1;
				break;
			}
			mp[r]++;
			ctr++;
		}
		cout<<ctr<<endl;
	}
}