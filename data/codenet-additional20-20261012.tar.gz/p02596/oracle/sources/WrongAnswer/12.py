import math
import time

K = int(input())
start_time = time.time()
seven_number = 0
while True:
    elapsed_time = time.time() - start_time
    seven_number = seven_number*10+7
    target_number = math.gcd(K,seven_number)
    if elapsed_time > 1:
        print("-1")
        break
    elif target_number == 1:
        continue
    else:
        print(len(str(seven_number)))
        break

