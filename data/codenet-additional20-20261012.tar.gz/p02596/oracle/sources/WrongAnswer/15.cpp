#include <iostream>
#include <cmath>
#include <string>
 
int main()
{
	long long int K, seven = 7;
	int ans = 1;
	std::cin >> K;
	while (seven % K != 0 && ans < K)
	{
		seven =(seven * 10 + 7)% K;
		ans++;
	}
	std::cout << (ans > 0 ? ans : -1) << std::endl;
	return 0;
}