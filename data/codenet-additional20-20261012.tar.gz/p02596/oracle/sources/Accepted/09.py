K=int(input())
t=0
for i in range(K+2):
  t=(10*t+7)%K
  if t%K==0:
    ans=i+1
    break
else:
  ans=-1
print(ans)