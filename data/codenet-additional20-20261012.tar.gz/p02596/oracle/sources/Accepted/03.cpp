#include<bits/stdc++.h>
using namespace std;

int main()
{
	int k;
  	cin>>k;
  	if((k%2)==0)
    {
      cout<<-1<<endl;
      return 0;
    }
  	if((k%7)==0)k/=7;
    int a=(9*k);
    int count=1;
    for(int i=2;((long long)i*i)<=a;i++)
    {
		if((a%i)==0)
        {
          int c=0;
          while(a%i==0)
          {
            c++;
            a/=i;
          }
          count*=(c+1);
        }
      	
    }
    if(a>1)count*=2;
  	count--;
  int p=10;
  a=(9*k);
  int ans=-1;
  int lim=(9*k)-count;
  for(int i=1;i<=lim;i++)
  {
    if((p%a)==1)
    {
      ans=i;
      break;
    }
   	p=(p*10)%a;
  }
  cout<<ans<<endl;
    return 0;
}