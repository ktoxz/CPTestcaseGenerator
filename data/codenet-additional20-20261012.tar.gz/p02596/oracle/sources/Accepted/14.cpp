#include <bits/stdc++.h>
#define ll long long
#define IOS std::ios::sync_with_stdio(false); cin.tie(0);
#define rep(i, init, n) for (int i = init; i < n; i++)
#define pb push_back
#define mp make_pair
#define mt make_tuple
#define F first
#define S second
#define gcd __gcd
using namespace std;
const ll mod = 1e9 + 7;
const int N = 2e5 + 1;
const ll MOD = 998244353;

ll POW(ll base, ll exponent){
    ll result = 1;
    while (exponent > 0)
    {
        if (exponent % 2 == 1)
            result = (result * base) % mod;
        exponent = exponent >> 1;
        base = (base * base) % mod;
    }
    return result;
}
 
ll Inv(ll x){
    return POW(x, mod - 2);
}
 
/*void DFS(int src){
    visited[src] = 1;
    for(auto i : g[src]){
        if(!visited[i]){
            int mn = min(i, src), mx = max(i, src);
            pair<int, int> p = mp(mn, mx);
            bool ok = 0;
            typedef multimap<pair<int, int>, int>::iterator it;
            pair<it, it> result = Mp.equal_range(p);
            for(it j = result.F; j != result.S; j++){
                if((j -> S) <= R and (j -> S) >= L){
                    ok = 1;
                    break;
                }
            }
            if(ok) DFS(i);
        }
    }
}
 
void BFS(int s){
    dist[s] = 0;
    queue<int> Q;
    Q.pb(s);
    while (!Q.empty()){
        int v = Q.front();
        Q.pop();
        for (auto to : edge[v]){
            if(!par[v] or (par[v] and s.find(mp(mp(par[v], v), to)) == s.end())){
                if(dist[to] > dist[v] + 1) dist[to] = dist[v] + 1, Q.pb(to), par[to] = v;
            }
        }
    }
}

int dijkstra(int n){
    set<pair<int, int>> setds;
    vector<int> dist;
    dist.resize(n + 1, INT_MAX);
    setds.insert(mp(0, 1));
    dist[1]=0;
    while(!setds.empty()){
        pair<int, int> pu = *(setds.begin());
        setds.erase(setds.begin());
        int u = pu.S;
        vector<pair<int, int>> &temp = edge[u];
        for(int i = 0; i < (int)temp.size(); i++){
            int v = temp[i].F;
            int w = temp[i].S;
            if(dist[u] + w < dist[v]){
                if(dist[v] != INT_MAX)
                    setds.erase(setds.find(mp(dist[v], v)));
                dist[v] = dist[u] + w;
                setds.insert(mp(dist[v], v));
            }
        }
    }
    return dist[n];
}
void DFS_Mat(int x, int y){
    visited[x][y] = 1;
    dp[x][y] = 0;
    if(x + 1 == ca) return;
    if(x + 1 < ca){
        if(s[x + 1][y] == s[x][y]){
            if(!visited[x + 1][y]) DFS_Mat(x + 1, y);
            dp[x][y] = (dp[x][y] + dp[x + 1][y]) % mod;
        }
        if(y + 1 < n and s[x + 1][y + 1] == s[x][y]){
            if(!visited[x + 1][y + 1]) DFS_Mat(x + 1, y + 1);
            dp[x][y] = (dp[x][y] + dp[x + 1][y + 1]) % mod;
        }
        if(y - 1 >= 0 and s[x][y] == s[x + 1][y - 1]){
            if(!visited[x + 1][y - 1]) DFS_Mat(x + 1, y - 1);
            dp[x][y] = (dp[x][y] + dp[x + 1][y - 1]) % mod;
        }
    }
    if(x - 1 >= 0){
        if(s[x - 1][y] == s[x][y] and !visited[x - 1][y]){
            DFS_Mat(x - 1, y, x, y);
            b = dp[x - 1][y];
        }
        else if(s[x - 1][y] != s[x][y] and !visited[x - 1][y]){
            DFS_Mat(x - 1, y, x, y);
            b = 1 + dp[x - 1][y];
        }
    }
    if(y + 1 < m){
        if(s[x][y + 1] == s[x][y] and !visited[x][y + 1]){
            DFS_Mat(x, y + 1);
            c = dp[x][y + 1];
        }
        else if(s[x][y + 1] != s[x][y] and !visited[x][y + 1]){
            DFS_Mat(x, y + 1);
            c = 1 + dp[x][y + 1];
        }
        else if(visited[x][y + 1]){
            if(s[x][y] != s[x][y + 1]) c = 1 + dp[x][y + 1];
            else c = dp[x][y + 1];
        }
    }
    if(y - 1 >= 0){
        if(s[x][y - 1] == s[x][y] and !visited[x][y - 1]){
            DFS_Mat(x, y - 1, x, y);
            d = dp[x][y - 1];
        }
        else if(s[x][y - 1] != s[x][y] and !visited[x][y - 1]){
            DFS_Mat(x, y - 1, x, y);
            d = 1 + dp[x][y - 1];
        }
    }
}*/

int main(){
    IOS
    int t;
    //cin>>t;
    t = 1;
    while(t--){
        int k, r = 0, f = 0;
        cin>>k;
        set<int> s;
        while(1){
            r = ((r * 10) % k + 7 % k) % k;
            if(!r){
                f = 1;
                break;
            }
            if(s.find(r) != s.end()) break;
            s.insert(r);
        }
        if(f) cout<<s.size() + 1<<'\n';
        else cout<<-1<<'\n';
    }
    return 0;
}