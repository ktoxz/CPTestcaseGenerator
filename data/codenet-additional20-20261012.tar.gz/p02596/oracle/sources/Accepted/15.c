#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define MAX 1000001

//int solve(int data[],int size);

int main()
{
    int k,ans=0;
    int i,j;
    int a=7;
	scanf("%d",&k);
	for(i=1;i<=MAX;i++)
    {
	    a=a%k;
	    if(a==0)break;
	    else a=a*10+7;
    }
	if(i>1000000)i=-1;
	printf("%d",i);
}
