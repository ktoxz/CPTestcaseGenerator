k = int(input())

ans = 1
used = [False]*k
now = 7%k
pow7 = 7
while not used[now]:
    if now == 0:
        print(ans)
        exit()
    used[now]=True
    pow7 = (pow7*10)%k
    now = (now+pow7)%k
    ans+=1
print(-1)

