#include <bits/stdc++.h>
using namespace std;

int main() {
	ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int k;
    cin>>k;
    
    int s=7%k;
    int c=1;
    while(s!=0 && c<=2e6){
            s = ((s * 10) + 7)%k;
            c++;
    }

     cout<<(s ? -1 : c);
	return 0;
}
