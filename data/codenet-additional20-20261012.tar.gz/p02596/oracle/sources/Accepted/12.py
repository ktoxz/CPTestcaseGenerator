def main(k):
    r0 = 7 % k
    if r0 == 0:
        print(1)
        return
    if k % 2 == 0 or k % 5 == 0:
        print(-1)
        return
    rs = [r0]
    while True:
        ri = (10 * rs[-1] + r0) % k
        if ri == 0:
            break
        rs.append(ri)
        if len(rs) >= 3 and rs[-1] == rs[-2] == rs[-3]:
            print(-1)
            return
    print(len(rs) + 1)


main(int(input()))