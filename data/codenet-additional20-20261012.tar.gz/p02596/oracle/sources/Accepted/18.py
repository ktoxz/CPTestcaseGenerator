from itertools import count

k = int(input())
if k % 2 == 0 or k % 5 == 0:
    print(-1)
else:
    m = 0
    for i in count(0):
        m += pow(10, i, k) * 7
        m %= k
        if m == 0:
            print(i+1)
            break
