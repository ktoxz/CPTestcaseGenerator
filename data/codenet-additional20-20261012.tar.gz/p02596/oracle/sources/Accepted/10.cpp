#include <bits/stdc++.h>
#include <math.h>
#define ALL(a)    a.begin(), a.end() 
#define rep(i, K, N)  for(long long int i = K; i < N; i++)
#define ll long long int
using namespace std;

#include <bits/stdc++.h>
#include <math.h>
#define ALL(a)    a.begin(), a.end() 
#define rep(i, K, N)  for(long long int i = K; i < N; i++)
#define ll long long int
using namespace std;

int main (){
ll K, Ans = 1;cin >> K;
ll n = 0;
map<ll, ll> M;

while(1){

    n*=10;n+=7;n%=K;M[n]++;

    if(n == 0){cout << Ans;exit(0);}

    if(M[n] == 2)break;

    Ans++;
}
cout << -1;
}