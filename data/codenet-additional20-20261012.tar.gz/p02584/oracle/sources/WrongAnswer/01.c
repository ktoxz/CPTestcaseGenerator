#include <stdio.h>
#include <math.h>

int main(void)
{
  long long int a, b, c, x, k, d, m = 0;
  
  scanf("%lld %lld %lld", &x, &k, &d);

  
  if( x < 0 ){
      m = 1;
      x *= -1;
  } 
  
  if( x >= k*d ){
      printf("%lld\n", x-k*d);
      return 0;
  }
  
  a = x % d;
  b = d - a;
  if( a < x ){
      k -= ( x - a ) / 3;
  }
  
  if( k % 2 == 1 ){
      printf("%lld\n", b);
  } else {
      printf("%lld\n", a);
  }
  
  return 0;
}