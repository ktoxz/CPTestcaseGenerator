x, k, d = map(int, input().split())
r = x % d
q = (x - r) // d
if k%2 == q%2:
  ans = r
else:
  ans = d - r
print(ans)