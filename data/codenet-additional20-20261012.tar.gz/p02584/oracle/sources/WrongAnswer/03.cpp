#include <bits/stdc++.h>
#define ll long long
#define ALL(x) x.begin(),x.end()
#define MOD (1000000000+7)
using namespace std;
#define PI 3.14159265359
#define tMOD 998244353
#define mkpr(x,y) make_pair(x,y)


int main(){
 ll X,K,D;
 cin>>X>>K>>D;

 ll nc=0;
ll ans=abs(X);
 if(X>=0&&K*D<=X){
   cout<<abs(X-K*D);
   return 0;
 }
  if(X<0&&K*D<=(-1)*X){
   cout<<abs(X+K*D);
   return 0;
 }

 ll P=X/D;

ll mmde=10000000000000000;
ans =mmde;
 for(ll i=-30;i<30;i++){
if(P-i<0||P+i>K)
continue;

if((K-(P-i))%2==0){
ans = min(ans,abs(X-(P+i)*D));
}
else{
  ans = min(ans,abs(X-(P+i)*D)+D);
   ans = min(ans,abs(abs(X-(P+i)*D)-D));
}




 }

 







  cout<<ans<<endl;
  }








