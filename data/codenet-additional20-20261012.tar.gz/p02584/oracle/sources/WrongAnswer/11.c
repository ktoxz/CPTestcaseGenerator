#include <stdio.h>
#include <stdlib.h>

int main(){
  
  long x,k,d;
  scanf("%d%d%d",&x,&k,&d);
  long i;
  for(i = 0;i < k;i++){
      if(x > 0){
          x + d;
      }
      else{
          x - d;
      }
  }
  printf("%d",labs(x));
  
  
    
}