x,k,d=[int(i) for i in input().split()]

x=abs(x)

t=x

if k%2==1:
    t-=d
    k-=1

min=abs(t)

if t-k*d>0:
    print(t-k*d)
    exit(0)

if t-k*d<0:
    s=(x/(d*2))*2
    k-=s
    t-=d*s

while(-x<t and k>0):
    t-=d*2
    k-=2
    if min < abs(t):
        break
    else:
        min=abs(t)

print(min)
