#include<iostream>
#include<algorithm>
#include<string>

int main(){
  long long x, d, k;
  std::cin >> x >> d >> k;
  long long ps = x%d;
  long long least = std::min(ps, d - ps);
  long long reach = (x-ps)/k;
  if(ps!=0){
  if(k > (reach+1)){
    std::cout << least;
  }else if(k == (reach+1)){
    if(least != ps){
      std::cout << ps;
    }else{
      std::cout << least;
    }
  }else{
    std::cout << x-k*d;
  }
  }else{
    if(k >= reach){
      if((k-reach)%2==0){
        std::cout << 0;
      }else{
        std::cout << d;
      }
    }else{
      std::cout << x-k*d;
    }
  }
  std::cout << "\n";
  return 0;
}