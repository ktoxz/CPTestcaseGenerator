import sys

line = sys.stdin.readline()

arr = line.rstrip().split(" ")
x = int(arr[0])
k = int(arr[1])
d = int(arr[2])

max = x // d

if k < max:
    print( x - ( k * d ) )
    sys.exit()

maxv = x % d

if 0 == (k - max) % 2:
    print(maxv)
    sys.exit()


maxnv = d - maxv
print(maxnv)