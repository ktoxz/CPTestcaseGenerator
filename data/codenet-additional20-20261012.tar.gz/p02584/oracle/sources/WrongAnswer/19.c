#include<stdio.h>
#define abs(opr) ((opr)<0?-(opr):(opr))

int main(void){
    long long x,k,d;
    scanf("%lld %lld %lld",&x,&k,&d);
    long long distc = x / d; 
    if(abs(distc) >= k)
        printf("%lld",((abs(distc) - k) * (distc / abs(distc)))*d + x % d);
    else printf("%lld",k%2==distc%2?x%d:d-abs(x%d));
}