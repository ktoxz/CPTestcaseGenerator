X,K,D = map(int, input().split())
tm = round(X/D)
if K <= tm:
  print(abs(X+D*K)if abs(X+D*K) < abs(X-D*K)else abs(X-D*K))
else:
  if (K-tm)%2==1:
    print(abs(X-D*(tm+1)) if abs(X-D*(tm+1)) < abs(X-D*(tm-1))else abs(X-D*(tm-1)))
  else:
    print(abs(X+D*K)if abs(X+D*K) < abs(X-D*K)else abs(X-D*K))