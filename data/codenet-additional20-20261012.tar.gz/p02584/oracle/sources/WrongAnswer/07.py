X,K,D = map(int, input().split())
for i in range(K):
    if abs(X)<(D/2):
        break
    if X>=0:
        X -= D
    else:
        X += D
    if abs(X)<=D/2:
        break
x = abs(X)
print(x)