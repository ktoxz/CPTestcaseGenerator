#include<stdio.h>
#include<stdlib.h>
#include<string.h>

long long int absolute(long long int a) {
	if(a > 0) {
		return a;
	} else {
		return -a;
	}
}

int main(void) {
	int i;
	long long int X, K, D;
	char buf[256], *ch;

	fgets(buf, sizeof(buf), stdin);
	ch = strtok(buf, " ");
	X = atoll(ch);
	ch = strtok(NULL, " ");
	K = atoll(ch);
	ch = strtok(NULL, " ");
	D = atoll(ch);

	X = absolute(X);

	if(K < (X / D)) {
		printf("%lld\n", (X - (K * D)));
	} else if((K - (X / D)) % 2 == 0) {
		printf("%lld\n", (X % D));
	} else {
		printf("%lld\n", absolute(D - (X % D)));
	}

	return 0;
}
