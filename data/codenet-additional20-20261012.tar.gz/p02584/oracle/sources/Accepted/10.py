def main():
    x, k, d = [int(e) for e in input().split()]

    x = abs(x)
    if d >= x:
        if k % 2 == 0:
            print(x)
        else:
            print(d - x)
    else:
        if k > x // d:
            if k % 2 == (x // d) % 2:
                print(x % d)
            else:
                print(d - x % d)
        else:
            print(x - k * d)


if __name__ == '__main__':
    main()
