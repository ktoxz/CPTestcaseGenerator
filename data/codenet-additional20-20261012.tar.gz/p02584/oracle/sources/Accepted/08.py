line = input()

strL = line.split()
X = abs(int(strL[0]))
K = int(strL[1])
D = int(strL[2])

mod = X % D
div = int(X / D)

if div > K:
    ans = X - K * D
elif (K - div) % 2 != 0:
    ans = mod - D
else:
    ans = mod

print(abs(int(ans)))