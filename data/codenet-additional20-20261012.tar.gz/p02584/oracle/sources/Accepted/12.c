#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>
long f(long X, long K, long D)
{
    {
        long tmp = ((labs(X) / D) > K ? K : labs(X) / D);
        X -= tmp * D;
        K -= tmp;
    }
    if (K %2== 1)
    {
        X -= D;
    }

    return labs(X);
}
int main(void)
{
    long X, K, D;
    scanf("%li %li %li", &X, &K, &D);
    X = labs(X);

    printf("%li\n", f(X, K, D));
}