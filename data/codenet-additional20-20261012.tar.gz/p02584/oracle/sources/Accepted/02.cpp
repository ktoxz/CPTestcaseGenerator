#include <bits/stdc++.h>
using namespace std;

int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  long long x, k, d;
  cin >> x >> k >> d;
  long long res;
  if (x < 0) {
    // x + d * k >= 0
    long long nk = -x / d;
    if (x + d * nk < 0)
      ++nk;
    if (nk > k)
      res = x + d * k;
    else {
      long long rem = nk - k;
      if (rem % 2 == 0)
        res = x + d * nk;
      else
        res = x + d * (nk - 1);
    }
  } else {
    // x - d * k <= 0
    long long nk = x / d;
    if (x - d * nk > 0)
      ++nk;
    if (nk > k)
      res = x - d * k;
    else {
      long long rem = nk - k;
      if (rem % 2 == 0)
        res = x - d * nk;
      else
        res = x - d * (nk - 1);
    }
  }
  cout << abs(res) << '\n';
  return 0;
}