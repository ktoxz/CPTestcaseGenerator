data = input().split(" ")
x0 = int(data[0])
k  = int(data[1])
d  = int(data[2])

const = x0 - k*d
if const >= 0:
  print(const)
else:
  ii = int(abs(const)/(2*d))
  if ii >= k:
    print( abs(const+2*d*(k)) )
  else:
    x_1 = abs(const+2*d*(ii-1))
    x_2 = abs(const+2*d*(ii))
    x_3 = abs(const+2*d*(ii+1))
    x = [x_1,x_2,x_3]
    x.sort()
    print(x[0])