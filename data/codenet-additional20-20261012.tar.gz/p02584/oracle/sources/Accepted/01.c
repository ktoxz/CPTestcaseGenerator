#include <stdio.h>
int main(void){
    // Your code here!
    long long int x, k,kk, dd, d, i, ii, tmp = 0;
    scanf("%lld%lld%lld", &x, &k, &d);
    if (x < 0)
        x *= -1;
    kk = k; dd = d;
    while (kk > 0)
    {
        kk /= 10;
        tmp++;
    }
    while (dd > 0)
    {
        dd /= 10;
        tmp++;
    }
    if (x > k * d && tmp < 18)
        printf("%lld", x - k * d);
    else if ((k - x / d) % 2)
        printf("%lld", d - x % d);
    else
        printf("%lld", x % d);
}
