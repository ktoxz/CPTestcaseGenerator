#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
//if(strcmp(s[i],"AC")==0)
//if(s[l]=='#')
/*小文字判定
if((moji>= 'a') && (moji<='z')){
    printf("a\n");
    return 0;
  }
  */

int W_Length(char *str){
	int length = 0;
	while(*str++ != '\0')
		length++;
	return length;
}

void swap(int *a, int *b){
  int temp;
  temp=*a;
  *a=*b;
  *b=temp;
}
//swap(&a, &b)

double deg(double theta){//deg to theta
return theta*(2*3.14159265359)/360;
}

int cmp( const void *p, const void *q ) {
    return *(int*)p - *(int*)q;
}//ちいさい順
//qsort(a,n,sizeof(int),cmp);
//char s[n][11]

int cmp_s(const void * left, const void * right)
{
	char *left_char = (char *)left;
  char *right_char = (char *)right;
  return strcmp(left_char, right_char);
}
//qsort(s,n,sizeof(s[0]),cmp_s);


int main (void)
{
	long long int a,k,d,b,c,n,i,x,temp;
  char s[200005];

scanf("%lld %lld %lld",&x,&k,&d);
  //printf("x=%lld, k=%lld, d=%lld",x,k,d);
  if(x<=-1){
  x=-x;
  }
  
    temp=x/d;
  if(x>d){
    if(temp>=k){
      
      if(x-k*d<0){
    printf("%lld\n",-x+k*d);
      return 0;
    }
      
    printf("%lld\n",x-k*d);
      return 0;
    }
  }
  
    k=k-temp;
  
  if(k%2==0){
    if(x-d*temp<0){
    printf("%lld\n",-x+d*temp);
      return 0;
    }
  printf("%lld\n",x-d*temp);
    return 0;
  }
  else{
    if(d*(temp+1)-x<0){
    printf("%lld\n",-d*(temp+1)+x);
      return 0;
    }
  printf("%lld\n",d*(temp+1)-x);
    //printf("k=%lld, temp=%lld, x=%lld",k,temp,x);
    return 0;
  }
	
return 0;
}
