X, K, D = map(int, input().split())

if X >= 0:
    num = min(K, X//D)
    X -= num*D
    K -= num
    if K%2:
        X -= D
else:
    num = min(K, abs(X)//D)
    X += num*D
    K -= num
    if K%2:
        X += D

print(abs(X))
