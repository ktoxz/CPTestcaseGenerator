#include<bits/stdc++.h>
  
#define lol long long
#define gcd(x,y) __gcd(x,y)
#define mt make_tuple
#define mp make_pair
#define fi first
#define se second
#define fixed(x) fixed<<setprecision(x)
using namespace std;
using pii=pair<int,int>;
template <class A, class B> inline bool chmax(A &a, const B &b) { return b > a && (a = b, true); }
template <class A, class B> inline bool chmin(A &a, const B &b) { return b < a && (a = b, true); }
template <class A> inline A abs(A &a) { return (a < 0 ? -a : a); }
bool inLine(int x,int y,int mx,int my){return (x>=0&&y>=0&&x<mx&&y<my);}
const lol inf=(1LL<<62);
const lol MOD=(1e9)+7;
const lol mod=998244353;
const int dx[]={1,0,-1,0,1,1,-1,-1};
const int dy[]={0,1,0,-1,1,-1,1,-1};
signed main(){
  cin.tie(0);
  ios::sync_with_stdio(false);
  lol x,k,d;
  cin >>x>>k>>d;
  lol ans=inf;
  chmin(ans,abs(abs(x)-k*d));
  x=abs(x);
  if(x/d<=k){
    k-=x/d;
    x-=d*(x/d);
    
  }else{
    x-=d*k;
    k=0;
  }
  if(k&1){
    chmin(ans,x+d);
    chmin(ans,abs(x-d));
  }else {
    chmin(ans,x);
  }
  cout <<ans<<'\n';

  return(0);
}