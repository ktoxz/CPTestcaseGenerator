#include <stdio.h>

int main(void){
  long int n = 0;
  long int k = 0;
  long int a = 0;
  long int sum = 0;
  long int prd = 0;
  
  scanf("%ld", &n);
  scanf("%ld", &k);
  
  for(int i = 0; i < n; i++){
    scanf("%ld", &a);
    sum += a;
  }
  prd = sum / (n + k);
  printf("%ld", prd);
  
  return 0;
}