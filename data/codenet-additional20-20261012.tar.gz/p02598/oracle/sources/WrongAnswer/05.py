rule=input().split()
N=int(rule[0])
K=int(rule[1])
data=input().split()
ans=0
for i in range(len(data)):
    ans+=int(data[i])
import math
print(math.ceil(ans/(K+1)))