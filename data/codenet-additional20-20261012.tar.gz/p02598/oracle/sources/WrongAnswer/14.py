import sys
import re
import math
import collections
import bisect
import itertools
import fractions
import functools
import copy
import heapq
import decimal
import statistics
import queue

# import numpy as np

sys.setrecursionlimit(10 ** 9)
INF = 10 ** 16
MOD = 10 ** 9 + 7
# MOD = 998244353

ni = lambda: int(sys.stdin.readline())
ns = lambda: map(int, sys.stdin.readline().split())
na = lambda: list(map(int, sys.stdin.readline().split()))
na1 = lambda: list(map(lambda x: int(x) - 1, sys.stdin.readline().split()))


# ===CODE===


def main():
    n, k = ns()
    a = na()
    a.sort(reverse=True)
    upper = 10 ** 9 + 1
    under = 0

    ans = max(a)
    while upper - under > 0.001:
        middle = (upper + under) / 2

        tmp_max = 0
        tk = k
        flg = True
        for ai in a:

            ta = ai
            cnt = 1
            while ta > middle:
                ta /= 2
                tk -= cnt
                cnt *= 2
                if tk < 0:
                    flg = False
                    break

        if flg:
            upper = middle
        else:
            under = middle

    print(int(under))


if __name__ == '__main__':
    main()
