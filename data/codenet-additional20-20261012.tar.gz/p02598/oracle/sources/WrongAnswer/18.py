from heapq import heappush, heappop, heapify
import math
def solve():
	n , k= map(int, input().strip().split())
	if k >= 10*7:
		return 1
	a= [(-int(x),1,int(x)) for x in input().strip().split()]
	heapify(a)
	for i in range(k):
		x,cnt,orig = heappop(a)
		x = -x
		if x <= 1:
			return 1
		heappush(a,(-((orig+cnt)//(cnt+1)),cnt+1,orig))
	return -(heappop(a)[0])
 
 
print(solve())