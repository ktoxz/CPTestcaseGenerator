from collections import Counter
import heapq
from math import ceil

N,K = list(map(int,input().split()))
A = list(map(lambda x: -int(x),input().split()))
counter = Counter(A)
A = []
for key in counter.keys():
    heapq.heappush(A,(key,counter[key]))

if 10**6 < K:
    print(1)
else:
    while 0 < K:
        m = heapq.heappop(A)
        heapq.heappush(A,(m[0]*m[1]/(m[1]+1),m[1]+1))
        K -= 1

# print(A)
print(ceil(-heapq.heappop(A)[0]))