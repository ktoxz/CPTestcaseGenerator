#include <stdio.h>
#include <math.h>
#define max(a, b) ((a) > (b) ? (a) : (b))

int n, k;
int a[200010];
char check(const double n);

int main() {
	scanf("%d%d", &n, &k);
	int sum = 0, maxv = 0;
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a[i]);
		sum += a[i], maxv = max(maxv, a[i]);
	}
	
	double l = sum * 1.0 / (n + k), r = maxv;
	while (round(l + 1e-10) < round(r - 1e-10)) {
		double m = (l + r) / 2;
		if (check(m))
			r = m;
		else
			l = m;
	}
	printf("%d\n", (int)round(l + 1e-10));
	return 0;
}

char check(const double m) {
	int sum = 0;
	for (int i = 0; i < n; ++i)
		sum += ceil(a[i] / m);
	return sum <= n + k;
}

