#include<bits/stdc++.h>
#define ll long long int

using namespace std;

const ll mod=1000000007;
const ll inf=1e18;

int main(){

  ll n,k;
  cin >> n>> k;
  double a[n];
  for(ll i=0;i<n;i++)cin >> a[i];
  priority_queue<pair<double,ll>, vector<pair<double,ll>>, less<pair<double,ll>>> b;
  ll c[n]={};
  for(ll i=0;i<n;i++)b.push({a[i],i});

  for(ll i=0;i<k;i++){
    pair<double,ll> v=b.top();
    b.pop();
    v.first=v.first/2;
    c[v.second]++;
    b.push(v);
  }

  for(ll i=0;i<n;i++){
    if(c[i]!=0)a[i]/=(c[i]+1);
  }

  double m=0;
  for(ll i=0;i<n;i++)m=max(m,a[i]);

  cout << (ll) ceil(m) << endl;


  // printf("%lf",ceil(m)); 


}