//#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <algorithm>
#include <iostream>
#include <iomanip>
#include <utility>
#include <vector>
#include <limits>
#include <cmath>
#include <unordered_map>

typedef long long ll;

typedef struct {
    double length;
    ll div;
} LOG;

int main(int argc, char *argv[])
{
    int n, k;

    std::cin >> n >> k;

    std::vector<LOG> a(n);
    for (int i = 0; i < n; i++) {
        std::cin >> a[i].length;
        a[i].div = 1;
    }

    // 降順ソート
    std::sort(a.begin(), a.end(), [](auto const &lhs, auto const &rhs) {
        return lhs.length > rhs.length;
    });

    while(k > 0) {
        int div_add_longest = k / n;
        if (div_add_longest == 0) {div_add_longest = 1;}
        a[0].div += div_add_longest;
        k -= div_add_longest;
        double part_length_longest = a[0].length / a[0].div;

        for (int i = 1; i < a.size(); i++) {
            if (a[i].length / a[i].div <= part_length_longest) {continue;}

            int new_div = a[i].length / part_length_longest;
            if (a[i].length / new_div > part_length_longest) {new_div++;}

            int div_diff = new_div - a[i].div;
            if (div_diff > k) {
                div_diff = k;
            }

            a[i].div += div_diff;
            k -= div_diff;
            if (k == 0) {break;}
        }
    }

#ifdef _DEBUG
    for (int i = 0; i < a.size(); i++) {
        std::cout << a[i].length << " / " << a[i].div << " = " << (a[i].length / a[i].div) << std::endl;
    }
#endif

    double max = a[0].length / a[0].div;
    for(int i = 1; i < a.size(); i++) {
        max = std::max(max, a[i].length / a[i].div);
    }

    std::cout << static_cast<ll>(std::ceil(max)) << std::endl;

    return 0;
}
