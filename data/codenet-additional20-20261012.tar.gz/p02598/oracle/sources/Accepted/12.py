from math import ceil
n, k, *A = map(int, open(0).read().split())
t = sum(A) / (n+k)
A = [a for a in A if int(a/t) >= 1]
X = []
for a in A:
    X.append(ceil(a / ceil(a/t)))
    X.append(ceil(a / int(a/t)))
X.sort()
print(X[sum(int(a/t)-1 for a in A) -k-1])