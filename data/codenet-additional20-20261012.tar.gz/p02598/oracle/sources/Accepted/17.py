n,k=map(int,input().split())

A=[int(i) for i in input().split()]
CP=A[:]
R=[0 for i in range(n)]

suma=sum(A)
cnt=0
for i in range(n):
    zak=A[i]*k//suma
    R[i]=zak
    cnt+=zak
    A[i]=A[i]/(zak+1)

A=[(-CP[i]/(R[i]+1),CP[i],R[i]) for i in range(n)]

import heapq
import math

heapq.heapify(A)
for i in range(k-cnt):
    now=heapq.heappop(A)
    newr=now[2]+1
    newz=now[1]/(newr+1)
    heapq.heappush(A,(-newz,now[1],newr))

print(math.ceil(-heapq.heappop(A)[0]))