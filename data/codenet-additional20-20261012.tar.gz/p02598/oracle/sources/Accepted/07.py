n,k,*a=map(int,open(l:=0).read().split())
r=10**9
while~l+r:x=l+r>>1;l,r,*_=(l,x,r)[-sum(-b//x+1for b in a)>k:]
print(r)