import math,sys
n,k=map(int,input().split())
a=list(map(int,input().split()))
l=0
r=10**9+2
while math.ceil(l)<math.floor(r):
  tr=(l+r)/2
  temp=0
  for i in range(n):
    temp+=math.ceil(a[i]/tr)-1
  if temp<=k:
    r=tr
  else:
    l=tr
tr=math.ceil(l)
if tr==0:
  print(1)
  sys.exit()
temp=0
for i in range(n):
  temp+=a[i]//tr
  if a[i]%tr==0:
    temp-=1
if temp<=k:
  print(tr)
else:
  print(tr+1)