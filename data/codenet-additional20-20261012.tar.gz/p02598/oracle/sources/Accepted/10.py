_, k = map(int, input().split())
A = [*map(int, input().split())]
ng, ok = 0, 1<<30
while ok - ng > 1:
    m = (ng + ok) // 2
    if k < sum(map(lambda a: (a-1)//m, A)): ng = m
    else: ok = m
print(ok)
