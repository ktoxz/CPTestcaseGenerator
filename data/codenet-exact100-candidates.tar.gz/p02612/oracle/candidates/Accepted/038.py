import math

n = int(input())
n=(n/1000)
c=math.ceil(n)
a=round((c-n)*1000)
print(a)