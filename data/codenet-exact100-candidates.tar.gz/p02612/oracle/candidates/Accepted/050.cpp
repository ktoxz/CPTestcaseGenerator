#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define vl vector<ll>
#define pl pair<ll,ll>
#define TC int t;cin>>t;while(t--)
#define in(n) ll n;cin>>n;
#define inarr(n) ll n;cin>>n;vector<ll>arr;
int main(void){
    ios_base::sync_with_stdio(false);cin.tie(NULL);
    in(n);
    while(n>1000){
        n-=1000;
    }
    cout<<1000-n<<endl;
    return 0;
}