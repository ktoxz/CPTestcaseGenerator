#include <bits/stdc++.h>
using namespace std;

int main() {
	float n;cin >> n;
	n /= 1000;
	float val = (ceil(n) - n)*1000;
	cout << round(val) << "\n";
	return 0;
}