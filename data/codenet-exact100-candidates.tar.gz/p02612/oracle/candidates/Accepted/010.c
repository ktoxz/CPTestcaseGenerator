#include <stdio.h>

int main(void)
{
	int n, ans;

	scanf("%d", &n);

	ans = ((n - 1)/ 1000 * 1000 + 1000) - n;

	printf("%d\n", ans);

	return 0;
}
