#include <stdio.h>
int main() {
  int ans,a,n;
  n=0,
  a=0;
  ans=0;
  scanf("%d",&n);
  for(a=0;a<n;a+1000)
  {
   a=a+1000;
  }
  
  ans=a-n;
  printf("%d",ans);
  return 0;
}

