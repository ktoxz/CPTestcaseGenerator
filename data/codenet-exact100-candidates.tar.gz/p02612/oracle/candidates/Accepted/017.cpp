#include <iostream>
using namespace std;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n; cin >> n;
    int money = 1000;
    while(money < n){
        money += 1000;
    }
    cout << money-n << endl;
    return 0;
}