#include<bits/stdc++.h>
#define endl '\n'

using namespace std;

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int N;
    cin >> N;
    while(N > 0){
        N-=1000;
    }
    cout << -N;
    return 0;
}