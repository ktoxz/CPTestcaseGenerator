#include <iostream>
using namespace std;

int main()
{
    int n, a;
    cin >> n;

    if (n % 1000 != 0)
        a = (n / 1000 + 1) * 1000;
    else
        a = n;

    cout << a - n << endl;
}
