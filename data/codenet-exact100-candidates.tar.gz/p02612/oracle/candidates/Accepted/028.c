#include <stdio.h>

int main(void)
{
	int n ;
	scanf("%d",&n);
	if (n%1000 == 0) printf("%d\n",0);
	else
	printf("%d\n",1000 - n % 1000);
	return 0;
}