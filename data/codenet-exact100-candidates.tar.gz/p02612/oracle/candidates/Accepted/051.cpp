#include<bits/stdc++.h>
using namespace std;
int main()
{
    int N,ans;
    cin>>N;
    ans=1000-(N%1000);
    if(N%1000!=0)
        printf("%d",ans);
    else
        cout<<0;
}
