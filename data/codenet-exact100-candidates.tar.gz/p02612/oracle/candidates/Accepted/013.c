#include<stdio.h>
int main(void)
{
	int	n,a;
	scanf("%d",&n);
	a=n/1000;
	if(n%1000!=0)	{
		a++;
	}
	a=a*1000;
	printf("%d\n",a-n);
	return 0;
}		