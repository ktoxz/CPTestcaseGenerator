//AtCoder Biginner Contest 173 A問題

#include <stdio.h>

int main(void) {
    int n, m;

    scanf("%d", &n);

    m = n % 1000;

    if (m == 0) {
        printf("%d", 0);
    } else {
        m = 1000 - m;
        printf("%d", m);
    }

    return 0;
}
