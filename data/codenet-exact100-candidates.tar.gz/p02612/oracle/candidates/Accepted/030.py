N = int(input())
ans = []
for i in range(1,12):
    ans.append(((i*1000)-N))
print(min([i for i in ans if i >= 0]))