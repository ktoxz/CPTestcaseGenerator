#include <bits/stdc++.h> 
using namespace std; 

#define ll long long
#define endl "\n"
#define M 10000001

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll n;
    cin>>n;
    ll div = n/1000;
    if(n%1000 == 0)
    {
        cout<<0<<endl;
    }
    else
    {
        ll mul = (div+1)*1000;
        cout<<(mul-n)<<endl;
    }
}