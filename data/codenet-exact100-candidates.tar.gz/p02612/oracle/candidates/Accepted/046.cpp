#include<stdio.h>
#include<bits/stdc++.h>
#include<math.h>
using namespace std;

int main()
{
    long long n,k,i,j,t;


   cin>>n;
   while(n>0)
   {
       n=n-1000;
   }
   cout<<-n<<endl;




return 0;

}

