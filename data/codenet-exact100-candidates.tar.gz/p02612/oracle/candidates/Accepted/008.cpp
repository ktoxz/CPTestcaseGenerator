#include <iostream>

main()
{
  int n = 0;
  std::cin >> n;
  
  if(n%1000 == 0)
  {
    std::cout << 0;
  }
  else
  {
    std::cout << (1000 - n % 1000);
  }
}
