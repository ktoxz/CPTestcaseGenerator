#include <bits/stdc++.h>
using namespace std;

int64_t MOD = 1000000007;
double PI = 3.141592653589793;

int main()
{
    int N;
    cin >> N;
    if (N % 1000 != 0)
        cout << 1000 - N % 1000;
    else
        cout << 0;
}