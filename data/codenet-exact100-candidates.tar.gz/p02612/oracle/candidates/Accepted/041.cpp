// Tue Jun 30 14:06:52 IST 2020  
#include <bits/stdc++.h>        
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>
#define forn(ii,a,b)        for(int ii = (int)a ; ii < (int)b  ; ii++ )
#define debug(x)           cerr << #x << " " << x << " -- \n"
#define I__O               ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL)
#define int64              long long    
#define MOD                998244353 
#define pb                 push_back
#define f1                 first 
#define s1                 second    
#define all(x)             (x).begin(),(x).end() 
#define precise(x)         cout << fixed << setprecision(12) << x << '\n'; 
#define tough_nut          numeric_limits<int64>::min()

const double pi = 3.141592653589793238;
using namespace  std ;       
using namespace __gnu_pbds;
 
typedef tree<int,null_type,less<int>,rb_tree_tag,tree_order_statistics_node_update> indexed_set ; 
const int N = 3e5+7; 
const int INF = INT_MAX;
struct comp{
    bool operator()(const pair<int,int> A,const pair<int,int>& B)const{
        if(A.first == B.first)
            return A.second < B.second ;
        return A.first > B.first;
    } 
};    
int tests(){
    int n;
    cin >> n;
    if(n%1000 == 0)
        return cout << 0 << '\n',0;
    cout << 1000-n%1000 << '\n';
    return 0;
}
int32_t main(){
    I__O ;     
    int cases = 1 ;  
    // cin >> cases ;  
    while(cases--) 
        tests(); 
     
    return 0 ; 
}