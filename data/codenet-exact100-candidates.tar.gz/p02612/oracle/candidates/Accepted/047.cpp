#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
typedef long long int ll;
int main(){
  ll N;
  cin>>N;
  ll cont=1000;
  while(cont<N){
    cont+=1000;
  }
  cout<<cont-N;
}