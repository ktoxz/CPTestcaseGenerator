import sys
def input():
    return sys.stdin.readline().rstrip('\n')
    

def calc(N):
    x = N % 1000
    if x == 0:
        return 0
    else:
        return 1000 - x



N = int(input())
print(calc(N))