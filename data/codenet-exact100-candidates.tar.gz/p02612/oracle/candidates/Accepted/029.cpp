#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const long long INF = 1LL << 60; //intじゃ扱えないことに注意！
#define mod 1000000007
#define rep(i, n) for(int i = 0; i < (int)(n); i++) //範囲外参照とループの初期化に注意！

int main() {
 int N;
 cin >> N;
 
 int mon;
 int ans;
 for(int i = 0; i < 10; i++){
   mon += 1000;
   if(mon >= N){
     ans = mon - N;
     break;
   }
 }
 cout << ans << endl;
}