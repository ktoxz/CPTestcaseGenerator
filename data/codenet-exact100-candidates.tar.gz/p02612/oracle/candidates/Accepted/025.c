#include <stdio.h>

int main(void){
  int N = 0;
  int B = 0;
  scanf("%d",&N);
  if(1<=N && N<=10000){
    B = (((N / 1000) + 1) * 1000) - N;
    if(B == 1000){
      B = 0;
      printf("%d\n",B);
    }else{
      printf("%d\n",B);
    }
  }
  return 0;
}
