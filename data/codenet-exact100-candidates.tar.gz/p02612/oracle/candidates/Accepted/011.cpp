#include <iostream>
using namespace std;
int main(int argc, char* argv[])
{
	int N;
	cin>>N;
	while (N>0){
		N-=1000;
	}
	if (N<0){
		N=-N;
	}
	cout<<N<<endl;
	return 0;
}