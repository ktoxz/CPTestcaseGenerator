#include<iostream>
#include<math.h>
#include<algorithm>
#include<stdio.h>
#include<string.h>
#define ll long long
using namespace std;
int n,ans;

inline int read()
{
    int n=0,f=1; char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1; c=getchar();}
	while(c>='0' && c<='9') {n=n*10+c-'0'; c=getchar();}
	return n*f;
}

int main(void)
{
	n=read();
	ans-=n%1000;
	if(ans<0) ans+=1000;
	cout<<ans;
	return 0;
}
