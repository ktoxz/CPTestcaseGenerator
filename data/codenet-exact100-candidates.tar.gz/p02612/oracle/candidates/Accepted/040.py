from math import ceil

n=int(input())
print(ceil(n/1000)*1000-n)