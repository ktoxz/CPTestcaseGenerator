#include <stdio.h>
 
int main(void) {
  int N;
  scanf("%d", &N);
  
  for (int i=0; i<10; i++) {
    if (0<=N && N<=1000) {
      printf("%d",1000-N);
      return 0;
    }
    N -= 1000;
  }
}