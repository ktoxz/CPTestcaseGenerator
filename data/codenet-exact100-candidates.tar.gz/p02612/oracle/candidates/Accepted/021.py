N = int(input())

for i in range(1,11):
    x = 1000 * i - N
    if x < 0:
        continue
    else:
        print(x)
        exit()