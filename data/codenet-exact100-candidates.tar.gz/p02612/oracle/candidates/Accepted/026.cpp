#include <iostream>
using namespace std ;
int main(){
     int n ;
     cin >> n ;
     int f =0 ;
     for (int i=1000 ; ; i=i+1000)
     {
         if(i>=n){
           f=i-n ;
           break ;
           }
     }
     cout << f ;
}