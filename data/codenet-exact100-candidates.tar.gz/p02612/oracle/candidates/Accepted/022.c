#include <stdio.h>
#include<string.h>
#define LENGTH 256

int calculate(int price){
    int charge;
    int i = 0;
    while(1){
        charge = i*1000 - price;
        if(charge>0){
            return charge;
        }else if(charge == 0){
            return charge;
        }else{
            i = i+1;
        }
    }
}
void main() {
        int r,d;
        scanf("%d", &d);
        r = calculate(d);
        printf("%d\n", r);
}
