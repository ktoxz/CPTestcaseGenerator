#include <stdio.h>
 
int main(void) {
    printf("文字列を入力してEnterボタンを押してください\n");
 
    int N;
    scanf("%d", &N);  
    if(N<0 && N<=10001){
        printf("0<=N<=10000の範囲で入力してください。");
        scanf("%d", &N);
        printf("入力された数値は：%d\n", N);
    }
    
    int payment = 1000;
    int i = 1;
    while(N>payment){
        payment = payment + 1000;
        }
    
    printf("%d\n", payment-N);
 
    return 0;
}