#include <bits/stdc++.h>
#include <algorithm>  
#include <unordered_set>

#define ll long long

using namespace std;

int main() {

	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	ll n;

	cin >> n;

	ll x = 1;
	while (x < n) {
		x *= 1000;
	}

	cout << x - n << endl;

	
	return 0;
}