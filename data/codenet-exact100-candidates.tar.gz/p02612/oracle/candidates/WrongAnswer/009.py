def main():
    R, C, K = map(int, input().split())
    grid = []
    for r in range(R):
        grid.append([1 if c == '#' else 0 for c in input()])
                
    n_configs = 0

    for rm in range(2**R):
        for cm in range(2**C):
            nb = 0
            for r in range(R):
                for c in range(C):
                    if ((rm >> r) & 1) == 0 and ((cm >> c) & 1) == 0 and grid[r][c] == 1:
                        nb += 1
            if nb == K:
                n_configs += 1

    print(n_configs, flush=True)
    return
