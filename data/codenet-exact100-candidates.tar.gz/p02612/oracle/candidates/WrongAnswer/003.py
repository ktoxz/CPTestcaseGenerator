in_value = int(input())

while(1):
    in_value %= 1000
    if in_value < 1000:
        print(in_value)
        break
