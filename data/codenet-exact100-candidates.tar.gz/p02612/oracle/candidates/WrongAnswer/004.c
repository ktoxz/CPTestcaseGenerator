#include<stdio.h>
int main(void) {
	int N;
    int c0 = 0, c1 = 0, c2 = 0, c3 = 0;
    scanf("%d", &N);
    for(int i = 0; i < N; i++) {
        char str[4];
    	scanf("%s", str);
    	if(strcmp(str, "AC") == 0)
        	c0++;
        else if(strcmp(str, "WA") == 0)
        	c1++;
        else if(strcmp(str, "TLE") == 0)
        	c2++;
        else if(strcmp(str, "RE") == 0)
        	c3++;
    }
    printf("AC × %d\n", c0);
    printf("WA × %d\n", c1);
    printf("TLE × %d\n", c2);
    printf("RE × %d\n", c3);
}