#include <stdio.h>

int main()
{int a;
scanf("%d",&a);
printf("%d",a%1000-1000);
    return 0;
}