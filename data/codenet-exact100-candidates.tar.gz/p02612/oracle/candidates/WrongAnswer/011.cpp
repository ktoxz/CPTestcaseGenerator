#include<bits/stdc++.h>
using namespace std;
int main(){
    int N,i,ans;
    cin >> N;

    if(N == 0){
        cout << 0 << endl;
        return 0;
    }
    
    int j = N / 1000;
    i = (j + 1) * 1000;

    ans = i - N;
    
    cout << ans << endl;


    return 0;
}