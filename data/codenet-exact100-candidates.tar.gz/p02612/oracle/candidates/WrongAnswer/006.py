N = int(input())
pay = 0
while N>=pay:
  pay+= 1000
  
print(pay-N)