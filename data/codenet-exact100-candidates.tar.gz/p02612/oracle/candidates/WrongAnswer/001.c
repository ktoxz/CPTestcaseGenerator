#include<stdio.h>

int main() {
  int n,counter=0,m=1;
  if(scanf("%d",&n) == 0)
    return 0;
  if(n>10000 || n<0) {
    printf("You have to enter positive number less than 10000\n");
    return 1;
  }
  while (n/m >= 1) {
    counter++;
    m*=10;
  }  
  if (counter<=3)
    printf("%d",1000-n);
  else if (counter==4)
    printf("%d",((n/1000)+1)*1000-n);
  else
    printf("%d",0);
  return 0;
}