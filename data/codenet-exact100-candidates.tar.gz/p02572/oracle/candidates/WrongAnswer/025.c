#include <stdio.h>
#include <stdlib.h>

int main(void){
    int n;

    unsigned long int *a;

    unsigned long int result = 0;

    unsigned long int sum = 0;


    int i;

    scanf("%d", &n);

    a= (unsigned long int*)malloc(sizeof(unsigned long int) * n);

    for(i = 0; i < n; i++){
        scanf("%lu", a + i);
    }

    for(i = 0; i < n; i++){
        sum += a[i];
    }


    for(i = 0; i < n - 1; i++){
        sum -= a[i];
        result += (sum * a[i]) % (unsigned long int)(1e+9 + 7);
        result %= (unsigned long int)(1e+9 + 7);
    }
    printf("%lu\n", result);





    free(a);



    return 0;
}