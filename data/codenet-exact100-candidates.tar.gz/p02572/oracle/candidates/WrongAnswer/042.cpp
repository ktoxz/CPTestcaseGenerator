#define rep(i,n) for (int i=0;i<n;i++)
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007


int main(){
unsigned long n,sum=0,sum2=0;
  cin >> n;
 
  vector <ll> a(n);
  
  rep(i,n){
    cin >> a.at(i);
    sum=(sum+a.at(i))%mod;
  }
  
  rep(i,n){
    if(sum-a.at(i)<0)
      sum=sum-a.at(i)+mod;
    else
      sum=sum-a.at(i);
    sum2=(sum2+(a.at(i)*(sum%mod))%mod)%mod;
  }
  
 cout << sum2 << endl; 
}