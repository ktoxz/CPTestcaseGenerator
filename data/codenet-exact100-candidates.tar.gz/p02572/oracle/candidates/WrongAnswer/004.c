#include <stdio.h>

#define MOD 1000000007

int main() {
  int N = 0;
  unsigned long long int A[200001] = {0};
  unsigned long long int sum = 0,sum2 = 0;

  scanf("%d",&N);
  for(int i=0;i<N;i++) {
    scanf("%I64d",&A[i]);
    if(i != 0){
      sum2 += A[i];
      sum2 %= MOD;
    }
  }

  // for(int i=0;i<N-1;i++){
  //   for(int j=i+1;j<N;j++){
  //     sum += (A[i] * A[j]) % MOD;
  //     sum = sum % MOD;
  //   }
  //   //printf("%d:%I64d\n",i,sum);
  // }
  for(int i=0;i<N-1;i++){
      sum2 -= A[i+1];
      if(sum2 < 0) sum2 += MOD;
      sum += (A[i] * sum2) % MOD;
      sum = sum % MOD;
  }
  printf("%I64d\n",sum);

  return 0;
}
