#include <iostream>

int main()
{
  int n;
  std::cin >> n;
  long long unsigned int a[200000];
  for (int i = 0; i < n; ++i)
  {
    std::cin >> a[i];
  }
  long long unsigned int ans = 0;
  for (int i = 0; i < n-1; ++i)
  {
    long long unsigned int jsum = 0;
    for (int j = i+1; j < n; ++j)
    {
      jsum += a[j];
    }
    ans += a[i] * jsum;
    ans = ans % 1000000007;
  }
  std::cout << ans;
  return 0;
}
