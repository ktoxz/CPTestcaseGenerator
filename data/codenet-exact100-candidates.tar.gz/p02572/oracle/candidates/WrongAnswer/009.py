n = int( input() )

a = list( map(int , input().split() ) )

Sum = 0


for i in range(n):
	for j in range(i+1,n):
		Sum = Sum + i*j

print(Sum)