#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
using namespace std;
int main(){
  int N;
  cin >> N;
  int A[N];
  for(int i=0;i<N;i++){
    cin >> A[i];
  }
  int a,b,sum;
  sum=0;
  for(int j=0;j<N;j++){
    a = A[j];
	for(int k=0;k<N;k++){
      if(k>j) sum += fmod(a*A[k],7+10^9);
      if(sum >= 7+10^9) sum -= 7+10^9;
    }  
  }
   
  if(sum <0) sum *= -1;
  cout << sum << endl;
  return 0;
}