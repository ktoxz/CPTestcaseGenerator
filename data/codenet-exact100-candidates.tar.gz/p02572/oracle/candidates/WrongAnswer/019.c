#include<stdio.h>
int main(void)
{
    long long int n,a[200001],i,j,sum = 0,dekai = 1000000000 + 7,b = 0;
    scanf("%lld",&n);
    for(i = 1 ; i <= n ; i++)
    {
        scanf("%lld",&a[i]);
        b += a[i] % dekai;
        a[i] = a[i] % dekai;
    }
    
    
    
    for(i = 1 ; i < n ; i++)
    {
        sum += (a[i] * (b - a[i])) % dekai ;
        b = b - a[i] ;
    
    }
    sum = sum % dekai;
    while(sum < 0)
    {
        sum += dekai;
    }
    printf("%lld\n",sum);
    return 0;
}