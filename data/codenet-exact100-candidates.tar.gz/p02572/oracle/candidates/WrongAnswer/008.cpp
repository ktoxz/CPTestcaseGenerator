#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <queue>
typedef long long ll;
using namespace std;
ll a[200010];
#define MOD (1000000007)
int main()
{
	int N;
	cin>>N;
	ll sumA = 0;
	for( int i=0; i<N; i++ )
	{
		cin>>a[i];
		sumA = (sumA+a[i])%MOD;
	}
	ll ot = (sumA*sumA)%MOD;
	for( int i=0; i<N; i++ )
	{
		ot = (ot+MOD-(a[i]*a[i])%MOD)%MOD;
	}
	ot = ot/2;
	
	cout << ot << endl;
	
	return 0;
}