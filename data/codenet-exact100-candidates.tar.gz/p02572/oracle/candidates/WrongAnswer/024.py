n=int(input())
a=list(map(int,input().split()))
x=0
for i in range(0,n-1):
  x+=a[i]
y=0
for j in range(1,n):
  y+=a[j]
z=x+y
print(z%(10**9+7))