#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define REP(i, n) for (ll i = 0; i < ll(n); i++)
#define REPD(i, n) for (ll i = n - 1; i >= 0; i--)
#define FOR(i, a, b) for (ll i = a; i <= ll(b); i++)
#define FORD(i, a, b) for (ll i = a; i >= ll(b); i--)
#define FORA(i, I) for (const auto &i : I)

signed main()
{

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll Ans = 0;
    const int Mod = 1e9 + 7;
    long long cal_num;
    int N;
    cin >> N;
    vector<int> vec(N);
    ll temp1, temp2;
    REP(i, N)
    {
        cin >> vec.at(i);
    }
    REP(i, N - 1)
    {
        temp1 = vec.at(i);
        temp2 = 0;
        for (ll j = i + 1; j < ll(N); j++)
        {
            temp2 += vec.at(j);
        }
        Ans += (temp1 * temp2) % Mod;
    }
    Ans = Ans % Mod;
    cout << Ans << endl;
}