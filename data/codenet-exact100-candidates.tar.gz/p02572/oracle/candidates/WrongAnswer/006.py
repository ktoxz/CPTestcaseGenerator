N = int(input())
A = list(map(int, input().split()))
ans = 0

for i in range(0,N-1):
  for j in range(i+1,N):
    ans = ans+(A[i]*A[j])%(7+10**9)
print(ans)