#include<bits/stdc++.h>
using namespace std;
const long long mod = 1e9 +7;
int main(){
    ios_base :: sync_with_stdio(false);
    cin.tie(NULL);
    long long n,num;
    cin>>n;
    map<long long,long long> m;
    for(auto i=1;i<=n;i++){
        cin>>num;
        m[num]++;
    }
    
    long long ans=0;
    map<long long,long long> :: iterator it = m.end();
    map<long long,long long> :: iterator it1;
    it--;
    for(auto i=m.begin();i != it;i++){
        it1 = i;
        it1++;
        for(auto j=it1;j != m.end();j++){
            ans += ((i->first)*(j->first))%mod*((i->second)*(j->second));
            ans %= mod;
        }
    }
    cout<<ans;
    return 0;
}