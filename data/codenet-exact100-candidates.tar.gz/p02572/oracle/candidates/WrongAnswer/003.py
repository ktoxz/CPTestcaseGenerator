import itertools

N = int(input())

xlist = input().split(" ")
ylist = []

for num in xlist:
    ylist.append(int(num))


    """
pairs = itertools.combinations(ylist, 2)
answer = 0
for pair in pairs:
    answer += pair[0] * pair[1]

print(answer % (10**9 +7 ))"""


def findProductSum(A, n):
    product = 0
    for i in range(n):
        for j in range(i + 1, n):
            product = product + A[i] * A[j]
    return product


print(findProductSum(ylist,N ))