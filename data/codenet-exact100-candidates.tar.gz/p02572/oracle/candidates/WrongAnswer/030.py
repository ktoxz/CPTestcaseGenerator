n = int(input())
a = list(map(int, input().split()))
b = sum([(i**2)%(10**9+7) for i in a])#%(10**9+7)
print(((sum(a)%(10**9+7))**2-b)%(10**9+7)//2)