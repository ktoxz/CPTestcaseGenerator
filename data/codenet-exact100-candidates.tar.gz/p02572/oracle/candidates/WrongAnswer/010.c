#include<stdio.h> 
 long int arrscaner(long int a,long int b[200001]){
   long int i=0;
		for(i=0;i<a;i++){
          scanf("%ld",&b[i]);
        }
	return b;
  }

 int main(){
 long int i=0,j=0;
 long int a=0,ans=0,sum=0;
 long int num[200001]={};
  scanf("%ld",&a);
  num[20001]=arrscaner(a,num);
  for(i=0;i<a;i++){
    sum+=num[i];
  }
  for(i=0;i<a;i++){    
    ans+=(sum-num[i])*num[i];    
  }
  ans=ans%1000000007;
  printf("%ld",ans/2);
  return 0;
}
