
#include <bits/stdc++.h>
using namespace std;

int main()
{
   long long int n;
    cin>>n;
   long long int arr[n],arsum=0,sqsum=0;
    for(long long int i=0;i<n;i++){
    cin>>arr[i];
    arsum+=arr[i];
    sqsum+=arr[i]*arr[i];
    }
    long long int sum=((arsum*arsum)-sqsum)/2;
    long long int mod=pow(10,9)+7;
    cout<<sum%mod;
}
