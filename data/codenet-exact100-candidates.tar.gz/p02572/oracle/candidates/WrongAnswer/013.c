#include <stdio.h>
#include <math.h>
#include <string.h>
int main()

{
    int n;
    long long int a[200010],sum=0;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%lld",&a[i]);
    }
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            sum+=a[i]*a[j];
        }
    }
    printf("%lld\n",sum);
    return 0;
}