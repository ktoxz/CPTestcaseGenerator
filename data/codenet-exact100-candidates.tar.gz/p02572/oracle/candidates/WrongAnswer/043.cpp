#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <math.h>
#include <map>
#include <set>
#include <algorithm>
#include <numeric>
#include <bitset>
using namespace std;
using ll = long long;
constexpr ll INF = 1010000000000000017LL;
constexpr ll mod = 1000000007;
#define rep(i, n) for(ll i = 0; i < (ll)(n); i++)
#define all(v) v.begin(), v.end()

int main() {
    int n;cin>>n;
    ll a[n];
    rep(i,n) cin>>a[i];
    ll res = 0;
    for(int i = 0; i < n -1; ++i){
        for(int j = i+1; j < n; ++j){
            res += (a[i])*(a[j]);
        }
    }
    res %= mod;
    cout<<res<<endl;
}
