#include <stdio.h>
#include <stdlib.h>
#define N 200010
#define M 1000000007



int main(void){
    int n;
    long long a[N];
    long long total = 0;
    scanf("%d",&n);
    for(int i=0; i < n;i++){
        scanf("%lld",&a[i]);
    }

    for(int i=0;i < n-1 ;i++){
        for(int j = i+1; j < n ; j++){
            total = total + a[i]*a[j];
        }
    }

    total %= M;
    printf("%lld\n",total);
    return 0;
}