#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod = 1000000007;

int main(){
    ll N;
    cin >> N;

    ll A[N];
    ll sum = 0;
    for(ll i = 0; i < N; i++){
        cin >> A[i];
        A[i] %= mod;
        sum += A[i];
    }

    ll ans = 0;

    for(ll i = 0; i < N-1; i++){
        sum -= A[i];
        if(sum<0){
            sum += mod;
        }
        ans += (A[i] * sum)%mod;
        ans %= mod;
    }

    cout << ans << endl;

    return 0;
}