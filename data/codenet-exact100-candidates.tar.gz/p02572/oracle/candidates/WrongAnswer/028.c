#include<stdio.h>
int main(void){
  long long int n;
  scanf("%lld",&n);
  long long int a[n],i,j,b=0,c=0,s=0;
  for(i=0;i<n;i++){
  	scanf("%lld",&a[i]);
  }
  for(i=0;i<n;i++){
	b+=a[i];
	c+=(a[i]*a[i]);
  }
  s=((b*b-c)/2)%1000000007;
  printf("%lld\n",s%1000000007);
  
  return 0;
  
}
