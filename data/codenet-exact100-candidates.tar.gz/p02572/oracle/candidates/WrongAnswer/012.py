n = int(input())
a = [int(s) for s in input().split()]
b = []
val = 0
for i in range(0, n):
    b.append(a[i] * sum(a[:i])) 
val = sum(b)
print(b)
print(val % (10 ** 9 + 7))