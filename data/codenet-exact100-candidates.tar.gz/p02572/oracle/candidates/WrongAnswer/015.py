import itertools

def NextInts(): return map(int,input().split())

saisyo = input()
X = NextInts()
p = itertools.combinations(X, 2)
ANSWER = 0
MOD = 10**9+7
for i in p:
	answer = (int(i[0])%MOD*int(i[1])%MOD)
	ANSWER+=answer
print(ANSWER)
