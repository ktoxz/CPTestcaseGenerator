#include <bits/stdc++.h>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    long N = 0;
    cin >> N;
    long A[N];
    long sum = 0;
    long max = 0;
    long result = 0;
    long m = 1000000000 + 7;
    for (long i = 0 ; i < N; i++) {
        std::cin >> A[i];
        sum += A[i];
    }

    for (long j = 0 ; j < N; j++) {
        sum -= A[j];
        result += A[j] * sum; 
    }

    cout << result % m << endl;
}