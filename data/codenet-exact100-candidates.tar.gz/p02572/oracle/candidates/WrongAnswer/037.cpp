    #include <bits/stdc++.h>
    using namespace std;
    #define ll unsigned long long
    #define pb push_back
    #define NUM 1000000007
    #define MAX 100001
    #define INF LLONG_MAX
    int main(){
        ios_base::sync_with_stdio(false);
        cin.tie(NULL);
        cout.tie(NULL);
        ll n,tmp;
        cin>>n;
        vector<ll> v;
        for(int i=0;i<n;i++){
            cin>>tmp;
            v.pb(tmp);
        }
        vector<ll> prf(n+1);
        prf[0]=v[0]%NUM;
        for(int i=1;i<n;i++){
            prf[i]=(prf[i-1]%NUM+v[i]%NUM)%NUM;
        }
        ll ans = 0;
        for(int i=0;i<n-1;i++){
            ans=(ans+(v[i]*(prf[n-1]-prf[i])))%NUM;
        }
        cout<<ans<<endl;
        return 0;
    }
