#include<bits/stdc++.h>
using namespace std;
#define ll long long int
const ll mod = 1000000007;
int main()
{
    ll a,b,c=0,d,i,mx=-1,cn=0,j;
    string s,ss;
    cin>>a;
    ll ar[a],arr[a];
    for(i=0; i<a; i++)cin>>ar[i],cn+=ar[i],arr[i]=cn;
    for(i=a-1; i>0; i--)
    {
        c+=(arr[i-1]*ar[i]);
        c%=mod;
    }
    cout<<c<<endl;
    /*cin>>s>>ss;
    for(i=0; i<ss.size(); i++)
    {
        j=0;
        while(j<s.size() and i<ss.size())
        {
            if(s[j]==ss[i])cn++,i++,j++;
            else break;
        }
        mx=max(mx,cn);
        cn=0;
    }
    cout<<s.size()-mx<<endl;*/
    return 0;
}
