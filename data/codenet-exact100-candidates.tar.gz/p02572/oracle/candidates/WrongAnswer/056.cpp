#include <iostream>

using namespace std;
typedef long long int ll;

int main(void) {
  int n; cin >> n;
  ll a[n], sum, ans=0;
  for (size_t i = 0; i < n; i++) cin >> a[i];
  for (size_t i = 0; i < n-1; i++) {
    sum=0;
    for (size_t j = i+1; j < n; j++) sum+=a[j];
    sum=sum%1000000007;
    ans=ans+(a[i]*sum)%1000000007;
  }
  cout << ans << endl;
  return 0;
}
