#include<iostream>
int main(){
	int N;
	std::cin>>N;
	long int* A=new long int[N];
	for(int i=0;i<N;i++){
		std::cin>>A[i];
	}
	long ans=0;
	for(int i=0;i<N;i++){
		long now=0;
		for(int j=i+1;j<N;j++){
			now+=A[j]%1000000007;
		}
		ans+=now*A[i]%1000000007;
	}
	std::cout<<ans;
	return 0;
}
