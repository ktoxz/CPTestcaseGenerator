#include <stdio.h>

int main() {
    int i,j, N;
    long long int ans, sum;
    sum = ans = 0;
    
    scanf("%d", &N);
    long long int A[N];
    long long int B[N];

    for(i=0; i < N; i++) {
        scanf("%lld", &A[i]);
        sum+= A[i];
        B[i] = sum;
    }

    for(i=N-1; i > 0; i--) ans+= (A[i] * B[i-1])  % 1000000007;

    printf("%lld\n", ans);
    return 0;
}