#include <iostream>
#include <vector>
#define num 1000000007

int main() {
    int N;
    std::cin >> N;
    std::vector<long long int> A(N);
    long long int ans = 0, tmp = 0;
    for(int i = 0; i < N; i++) {
        std::cin >> A.at(i);
        tmp += A.at(i);
    }

    for(int i = 0; i < N - 1; i++) {
        tmp -= A.at(i);
        ans += (A.at(i) * tmp);

        ans %= num;
    }

    std::cout << ans << std::endl;

    return 0;
}
