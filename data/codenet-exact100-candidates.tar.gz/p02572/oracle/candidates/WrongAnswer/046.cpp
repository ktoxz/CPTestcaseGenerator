#include<bits/stdc++.h>
using namespace std;

int main(){
    int N;
    cin >> N;
    vector<long long> v(N,0);
    for(int i = 0; i < N; i++){
        cin >> v.at(i);
    }

    long long int sum = 0;
    for(int i = 0; i < N-1; i++){
        for(int j = i + 1;j < N; j++){
            sum += v.at(i) * v.at(j);
        }
        sum %= 1000000007;
    }
    cout << sum << endl;
}