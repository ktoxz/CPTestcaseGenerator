#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>



void swap (int *x, int *y) {
  int temp;

  temp = *x;
  *x = *y;
  *y = temp;

  return;
}

int gcd(int a,int b){
  if(a<b){
    swap(&a,&b);
  }

  if(b==0){
    return a;
  }

  int r=a%b;
  while(r!=0){
    a = b;
    b = r;
    r = (a%b);
  }

  return b;
}

/* クイックソート */
int dn(const void*a,const void*b){return*(int*)b-*(int*)a;}


long int modpow(long int a,long int n,long int mod){
  long int ans=1;
  while(n>0){
    if(n & 1){
      ans=ans*a%mod;
    }
    a=a*a%mod;
    n/=2;
  }
  return ans;
}

long int modinv(long int a,long int mod){
  return modpow(a,mod-2,mod);
}

int max(int a,int b){
  if(a<b){
    return b;
  }
  else{
    return a;
  }
}

int min(int a,int b){
  if(a<b){
    return a;
  }
  else{
    return b;
  }
}

void chmax(int *a,int b){
  if(*a < b){
    *a = b;
  }

  return;
}

void chmin(int *a,int b){
  if(*a > b){
    *a =b;
  }

  return;
}

/****************************************\
| Thank you for viewing my code:)        |
| Written by RedSpica a.k.a. RanseMirage |
| Twitter:@asakaakasaka                  | 
\****************************************/

int main(void){
  /*
  解法2
  (答え)=((総和の2乗)-(2乗の総和))/2
  ということがわかるので，それを実装

  2で割る部分は解法1と同じ

  */
  long int n;
  scanf("%ld",&n);

  long int A[n];
  
  //総和
  long int all=0;
  
  //2乗の総和
  long int sq_all=0;

  long int MOD=1e9+7;

  for(int i=0;i<n;i++){
    scanf("%ld",&A[i]);
    all+=A[i];

    //常にMODを取る！
    all%=MOD;

    sq_all+=modpow(A[i],2,MOD);
    
    //常にMODを取る！
    sq_all%=MOD;
  }


  //MOD上の2の逆元
  long int v=modinv(2,MOD);

  long int ans=modpow(all,2,MOD);
  ans-=sq_all;
  ans+=MOD;
  ans%=MOD;

  //常にMODを取る！
  printf("%ld\n",ans*v%MOD);

  return 0;
}