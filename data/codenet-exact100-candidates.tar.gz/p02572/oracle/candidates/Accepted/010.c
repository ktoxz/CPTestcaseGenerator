#include<stdio.h>

int main(void){
  long long int N;
  scanf("%ld",&N);
  long long int A[N];
  int i,j;
  long long int S[N+1];
  for(i=0;i<N+1;i++){
    S[i]=0;
  }
  for(i=0;i<N;i++){
    scanf("%ld",&A[i]);
    S[i+1]=S[i]+A[i];
  }
  long long int sum=0;
  long int mod=1000000007;
  for(i=0;i<N-1;i++){
    sum+=A[i]*((S[N]-S[i+1])%mod);
    sum%=mod;
  }
 
  
  printf("%ld",sum);
  return 0;
}