#include <stdio.h>

#define LIMIT 1000000007

int main(){
   int i,j,k,n;
   long ans,sum,a[200000];

   scanf("%d",&n);
   for (i=0;i<n;i++) scanf("%ld",&a[i]);
   sum=ans=0;
   for (i=n-1;i>0;i--) {
      sum=(sum+a[i])%LIMIT;
      ans=(ans+sum*a[i-1])%LIMIT;
   }
   printf("%ld\n",ans);
   return 0;
}
