#include <stdio.h>

#define MOD_BY 1000000007

int add(int a, int b) {
	return a + b - MOD_BY * (a + b >= MOD_BY);
}

int mul(int a, int b) {
	int r = 0;
	while (b > 0) {
		if (b & 1) r = add(r, a);
		a = add(a, a);
		b >>= 1;
	}
	return r;
}

int N;
int A[212345];

int morigutihiroko[212345];

int main(void) {
	int i;
	int kotae = 0;
	if (scanf("%d", &N) != 1) return 1;
	for (i = 0; i < N; i++) {
		if (scanf("%d", &A[i]) != 1) return 1;
	}
	morigutihiroko[N] = 0;
	for (i = N - 1; i >= 0; i--) {
		morigutihiroko[i] = add(morigutihiroko[i + 1], A[i]);
	}
	for (i = 0; i < N; i++) {
		kotae = add(kotae, mul(A[i], morigutihiroko[i + 1]));
	}
	printf("%d\n", kotae);
	return 0;
}
