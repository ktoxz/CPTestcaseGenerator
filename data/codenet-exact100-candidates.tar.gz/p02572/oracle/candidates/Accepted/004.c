#include <stdio.h>
#define N 400000
#define mod 1000000007
int main(int argc, char *argv[])
{
	long long a[N]={0},n,i,sum=0;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
		sum+=a[i];
	}
	long long s=0;
	for(i=0;i<=n-2;i++){
		sum-=a[i];
		s+=((sum%mod)*a[i])%mod;
	}
	printf("%lld\n",(s+mod)%mod);
}