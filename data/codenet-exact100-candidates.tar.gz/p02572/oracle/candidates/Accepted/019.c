#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(void) {
	int i, j;
	int N;
	long long int *A;
	long long int ans, temp;
	long long int naive_ans;
	long long int module = 1000000000 + 7;
	char buf[128], *ch;
	char *great_buf;

	fgets(buf, sizeof(buf), stdin);
	ch = strtok(buf, " ");
	N = atoi(ch);

	A = (long long int *)calloc(N, sizeof(long long int));
	great_buf = (char *)calloc(N*12, sizeof(char));
	fgets(great_buf, N*12, stdin);
	ch = strtok(great_buf, " ");
	A[0] = atoi(ch);
	for(i = 1; i < N; i += 1) {
		ch = strtok(NULL, " ");
		A[i] = atoi(ch);
	}
	free(great_buf);
	/*
	for(i = 0; i < N; i += 1) {
		A[i] = rand()%100000000;
	}
	*/

	/*
	naive_ans = 0;
	for(i = 0; i < N; i += 1) {
		for(j = i + 1; j < N; j += 1) {
			temp = A[i] * A[j];
			temp = temp % module;
			naive_ans += temp;
			naive_ans = naive_ans % module;
		}
	}
	printf("%lld\n", naive_ans);
	*/

	ans = 0;
	temp = 0;
	for(i = 0; i < N; i += 1) {
		temp += A[i];
	}
	for(i = 0; i < N - 1; i += 1) {
		temp -= A[i];
		ans += ((temp % module) * A[i]) % module;
		ans = ans % module;
	}
	printf("%lld\n", ans);

	free(A);
	return 0;
}
