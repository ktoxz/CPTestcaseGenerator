#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MOD 1000000007

int main(void){

    int n;
    int i;
    long long *p;
    long long ans = 0;
    long long ans2 = 0;

    scanf("%d",&n);
    p = (long long*)malloc(sizeof(long long)*n);

    for(i=0;i<n;i++){
        scanf("%lld",&p[i]);
    }

    for(i=1;i<n;i++){
        ans += p[i];
    }

    i = 0;
    do{
        ans2 += ((ans%MOD)*p[i])%MOD;
        ans2 = ans2 % MOD;
        ans -= p[i+1];
        i++;
    }while(i<n-1);

    printf("%lld",ans2);
    free(p);
    return 0;
}