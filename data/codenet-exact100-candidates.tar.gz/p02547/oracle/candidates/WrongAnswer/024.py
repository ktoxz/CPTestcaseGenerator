N=int(input())
T=False
k=0
for i in range(N):
    D1,D2=map(int,input().split())
    if D1==D2:
        k+=1
        if k>=3:
            T=True
    else:
        k=0
    print(k)
if T:
    print("Yes")
else:
    print("No")