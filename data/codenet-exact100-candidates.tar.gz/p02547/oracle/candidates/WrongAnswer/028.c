#include <stdio.h>

int main()

{

  int N, Di, Dj, i, mehrab;

  scanf("%d",&N);

  

  for(i=1; i<=N; i++)

  {

    scanf("%d%d",&Di,&Dj);

    

    if(Di == Dj)

    {

      mehrab++;

    }

    else 

    {

      break;

    }

  }

  

  if(mehrab == 3)

  {

    printf("Yes\n");

  }

  else

  {

    printf("No\n");

  }

  

  return 0;

}