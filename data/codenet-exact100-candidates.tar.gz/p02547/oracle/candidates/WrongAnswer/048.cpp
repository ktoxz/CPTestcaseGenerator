#include <iostream>
#include<vector>
#include<algorithm>
#include<string>
#include<cmath>
#include<set>

using namespace std;

int main()
{
	int N;
	cin >> N;

	int count = 0;
	for (int i = 0; i < N; i++) {
		int D1, D2;
		cin >> D1 >> D2;
		if (D1 == D2) {
			count++;
		}
		else {
			count = 0;
		}
	}

	if (count == 3) {
		cout << "Yes" << endl;
	}
	else {
		cout << "No" << endl;
	}




	
}
