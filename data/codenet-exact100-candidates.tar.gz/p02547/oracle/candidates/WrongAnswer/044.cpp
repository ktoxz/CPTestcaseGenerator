#include <iostream>
using namespace std;

int main() {
    int i = 0;
    int a;
    int b;
    int t;
    int c = 1;
    int sum1;
    int sum2;
    cin >> t;
        while(c != t) {
            cin >> a;
            cin >> b;
            sum1 = a * 2;
            sum2 = b * 2;
                if(sum1 == b or sum2 == a) {
                    i++;
                }
                if(sum1 != b or sum2 != a) {
                    i = 0;
                }
            c++;
        }
        if(c == t) {
            cin >> a;
            cin >> b;
            sum1 = a * 2;
            sum2 = b * 2;
                if(sum1 == b or sum2 == a) {
                    i++;
                    c++;
                        if(i == 3 or i > 3) {
                           cout << "Yes\n";
                           return 0;
                        }
                        else {
                            cout << "No\n";
                            return 0;
                        }
                }
                if(sum1 != b or sum2 != a) {
                    c++;
                        if(i == 3 or i > 3) {
                           cout << "Yes\n";
                           return 0;
                        }
                        else {
                            cout << "No\n";
                            return 0;
                        }
                }
        }
}