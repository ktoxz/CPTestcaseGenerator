N = int(input())
D = [list(map(int, input().split())) for i in range(N)]
cnt_cons=0

for i in range(1, N-2, 1):
  if D[i][0] == D[i][1] and D[i+1][0] == D[i+1][1] and D[i+2][0] == D[i+2][1]:
    print("Yes")
    cnt_cons += 1
    exit()
if cnt_cons == 0:
  print("No")