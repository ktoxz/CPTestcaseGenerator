#include <iostream>
#include <string>
#include<vector>
using namespace std;
int main() {
	int n;
	cin >> n;
	int s[110][2];
	int m = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < 2; j++) {
			cin >> s[i][j];
		}
	}
	vector<int>a;


	for (int i = 0; i < n; i++) {
		if (s[i][0] == s[i][1]) {
			a.push_back(1);
		}else{
			a.push_back(0);
		}

	}

	for (int i = 0; i < n-2; i++) {
		if (a[i] == a[i + 1] == a[i + 2] == 1) {
			cout << "Yes" << endl;
		break;
		}
		
		m++;
	}
	if (m++ == n - 2) {
		cout << "No" << endl;
	}


	return 0;
}