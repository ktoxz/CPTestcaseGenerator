#include <bits/stdc++.h>
using namespace std;
int main(){
    int N;
    vector<vector<int>> D(N, vector<int>(2)); 
    int F=0;
    cin >> N;
    
     for (int i = 0; i < N; i++) {
    for (int j = 0; j < 2; j++) {
      cin >> D.at(i).at(j);
    }
  }
  for(int i=0; i<N; i++){
      if(D.at(i).at(0)==D.at(i).at(1) && D.at(i+1).at(0)==D.at(i+1).at(1) && D.at(i+2).at(0)==D.at(i+2).at(1)){
          F++;    
      }  
  }
  if(F!=0){
  cout << "Yes" << endl;}
  else {
  cout << "No" << endl;}
}