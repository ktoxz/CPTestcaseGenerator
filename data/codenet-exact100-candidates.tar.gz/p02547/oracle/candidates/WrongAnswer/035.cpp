#include<iostream>
using namespace std;
int main(){
  int N;
  cin>>N;
  int D[N-1][2];
  for(int i=0;i<N;i++){
    cin>>D[i][0]>>D[i][1];
  }
  int ans=0;
  for(int i=0; i<N;i++){
    if(i+2<N){
      if(D[i][0]==D[i][1]){
        //cout<<"i:"<<i<<" OK"<<"\n";
        if(D[i+1][0]==D[i+1][1]){
          //cout<<"i:"<<i<<" OK"<<"\n";
          if(D[i+2][0]==D[i+2][1]){
            //cout<<"i:"<<i<<" OK"<<"\n";
            ans=1;
            break;
          }else{
            i=i+2;
          }
        }else{
          i++;
        }
      }
    }
    else{
      break;
    }
  }
  if(ans==1){
    cout<<"Yes";
  }else{
    cout<<"No";
  }
}
