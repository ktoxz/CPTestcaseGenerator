iterate = int(input())
cnt = 0
for i in range(iterate):
  dice = list(map(lambda x: int(x), input().split()))
  if dice[0]==dice[1]:
    cnt += 1
  if dice[0]!=dice[1]: cnt=0
  if cnt==3: break
    
if cnt!=0: print("Yes")
else: print("No")