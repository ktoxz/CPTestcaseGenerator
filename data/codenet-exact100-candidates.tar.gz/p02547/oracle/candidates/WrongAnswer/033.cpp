#include<bits/stdc++.h>
using namespace std;
int main()
{
   int n;
   cin>>n;
   int number1,number2;
   vector<pair<int,int> >v;
   for(int i=1;i<=n;i++)
   {
       cin>>number1>>number2;
       v.push_back(make_pair(number1,number2));
   }
   int k=1,i,j;
   for( i=0;i<v.size();i++)
   {
       if(v[i].first==v[i].second)
       break;

   }
   for( j=i+1;j<v.size();j++)
   {
        if(k==3)
        {
            break;
        }
        if(v[j].first==v[j].second)
            k++;
        else
        {
            break;
        }
   }
   //cout<<k<<endl;
   if(k==3)
   {
       cout<<"Yes"<<endl;
   }
   else
    cout<<"No"<<endl;
}
