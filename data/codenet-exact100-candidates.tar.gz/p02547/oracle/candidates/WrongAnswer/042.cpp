#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	int a[n],b[n];
	for(int i=0;i<n;i++)
{
	cin>>a[i]>>b[i];
}
int count=0;
for(int i=0;i<n;i++)
{
  if( a[i]=b[i] &&a[i+1]==b[i+1] && a[i+2]==b[i+2])
     count++;
}
if(count>=3)
{
	cout<<"YES"<<endl;
}
else
{
	cout<<"NO"<<endl;
}
return 0;
}
