N=int(input())
cnt=0

for i in range(N):
  if cnt==3:
    print('Yes')
    break
  D_1,D_2=map(int,input().split())
  if D_1==D_2:
    cnt+=1
  else:
    cnt=0
else:
  print('No')