#include<bits/stdc++.h>

using namespace std;

int main()
{
	int arr1[100];
	int arr2[100];
	
	
	int n;
	cin>>n;
	
	for(int i=0;i<n;i++)
	{
		cin>> arr1[i] >> arr2[i];
		
	}

	
	for(int j=0;j<n-2;j++)
	{
		if(arr1[j] == arr2[j] && arr1[j+1] == arr2[j+1] && arr1[j+2] == arr2[j+2])
		{
			cout<<"Yes";
			break;
	       goto odd;
		}
      
	}
	odd: 
    printf("No"); 
	
	
	return 0;
}