#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;

    cin >> n;

    int data[n][2];
    int N[n];

    for (int i = 0; i < n; ++i)
    {
        cin >> data[i][0] >> data[i][1];
    }

    for (int i = 0; i < n; ++i)
    {
        if (data[i][0] == data[i][1])
        {
            N[i] = true;
        }
        else
            N[i] = false;
    }
    for (int i = 0; i < n; ++i)
    {
        if (i >= 2)
        {
            if (N[i])
            {
                if (N[i - 1] == N[i - 2] == 1)
                {
                    cout << "Yes" << endl;
                    break;
                }
            }
        }
        if (i == n)
            cout << "No" << endl;
    }
}