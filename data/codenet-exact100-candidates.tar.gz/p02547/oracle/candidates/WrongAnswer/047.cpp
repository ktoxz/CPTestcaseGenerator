#include<bits/stdc++.h>
using namespace std;



void solve()
{
    int n;
    cin >> n;
    int ans =0;
    while(n--){
        int a, b;
        if(ans == 3){
            cout << "Yes";
            break;
        }
        else{
            cin >> a >> b;
            if(a==b)
                ans++;
            else
                ans = 0;
        }

    }
    if(ans < 3){
        cout << "No";
    }

}

int main()
{

    solve();
    cout << "\n";


}


