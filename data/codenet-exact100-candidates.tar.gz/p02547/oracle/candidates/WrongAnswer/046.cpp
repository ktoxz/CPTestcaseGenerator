#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define t() int t;cin>>t;while(t--)
#define ff first
#define ss second
#define loop(i,a,b) for(int i=a;i<b;i++)
#define rloop(i,a,b) for(int i=a;i>b;i--)
#define pb push_back
#define mp make_pair

 

void solvea(){
 
 int n;
 cin>>n;
 int a[n][2];
 for(int i=0;i<n;i++){
 	for(int j=0;j<2;j++)
 		cin>>a[i][j];
 }
 int f=0;
 for(int i=0;i<n-2;i++){
 	for(int j=0;j<2;j++){
 		if(a[i][j]==a[i][j+1] && a[i+1][j]==a[i+1][j+1] && a[i+2][j]==a[i+2][j+1]){
 			f=1;
 			break;
 		}
 	}
 }
 if(f)
 	cout<<"Yes";
 else cout<<"No";
 
 }

	
	
 
void solveb(){
	t(){
		
	}
}

int main()
{
	#ifndef ONLINE_JUDGE
		//for getting input from input1.txt
		freopen("input1.txt","r",stdin);
		//for getting output from output.txt
		freopen("output.txt","w",stdout);
		#endif

		solvea();
return 0;
}