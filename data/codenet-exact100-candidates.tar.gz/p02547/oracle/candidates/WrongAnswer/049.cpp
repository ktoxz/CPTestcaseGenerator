#include <bits/stdc++.h>
#define ll long long int
#define endl '\n'

using namespace std;

int main()
{
    int t,ans=0,flag=1,ma=0;
    cin>>t;
    
    while(t--){
        int a,b;
        cin>>a>>b;
        
        if(a == b) ans++;
        
        else ans=0;
        
        ma= max(ans,ma);
        
    }
    
    if(ma>2) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;

    return 0;
}
