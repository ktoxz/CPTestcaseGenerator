#include<bits/stdc++.h>
using namespace std;

int main(){
  int N;
  cin >> N;
  int D_1,D_2,count=0;
  for(int i=0;i<N;i++){
    cin >> D_1 >> D_2;
    if(D_1==D_2){
      count++;
    }else{
      count=0;
    }
  }
  if(count>2){
    cout << "Yes" << endl;
  }else{
    cout << "No" << endl;
  }
}