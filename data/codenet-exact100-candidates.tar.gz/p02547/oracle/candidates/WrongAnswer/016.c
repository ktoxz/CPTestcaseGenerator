#include<stdio.h>

int main(void){

  int  N,i;

  int D1[100];

  int D2[100];

  scanf("%d",&N);

  int A=0;

for(i=1;i<=N+1;i++){

  scanf("%d %d",&D1[i],&D2[i]);

  if(D1[i]==D2[i]){
  A = A+1;
  }

}

if(A >= 3){

    printf("Yes");

    return 0;

  }

else{

    printf("No");

    return 0;

  }

}