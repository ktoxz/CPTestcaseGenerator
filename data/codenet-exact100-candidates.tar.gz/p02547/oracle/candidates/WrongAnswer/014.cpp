#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define rep(i,a)  for(ll i=0; i< a; i++)
#define rep1(i,a)   for(ll i = 1; i< a; i++)
#define foi(i, a, b)    for(ll i = a; i<b ; i++)
#define fod(i, a, b)    for(ll i = a; i>=b ; i--)
#define max3(a, b, c)   max(max(a, b), c)
#define min3(a, b, c)   min(min(a, b), c)
#define MAX 1000005
#define MOD 1000000007

ll findgcd(ll n,ll m){
    return __gcd(n,m);
}
ll findlcm(ll n,ll m){
    return (n*m)/findgcd(n,m);
}

ll nodig(ll n){
    int ans =0;
    while(n!=0){
        ans+=1;
        n=n/10;
    }
    return ans;
}


int main(){
    ll n,temp=0,cnt=0,ans=0;
    cin>>n;
    int a[2*n];
    for(int i=0;i<2*n;i++) cin>>a[i];
    for(int i=0;i<2*n-6;i++){
        if(a[i+1]==a[i] && a[i+2]==a[i+3] && a[i+4]==a[i+5]) {
            cout<<"Yes";
            cnt = 1;
            break;
        } 
    }
    if(cnt==0) cout<<"No";
    

return 0;
}