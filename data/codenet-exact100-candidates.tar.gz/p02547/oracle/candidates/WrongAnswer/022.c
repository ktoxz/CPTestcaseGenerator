#include<stdio.h>
int main()
{
     long long int n,i;
    scanf("%lld",&n);
   long long int a1[n],a2[n];
    for(i=0;i<n;i++)
    {
        scanf("%lld %lld",&a1[i],&a2[i]);
    }
    for(i=0;i<n;i++)
    {
        if(a1[i]==a2[i])
        {
            printf("Yes");
            break;
        }
        else
        {
            printf("No");
            break;
        }
    }
}