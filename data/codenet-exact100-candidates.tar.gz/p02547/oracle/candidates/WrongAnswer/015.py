#!/usr/bin/env python3
N = int(input()) 

count = 0
result = 'No'
for i in range(1, N):
    d1, d2 = map(int, input().split())
    if(d1 == d2):
        count += 1
    else:
        count = 0
    if(count == 3):
        result = 'Yes'
        exit

print(result)


        


