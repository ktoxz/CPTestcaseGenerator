N = int(input())

D = []
for i in range(N):
    Da,Db = (map(int,input().split()))
    if Da == Db:
        D.append(1)
    else:
        D.append(0)

for i in range(N-2):
    if D[i]==1 and D[i+1] == 1 and D[i+2] == 1:
        ans = "Yes"
    else:
        ans = "No"
print(ans)