#include <iostream>
#include <string>
using namespace std;
int main(){
  int n;
  cin >> n;
  int d[n][2];
  for(int i=0;i<n;i++){
    for(int j=0;j<2;j++){
        cin >> d[i][j];
    }
  }
  int sum = 0;
  for(int i=0;i<n-3;i++){
      if(d[i][1] == d[i][2] && d[i+1][1] == d[i+1][2] && d[i+2][1] == d[i+2][2]){
          sum += 1;
        }
  }
  if(sum > 0){
      cout << "Yes" << endl;
  }
  else{
      cout << "No" << endl;
  }
  return 0;
}