#include <bits/stdc++.h>
using namespace std;
#define ll long long int
int main()
{
   ll n;
   cin>>n;
   ll ar[n][2];
   for(ll i=0;i<n;i++)
   {
       cin>>ar[i][0];
       cin>>ar[i][1];
   }
   ll f=0;
   for(ll i=0;i<n-3;i++)
   {
       if(ar[i][0]==ar[i][1] && ar[i+1][0]==ar[i+1][1] && ar[i+2][0]==ar[i+2][1])
       {cout<<"Yes";
       f=1;
       break;
       }
   }
   if(f==0)
   cout<<"No";
    return 0;
}