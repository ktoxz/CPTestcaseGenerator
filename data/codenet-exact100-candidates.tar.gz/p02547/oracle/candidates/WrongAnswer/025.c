#include<stdio.h>
#include<string.h>
#include<math.h>
#include<limits.h>
#include<stdbool.h>
#define e 1000000007
#define PI 3.141592653589793

typedef  long long ll;

int int_cmp(const void *a, const void *b){ 
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    return *ia  - *ib; 
} 


ll int_cmp1(const void *a, const void *b){ 
    const int *ia = (const int *)a;
    const int *ib = (const int *)b;
    return *ia  - *ib; 
} 



ll max(ll a,ll b){
	if(a<b)
		a=b;
	return a;	
}

ll min(ll a,ll b){
	if(a>b)
		a=b;
	return a;	
}

int absolu(int n){
	if(n<0)
		n*=-1;
	
	return n;	
}


void solve(){ 
	int x,y,n,ans=0,i,ma;
	
	scanf("%d",&n);
	for(i=0 ; i<n ; i++){
		scanf("%d%d",&x,&y);
		if(x==y){
			ans++;
		}else{
			ma=ans;
			ans=0;
		}
	}
	if(ans==n)
		ma=ans;
	if(ma>=3)
		printf("Yes\n");
	else
		printf("No\n");		
}

int main(){
 /* int t;
	scanf("%d",&t);
	
	while(t--)*/
		solve();
	
	return 0;
}	
	