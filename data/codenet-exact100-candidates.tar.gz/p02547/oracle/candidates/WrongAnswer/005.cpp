#include <bits/stdc++.h>
using namespace std;
#define LOCAL 1
int main(){
	#if LOCAL
	freopen("E:\\in.txt","r", stdin);
	#endif
	int n;
	cin >> n;
	int t = 0;
	for(int i = 0; i < n; i++){
		int x, y;
		cin >> x >> y;
		if(x == y){
			t++;
			if(t == 3) break;
		}else{
			t = 0;
		}
	}
	cout << (t==3 ? "Yes" : "No") << endl;
}