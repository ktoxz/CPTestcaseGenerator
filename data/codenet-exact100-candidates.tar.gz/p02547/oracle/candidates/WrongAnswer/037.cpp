#include<bits/stdc++.h>
using namespace std;
using ll = long long;

int main(){
  ll n, d[2][101], cnt = 0, ans = 0;
  cin >> n;
  for(int i = 0; i < n; i++) cin >> d[0][i] >> d[1][i];
  for(int i = 0; i < n; i++){
    if(d[0][i]==d[1][i]) cnt++;
    if(cnt == 3) ans++;
    else cnt = 0;
  }
  if (cnt) cout <<"Yes" ;
  else cout << "No";
}
