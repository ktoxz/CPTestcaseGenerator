#include <bits/stdc++.h>
#define rep(i,n) for (int i = 0; i < (n); ++i)
using namespace std;
using ll = long long;
using P = pair<int,int>;
int main() {
    int n; cin >> n;
    vector<int> d(2*n);
    rep(i, 2*n) cin >> d[i];
    for (int i=2;i<2*n;i++) {
        if (d[i] == d[i-1] && d[i-1] == d[i-2]) {
            cout << "Yes" << endl;
            return 0;
        }
    }
    cout << "No" << endl;
}
