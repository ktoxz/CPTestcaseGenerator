#include <bits/stdc++.h>
#define ll  long long int
#define out  cout<<

using namespace std;



int main(){
    ll n;
    cin>>n;
    ll a[n][2];

    for(ll i=0;i<n;i++){

        cin>>a[i][0]>>a[i][1];

    }
    //for(ll i=0;i<n;i++)
       // cout<<indx[i]<<"\n";
    bool flag =false;
       for(ll k=0;k<n-2;k++){
            if((a[k][0] ==a[k][1])&&(a[k+1][0]  == a[k+1][1])&&(a[k+2][0]  == a[k+2][1])){
                flag =true;
                break;
            }


       }
       if(flag == true)
        cout<<"YES"<<"\n";
       else
        cout<<"NO"<<"\n";

return 0;}
