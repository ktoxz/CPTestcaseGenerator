#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    bool ans=false;
    int cnt=0;
    for(int i=0;i<n;i++){
        int x,y;
        cin >> x >> y;    
        cnt++;
        if(cnt==3) ans=true;
        else cnt=0;
    }
    if(ans) cout << "Yes";
    else cout << "No";
}
