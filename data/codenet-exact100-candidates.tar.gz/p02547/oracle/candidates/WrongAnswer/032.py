N=int(input())
xy = [map(int, input().split()) for _ in range(N)]
x, y = [list(i) for i in zip(*xy)]
cnt=0
result="No"
# 出力して確認
#for n in range(N-1):
for i in range(N):
    cnt+=1 if x[i]==y[i] else 0
    if cnt>2:
        result="Yes"
print(result)