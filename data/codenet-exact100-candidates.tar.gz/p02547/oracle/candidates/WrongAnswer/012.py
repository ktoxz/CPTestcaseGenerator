N = int(input())
x=[0]*N
y=[0]*N
L=[0]*N

flag = "No"

if N <3:
  flag = "No"

else:

  for i in range(N):
      x[i],y[i] = map(int, input().split())

  for i in range(N):
    if x[i]==y[i]:
      L[i]=1

  #print(L)

  for i in range (N-2):
    #print(i)
    if L[i] == L[i+1] == L[i+2]:
      flag = "Yes"



print(flag)
    