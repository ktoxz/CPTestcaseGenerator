#include <iostream>
using namespace std;

int main(){
    int n;
    cin >> n;
    int d[n][2];
    int counter = 0;
    for(int i=0;i<n;i++){
        cin >> d[i][0] >> d[i][1];
        if( d[i][0] == d[i][1]){
            if(counter<2)
                counter++;
            else{
                cout << "yes";
                return 0;
                }
        }
        else
            counter = 0;
    }
    cout <<"No";
    return 0;

}