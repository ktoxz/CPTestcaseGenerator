#include <bits/stdc++.h> 
#define ll long long int
using namespace std; 

int main()
{
	ll n;
	cin>>n;
	int count = 0;
	bool flag = false;
	for(int i=0; i<n; i++)
	{
		int a,b;
		cin>>a>>b;
		if(count >0 && a != b) count = 0;
		if(a == b) count++;
		if(count >=3) flag = true;
	}
	if(flag) cout<<"Yes"<<endl;
	else
	cout<<"No"<<endl;
	
	return 0;
}