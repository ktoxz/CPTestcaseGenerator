#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define P pair<ll,ll>

int main(){
  int n;
  cin>>n;
  int tmp=0;
  bool ans=0;
  rep(i,n){
    int di,dj;
    cin>>di>>dj;
    if(di==dj) tmp++;
    else tmp=0;
    if(tmp==3) ans=1;
  }
  if(ans) cout<<"Yes"<<endl;
  else cout<<"No"<<endl;
}