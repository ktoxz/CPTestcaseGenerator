#include <bits/stdc++.h>
using namespace std;

int main(){
  int N;
  cin>>N;
  vector<int>v(N);
  vector<int>z(N);
  vector<int>count(N);
  int max =0;
  int sum =0;
  string s;
  for(int i=0;i<N;i++){
      cin>>v.at(i);
      cin>>z.at(i);
      count.at(i)=v.at(i)-z.at(i);
      //cout<<count.at(i)<<endl;
      if(count.at(i)!=0){
          max=0;
      }else{
          max++;
      }if(max==3){
          break;
      }
     // cout<<max<<endl;
     // cout<<max<<" "<<sum<<endl;
      if(sum==3){
          string s="Yes";
      }else{
          string s="No";
      }
  }
  //cout<<max<<endl;
  if(max>=3){
      cout<<"Yes"<<endl;
  }else{
      cout<<"No"<<endl;
  }
}
