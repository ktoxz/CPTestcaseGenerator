#include<bits/stdc++.h>
using namespace std;
int n,a[105],b[105],cnt; 
int main()
{
	cin >> n;
	for(int i = 1;i <= n;i++)
		cin >> a[i] >> b[i];
	for(int i = 1;i <= n;i++)
	{
		if(cnt >= 3) break;
		if(a[i] == b[i]) cnt++;
		if(a[i] != b[i]) cnt = 0;
	}
	if(cnt >= 3) cout << "Yes" << endl;
	else cout << "No" << endl;
	return 0;
}
