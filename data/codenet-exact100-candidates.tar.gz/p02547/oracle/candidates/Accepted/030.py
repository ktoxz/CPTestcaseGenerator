#!/usr/bin/env python3

import sys

DEBUG = False


def read(t):
    return t(sys.stdin.readline().rstrip())


def read_list(t, sep=" "):
    return [t(s) for s in sys.stdin.readline().rstrip().split(sep)]


def dprint(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)
    return


def main():
    n = read(int)
    zorome_times = 0
    for _ in range(n):
        dices = read_list(int)
        if dices[0] == dices[1]:
            zorome_times += 1
            if zorome_times >= 3:
                print("Yes")
                return
        else:
            zorome_times = 0
    print("No")


if __name__ == "__main__":
    main()
