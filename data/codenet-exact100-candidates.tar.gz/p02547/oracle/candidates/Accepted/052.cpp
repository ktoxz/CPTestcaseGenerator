/*
             much pretests
        ▄              ▄    
        ▌▒█           ▄▀▒▌   wow vectors
        ▌▒▒█        ▄▀▒▒▒▐   
       ▐▄█▒▒▀▀▀▀▄▄▄▀▒▒▒▒▒▐        heckin_TLE
     ▄▄▀▒▒▒▒▒▒▒▒▒▒▒█▒▒▄█▒▐   
   ▄▀▒▒▒░░░▒▒▒░░░▒▒▒▀██▀▒▌   
  ▐▒▒▒▄▄▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▀▄▒▌      beautiful graphs
  ▌░░▌█▀▒▒▒▒▒▄▀█▄▒▒▒▒▒▒▒█▒▐  
 ▐░░░▒▒▒▒▒▒▒▒▌██▀▒▒░░░▒▒▒▀▄▌ 
 ▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒░░░░░░▒▒▒▒▌  wow cp
▌▒▒▒▄██▄▒▒▒▒▒▒▒▒░░░░░░░░▒▒▒▐ 
▐▒▒▐▄█▄█▌▒▒▒▒▒▒▒▒▒▒░▒░▒░▒▒▒▒▌        much time
▐▒▒▐▀▐▀▒▒▒▒▒▒▒▒▒▒▒▒▒░▒░▒░▒▒▐ 
 ▌▒▒▀▄▄▄▄▄▄▀▒▒▒▒▒▒▒░▒░▒░▒▒▒▌     very memory
 ▐▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▒░▒▒▄▒▒▐  
  ▀▄▒▒▒▒▒▒▒▒▒▒▒▒▒░▒░▒▄▒▒▒▒▌  
    ▀▄▒▒▒▒▒▒▒▒▒▒▄▄▄▀▒▒▒▒▄▀   much loops
      ▀▄▄▄▄▄▄▀▀▀▒▒▒▒▒▄▄▀     
         ▀▀▀▀▀▀▀▀▀▀▀▀     
         bugs do me a bamboozle
*/

#include<bits/stdc++.h>
#define int 			long long
#define fi 				first
#define sc 				second
#define pii 			pair<int,int>
#define vi 				vector<int>
#define mii 			map<int,int>
#define msi 			map<string,int>
#define si 				set<int>
#define mlem			main
#define all(v) 			v.begin(),v.end()
#define sz(v)  			int((v).size())
#define rep(i,a,b)    	for(int i=a;i<b;i++)
#define dep(i,a,b)    	for(int i=a;i>=b;i--)
#define isinarr(i,n) 	((i>=0)?((i<n)?1:0):0)
#define pb 				push_back
#define ppb 			pop_back
#define lb 				lower_bound
#define ub 				upper_bound
#define hell 			1000000007
#define PI 				3.14159265
#define mp 				make_pair
#define inparr(a,n) 	rep(i,0,n)cin>>a[i];
#define strwspaces(s) 	getline(cin,s)
#define give(x,y) 		cout<<x<<" "<<y<<endl;
#define setp(n) 		cout<<fixed<<setprecision(n);
#define endl   			'\n'
#define inp(n) 			int n;cin>>n;
#define inps(s) 		string s;cin>>s;
#define setmem(inde,k) 	memset(inde,k,sizeof(inde))
#define tr(a,m) 		for(auto a=m.begin();a!=m.end();a++)
using namespace std;

int i,j,k,l;

void woof()
{
	inp(n);
	int cnt=0,ans=0;
	rep(i,0,n)
	{
		cin>>j>>k;
		if(j==k)
			cnt++;
		else
			cnt=0;
		ans=max(ans,cnt);
	}
	if(ans>=3)
		cout<<"Yes\n";
	else
		cout<<"No\n";
} 



signed mlem()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t=1;
    //cin>>t;
    while(t--)
        woof();
    return 0;
}