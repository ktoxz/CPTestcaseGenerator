N = int(input())

L = []
for i in range(0, N):
    L.append(input().rstrip().split())

counter = 0
out = ""
for j in range(len(L)):
    if (L[j][0] == L[j][1]):
        counter += 1
        if (counter >= 3):
            out = "Yes"
            break
    else:
        counter = 0
        out = "No"
        
print(out)