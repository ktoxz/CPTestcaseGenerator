import numpy as np
N = int(input())
ary = np.array([list(map(int, input().split())) for i in range(N)])

zoro = (ary[:, 0] == ary[:, 1]).astype(int)

f = "No"
for i in range(len(zoro) - 2):
  if zoro[i] + zoro[i+1] + zoro[i+2] == 3:
    f = "Yes"
    break

print(f)
