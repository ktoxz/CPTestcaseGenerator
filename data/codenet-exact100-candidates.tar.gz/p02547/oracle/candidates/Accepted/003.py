N = int(input())
counter = 0;

for i in range(N):
    d1, d2 = list(map(int, input().strip().split()))
    if d1 == d2:
        counter += 1
    else:
        counter = 0
    if counter >= 3:
        print("Yes")
        break;
if counter < 3:
    print("No")