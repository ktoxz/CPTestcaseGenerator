#include <bits/stdc++.h>
using namespace std;
#define endl "\n"
#define pb push_back
typedef long long ll;
int n,m;
pair<int,int>dice;
int main(){
    cin>>n;
    int cnt=0;
    bool done=false;
    for(int i=0;i<n;++i){
        int a,b;
        cin>>a>>b;
        if(a==b) cnt++;
        if(cnt>=3) done=true;
        if(a!=b) cnt=0;
    }

    if(done) cout<<"Yes"<<endl;
    else cout<<"No"<<endl;

}
