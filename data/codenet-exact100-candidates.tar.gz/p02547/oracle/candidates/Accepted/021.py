n = int(input())

cnt = 0
l = [list(map(int,input().split())) for i in range(n)]
for i in range(n):
    d1,d2 = l[i][0],l[i][1]
    if(d1==d2):
        cnt += 1
    else:
        cnt = 0
    if(cnt == 3):
        print('Yes')
        exit()

print('No')
        