#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define fi first
#define se second
#define endl "\n"

const ll mod = 1e9 + 7;
// const ll mod = 998244353;
const ll sz = 1e6 + 5;
vector<ll> fac(sz, 1);

ll powmod(ll a, ll b) { ll res=1; a%=mod; assert(b>=0); for(;b;b>>=1) { if(b&1) res=res*a%mod; a=a*a%mod; } return res; }
ll nCr(ll n, ll r) { return ( ( ( (fac[n] * powmod(fac[n-r], mod-2)) % mod ) * powmod(fac[r], mod-2) ) % mod ); }
ll gcd(ll a, ll b) { return b ? gcd(b,a%b) : a; }
ll lcm(ll a, ll b) { return (a / gcd(a,b)) * b; }
ll extended_gcd(ll a, ll b, ll &x, ll &y) {
    if (b == 0) { x = 1; y = 0; return a; }
    ll xx, yy;
    ll res = extended_gcd(b, a%b, xx, yy); x = yy; y = xx - yy * (a / b);
    return res;
}

// * ALways PASS arrays, strings etc to functions BY REFERENCE

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    
    // for (ll i = 2; i < sz; i++)
    //     fac[i] = (fac[i-1] * i) % mod;
    
    int t = 1;
    // cin >> t;

    while(t--) {
        int n;
        cin >> n;
        
        vector<pair<int,int>> arr(n);
        for (auto &p: arr)
            cin >> p.fi >> p.se;
        
        bool f;
        for (int i = 0; i <= n-3; i++) {
            f = true;
            for (int j = i; j <= i+2; j++) {
                if (arr[j].fi != arr[j].se) {
                    f = false;
                    break;
                }
            }
            if (f)
                break;
        }
        
        cout << (f ? "Yes" : "No") << endl;
    }
    
	return 0;
}
