#include <bits/stdc++.h>
using namespace std;
int main()
{
  long long t,i,j,k,a,b,c=0,d=0,n;
  cin>>n;
  long long A[n],B[n];
for(i=0;i<n;i++)
cin>>A[i]>>B[i];
for(i=0;i<n;i++)
{
  if(A[i]==B[i]) c++;
  else c=0;
  if(c>=3)
  {
     cout<<"Yes"<<endl;
     return 0;
  }
}
cout<<"No"<<endl;
return 0;
}
