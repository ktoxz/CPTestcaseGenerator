N = int(input())
sig = 0
Ans = 'No'
for i in range(N):
  C,D = map(int,input().split())
  if C == D:
    sig += 1
  else:
    sig = 0
  if sig == 3:
    Ans = 'Yes'
print(Ans)