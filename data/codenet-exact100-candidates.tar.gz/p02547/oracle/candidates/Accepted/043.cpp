typedef long long int ll;
typedef unsigned long long int ull;
#define fast  ios_base::sync_with_stdio(false); cin.tie(NULL);
#define MOD 1000000007
#define M_PI           3.14159265358979323846  /* pi */
#define sec second
#define fir first
#define rep(i,n) for(int (i)=0;(i)<(n);(i)++)
#define repe(i,m,n) for(int (i)=(m);(i)<(n);(i)++)
#define entire(a) (a).begin(),(a).end()
#define pb push_back
#define pii pair<int,int>
#include<bits/stdc++.h>
using namespace std;

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int t = 1;
	// cin >> t;
	while (t--) {
		int n,cnt=0;
		cin>>n;
		bool flag= false;

		while(n--){
			int a,b;
			cin>>a>>b;
			if(a==b){
				cnt++;
			}else{
				cnt=0;
			}
			if(cnt==3){
				flag=true;
			}
		}
		cout<<(flag?"Yes\n":"No\n");

	}

	return 0;

}
