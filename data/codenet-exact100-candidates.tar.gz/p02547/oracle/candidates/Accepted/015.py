import math


def a():
    s = input()
    if s[-1] == 's':
        print(s + 'es')
    else:
        print(s + 's')


def b():
    n = int(input())
    d = []
    for i in range(n):
        d.append(list(map(int, input().split())))
    for i in range(n - 2):
        if d[i + 2][0] == d[i + 2][1] and \
            d[i + 1][0] == d[i + 1][1] and \
                d[i][0] == d[i][1]:
            print('Yes')
            break
    else:
        print('No')


def c():
    pass


def d():
    pass


# a()
b()
# c()
# d()
