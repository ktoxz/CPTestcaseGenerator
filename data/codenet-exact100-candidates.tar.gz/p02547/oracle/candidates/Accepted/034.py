N = int(input())
ans = "No"
tmp = 0
for i in range(N):
    d1, d2 = map(int, input().split())
    if d1 == d2:
        tmp += 1
        if tmp == 3:
            ans = "Yes"
            break
    else:
        tmp = 0
print(ans)