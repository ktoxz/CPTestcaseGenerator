n=int(input())
m=0
c=0
for _ in range(n):
	n1,n2=map(int,input().split())
	if n1==n2:
		c+=1
		m=max(m,c)
	else:
		m=max(m,c)
		c=0
if m>=3:
	print('Yes')
else:
	print('No')