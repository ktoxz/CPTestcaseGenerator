#include <bits/stdc++.h>
#define ft first
#define sd second
#define maxn 1000005
#define mod
#define PI 3.14159265
#define MP make_pair
#define PB push_back
#define heap priority_queue
#define Bjerg ""
using namespace std;

void read()
{

}
void solve()
{

}
int main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    //freopen(Bjerg".inp","r",stdin);
    int n;
    cin >> n;
    int cnt=0;
    for(int i=1;i<=n;++i)
    {
        int x , y;
        cin >> x >> y;
        if(x==y) cnt++;
        else cnt=0;
        if(cnt==3)
        {
            cout <<"Yes";
            return 0;
        }
    }
    cout <<"No";
    return 0;
}
