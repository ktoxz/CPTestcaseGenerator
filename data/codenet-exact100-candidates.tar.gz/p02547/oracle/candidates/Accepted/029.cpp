#include<bits/stdc++.h>
using namespace std;

#define ll long long

int main()
{
    int n;
    cin >> n;
    int c=0,f=0;
    while(n--)
    {
        int d1,d2;
        cin >> d1 >> d2;
        if(d1 == d2)
        {
            c++;
        }
        else
        {
            c = 0;
        }
        if(c == 3)
        {
            cout << "Yes" << endl;
            f = 1;
            break;
        }
    }
    if(f == 0)
    {
        cout << "No" << endl;
    }
    return 0;
}