#include<bits/stdc++.h>
using namespace std;
int a[101][2];
int main(){
	int n;
	bool flag=false;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i][1]>>a[i][2];
	}
	for(int i=0;i<n-2;i++){
		if((a[i][1]==a[i][2])&&(a[i+1][1]==a[i+1][2])&&(a[i+2][1]==a[i+2][2])){
			flag=true;
			break;
		}
	}
	if(flag){
		cout<<"Yes";
	}
	else{
		cout<<"No";
	}
	return 0;
}