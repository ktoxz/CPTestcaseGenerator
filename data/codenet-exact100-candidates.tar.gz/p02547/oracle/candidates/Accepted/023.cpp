#include <iostream>
using namespace std;
 
int main()
{   
    int d1, d2, n;
    cin>>n;
    int count=0;
    bool flag=false;
    while(n--){
        cin>>d1>>d2;
        if(d1==d2){
            count++;
            if(count==3)
                break;
        }
        else{
            count=0;
        }
            
    }
    if(count>=3)
        cout<<"Yes"<<endl;
    else
        cout<<"No"<<endl;
        
    return 0;
}