#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int a1[n];
    int a2[n];
    int count = 0;
    for(int i = 0;i<n;i++)
    {
        cin>>a1[i]>>a2[i];
    }
    int flag = 0;
    for(int i = 0;i<n;i++)
    {
        if(a1[i]==a2[i])
        {
            count++;
        }
        else
        {
            count = 0;
        }
        if(count==3)
        {
            flag = 1;
            break;
        }
    }
    if(flag==0)
    {
        cout<<"No"<<endl;
    }
    else
    {
        cout<<"Yes"<<endl;
    }
    return 0;
}