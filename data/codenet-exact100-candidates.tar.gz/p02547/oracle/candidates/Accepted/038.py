n = int(input())
xy = [map(int, input().split()) for _ in range(n)]
x, y = [list(i) for i in zip(*xy)]

ans = 0
for i in range(n):
    if x[i] == y[i]:
        ans += 1
        if ans == 3:
            print("Yes")
            break
    
    else:
        ans = 0
        

if ans == 0 or ans == 1 or ans == 2:
    print("No")


