#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <set>
#include <string>
#include <queue>
#include <stack>
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
constexpr ll MOD = 1000000007;
constexpr ll MAX = 2000;

ll N, D[MAX], E[MAX];

int main()
{
    ll count = 0;
    cin >> N;
    for (int i = 0; i < N; i++)
    {
        cin >> D[i] >> E[i];
    }
    for (int i = 0; i < N - 2; i++)
    {
        if (D[i] == E[i] && D[i + 1] == E[i + 1] && D[i + 2] == E[i + 2])
        {
            count += 1;
        }
    }
    if (count > 0)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }

    return 0;
}