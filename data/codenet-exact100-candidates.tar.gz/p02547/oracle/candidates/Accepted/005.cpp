#include<iostream>
 
using namespace std;
 
int D[100][2];
 
int main()
{
	int n;
	cin>>n;
    //take input
    for(int  i =0; i < n; i++)
    {
    	cin>>D[i][0];
        cin>>D[i][1];
    }
    //check doublets
    for (int i = 0; i < n-2; i++)
    {
    	if (D[i][0] == D[i][1])
        {
        	if (D[i+1][0] == D[i+1][1])
            {
            	if (D[i+2][0] == D[i+2][1])
                {
                	cout<<"Yes";
                    return 0;
                }
            }
        }
    }
    cout<<"No";
}