
N = int(input())

D = input().split()
x = D[0] == D[1]
D = input().split()
y = D[0] == D[1]

for i in range(N - 2):
  D = input().split()
  z = D[0] == D[1]
  if x and y and z:
    print('Yes')
    exit()
  else:
    x = y
    y = z
    
print('No')