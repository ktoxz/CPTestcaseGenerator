n=int(input())
d=[list(map(int,input().split())) for i in range(n)]

flg = False
count = 0
for i in range(n):
  if d[i][0] == d[i][1]:
    flg = True
  else:
    flg = False
    count = 0
    
  if flg:
    count += 1
  if count >= 3:
    print('Yes')
    exit(0)
print('No')