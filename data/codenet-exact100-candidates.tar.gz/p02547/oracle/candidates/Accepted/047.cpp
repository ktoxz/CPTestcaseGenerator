#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <unordered_map>
#define rep(i,n) for( int i = 0; i < n; i++)
using namespace std;
using ll = long long;
#define SIZE_OF_ARRAY(array) (sizeof(array)/sizeof(array[0]))
ll u18 = 1000000000000000000;
int main()
{
    
  int n;
  cin >> n;
  int d[n][2];
  int tmp = 0;
  for ( int i = 0; i < n ; i++){
    cin >> d[i][0] >> d[i][1];
  }
  for ( int i = 0; i < n ; i++){
    if( d[i][0] == d[i][1] ){
      tmp ++;
      if( tmp >= 3 ) break;
    }
    else{
      tmp = 0;
    }
  }
  
  if( tmp >= 3 ){
    cout << "Yes" << endl;
  }
  else{
    cout << "No" << endl;
  }
	
   
  return 0;
}
