#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> P;
const ll MOD=1000000007;
int n;
int a[105],b[105];
bool x,y;
int main(void){
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i]>>b[i];
        if(a[i]==b[i]){
            if(x){
                if(y){
                    cout<<"Yes"<<endl;
                    return 0;
                }else{
                    y=true;
                }
            }else{
                x=true;
            }
        }else{
            x=false;
            y=false;
        }
    }
    cout<<"No"<<endl;
    
}
