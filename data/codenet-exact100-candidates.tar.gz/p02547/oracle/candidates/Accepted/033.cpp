#include <bits/stdc++.h>
using namespace std;

int main(){
    int N;
    cin >> N;
    int len = 0, ok = 0;
    while(N--){
        int a, b;
        cin >> a >> b;
        if(a == b){
            len++;
            if(len >= 3) ok = 1;
        }else{
            len = 0;
        }
    }
    cout << (ok ? "Yes" : "No") << endl;
    return 0;
}
