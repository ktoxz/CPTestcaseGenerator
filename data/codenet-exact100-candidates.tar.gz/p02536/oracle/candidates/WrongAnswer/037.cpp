// ConnectCities.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;

int main()
{
	int N, M;
	int A[100000];
	int B[100000];

	bool tuku[100000];

	cin >> N >> M;

	for (int i = 0; i < M; i++) {
		cin >> A[i] >> B[i];
	}

	for (int i = 0; i < N; i++) {
		tuku[i] = false;
	}

	int cnt = 0;

	queue<int> q;

	q.push(0);

	for (int i = 0; i < N; i++) {
		if (tuku[i] == false) {
			cnt++;
			while (q.size())
			{
				int x = q.front();
				tuku[x] = true;
				q.pop();

				for (int i = 0; i < M; i++) {
					if (x == A[i] - 1) q.push(B[i] - 1);
				}
			}
		}
	}

	cout << cnt - 1 << endl;

}

// プログラムの実行: Ctrl + F5 または [デバッグ] > [デバッグなしで開始] メニュー
// プログラムのデバッグ: F5 または [デバッグ] > [デバッグの開始] メニュー

// 作業を開始するためのヒント: 
//    1. ソリューション エクスプローラー ウィンドウを使用してファイルを追加/管理します 
//   2. チーム エクスプローラー ウィンドウを使用してソース管理に接続します
//   3. 出力ウィンドウを使用して、ビルド出力とその他のメッセージを表示します
//   4. エラー一覧ウィンドウを使用してエラーを表示します
//   5. [プロジェクト] > [新しい項目の追加] と移動して新しいコード ファイルを作成するか、[プロジェクト] > [既存の項目の追加] と移動して既存のコード ファイルをプロジェクトに追加します
//   6. 後ほどこのプロジェクトを再び開く場合、[ファイル] > [開く] > [プロジェクト] と移動して .sln ファイルを選択します
