import collections
n, m = map(int, input().split())
linked = collections.defaultdict(list)
for i in range(1, n + 1):
  linked[i] = [[i]]

for i in range(m):
  a, b = map(int, input().split())
  al, bl = linked[a][0], linked[b][0]
  if al == bl: continue

  al.extend(bl)
  linked[b][0] = al
  
print(linked)


n_connected = 0
n_group = 0
for s in linked.values():
  s = s[0]
  if s:
    n_group += 1
    n_connected += len(s)
    s.clear()
print((n - n_connected) + (n_group - 1))
