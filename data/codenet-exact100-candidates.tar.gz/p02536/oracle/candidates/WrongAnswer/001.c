#include <stdio.h>
#define nmax 100010

int main() {
	const int dif = 100000000;
	int n, m, a[nmax], r = 0, ans = 0;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)a[i] = dif;
	for (int i = 0; i < m; i++) {
		int s, t;
		scanf("%d%d", &s, &t);
		if (a[s] != dif && a[t] != dif && a[t] != a[s])ans--;
		else if (a[s] != dif && a[t] != dif);
		else if (a[t] != dif)a[s] = a[t];
		else if (a[s] != dif)a[t] = a[s];
		else {
			a[s] = r;
			a[t] = r;
			r++;
		}
	}
	for (int i = 1; i <= n; i++)if (a[i] == dif)ans++;
	printf("%d", r - 1 + ans);
	return 0;
}