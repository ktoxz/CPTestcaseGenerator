N,M=map(int,input().split())

for i in range(M):
    A,B=map(int,input().split())
    
print((N-1)-M)