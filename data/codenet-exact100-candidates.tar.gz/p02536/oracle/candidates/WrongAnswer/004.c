#include <stdio.h>

int main(void)
{
	int n, m;
	int a[100000] = {0};
	int b[100000] = {0};
	int i, j,equal;
	
	scanf("%d %d", &n, &m);
	for (i = 0; i < m; i++) {
		scanf("%d %d", &a[i], &b[i]);
	}
	
	equal = 0;
	for (i = 0; i < m; i++) {
		for (j = i + 1; j < m; j++) {
			if ( ((a[i] == a[j]) && (b[i] == b[j])) 
				|| ((a[i] == b[j]) && (b[i] == a[j])) ) {
				equal++;
			}
		}
	}
	printf("%d", (n - 1 - (m - equal)));
	
	return 0;
}