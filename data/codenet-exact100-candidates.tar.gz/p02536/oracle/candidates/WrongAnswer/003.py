N, M = map(int, input().split())
l = [list(map(int, input().split())) for l in range(M)]
sl = sorted(l)
flag = [0 for i in range(N)]
ans = 0
i = sl[0][0]
for s in sl:
    if s[0] == i:
        flag[i - 1] = 1
        flag[s[1] - 1] = 1
    else:
        if flag[s[0] - 1] != 1 and flag[s[1] - 1] != 1:
            ans += 1
        flag[s[0] - 1] = 1
        flag[s[1] - 1] = 1
        i = s[0]

print(ans + flag.count(0))