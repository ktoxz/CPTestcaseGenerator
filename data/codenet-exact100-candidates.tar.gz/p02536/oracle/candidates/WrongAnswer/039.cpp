#include<bits/stdc++.h>
#define ll                long long int
#define ld                long double
#define pb                push_back
#define pf                push_front
#define ppb               pop_back
#define ppf               pop_front
#define sz                size()
#define pi                acos(-1.0)
#define mod               1000000007
#define maxe              max_element
#define mine              min_element
#define F                 first
#define S                 second
#define C                 continue
#define G                 goto done
#define mem(a,b)          memset(a,b,sizeof(a))
#define all(a)            (a).begin(),(a).end()
#define gcd(a,b)          __gcd(a,b)
#define lcm(a,b)          ((a)*((b)/gcd(a,b)))
#define point(a)          fixed<<setprecision(a)
#define get(a)            for(auto &x:a) cin>>x
#define print(a)          for(auto x:a) cout<<x<<" "; cout<<endl
#define see(x)            cout<<#x<<" = "<<x<<endl
#define uniq(a)           sort(all(a)); (a).erase(unique((a).begin(),(a).end()),(a).end())
#define fast              ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define tc                int test; cin>>test; while(test--)
using namespace std;
int main()
{
    ll n,m; cin>>n>>m;
    ll a[n+2]; mem(a,0);
    while(m--)
    {
        ll x,y; cin>>x>>y; a[x]++; a[y+1]--;
    }
    //print(a);
    for(ll i=1;i<=n;i++) a[i]=a[i]+a[i-1];
    //print(a);
    ll c=0;
    for(ll i=1;i<=n;i++) if(a[i]==0) c++;
    cout<<c;
}


















