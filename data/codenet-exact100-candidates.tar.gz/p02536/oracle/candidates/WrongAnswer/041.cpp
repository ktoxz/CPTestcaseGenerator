#include <atcoder/dsu>
#include <cstdio>
#include <iostream>
using namespace std;
using namespace atcoder;

int main() {
    int n, m, i, count;
    cin >> n >> m;
    dsu d(n+1);
    for (i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        d.merge(a, b);
    }
    count = 0;
    for (i = 2; i < n+1; i++){
        if (!d.same(1, i)){
            count++;
        }
    }
    cout << count << endl;
    return 0;
}