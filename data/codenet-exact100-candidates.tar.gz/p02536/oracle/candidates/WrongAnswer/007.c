#include <stdio.h>

int main (void){
    int N;
    int M;
    scanf("%d",&N);
    scanf("%d",&M);
    int A[N];
    int B[N];
    
    for(int i=0;i<M;i++){
        scanf("%d",&A[i]);
        scanf("%d",&B[i]);
    }
    
    printf("%d",N-1-M);
    
    
    
    
return 0;
}