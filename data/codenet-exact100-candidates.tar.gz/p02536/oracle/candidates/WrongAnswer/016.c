#include <stdio.h>
#include <limits.h>

int main(void){

    long long int N;
    long long int M;
    scanf("%lld",&N);
    scanf("%lld",&M);
    
    long long int A[M];
    long long int B[M];
    
    for(int i=0;i<M;i++){
        scanf("%lld",&A[i]);
        scanf("%lld",&B[i]);
    }
    
    int C[N];
    for(int j=0;j<N;j++){
        C[j]=j;
    }
    
    for(int k=0;k<M;k++){
        C[B[k]]=C[A[k]];
    }
    
    int D[N];
    
    for(int t=0;t<N;t++){
        D[t]=0;
    }
    
    for(int g=0;g<N;g++){
        D[C[g]]++;
    }
    long long int answer = 0;
    
    for(int r=0;r<N;r++){
       
        if(D[r]>0){
            answer++;
            }
    }
    
    printf("%lld",answer-1);
    
    return 0;
}