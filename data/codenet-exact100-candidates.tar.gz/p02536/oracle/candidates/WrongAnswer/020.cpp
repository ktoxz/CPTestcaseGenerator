#include<unordered_map>
#include<unordered_set>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;

int main(){

    int n = 0;
    int m = 0;

    cin>>n>>m;

    int group[n] = {};
    for(int i = 0; i < n; i++){ group[i] = i; }

    int a = 0;
    int b = 0;

    for(int i = 0; i < m; i++){
        cin>>a>>b;

        group[b-1] = a-1; 
    }

    int cnt = 0;

    for(int i = 0; i < n; i++){
        // cout<<"group["<<i<<"]: "<<group[i]<<endl;
        if(group[i] == i){ cnt++; }
    }

    cout<<cnt - 1<<endl;

    return 0;
}