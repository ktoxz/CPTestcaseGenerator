N,M=map(int,input().split())
L=[0]*N
s=N-1
for i in range(M):
    A,B=map(int,input().split())
    if L[A-1]==1 or L[B-1]==0:
        s-=1
    L[B-1]=1
print(s)