/*
    हॉंजी । की हाल चाल?
    बड़ीया सब?
*/

#include<bits/stdc++.h>
using namespace std;

#define ff              first
#define ss              second
#define int             long long
#define pb              push_back
#define mp              make_pair
#define pii             pair<int,int>
#define vi              vector<int>
#define mii             unordered_map<int,int>
#define setbits(x)      __builtin_popcountll(x)
#define zrobits(x)      __builtin_ctzll(x)
#define MOD             998244353
#define inf             1e18
#define ps(x,y)         fixed<<setprecision(y)<<x
#define w(x)            int x; cin>>x; while(x--)
#define EPS             1e-9

void gogeta()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
}
#define MN 100001

struct dsu {
    int par[MN];
    int sz;
    void init(int n) {
        for (int i = 0; i < n; i++)  par[i] = i;
        sz = n;
    }

    int get_parent(int x) {
        if (par[x] != x) {
            return par[x] = get_parent(par[x]);
        }
        return x;
    }

    void unite(int x, int y) {
        int par_x = get_parent(x);
        int par_y = get_parent(y);
        // cout << par_x << " " << par_y << endl;
        if (par_x != par_y) {
            par[y] = par_x;
            sz--;
        }
    }

};

int32_t main()
{
    gogeta();
    int n, m; cin >> n >> m;
    struct dsu d;
    d.init(n);
    for (int i = 0; i < m; i++) {
        int x, y; cin >> x >> y;
        d.unite(x - 1, y - 1);
    }
    cout << d.sz - 1 << endl;
    // for (int i = 0; i < n; i++)  cout << d.par[i] << " ";
}
