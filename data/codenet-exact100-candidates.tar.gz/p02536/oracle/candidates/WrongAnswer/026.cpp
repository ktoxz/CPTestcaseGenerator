#include <iostream>
#include<bits/stdc++.h>
#include<vector>
#define ll long long
using namespace std;
void dfs(vector<vector<int>> adj,int i,vector<bool> &vis){
    vis[i]=1;
    for(auto it: adj[i])
    if(!vis[it])
    dfs(adj,it,vis);
}
int32_t main ()
{
 int n,m;
 cin>>n>>m;
 vector<vector<int>> v(n+1);
 for(int i=0;i<m;i++){
     int a,b;
   cin>>a>>b; 
   v[b].push_back(a);
   v[a].push_back(b);
   }
vector<bool> vis(n+1,0);
int cnt=0;
for(int i=1;i<=n;i++)
if(!vis[i]){
dfs(v,i,vis);cnt++;}
 
 cout<<cnt<<endl;
   
   return 0;
}