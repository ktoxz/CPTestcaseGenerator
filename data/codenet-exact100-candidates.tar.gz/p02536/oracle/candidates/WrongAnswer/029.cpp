#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main()
{

    long long n,m,ans;
    set<long long>s;

    cin>>n>>m;
    ll a[m],b[m];
    for(ll i=0;i<m;i++){
        cin>>a[i]>>b[i];
        s.insert(a[i]);
        s.insert(b[i]);
    }
    ans=n-s.size();


       cout<<ans<<"\n";
    return 0;
}
