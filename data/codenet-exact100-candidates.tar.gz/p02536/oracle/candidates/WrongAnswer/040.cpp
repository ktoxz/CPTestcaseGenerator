//#include <bits/stdc++.h>
#include <iostream>
#include <vector>

#define rep(i,n) for (int i = 0; i < (n); ++i)
using namespace std;
using ll = long long;


int main(){
    //int n;
    //string s;
    //ll a,b,c,d;
    int n,m;
    cin>>n>>m;
    vector<int> c(n);
    rep(i,n)c[i]=1;

    //vector<int> a(m),b(m);
    int a,b;
    int sum=0;
    rep(i,m) {
        cin>>a>>b;
        if(c[b-1]==1 && c[a-1]==1){
            sum++;
            c[b-1]=0;
            c[a-1]=0;
        }else if(c[b-1]==0 || c[a-1]==0){
            c[b-1]=0;
            c[a-1]=0;
        }
    }

    rep(i,n)sum+=c[i];
    cout<<sum-1<<endl;

} // end of main

//実行は、Opt + Ctl + N