#include <stdio.h>
int main(void){
    int n, m, a[100001], b[100001], f[100001], i, ii, ans = 0;
    scanf("%d%d", &n, &m);
    for (i = 0; i < m; i++)
        scanf("%d%d", a + i, b + i);
    for (i = 0; i < n; i++)
        f[i + 1] = i + 1;
    
    for (i = 0; i < m; i++)
    {
        if (f[a[i]] == a[i])
            f[a[i]] = f[b[i]];
        else
            f[b[i]] = f[a[i]];
    }
        
        
    for (i = 0; i < n; i++)
        if (f[i] == i)
            ans++;
    printf("%d", ans - 1);
}
