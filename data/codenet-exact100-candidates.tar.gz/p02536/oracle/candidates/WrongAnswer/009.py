n,m=map(int,input().split())
l=[]
for i in range(m):
    x,y=map(int,input().split())
    l.append(x-1)
    l.append(y-1)
out=0
for i in range(n):
    if i not in l:
        out+=1
print(out)