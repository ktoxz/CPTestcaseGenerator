#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ii = pair<int,int>;

const int mx = 2e5+5;
int n, m, vis[mx];
vector<int> g[mx];

void dfs(int u){
    vis[u] = 1;
    for(int v : g[u])
        if(!vis[v])
            dfs(v);
}

int main(){

    ios_base::sync_with_stdio(0);
    cin.tie(nullptr); cout.tie(nullptr);

    cin >> n >> m; int u, v;
    while(m--){
        cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(v);
    }

    int ans = -1;
    for(int i=1; i<=n; i++)
        if(!vis[i]) dfs(i),  ans++;
    cout << ans << "\n";
    return 0;
}

