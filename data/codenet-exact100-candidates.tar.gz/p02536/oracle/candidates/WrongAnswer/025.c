#include <stdio.h>

int main()
{
  int n,m, result = 0;
  scanf("%d %d", &n, &m);
  int estradas[m][2];

  int marcar[100001] = {0};
  for(int i=0; i<m; ++i)
  {
    scanf(" %d %d", &estradas[i][0], &estradas[i][1]);
    marcar[estradas[i][0]]++;
    marcar[estradas[i][1]]++;

    if(marcar[estradas[i][0]] == 2) result++;
    if(marcar[estradas[i][1]] == 2) result++;
  }

  if(n-result <= 2)
    printf("%d\n", 0);
  else
    printf("%d\n", n-2-result);



  return 0;
}
