
// Problem : C - Connect Cities
// Contest : AtCoder - ACL Beginner Contest
// URL : https://atcoder.jp/contests/abl/tasks/abl_c
// Memory Limit : 1024 MB
// Time Limit : 2000 ms
// Powered by CP Editor (https://github.com/cpeditor/cpeditor)

#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007
#define fast ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)

int main() {
	fast;
	ll n,m;
	cin>>n>>m;
	ll diff=n-1-m;
	ll x,y;
	while(m--)
		cin>>x>>y;
	cout<<(diff>=0?diff:0);
	return 0;
}




