#include <bits/stdc++.h>

typedef unsigned long long int ull;
typedef long long int ll;

#define deb(x) cout << (#x) << " - " << x << "\n"; 
ull M = 1000000007;

using namespace std;

int main()
{
    // *********************
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    // *********************
    
    // Driver Function Starts Here

    int n, m;
    cin >> n >> m;
    int a, b;
    for (int i=0; i<m; i++)
    cin >> a >> b;
    int total_roads = n-1, ans = total_roads - m;
    cout << ans << "\n";

    // Driver Function Ends Here
    return 0;
}