#include <bits/stdc++.h> //
using namespace std;

typedef unsigned long long int LL;
typedef pair<int, int> pii;
typedef pair<LL, LL> pll;
typedef pair<string, string> pss;
typedef vector<LL> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;
typedef vector<LL> vl;
typedef vector<vl> vvl;

/* Author : Adnan Ullah
   Creating an algo for long digit addition
   */



int visited[10000060];

int CNT=0;
int bfs(int s, int n,vector<int> adj[])
{
    for(int i =0 ; i< n ; i++)
        visited[i] = 0;

    queue<int> Q;
    Q.push(s);
    visited[s] = 1;


    while(!Q.empty())
    {
        int  u = Q.front();
        Q.pop();

        for(int i = 0 ; i< adj[u].size() ; i++)
        {
              if(adj[u].size() == 1)
            {
                adj[u].push_back(u+1);
                CNT++;
            }
            if(visited[adj[u][i]] ==0)
            {
                int v = adj[u][i];
                visited[v] = 1;
                Q.push(v);
            }

        }
    }

    return CNT;
}

int main()
{
     LL N;cin>>N;
    vector<int> adj[N];
    LL m,a,b;

    cin>>m;
    cin>>a>>b;
    adj[a].push_back(b);

   cout<< bfs(1,N,adj)<<endl;



}
