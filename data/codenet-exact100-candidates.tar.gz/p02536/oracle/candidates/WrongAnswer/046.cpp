#include <iostream>
#include <vector>

using namespace std;

class DisjointSet{
    public:
        vector<int> rank, p;
        DisjointSet(){}
        DisjointSet(int size){
            rank.resize(size, 0);
            p.resize(size, 0);
            for(int i = 1; i < size; i++){
                p[i] = i;
                rank[i] = 0;
            }
        }

        void unite(int x, int y){
            link(findSet(x), findSet(y));
        }

        void link(int x, int y){
            if(rank[x] > rank[y]){
                p[y] = x;
            }else{
                p[x] = y;
                if(rank[x] == rank[y]){
                    rank[y]++;
                }
            }
        }

        int findSet(int x){
            if(x != p[x]){
                p[x] = findSet(p[x]);
            }
            return p[x];
        }
};

int main()
{
    int n, a, b, m;
    int cnt = 0;
    cin >> n >> m;
    DisjointSet ds = DisjointSet(n + 1);
    for(int i = 0; i < m; i++){
        cin >> a >> b;
        ds.unite(a, b);
    }
    for(int i = 2; i <= n; i++){
        if(ds.p[1] != ds.p[i]){
            ds.unite(i, 1);
            cnt++;
        }
    }
    for(int i = 1; i <= n; i++){
        cout << ds.p[i] << endl;
    }
    cout << cnt << endl;
    return 0;

}