#include<cstdio>
#include<cstdlib>
#include<iostream>
using namespace std;
int n,m,a,b,f[100002];
bool fa[100002];

void find(int x)
{
	if (f[x]!=x)
	  {
	  	find(f[x]);
	  	f[x]=f[f[x]];
	  }
	  return;
 } 

int main()
{
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++) f[i]=i;
	for (int i=1; i<=m; i++)
	 {
	 	scanf("%d%d",&a,&b);
	 	find(a); find(b);
	 	if (f[a]!=f[b]) f[f[b]]=f[a];
	 }
	 int ans=0;
	  
	for (int i=1; i<=n; i++)
	 if (fa[f[i]]==0) {ans++;
	  fa[f[i]]=1;
	 }
	 ans--;
	printf("%d",ans); 
	return 0;
 } 