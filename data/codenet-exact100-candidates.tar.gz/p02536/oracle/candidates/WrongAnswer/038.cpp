#include <atcoder/dsu>
#include <cstdio>
#include <iostream>
using namespace std;
using namespace atcoder;

int main() {
    int n, m, i, j, count;
    cin >> n >> m;
    dsu d(n+1);
    for (i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        d.merge(a, b);
    }
    count = 0;
    for (i = 1; i < n+1; i++){
        int cnt = 0;
        for (j = 1; j < n+1; j++){
            if (i != j){
                if (!d.same(i, j)){
                    cnt++;
                }
            }else{
                break;
            }
        }
        if (cnt == n-1){
          count++;
        }
    }
    cout << count << endl;
    return 0;
}