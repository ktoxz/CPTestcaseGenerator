#include <bits/stdc++.h>
using namespace std;
 
int main() {
  int N,M;
  cin >> N >> M;
  vector<vector<int>> road(M,vector<int>(2));
  for(int i = 0;i < M;i++){
    cin >> road.at(i).at(0);
    cin >> road.at(i).at(1);
  }
  vector<bool> sure(N,true);
  for(int i = 0; i < M;i++){
    if(road.at(i).at(0) > road.at(i).at(1)){sure.at(road.at(i).at(0)-1) = false;
} else {sure.at(road.at(i).at(1)-1) = false;}
                }
  
  int ans = 0;
  for(int i = 0; i < N;i++){
    if(sure.at(i)){
      ans++;
    }
  }
  cout << ans-1 << endl;
}