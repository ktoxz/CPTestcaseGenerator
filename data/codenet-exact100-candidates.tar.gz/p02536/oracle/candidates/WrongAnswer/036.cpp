#include<bits/stdc++.h>
#define int long long
#define REP(i,a,n) for(int i=a;i<(n);i++)
#define REP_sz(i,s) for(int i=0;i<s.size();i++)
#define RE return
#define FILL(a,b) memset(a,b,sizeof(a))
#define SO(a) sort(all(a))
#define pb push_back
#define sz(a) a.size()
#define V vector
#define ld long double
#define viit(a) vector<int>::iterator a
#define msit1(a) map<string,int>::iterator a
#define miit(a) map<int,int>::iterator a
#define msit2(a) map<int,string>::iterator a
#define IT iterator
#define FOR(i,a,n) for(int i=a;i<=(n);i++)
#define B(s) s.back()
#define all(a) a.begin(),a.end()
#define ER1(a) a.erase(a.begin())
#define ER0(a) a.erase(a.end())
#define pii pair<int,int>
#define pause system("PAUSE")
#define cls system("CLS")
using namespace std;
V<int>a[1000001];
int vis[1000001];
int n,m,groups=0;
void find(int x){
	REP(i,0,a[x].size())
	{
		if(!vis[a[x][i]]){
			vis[a[x][i]]=1;
			find(a[x][i]);
		}
	}
}
signed main()
{
	ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
	cin>>n>>m;
	REP(i,0,m){
		int x,y;
		cin>>x>>y;
		x--;y--;
		a[x].pb(y);
		a[y].pb(x);
	}
	find(0);
	int cnt=0;
	REP(i,1,n)
	if(!vis[i])cnt++;
	cout<<cnt;
    return 0;
}
