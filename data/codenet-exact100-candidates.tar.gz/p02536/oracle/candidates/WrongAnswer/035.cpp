#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int i = 0; i < (n); i++) 
#define all(v) begin(v),end(v)
using ll = long long;

int main() {
  int n,m;cin>>n>>m;
  map<int,int> mp;
  rep(i,m){
    int a,b;cin>>a>>b;
    mp[a]++,mp[b]++;
  }
  int cnt=0;
  for(auto x:mp){
    cnt=max(cnt,x.second);
  }
  cout<<n-1-cnt<<endl;
}