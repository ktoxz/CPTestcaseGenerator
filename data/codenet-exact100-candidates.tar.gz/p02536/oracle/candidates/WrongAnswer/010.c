#include <stdio.h>

int main(){
	int n, m, res=1;
	scanf("%d%d",&n,&m);
	int a[m],b[m];
	for(int i=0;i<=m-1;i++){
		scanf("%d%d",&a[m],&b[m]);
	}
	for(int i=n;i<=n-1;i--){
		res *= i;
	}
	res /=2;
	res -= m;
	printf("%d",res);

}