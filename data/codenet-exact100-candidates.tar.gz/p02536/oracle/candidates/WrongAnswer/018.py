N,M = map(int, input().split())
roads_list = []
for _ in range(M):
    roads_list.append(list(map(int, input().split())))

roads = 0
if N == 2:
    if M == 1:
        print("0")
    else:
        print("1")

if N >= 3:
    roads = N - (M+1)
    print(roads)