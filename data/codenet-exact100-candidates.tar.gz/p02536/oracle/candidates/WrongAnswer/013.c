#include<stdio.h>
int first[200000],b[200000];
int go[400000],next[400000];
void search(int k){
	int t=first[k];
	while (t!=0){
		int v=go[t];
		if (b[v]==1){
			b[v]=0;
			search(v);
		}
		t=next[t];
	}
}
int main(){
	int n,m;
	int x,y;
	scanf("%d %d",&n,&m);
	for (int i=1;i<=m;i++){
	scanf("%d %d",&x,&y);
    next[i]=first[x];
    first[x]=i;
    go[i]=y;
    next[i+m]=first[y];
    first[y]=i+m;
    go[i+m]=x;
	}
	int count=0;
	for (int i=1;i<=n;i++){
		b[i]=1;
	}
	for (int i=1;i<=n;i++){
		count++;
		b[i]=0;
		search(i);
	}
	printf("%d",count-1);
}