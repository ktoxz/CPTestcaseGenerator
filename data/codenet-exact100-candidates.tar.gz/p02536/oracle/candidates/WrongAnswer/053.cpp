#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct UnionFind{
  vector<int64_t> S;
  vector<int64_t> weight;
  
  UnionFind(int N){
    S = vector<int64_t>(N,0);
    weight = vector<int64_t>(N,1);
    for(int i = 0 ; i < N ; i++){
      S.at(i) = i;
      weight.at(i) = 1;
    }
  }
  
  int root(int x) { // データxが属する木の根を再帰で得る：root(x) = {xの木の根}
    if(S.at(x) == x){
     return x; 
    }
    return S.at(x) = root(S.at(x));
  }
  
  void unite(int x, int y) { // xとyの木を併合
    int rx = root(x); //xの根をrx
    int ry = root(y); //yの根をry
    //cout << rx << ":" << ry <<endl;
    if (rx == ry){
      return;
    }
    if (S.at(x) > S.at(y)){
      swap(x, y);
    }
    //cout << x << ":" << y <<endl;
    weight.at(S.at(x)) += weight.at(S.at(y));
    S.at(y) = S.at(x);
    return; //xとyの根が同じでない(=同じ木にない)時：xの根rxをyの根ryにつける
  }
  
  int size(int x){
    return weight.at(x);
  }
  
  //bool same(int x, int y) { // 2つのデータx, yが属する木が同じならtrueを返す
    //int rx = root(x);
    //int ry = root(y);
    //return rx == ry;
  //}
  
};

int main(){//main_program
  int64_t N,M,S,count;
  S = -1;
  count = -1;
  cin >> N >> M;
  UnionFind UF(N);
  vector<int> A(N);

  for(int i = 0; i < M ; i++){
    int64_t k,l;
    cin >> k >> l;
    k--;l--;  
    UF.unite(k,l);
  }
  
  for(int i = 0; i < N ; i++){
    A.at(i) = UF.root(i);
  }
  //cout <<endl;
  sort(A.begin(), A.end());
  
  for(int i = 0; i < N ; i++){
    if(S != A.at(i)){
      count++;
    }
    //cout << A.at(i) << ":" << S << ":" << count <<endl;
    S = A.at(i);
  }
  
  cout << count <<endl;
  
}
