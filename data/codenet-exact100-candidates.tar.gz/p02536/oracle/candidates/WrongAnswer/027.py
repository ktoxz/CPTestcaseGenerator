n,m = (int(x) for x in input().split()) 
alist =[]
blist =[]
for i in range(m):
    a,b = (int(x) for x in input().split()) 
    alist = alist + [a]
    blist = blist + [b]
for i in range(m):
    for j in range(m):
        if alist[j-1] == i:
            blist[j-1] = i
        if blist[j-1] == i:
            alist[j-1] = i
world1 = set(alist)
world2 = set(blist)
world  = world1|world2
print(len(world)-1)