#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>
#include <stdarg.h>
#include <algorithm>
#include <iostream>
#include <set>

#define ll long long

using namespace std;

ll color[100005];

ll
getColor(ll n) {
  ll end = n;
  while (color[end] != end) 
    end = color[end];

  ll mid = n;
  while (color[mid] != end) {
    ll temp = color[mid];
    color[mid] = end;
    mid = temp;
  }

  return end;
}

int
main() {
  ll n, m;
  cin>>n>>m;
  for (ll i=1; i<=n; i++) color[i] = i;

  ll x, y;
  for (ll i=0; i<m; i++) {
    cin>>x>>y;

    ll a = getColor(x);
    ll b = getColor(y);
    color[a] = b;
  }

  set<ll> c;
  for (ll i=1; i<=n; i++)
    c.insert(color[i]);
  cout<<c.size()-1<<endl;

  return 0;
}
