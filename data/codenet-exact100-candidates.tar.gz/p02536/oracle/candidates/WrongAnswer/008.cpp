
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <cmath>
#include <string>
#include <sstream>
#include <cstdio>
#include <cstring>
using namespace std;
typedef long long  ll;


int f[100005];
int rk[1000005];
int find(int x){
    if(f[x]!=x) f[x]=find(f[x]);
    return f[x];
    

   
}


void join(int x,int y){
    int fx=find(x);
    int fy=find(y);
    if(rk[fx]<=rk[fy]) {f[x]=fy;rk[fy]+=rk[fy];}
    else {f[y]=fx;rk[fx]+=rk[fy];}
    
    
    
}
/*1 2
3 4
3 5*/


int main(int argc, const char * argv[]) {
    
    
    for(int i=1;i<=100000;i++) {f[i]=i;rk[i]=1;};
    
    int n,m;cin>>n>>m;
    map<int,int>mp;
    while (m--) {
        int u,v;cin>>u>>v;
        join(u, v);
        
    }
    
    for(int i=1;i<n;i++) f[i]=find(i);
    
  //  for(int i=1;i<=n;i++) cout<<f[i]<<" ";
           
    
   
   // cout<<endl;
    for(int i=1;i<=n;i++){
        mp[f[i]]++;
    }
    cout<<mp.size()-1<<endl;
    
    
    
    
    
   
    
    
    
     
    return 0;
}













