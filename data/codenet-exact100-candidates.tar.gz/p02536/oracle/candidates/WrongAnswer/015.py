n, m = map(int, input().split())
ab = [list(map(int, input().split())) for _ in range(m)]

dup = [tuple(d) for d in ab]
unique = set(dup)
unique = [list(d) for d in unique]
print((n - 1) - len(unique))