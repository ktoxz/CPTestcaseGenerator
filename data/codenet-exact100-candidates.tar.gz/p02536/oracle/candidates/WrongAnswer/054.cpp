#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <iostream> // cout, endl, cin
#include <iomanip>
#include <string> // string, to_string, stoi
#include <vector> // vector
#include <algorithm> // min, max, swap, sort, reverse, lower_bound, upper_bound
#include <utility> // pair, make_pair
#include <tuple> // tuple, make_tuple
#include <cstdint> // int64_t, int*_t
#include <cstdio> // printf
#include <map> // map
#include <queue> // queue, priority_queue
#include <set> // set
#include <stack> // stack
#include <deque> // deque
#include <unordered_map> // unordered_map
#include <unordered_set> // unordered_set
#include <bitset> // bitset
#include <cctype> // isupper, islower, isdigit, toupper, tolower
#include <math.h>
#include <atcoder/all>
using namespace std;
using namespace atcoder;

int main(){
    long long N, M;
    cin >> N >> M;
    dsu d(N + 1);
    for(int i = 0; i < M; i++){
        long long A, B;
        cin >> A >> B;
        d.merge(A, B);
    }
    vector<vector<int>> G = d.groups();
    long long ans = G.size() - 1;
    cout << ans << endl;
}