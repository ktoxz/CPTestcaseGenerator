i = list(map(int, input().split()))
p = [map(int, input().split()) for _ in range(i[1])]
print(i[0]-1-i[1])