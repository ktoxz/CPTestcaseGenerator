#include <bits/stdc++.h>
using namespace std;

int main() {
  int N, M;
  cin >> N >> M;

  vector<vector<int>> A(M, vector<int>(2));
  for(int i=0; i<M; i++){
    for(int j=0; j<2; j++){
      cin >> A.at(i).at(j);
    }
  }


  cout << (N-M-1)<< endl;

return 0;  
}