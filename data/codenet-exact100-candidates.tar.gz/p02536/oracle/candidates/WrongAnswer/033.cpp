#include <bits/stdc++.h>

using namespace std;

int main()
{
 	int n,m;
    cin>>n>>m;
    vector<int> a[n+2];
    for(int i=0;i<m;i++)
	{
        int u,v;
        cin>>u>>v;
        a[u].push_back(v);
        a[v].push_back(u);
	}
    bool q[n+2]={0};
    for(int i=1;i<=n;i++)
	{
        if(a[i].size())
		{
            q[i]=1;
            break;
		}
	}
    int dem=0;
    for(int i=1;i<=n;i++)
	{
        int u=i;
        if(q!=0)
        for(int v=0;v<a[u].size();v++)
		{
            q[a[u][v]]=1;
		}
        if(q[u]==0)
		{
			q[u]=1;
			dem++;
            for(int v=0;v<a[u].size();v++)
			{
                q[a[u][v]]=1;
			}
		}
	}
	cout<<dem;
}
