#include<bits/stdc++.h>
#define rep(i,n) for(int i= 0;i < (n); i++)
using namespace std;
using ll = long long;
using P = pair<int,int>;
//vector<> vec(n);

int main(){
  ll n,m;
  cin >> n >> m ;
  vector<ll> a(m);
  vector<ll> b(m);
  vector<ll> c;
  c.reserve(n);
  int flg_a=0,flg_b=0;
  rep(i,m){
    cin >> a[i] >> b[i];
    for(int j=0;j<i;j++){
      cout << c[j] << endl;
      if(c[j]==a[i]){flg_a=1; continue;}
      else if(c[j]==b[i]){flg_b=1; continue;}
    }
    if(flg_a==0){
      c.push_back(a[i]);
      flg_a=0;
    }
    if(flg_b==0){
      c.push_back(b[i]);
      flg_b=0;
    }
  }

  cout << n-c.size() << endl;
  
  return 0;
}