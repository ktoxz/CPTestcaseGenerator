#include<stdio.h>
#include<stdlib.h>
int *a;
int findRoot (int x){
	if (a[x]<0) return x;
	else return a[x]=findRoot(a[x]);
}
void unite(int k1,int k2){
	int q=findRoot(k1);
	int w=findRoot(k2);	
	if (w!=q) a[w]=q;
}
int ans(int *p,int n){
	int k=0;
	while (n) {
		if(p[n-1]<0) k++;
		n--;
	}
	return k;
}
int main(){
	int n,m,i;
	scanf("%d%d",&n,&m);
	a=(int*)malloc(n*sizeof(int));
	for (i=0;i<n;i++) a[i]=-1;
	while(m){
		int k1,k2;
		scanf("%d%d",&k1,&k2);
		k1--;
		k2--;
		printf("Qqq\n");
		unite (k1,k2);
		printf("www\n");
		m--;
	}
	int q=ans(a,n);
	printf("%d\n",q-1);
	free(a);
	return 0;
}
