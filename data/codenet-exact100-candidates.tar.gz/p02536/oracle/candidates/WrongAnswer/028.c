#include <stdio.h>

int main(void){
  int N,M;
  int cnt;
  int A[100000],B[100000];
  scanf("%d %d",&N,&M);
  cnt = N-1;
  int i;
  for(i=0;i<M;i++){
    scanf("%d %d",&A[i],&B[i]);
  }
  
    int c[100001];
  for(i=1;i<=N;i++){
    c[i]=i;
  }
  for(i=0;i<M;i++){
     if(c[B[i]] != 0){
      c[B[i]]=0;
    }
  }
  
  
  int TC=0;
  for(i=1;i<=N;i++){
 //   printf("[%d] ",c[i]); 
    if(c[i]==0){
      TC++;
    }
  }
 // printf("cnt %d \nTC %d \n",cnt,TC);
    printf("%d",cnt-TC);
    return 0;
  }