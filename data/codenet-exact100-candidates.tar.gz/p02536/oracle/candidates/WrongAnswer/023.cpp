#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

#define debug(x) cout << #x << " : " << x << '\n';


// code //


int main() {
	ios::sync_with_stdio(false);

	int n, m;
	cin >> n >> m;

	for(int i=0; i<m; ++i) {
		int a, b; cin >> a >> b;
	}

	if(m>=n-1)
		cout << 0;
	else cout << n-1-m;	
}	
