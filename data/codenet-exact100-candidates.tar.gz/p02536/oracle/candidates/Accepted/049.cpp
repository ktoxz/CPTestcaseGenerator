#include<bits/stdc++.h>
#define fastio ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define ll long long
#define all(x) (x).begin(),(x).end()
#define print(x) if(x)cout<<"Yes\n";else cout<<"No\n";
#define f(i,x,y) for(ll i=x;i<=y;i++)
#define rf(i,x,y) for(ll i=x;i>=y;i--)
#define pb push_back
#define F first
#define S second
#define mod 1000000007
using namespace std;
ll expo(ll x, ll y)
{
  if (y == 1)
    return x;
  if (y % 2 == 1)
    return (x * (expo((x * x) % mod, (y - 1) / 2)) % mod) % mod;
  else
    return  (expo((x * x) % mod, y / 2)) % mod;
}
vector<ll> v[100000 + 1];
ll vis[100000 + 1];
void dfs(ll n)
{
  vis[n] = 1;
  for (auto x : v[n])
  {
    if (!vis[x])
      dfs(x);
  }
}
int main()
{
// #ifndef HP
//   freopen("in.txt", "r", stdin);
//   freopen("out.txt", "w", stdout);
// #endif
  fastio;
  int t = 1;
  //cin >> t;
  while (t--)
  {
    ll n, m;
    cin >> n >> m;
    ll i, p, q;
    for (i = 0; i < m; i++)
    {
      cin >> p >> q;
      v[p].pb(q);
      v[q].pb(p);
    }
    ll ans = 0;
    for (i = 1; i <= n; i++)
    {
      if (!vis[i])
      {
        dfs(i);
        ans++;
      }
    }
    cout << ans - 1 << endl;
  }
}
