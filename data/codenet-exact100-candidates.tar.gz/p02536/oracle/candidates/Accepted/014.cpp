
#include <bits/stdc++.h>
#include <atcoder/all>

typedef unsigned long long ULLONG;
typedef long long LLONG;
static const LLONG MOD_NUM = 1000000007; //998244353;

template<class _T> static void get(_T& a) {
	std::cin >> a;
}
template<class _T> static void get(_T& a, _T& b) {
	std::cin >> a >> b;
}
template<class _T> static void get(_T& a, _T& b, _T& c) {
	std::cin >> a >> b >> c;
}
template <class _T> static _T tp_abs(_T a) {
	if (a < (_T)0) {
		a *= (_T)-1;
	}
	return a;
}

static void C_task();

int main()
{
	C_task();
	fflush(stdout);
	return 0;
}

static void C_task()
{
	int N, M;
	get(N, M);

	atcoder::dsu gr(N);
	int a, b;
	for (int i = 0; i < M; i++) {
		get(a, b); a--; b--;
		gr.merge(a, b);
	}
	int ans = gr.groups().size();
	printf("%d\n", ans - 1);
}
