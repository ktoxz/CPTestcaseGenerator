#include <bits/stdc++.h>
#include <ctype.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int, int> ii;
typedef pair<ll, int> li;
typedef pair<int, ll> il;
typedef vector<ii> vii;
typedef vector<il> vil;
typedef vector<li> vli;

#define ff first
#define PI acos(-1.0)
#define ss second
#define pb push_back
#define mp make_pair
#define sz size()
#define MOD 1000000007
#define MOD1 998244353
#define ep 0.000000001
int dx8[] = {0, 0, 1, 1, 1, -1, -1, -1};
int dy8[] = {1,-1, 1, -1, 0, 0, -1, 1};
int dx4[] = {0, 0, 1, 1};
int dy4[] = {1, -1, 1, -1};
//#define fio() ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)

vector<int>path[1000010];
int level[100010], vis[100010];
void bfs(int start)
{
    queue<int>q;
    level[start]=0;
    q.push(start);
    vis[start]=1;
    while(!q.empty())
    {
        int v=q.front();
        q.pop();
        for(int i=0;i<path[v].size();i++)
        {
            if(vis[path[v][i]]==0)
            {
                level[path[v][i]]=level[v]+1;
                vis[path[v][i]]=1;
                q.push(path[v][i]);

            }
        }
    }
}

int main()
{
    #ifndef ONLINE_JUDGE
    freopen ("in.txt", "r", stdin);
    freopen ("out.txt", "w", stdout);
    #endif
    int n, e, n1, n2, c=0, cnt=0;  
    cin>>n>>e; map <int, int> mp;
    for(int i=0;i<e;i++){
        cin>>n1>>n2; mp[n1]=-1; mp[n2]=-1;
        path[n1].push_back(n2);
        path[n2].push_back(n1);
    }
    for(int i=1;i<=n;i++){
        if(mp[i]==0)cnt++;
        else if(vis[i]==0)c++,bfs(i);
    }
    ll ans=0; 
    ans+=cnt; if(c>1)ans+=(c-1);
    cout<<ans<<endl;
    //for(int i=1;i<=n;i++) cout<<i<<" "<<level[i]<<endl;
    return 0;
}