#include <bits/stdc++.h>
using namespace std;
  #define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  #define int long long
  #define endl "\n"
  #define all(v) v.begin(),v.end()
  #define double long double
  #define trace1(x)                cerr<<#x<<": "<<x<<endl
  #define trace2(x, y)             cerr<<#x<<": "<<x<<" | "<<#y<<": "<<y<<endl
  #define trace3(x, y, z)          cerr<<#x<<":" <<x<<" | "<<#y<<": "<<y<<" | "<<#z<<": "<<z<<endl
  #define trace4(a, b, c, d)       cerr<<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<endl
  #define trace5(a, b, c, d, e)    cerr<<#a<<": "<<a<<" | "<<#b<< ": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<" | "<<#e<< ": "<<e<<endl
  #define trace6(a, b, c, d, e, f) cerr<<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<" | "<<#e<< ": "<<e<<" | "<<#f<<": "<<f<<endl
  #define cases int testcases;cin>>testcases; while(testcases--)
  const int N = 200005;

  int ans;

    vector<int> adj[N];
    vector<int> vis(N,false);
    void dfs(int s)
    {
      if(!vis[s])
      {

        vis[s] = true;
  
        for(auto i : adj[s])
        {
          if(!vis[i])dfs(i);
        }
      }
    }


int32_t main()
{


    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    #endif
    IOS


   	int n,m;
   	cin >> n >> m;


   	for(int i = 1; i <= m; i++)
   	{
   		int x,y;
   		cin >> x >> y;

   		adj[x].push_back(y);
   		adj[y].push_back(x);
   	}


   	for(int i = 1; i <= n; i++)
   	{
   		if(!vis[i])
   		{
   			dfs(i);
   			ans++;
   		}
   	}

   	cout << ans - 1;

   	
    return 0;
}
