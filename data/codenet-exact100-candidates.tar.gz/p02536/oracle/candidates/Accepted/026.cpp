#include<bits/stdc++.h>
using namespace std;
const int N=100005;
int p[N],cnt;
int find(int x){
	if (x==p[x]) return x;
	return find(p[x]);
}
void Union(int x,int y){
	x=find(x);
	y=find(y);
	if (x==y) return;
	p[x]=p[y];
	cnt--;
}
int ans;
bool pa[N];
int main(){
	int n,m;
	scanf("%d %d",&n,&m);
	cnt=n;
	for (int i=1;i<=n;i++) p[i]=i;
	for (int i=1;i<=m;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		Union(a,b);
	}
	printf("%d\n",cnt-1);
	return 0;
}