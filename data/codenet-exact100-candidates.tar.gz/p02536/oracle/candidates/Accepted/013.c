#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define ll long long
#define mod 1000000007
#define max(p,q)((p)>(q)?(p):(q))
ll powe(ll a,ll n,int m){ll x=1;for(a%=m;n;n/=2)n&1?x=x*a%m:0,a=a*a%m;return x;}
int upll(const void*a, const void*b){return*(ll*)a<*(ll*)b?-1:*(ll*)a>*(ll*)b?1:0;}
void sortup(ll*a,int n){qsort(a,n,sizeof(ll),upll);}


ll n,m;
int a,b;
ll par[112345];
int find(int x){
  if(par[x]==x) return x;
  return par[x]=find(par[x]);
}
void unite(int x,int y){
  int rx=find(x);
  int ry=find(y);
  if(rx==ry) return;
  par[rx]=ry;
}


int main(){
  scanf("%lld%lld",&n,&m);
  ll ans=0;
  for(int i=0;i<=n;i++){
    par[i]=i;}

  for(int i=0;i<m;i++){
    scanf("%d%d",&a,&b);
    if(find(a)!=find(b)){
      unite(a,b);}
    }
  for(int i=1;i<n;i++){
    if(find(i)!=find(i+1)){
      ans++;
      unite(i,i+1);}}
  
  printf("%lld\n",ans);
  return 0;
}
