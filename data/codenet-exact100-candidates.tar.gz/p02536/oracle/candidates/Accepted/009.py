from collections import defaultdict
from sys import setrecursionlimit
setrecursionlimit(10**6)
n,m=map(int,input().split())
d=defaultdict(list)
for i in range(m):
    a,b=map(int,input().split())
    d[a].append(b)
    d[b].append(a)
def dfs(node):
    vis.add(node)
    for i in d[node]:
        if i not in vis:
            dfs(i)
vis=set()
ans=0
for i in range(1,n+1):
    if i not in vis:
        dfs(i)
        ans+=1
print(ans-1)