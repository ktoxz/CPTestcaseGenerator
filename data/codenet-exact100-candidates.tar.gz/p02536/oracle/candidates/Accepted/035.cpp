#include <bits/stdc++.h>

using namespace std;
#define fast	ios::sync_with_stdio(0);cin.tie(0);
#define ll 		long long int
#define INF     1e18L
#define precision(x)	fixed << setprecision(x)
const ll mod = 1e9 + 7;

ll gcd(ll a, ll b) {
	if (b == 0)  return a;
	return gcd(b , a % b);
}


ll powm(ll a, ll b) {
	ll res = 1;
	while (b) {
		if (b & 1)
			res = (res * 1LL * a) % mod;
		b >>= 1LL;
		a = (a * 1LL * a) % mod;
	}
	return res;
}
const int N = 2e5 + 5;
const int M = 2005;

//--------------------------------------------------------------------------------------------------------------------------//
int vis[N];
vector<int> g[N];

void dfs(int v) {
	if (vis[v]) return;
	vis[v] = 1;
	for (auto u : g[v]) {
		dfs(u);
	}
}
void solve() {
	int n, m;
	cin >> n >> m;

	for (int i = 0; i < m; i++) {
		int a, b; cin >> a >> b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	int ans = -1;
	for (int i = 1; i <= n; i++) {
		if (!vis[i]) {
			++ans;
			dfs(i);
		}
	}
	cout << ans << endl;
}

int main() {
	fast
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int tc = 1;
	// cin >> tc;

	int _ = 0;
	while (_++ < tc) {
		solve();
	}

	return 0;
}




