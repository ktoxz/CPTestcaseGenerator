#include <bits/stdc++.h>
using namespace std;
using ll = int64_t;
using ull = uint64_t;
using ld = long double;
using pii = pair<int, int>;

vector<int> g[100100];
int u[100100];

void dfs(int v) {
    if (!u[v]++) {
        for (int to : g[v])
            dfs(to);
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int n, m;
    cin >> n >> m;
    while (m--) {
        int x, y;
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    int ans = 0;
    for (int i = 1; i <= n; ++i) {
        if (!u[i]) {
            dfs(i);
            ++ans;
        }
    }
    cout << ans - 1 << endl;
}
