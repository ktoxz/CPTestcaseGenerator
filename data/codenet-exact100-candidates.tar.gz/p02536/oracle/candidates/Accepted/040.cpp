#pragma GCC optimize "trapv"
#include<iostream>
#include <bits/stdc++.h>
using namespace std;
#define fio ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define ll long long
#define ull unsigned long long
#define ui unsigned int
#define vi vector<int>
#define vll vector<ll>
#define pb push_back
#define ld long double
#define mp make_pair
#define pii pair<int,int>
#define mod 1000000007
#define rep(i,n) for(int i=0;i<n;i++)
#define repp(i,a,n) for(int i=a;i<n;i++)
#define all(v) v.begin(),v.end()
#define input(arr,n) for(ll i1=0;i1<n;i1++ )cin>>arr[i1]
#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp> 
using namespace __gnu_pbds; 
#define ordered_set tree<ll, null_type,less_equal<ll>, rb_tree_tag,tree_order_statistics_node_update>//s.order_of_key(val) *s.find_by_order(ind)
vll vec[100001];
bool vis[100001];
void dfs(ll node)
{
    vis[node]=true;
    for(auto x:vec[node])
    {
        if(!vis[x])
        {
            dfs(x);
        }
    }
}
int main()
{
    fio;
    int t=1;
    //cin>>t;
    while(t--)
    {
        ll n,m;
        cin>>n>>m;
        rep(i,m)
        {
            ll u,v;
            cin>>u>>v;
            vec[u].pb(v);
            vec[v].pb(u);
        }
        memset(vis,false,sizeof(vis));
        ll cc=0;
        for(int i=1;i<=n;i++)
        {
            if(!vis[i])
            {
                cc++;
                dfs(i);
            }
        }
        cout<<cc-1<<endl;
    }
}