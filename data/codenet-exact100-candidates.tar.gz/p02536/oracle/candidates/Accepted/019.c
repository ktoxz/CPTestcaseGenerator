#include<time.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<stdarg.h>
#include<tgmath.h>
#include<assert.h>
#include<iso646.h>
#include<stdbool.h>

//fast(?) Input
#define buf_sz 1<<24
char buf[buf_sz];
unsigned int nextint(){
	static int idx = 0, sz;
	if(idx == 0)sz = read(0, buf, buf_sz);
	unsigned int res = 0;
	while(idx<sz && buf[idx]<'0' || '9'<buf[idx])idx++;
	while(idx<sz && '0'<=buf[idx] && buf[idx]<='9'){
		res *= 10;
		res += buf[idx++] - '0';
	}if(idx>=sz)exit(1);
	return res;
}

int d[] = {[0 ... 1<<17] -1};
int find(int x){
	if(d[x] < 0) return x;
	return d[x] = find(d[x]);
}
bool unite(int x, int y){
	x = find(x); y = find(y);
	if(x == y)return false;
	if(d[x] > d[y]){
		int tmp = x;
		x = y;
		y = tmp;
	}
	d[x] += d[y];
	d[y] = x;
	return true;
}
bool same(int x, int y){return find(x) == find(y);}
int size(int x){return -d[find(x)];}

int main(){
	int N = nextint() - 1;
	int M = nextint();
	for(int i=0;i<M;i++)N -= unite(nextint(), nextint());
	printf("%d\n", N);
	return 0;
}