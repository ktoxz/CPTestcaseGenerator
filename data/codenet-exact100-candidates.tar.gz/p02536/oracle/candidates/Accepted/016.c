#include <stdio.h>

#define KI_MAX 114514

int ki[KI_MAX];

void ki_init(void) {
	int i;
	for (i = 0; i < KI_MAX; i++) ki[i] = -1;
}

int ki_root(int n) {
	if (ki[n] < 0) return n;
	return ki[n] = ki_root(ki[n]);
}

int ki_size(int n) {
	return -ki[ki_root(n)];
}

void ki_merge(int a, int b) {
	int ar = ki_root(a);
	int br = ki_root(b);
	if (ar != br) {
		int as = ki_size(ar);
		int bs = ki_size(br);
		if (as <= bs) {
			ki[br] += ki[ar];
			ki[ar] = br;
		} else {
			ki[ar] += ki[br];
			ki[br] = ar;
		}
	}
}

int main(void) {
	int N, M;
	int i;
	int mamegu = 0;
	if (scanf("%d%d", &N, &M) != 2) return 1;
	ki_init();
	for (i = 0; i < M; i++) {
		int A, B;
		if (scanf("%d%d", &A, &B) != 2) return 1;
		ki_merge(A, B);
	}
	for (i = 2; i <= N; i++) {
		if (ki_root(1) != ki_root(i)) {
			mamegu++;
			ki_merge(1, i);
		}
	}
	printf("%d\n", mamegu);
	return 0;
}
