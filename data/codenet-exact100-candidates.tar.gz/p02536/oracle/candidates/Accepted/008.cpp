#include <bits/stdc++.h>
using namespace std;

struct Edge
{
    int to;
};
using Graph = vector<vector<Edge>>;

vector<bool> seen;  // 訪問済みかどうか
void dfs(const Graph &G, int v)
{
    seen[v] = true;
    for(auto e: G[v])
    {
        // 訪問済みでなければ探索する
        if(!seen[e.to])
        {
            dfs(G, e.to);
        }
    }
}

int main() {
    int N,M;
    cin >> N >> M;

    Graph G(N);
    for(int i=0; i<M; i++)
    {
        int a,b;
        cin >> a >> b;
        G[a-1].push_back({b-1});
        G[b-1].push_back({a-1});
    }

    seen.assign(N, false);
    int count = 0;
    for(int i=0; i<N; i++)
    {
        if(!seen[i])
        {
            dfs(G,i);
            count += 1;
        }
    }

    cout << count-1 << endl;
    return 0;
}