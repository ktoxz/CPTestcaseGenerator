#include <cstdio>
#include <vector>
using namespace std;
vector<int>v[100005];
int n,m,a,b;
bool vis[100005];
void dfs(int x){
	if(vis[x])return;
	vis[x]=true;
	for(int i=0;i<v[x].size();++i)dfs(v[x][i]);
}
int main(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;++i){
		scanf("%d%d",&a,&b);
		v[a].push_back(b);
		v[b].push_back(a);
	}
	int j=0;
	for(int i=1;i<=n;++i){
		if(!vis[i]){
			++j;
			dfs(i);
		}
	}
	printf("%d\n",j-1);
	return 0;
}
