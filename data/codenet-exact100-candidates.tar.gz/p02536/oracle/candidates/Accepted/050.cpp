#include <bits/stdc++.h>
using namespace std;
int dsu[1000001];
int prt(int n){
	if (dsu[n]==n) return n;
	return dsu[n]=prt(dsu[n]);
}
void unn(int x,int y){
	if (prt(x)==prt(y)) return;
	dsu[prt(x)]=dsu[prt(y)];
}
void solve(){
	int n,m;
	cin>>n>>m;
	for (int i=1; i<=n; i++) dsu[i]=i;
	int x,y;
	for (int i=0; i<m; i++){
		cin>>x>>y;
		unn(prt(x),prt(y));
	}
	map <int,bool> p;
	int ans=0;
	for (int i=1; i<=n; i++){
		if (!p[prt(i)]){
			p[prt(i)]=1;
			ans++;
		}
	}
	cout<<ans-1;
}
signed main(){
    solve();
}