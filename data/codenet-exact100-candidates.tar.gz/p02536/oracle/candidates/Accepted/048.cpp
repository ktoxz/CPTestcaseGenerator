#include <bits/stdc++.h>

#include <atcoder/all>

#define rep(i, n) for (int i = 0; i < (n); i++)
using namespace std;
using namespace atcoder;
typedef long long ll;

int main() {
  ll n, m, ans = 0, a, b;
  cin >> n >> m;
  dsu d(n);

  rep(i, m) {
    cin >> a >> b;
    a--, b--;
    d.merge(a, b);
  }

  rep(i, n) for (int j = i + 1; j < n; ++j) {
    if (d.size(i) == n) break;
    if (d.same(i, j))
      continue;
    else
      d.merge(i, j), ans++;
  }

  cout << ans << endl;
  return 0;
}
