#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

int find(int u, vector<int> &fa){
    if(fa[u] == u)return u;
    return fa[u] = find(fa[u], fa);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    vector<int> fa(n + 1);
    for(int i = 1; i <= n; ++i)
        fa[i] = i;
    int comp = n;
    while(m--){
        int x, y;
        cin >> x >> y;
        int u = find(x, fa);
        int v = find(y, fa);
        if(u != v){
            --comp;
            fa[u] = v;
        }
    }
    cout << comp - 1 << endl;
    return 0;
}
