#include <stdio.h>
#include <stdlib.h>

long *tree[100010];

int main(void) {

  long n,m,a,b;
  scanf("%ld %ld", &n, &m);
  long tree_s[n+1];
  for (long i = 1; i <= n; i++) {
    tree_s[i] = 0;
  }
  for (long i = 0; i < m; i++) {
    scanf("%ld %ld", &a, &b);
    tree[a] = realloc(tree[a], sizeof(long)*(tree_s[a]+1));
    tree[a][tree_s[a]] = b;
    tree_s[a]++;
    tree[b] = realloc(tree[b], sizeof(long)*(tree_s[b]+1));
    tree[b][tree_s[b]] = a;
    tree_s[b]++;
  }
  long visited[n+1],que[n];
  visited[1] = 1;
  for (long i = 2; i <= n; i++) {
    visited[i] = 0;
  }
  que[0] = 1;
  long head = 1,cur,next,start = 0,end = 0,tail = 0,count = 0;
  int flag;
  while (1) {
    flag = 0;
    for (long i = start; i <= end; i++) {
      cur = que[i];
      for (long j = 0; j < tree_s[cur]; j++) {
        next = tree[cur][j];
        if (visited[next] == 1) {
          continue;
        }
        visited[next] = 1;
        tail++;
        que[tail] = next;
        flag = 1;
      }
    }
    if (flag == 1) {
      start = end+1;
      end = tail;
    } else {
      if (tail == n-1) {
        break;
      }
      for (long i = head+1; i <= n; i++) {
        if (visited[i] == 0) {
          head = i;
          visited[i] = 1;
          tail++;
          que[tail] = i;
          start = tail;
          end = tail;
          count++;
          break;
        }
      }
    }
  }
  printf("%ld\n", count);

  return 0;
}