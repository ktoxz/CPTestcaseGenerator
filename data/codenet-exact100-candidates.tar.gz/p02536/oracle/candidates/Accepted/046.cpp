#include<bits/stdc++.h>
using namespace std ;

vector<int> g[100001] ;

bool visited[100001] ;

void dfs( int i ) {
   visited[i] = true ;
   for( int child : g[i] ) {
       if( visited[child] == false) dfs(child) ;
   }
}

int main() { 
/*  #ifndef ONLINE_JUDGE
  freopen("/home/yash/Desktop/CPP/input.txt","r",stdin);
  freopen("/home/yash/Desktop/CPP/output.txt","w",stdout);
  #endif*/
  int  n, m ;
  cin >> n >> m ;
  while( m-- ){
        int node1 , node2;
        cin>> node1 >> node2;
        g[node1].push_back(node2);
        g[node2].push_back(node1);
  }
  int cc_count = 0 ;
  for( int i=1 ; i<=n ; i++ ) { 
     if( visited[i] == false ) {
        dfs(i) ;
        cc_count++;
     }
  }
  cout<<cc_count-1<<endl;
}
  
