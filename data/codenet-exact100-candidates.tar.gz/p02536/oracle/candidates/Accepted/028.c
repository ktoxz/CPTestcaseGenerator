#include <stdio.h>
#include <math.h>
#include <string.h>

typedef long long ll;
#define MAX_N (100005)

int uf[MAX_N]; // union-find
int n;

void uf_init()
{
	for (int i = 0; i < n; i++)
	{
		uf[i] = i;
	}
}

int uf_root(int x)
{
	if (uf[x] == x)
	{
		return x;
	}
	else
	{
		uf[x] = uf_root(uf[x]);
		return uf[x];
	}
}

void uf_unite(int x, int y)
{
	int rx = uf_root(x);
	int ry = uf_root(y);
	if (rx == ry)
	{
		return;
	}
	uf[rx] = ry;
}

int main() {
	int m;
	scanf("%d %d", &n, &m);
	
	uf_init();
	for (int i = 0; i < m; i++) {
		int a, b;
		scanf("%d %d", &a, &b);
		a--;
		b--;
		uf_unite(a, b);
	}
	int gr = 0;
	for (int i = 0; i < n; i++)
	{
		if (uf_root(i) == i)
		{
			gr++; // 根の数を数える
		}
	}
	printf("%d", gr - 1);
	
	return 0;
}
