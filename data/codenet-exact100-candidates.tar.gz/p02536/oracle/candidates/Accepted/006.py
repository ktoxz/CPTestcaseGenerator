class UnionFind():
    def __init__(self, n):
        self.n = n
        self.par = [-1] * n

    def find(self, x):
        if self.par[x] < 0:
            return x
        else:
            self.par[x] = self.find(self.par[x])
            return self.par[x]

    def unite(self, x, y):
        x = self.find(x)
        y = self.find(y)

        if x == y:
            return

        if self.par[x] > self.par[y]:
            x, y = y, x

        self.par[x] += self.par[y]
        self.par[y] = x

    def size(self, x):
        return -self.par[self.find(x)]


n, k = map(int, input().split())
uf = UnionFind(n)
for _ in range(k):
    a, b = map(int, input().split())
    uf.unite(a - 1, b - 1)

cnt = 0
for x in uf.par:
    if x < 0:
        cnt += 1
print(cnt - 1)
