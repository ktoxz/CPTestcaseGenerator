#include <bits/stdc++.h>
#include <atcoder/all>

#include <cstdio>
using namespace std;
using namespace atcoder;
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
using ll = long long;

int main() {
  ll n, m;
  cin >> n >> m;
  ll cnt = 0;

  dsu d(n);

  for (int i =0; i<m; i++){
    ll a, b;
    cin >> a >> b;
    a--;
    b--;
    d.merge(a, b);
  }

  rep(i, n){
    if (d.leader(i) == i){
      cnt++;
    }
  }
  int ans = cnt -1;
  cout << ans << endl;
  return 0;
}