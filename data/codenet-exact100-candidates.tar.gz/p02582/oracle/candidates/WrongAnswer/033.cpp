#include <bits/stdc++.h>
using namespace std;

int ans;
string s;

int main(){
	cin >> s;
	for (int i = 0; i < s.size(); ++i)
		if (s[i] == 'R') ans++;
	printf("%d\n", ans);
	return 0;
}