#include<bits/stdc++.h>
using namespace std;

int main() {
string s;
int k=0;
cin >> s;
for(int i =0;i<= s.size()-1;i++) {
if(s[i]=='R') k++;
}
cout << k << '\n';
return 0;
}