#include <stdio.h>
int main(void){
  char a[3];
  int count=0;
  for(int k=0;k<3;k++){
    scanf("%c",&a[k]);
  if(a[k]=='R')
    count++;
  }
  printf("%d",count);
  return 0;
}
