s = input()
ans = 0
if "S" in s:
    ans = 1
if "SS" in s:
    ans = 2
if s == "SSS":
    ans = 3
print(ans)