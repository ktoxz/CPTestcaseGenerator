#include<bits/stdc++.h>
using namespace std;

long long X, K, D;

int main(){
    cin >> X >> K >> D;
    long long ans = X;
    int m1=0, m2=0;
    for(long long k = 0; k < K; ++k){
        if(abs(ans+D) < abs(ans-D)){
            ans += D;
            m1 = m2; m2 = 1;
        }
        else{
            m1 = m2; m2 = -1;
            ans -= D;
        }
        if(k > 3 && k % 2 != K % 2 && m1 != m2) break;
    }
    cout << abs(ans) << endl;
    return 0;
}