#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define F first
#define S second
#define B begin()
#define E end()
using namespace std;
int main()
{
    string s; cin>>s; ll c=0;
    for(ll i=0;i<s.size();i++)
    {
        if(s[i]=='R') c++;
    }
    cout<<c;
}
