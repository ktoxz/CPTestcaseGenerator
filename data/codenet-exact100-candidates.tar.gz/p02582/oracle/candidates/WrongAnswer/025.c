#include<stdio.h>
int main()
{
	char s[3];
	int i,c=0,f=0,x=0;
	for(i=0;i<3;i++){
		scanf("%c",&s[i]);
		if(s[i]=='R') c++;
		if(s[i]!='R') f++;
	}
	for(i=0;i<3;i++){
		if(s[i]=='R'&&s[i+1]=='R') x++;
	}
	if(c>f&&x==1||f==0) printf("%d\n",c);
	else if(c>f&&x==0) printf("%d\n",c-f);
	else printf("0\n");
	
	return 0;
}
