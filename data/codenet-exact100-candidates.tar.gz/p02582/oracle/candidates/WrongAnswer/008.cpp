#include<iostream>
#include<stdio.h>
#include<string.h>
#include <algorithm>
using namespace std;

int main(void){
    int ans = 0;
    char s[3];
    cin >> s;

    for(int i = 0; i < 3; i++){
        if(s[i] == 'S' and i > 0) break;
        if(s[i] == 'R') ans++;
    }
    cout << ans << endl;

    return 0;
}