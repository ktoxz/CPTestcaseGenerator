#include<iostream>
#include<cmath>
#include<string>
#include<cstdlib>
#include<ctime>
#include<map>
#include<vector>
#include<list>
using namespace std;

#define ll long long
#define uint unsigned int
#define alloc(n,type) (type*)calloc(n,sizeof(type))
#define MODULE 1
#define RAND(min,max) (rand()%(max-min+1)+min)
#define repeat(i,condition) for(int i = 0; condition; i++)
#define LOG(log) cout<<#log<<" : "<<log<<'\n'
#define DEBUG() {cout<<"DEBUG "<<num_debug<<'\n'; num_debug++;}
int num_debug = 0;
bool* IsPrime;
vector<int> Prime;

int compare_int(const void* a, const void* b);
class Math {
public:
	template<typename T> static T Fac(int n) {
		T ans = 1;
		for (int i = 2; i <= n; i++) {
			ans *= i;
		}
		return ans;
	}
public :
	template<typename T> static T P(int n, int r) {
		T ans = 1;
		for (int i = 0; i < r; i++) {
			ans *= n - i;
		}
		return ans;
	}
public:
	template<typename T>static T C(int n, int r) {
		T nmr = 1;
		T dnm = 1;
		if (n - r < r)
			r = n - r;
		for (int i = 0; i < r; i++) {
			nmr *= n - i;
			dnm *= r - i;
		}
		return nmr / dnm;
	}
};
class Module_int {
public:
	static const int mod = MODULE;

public:
	static int add(int a, int b) {
		int ans = a + b;
		if (ans < 0)
			ans += mod;
		ans %= mod;
		return ans;
	}
public:
	static int mult(int a, int b) {
		return (a * b) % mod;
	}

public:
	static int Pow(int a, int b) {
		int base = a % mod;
		if (mod / 2 < abs(base))
			if (base < 0) {
				base += mod;  //negative
			}
			else {
				base -= mod;  //positive
			}

		return pow(base, b);
	}
};


int main(void) {
	srand((unsigned)time(NULL));

	char S[3];
	repeat(i, i < 3)
		cin >> S[i];
	//DEBUG();
	int a = 0;
	int max=0;
	
	repeat(i, i < 3) {
		//cout << S[i]<<"  "<<a;
		if (S[i] == 'R') {
			a++;
		}
		else {
			if (max < a)
				max = a;
			a = 0;
		}
	}

	cout << max;

	return 0;
}


int compare_int(const void* a, const void* b) {
	return *(int*)a - *(int*)b;
}
void PrimeEnable(int n) {
	//initialize IsPrime
	IsPrime = (bool*)calloc(n + 1, sizeof(bool));
	for (int i = 0; i <= n; i++)
		IsPrime[i] = true;

	//IsPrime 
	IsPrime[0] = IsPrime[1] = false;
	for (int i = 2; i * i <= n; i++) {
		if (IsPrime[i])
			for (int j = i; i * j <= n; j++) {
				IsPrime[i * j] = false;
			}
	}

	//push back to Prime
	for (int i = 0; i <= n; i++) {
		if (IsPrime[i])
			Prime.push_back(i);
	}
}
