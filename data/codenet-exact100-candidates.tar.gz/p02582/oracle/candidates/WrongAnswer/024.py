S = input()
max = 0
i = 0
m = 0
while(i != len(S)):
  if S[i] == "R":
    m += 1
  
  else:
    max = m
    m = 0
    break
  i += 1

print(max)
