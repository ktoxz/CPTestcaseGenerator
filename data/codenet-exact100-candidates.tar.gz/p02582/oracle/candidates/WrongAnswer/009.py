#coding :utf-8
S=input()
if (S=="sss"):
    print(3)
elif(S=="ssr"):
    print(2)
elif(S=="srs"):
    print(1)
elif(S=="rss"):
    print(1)
elif(S=="srr"):
    print(2)
elif(S=="rsr"):
    print(1)
elif(S=="rrs"):
    print(2)
else:
    print(0)
