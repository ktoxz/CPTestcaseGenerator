#include <bits/stdc++.h>

using namespace std;
#define pb push_back

vector<vector<long long> > vec;
int main(){
	
	int n, k; cin >> n >> k;
	int p[n];
	int c[n];
	int mx = -1e9 - 9;
	for(int i = 0; i < n; i++) cin >> p[i];
	for(int i = 0; i < n; i++) {
		cin >> c[i];
		mx = max(mx, c[i]);
	}
	int done[n];
	memset(done, 0, sizeof done);

	for(int i = 0; i < n; i++) {
		if(done[i]) continue;
		
		vector<long long> v;
		v.pb(c[i]);
		done[i] = 1;
		int j = p[i]-1;
		
		while(!done[j]) {
			v.pb(c[j]);
			done[j] = 1;
			j = p[j]-1;
			
		}
		vec.pb(v);
	}
	long long ans = 0;
	for(int j = 0; j < vec.size(); j++) {
		vector<long long> v = vec[j];
		n = v.size();
		long long psum[n];
		// cout<< " ---- " << j << " :: " << endl; 
		for(int i = 0; i < n; i++) {
			// cout << v[i] << ",";
			if(i == 0) psum[i] = v[i%n];
			else psum[i] = psum[i-1] + v[i%n];
		}
		// cout << endl;
		long long many = k / n;
		long long rem = k % n;
		long long best  = 0;
		long long bb = 0;
		
		for(int i = 0; i < n; i++) {
			long long tmp = 0;
			
			for(int kk = 0; kk < min(n, k); kk++) {
				tmp += v[(i + kk)%n];
				best = max(tmp, best);
				if(kk < rem) bb = max(bb, tmp);
			}
			
		}

		ans = max(ans, best);
		
		ans = max(ans, bb + many * psum[n-1]);
	}
	if(ans == 0 ) {
		cout << mx << endl;
	}else 
		cout << ans << endl;
	return 0;
}
