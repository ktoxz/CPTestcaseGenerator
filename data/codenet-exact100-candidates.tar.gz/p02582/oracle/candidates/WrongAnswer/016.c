#include<stdio.h>

int main() {
	char wet;
	int i, f=0;
	for (i = 0; i < 3; i++)
	{
		scanf("%c", &wet);
		if ((f > 0) && (wet= "S" ))
		{
			break;
		}
		if (wet == 'R')
		{
			f++;
		}
	}
	printf("%d", f);
}