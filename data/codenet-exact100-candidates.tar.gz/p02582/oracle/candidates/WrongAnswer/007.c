#include<stdio.h>
int main(){
  int S=0,R=0;
  char w=0;
  scanf("%s",w);
  if(w=="SSS"){
   printf("3");
  }
  if(w=="SSR"){
    printf("2");
  }
  if(w=="SRR"){
    printf("1");
  }
  if(w=="SRS"){
    printf("1");
  }
  if(w=="RRR"){
    printf("0");
  }
  if(w=="RRS"){
    printf("1");
  }
  if(w=="RSS"){
    printf("2");
  }
  if(w=="RSR"){
    printf("1");
  }
  return 0;
}
