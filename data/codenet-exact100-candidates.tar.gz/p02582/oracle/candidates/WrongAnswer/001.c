#include<stdio.h>
int main(void){
  char S[3];
  int i,r=0;
  printf("%c\n",S);
  for(i=0;i<4;i++){
    if(S[i]=='R')r++;
  }
  printf("%d",r);
  return 0;
}
