#include<bits/stdc++.h>
using namespace std;
int main()
{
  string s;
  cin>>s;
  int count=0;
  for(char i:s)
  {
    if(i=='R')
    {
      count++;
    }
    else if(i=='S' && count>0)
    {
      count--;
    }
  }
  cout<<count<<"\n";
  
 }