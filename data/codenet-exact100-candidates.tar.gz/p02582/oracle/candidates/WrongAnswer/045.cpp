#include <iostream>
using namespace std;
int main(void){
    // Your code here!
    string s;
    cin >> s;
    if(s[1] == 'R' && s[2] == 'R' && s[3] == 'S'|| s[1] == 'S' && s[2] == 'R' && s[3] == 'R') cout << 2 << endl;
    else if(s == "RRR") cout << 3 << endl;
    else if(s == "SSS") cout << 0 << endl;
    else cout << 1 << endl;
}
