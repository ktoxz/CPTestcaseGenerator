#include <bits/stdc++.h>

bool comp (int i,int j) { return (i>j); }
using namespace std;
using ll = long long;
ll r,g,b,w;
bool check(ll r, ll g, ll b, ll w)
{
    if (r%2 + g%2 + b%2 + w%2 > 1 ) return false;
    else return true;
}

int main()
{
    string s{3};
    while(!cin.eof())
    {
        cin>>s;
        int n_R=0,n_S=0;
        for(auto it: s)
            {
                if (it=='R') n_R++;
                else n_S++;
            }
        if(n_R==0) cout<<0<<endl;
        else if(n_R==1) cout<<1<<endl;
        else if(n_R==3) cout<<3<<endl;
        else
            {
                if(s[0]=='S' || s[2]=='S') cout<<2<<endl;
                else cout<<1<<endl;
            }
    }
    return 0;
}
