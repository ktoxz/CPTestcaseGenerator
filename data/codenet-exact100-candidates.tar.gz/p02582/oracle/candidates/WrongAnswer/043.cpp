

#include<bits/stdc++.h>
using namespace std;

#define fr                first
#define se                second
#define int               long long
#define pb                push_back
#define mp                make_pair
#define pii               pair<int,int>
#define vi                vector<int>
#define mi                map<int,int>
#define pqb               priority_queue<int>
#define set_bits(x)       __builtin_popcountll(x)
#define mod               1000000007
#define inf               1e18                        //Defining infinity the overflow of int
#define ps(x,y)           fixed<<setprecision(y)<<x   //fir defining the precision int the decimal upto y places. 
#define zrosetbits(x)     __builtin_ctzll(x)         //it will give no of 0's before the first 1 from the right.
#define mk(a,n,type)     type *a=new type[n];
#define test(t)            int t; cin>>t; while(t--)





int32_t main()
{


	//int te = 1;

	// test(t)
	// {
	// int r, g, b;
	string s;
	cin >> s;

	int ctr = 0;
	int res = INT_MIN;

	for (int i = 0; i < s.length(); i++)
	{
		if (s[i] == 'R')
			ctr++;
		if (s[i] == 'S')
			res = max(ctr, res);
	}

	if (res == INT_MIN)
		res = ctr;

	cout << res << "\n";





	// cout << concat(4, 1) << "\n";
	//te++;
// double c_time = (double) (clock() - begin) / CLOCKS_PER_SEC;
// cout << ps(c_time, 4) << " seconds\n";
	//}

	return 0;
}

