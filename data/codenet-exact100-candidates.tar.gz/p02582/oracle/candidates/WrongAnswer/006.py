s = input()
ans = 0
t = 0
for i in s:
  if(i=='R'):
    t += 1
  else:
    ans = t
    t = 0
print(ans)