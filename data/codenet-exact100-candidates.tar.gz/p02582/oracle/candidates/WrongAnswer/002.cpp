					#include<bits/stdc++.h>

					#define F first
					#define S second
					#define N 222222
					#define M 1000000007
					#define pb push_back
					#define cend(s) return cout << s, 0
					using namespace std;
					typedef long long ll;
					typedef vector<int> vi;

					int main()
					{
						string s;
						int k = 0, t = 0;
						cin >> s;
						for(int i = 0; i < 3; i++)
							if(s[i] == 'R')
								k++;
							else t = max(k, t), k = 0;
						cout << t;		
					}
