#include <bits/stdc++.h>
#define rep(i,n) for(int i = 0; i < (n); i++);
using ll = long long;
using namespace std;

int main(){
  char s[3];
  cin >> s;
  if(s == "RRS" || s == "SRR"){
      cout << "2" << endl;
  } 
  else if(s == "RRR"){
      cout << "3" << endl;
  }
  else{
      cout << "0" << endl;
  }
  return 0;
}
