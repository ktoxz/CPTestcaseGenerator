#include<bits/stdc++.h>
using namespace std;
 
int main(){
    string s;
    cin >> s;
    int sum  = 0;
    for (int i = 0; i < 3; i++)
    {
        if(s[i ] == 'R') sum ++;
    }
    if(sum == 1 || sum == 3) cout << sum;
    else{
        if(s[1] == 'R') cout << 2;
        else cout << 1;
    }    
}