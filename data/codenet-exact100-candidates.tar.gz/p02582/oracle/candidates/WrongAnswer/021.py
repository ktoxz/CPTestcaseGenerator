s=input()
if s=="RRR":print(3)
elif s=="RRS" or "SRR" :print(2)
elif s=="SSS":
  print(0)
else:
  print(1)