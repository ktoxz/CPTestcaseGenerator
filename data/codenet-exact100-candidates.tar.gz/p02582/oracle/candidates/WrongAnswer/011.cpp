#include <bits/stdc++.h>
using namespace std;

int main()
{
    string S;
    cin >> S;
    int count = 0;
    if (S == "RRS" || S == "SRR")
    {
        count = 2;
    }
    else if (S == "RSR" || S == "SRS" || S == "SSR")
    {
        count = 1;
    }
    else if (S == "RRR")
    {
        count = 3;
    }
    cout << count << endl;
}