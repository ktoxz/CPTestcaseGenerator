#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define rep(i,n) for(int i = 0; i < (int)n; i++)

int main() {
    string S;
    cin >> S;
    int cnt = 0;
    int max = 0;
    rep(i,3) {
        if(S.at(i) == 'R') {
            cnt++;
        } else {
            if(cnt > max) {
                max = cnt;
            }
            cnt = 0;
        }
    }
    cout << max << endl;
}