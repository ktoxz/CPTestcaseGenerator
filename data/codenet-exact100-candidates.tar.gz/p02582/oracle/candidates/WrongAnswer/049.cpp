#include <bits/stdc++.h>
using namespace std;

#define read(a) cin >> a
#define out(a)  cout << a
#define ull unsigned long long
#define ll long long
#define FOR(i, l, r) for (ll i = l; i <= r; i++)
#define FOD(i, l, r) for (ll i = l; i >= r; i--)
#define fast ios_base::sync_with_stdio(false);
#define mod 1000000007

ll d[300];

int main()
{
    ll dem = 0;
    string s;
    cin >> s;
    string t = s;
    s = s + ' ';
    FOR(i, 0, s.size()-1)
    {
        if (s[0] == 'R' and s[1] == 'R' and s[2] == 'R')
            return cout << 3, 0;
        else if (s[i] == 'S')
        {
            if (i > 0)
                return cout << i, 0;
            else
            {
                reverse(t.begin(), t.end());
                FOR(i, 0, t.size()-1)
                {
                    if (t[0] == 'R' and t[1] == 'R' and t[2] == 'R')
                        return cout << 3, 0;
                    else if (t[i] == 'S')
                        return cout << i, 0;
                }
            }
        }
    }
}
