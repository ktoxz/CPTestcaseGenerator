S = input()[0:3]
res = 0
if S == 'RRS' or S == 'rrs':
    res = 2
elif S=='RRR' or S == 'rrr':
    res = 3
elif S=='RSR' or S == 'rsr' and S=='RSS' or S=='rss':
    res = 1
else:
    res = 0
print(res)