#include <bits/stdc++.h>
using namespace std;
 
int main() {
  string S;
  cin >> S;
  if (S == "RRR") {
    cout << "3" << endl; } if (S == "SSS"){ cout << "0" << endl;  } if (S == "RSS" || S == "SRS" || S == "SSR") { cout << "1" << endl; } if (S == "RRS" || S == "RSR" || S == "SRR") {  cout << "2" << endl; }
}