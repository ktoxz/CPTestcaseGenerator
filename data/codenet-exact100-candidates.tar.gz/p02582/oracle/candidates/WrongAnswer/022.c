#include<stdio.h>
#include<stdlib.h>

int main(void){

  char whe[3];
  int count=0;

  scanf("%s",whe);

for (int i = 0; i < 3; i++) {
  if((whe[i]!='R')&&(whe[i]!='S')){
    exit(1);
  }
}

  if(whe[0]=='R'){
    count++;
  }
  if((whe[0]=='R')&&(whe[1]=='R')){
    count++;
  }if((whe[1]=='R')&&(whe[2]=='R')){
    count++;
  }

  printf("%d\n",count);



  return 0;
}
