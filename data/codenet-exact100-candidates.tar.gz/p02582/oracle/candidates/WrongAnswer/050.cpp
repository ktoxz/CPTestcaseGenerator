#include <bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define REP(i,n) FOR(i,0,n)
#define ALL(v) begin(v),end(v)
#define fi first
#define se second
template<typename A, typename B> inline bool chmax(A &a, B b) { if (a<b) { a=b; return 1; } return 0; }
template<typename A, typename B> inline bool chmin(A &a, B b) { if (a>b) { a=b; return 1; } return 0; }
using ll = long long;
using pii = pair<int, int>;
constexpr ll INF = 1ll<<30;
constexpr ll longINF = 1ll<<60;
constexpr ll MOD = 1000000007;
constexpr bool debug = 0;
//---------------------------------//

int main() {
	string S;
	cin >> S;
	vector<string> v;
	if (S[1] == 'S') {
		v.emplace_back(S.substr(0, 1));
		v.emplace_back(S.substr(2, 1));
	}
	else {
		v.emplace_back(S);
	}
	int ans = INF;
	for (auto s : v) chmin(ans, count(ALL(s), 'R'));
	cout << ans << endl;
	return 0;
}
