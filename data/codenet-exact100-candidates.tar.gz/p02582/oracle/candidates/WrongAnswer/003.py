s = input()
sd = ['' for i in range(3)]
ok = 0
if sd[0] == 'R':
    if sd[1] == 'R':
        if sd[2] == 'R':
            ok = 1
            print(3)
        else:
            ok = 1
            print(2)
    else:
        print(1)
else:
    if sd[1] == 'R':
        if sd[2] == 'R':
            ok =1 
            print(2)
        else:
            ok = 1
            print(1)
if ok == 0:
    print(0)