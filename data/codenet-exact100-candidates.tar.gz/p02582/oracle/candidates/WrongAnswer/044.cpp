#include<bits/stdc++.h>
using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    string s;
    cin >> s;
    int c = 1,sc=0;
    for(int i=1;i<=3;i++)
    {
        if(s[i] == 'R' && s[i+1] == 'R')
        c++;
        if(s[i] == 'S')
        sc++;
	}   
    if(sc==3)
    c=0;
    cout << c;
}