#include<stdio.h>
int record(char *ptr);
int main()
{
  char str[3];
  int i,result,ret;
  ret=scanf("%s",str);
  if(ret==EOF)
  {
    return -1;
  }
  /*for(i=0;i<3;i++)
  {
    printf("%c",str[i]);
  }*/
 // printf("\n");
  
  result=record(str);
  printf("%d",result);
  
  
}

int record(char *ptr)
{
  int i,count=0;
  char temp;
  
  for(i=0;i<3;i++)
  {
    if(*ptr==82)
    {
      count++;
    }
    
    if(*ptr!=temp && ptr==83)
    {
      count=0;
    }
    ptr++;
     //printf("pointer is %p\n",ptr);
  }
  return (count);
}