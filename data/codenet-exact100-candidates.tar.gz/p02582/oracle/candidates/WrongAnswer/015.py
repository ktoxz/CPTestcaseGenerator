l = []

count = 0
flag = True

for s in input():
    if s == "R":
        count += 1
    else:
        l.append(count)
        count = 0
        flag = False
if flag:
    l.append(count)


print(max(l))