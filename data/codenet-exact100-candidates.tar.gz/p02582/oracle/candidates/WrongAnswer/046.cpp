// Author: Harshdeep Sharma , IIT  Indore
#pragma GCC optimize("O2")
#include <bits/stdc++.h>
using namespace std;
// #define MOD  998244353
#define ll long long
const double PI = atan(1.0) * 4;
// const ll INF = (int)1e9 ;
const int di[4] = { -1, 0, 1, 0} ;
const int dj[4] = {0, -1, 0, 1} ;
const ll INF = (ll)2e18 + 50;
const int maximum  = numeric_limits<int>::max();
const int minimum  = numeric_limits<int>::min();
// const int N = 1e5 + 5 ;
const ll mod = 1e9 + 7 ;
// const int N = 1e5 + 5 ;

ll power(ll a , ll e) {
	ll res = 1LL ;
	while (e > 0) {
		if (e % 2 == 1) res = res * a;
		a =  a * a  ;
		e /= 2 ;
	}
	return res ;
}






int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	// int t ;
	// cin >> t ;
	// while (t--) {
	string s ;
	cin >> s ;
	int ans = 0;
	for (int i = 0 ; i  < s.length() - 1 ; i++) {
		if (s[i] == 'R' && s[i + 1] == 'R') ans++ ;
	}
	cout << ans << "\n";

	// }





	return 0 ;


}

