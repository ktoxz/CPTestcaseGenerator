N = list(input())
if N[0] == 'R' and N[1] == 'R' and N[2] == 'R':
    print(3)
elif N[0] == 'R' and N[1] == 'R' and N[2] == 'S':
    print(2)
elif N[0] == 'S' and N[1] == 'R' and N[2] == 'R':
    print(2)
else:
    print(0)
