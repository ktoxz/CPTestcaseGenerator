#include <bits/stdc++.h>
using namespace std;

int main (){
    char S[3];

    for (int i =0; i<3; i++){
        //check if input is S or R
		do {
         cin.clear();
           cin >> S[i];

        } while (S[i] != 'R' && S[i] != 'S');
	}
	
	if ( S [0] || S[1] || S[2] == 'R' ) {
		
		cout << 1;
	} 
	
	else if (S[0] ==S[1] == 'R'){
		cout << 2;
	}
	
	else if (S[1] ==S[2] == 'R'){
		cout << 2;
	}
	
	
	else if (S[0] == S[1] == S[2]== 'R')
	{
		cout << 3;
	}
	
	else {
		cout << 0;

}
}