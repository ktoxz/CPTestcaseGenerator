s = input()

cnt = 0
for i in range(2):
    if s[i] == 'R':
        if s[i+1] == 'R':
            cnt += 1
print(cnt)