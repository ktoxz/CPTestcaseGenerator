#include<iostream>
using namespace std;
int main()
{
  string s;
  cin>>s;
  int globalMax=0;
  int currMax=0;
  for(int i=0;i<3;i++)
  {
    if(s[i]=='R')
      currMax+=1;
   	globalMax= max(globalMax, currMax);
  }
  cout<<globalMax<<endl;
  return 0;
}