#include <stdio.h>

int main(int argc, const char * argv[]) {
    char S[3];
    scanf("%s", S);
    
    int num = 0;
    for (int i=0; i<3; i++) {
        if (S[i] == 'R') {
            num++;
        }
    }
    
    printf("%d\n", num);
    return 0;
}
