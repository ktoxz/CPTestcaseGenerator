#include<stdio.h>
int main()
{
    char c[3];
    {
        scanf("%s",c);
        if(c[0]=='R'){
            if(c[1]=='R'){
                if(c[2]=='R')
                printf("3\n");
                else printf("2\n");
            }
        }
        if(c[0]=='S' && c[1]=='R' && c[2]=='R')
        {
            printf("2\n");
        }
        if(c[0]=='R' && c[1]=='S' && c[2]=='R')
        {
            printf("1\n");
        }
        if(c[0]=='S' && c[1]=='R' && c[2]=='S')
        {
            printf("1\n");
        }
        if(c[0]=='S' && c[1]=='S' && c[2]=='S')
        {
            printf("0\n");
        }
    }
    return 0;
}