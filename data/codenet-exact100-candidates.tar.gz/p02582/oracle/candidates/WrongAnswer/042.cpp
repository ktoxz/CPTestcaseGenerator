#include <bits/stdc++.h>
using namespace std;

int main(void){

  char s[3];
  int cnt;
  int i;
  
  cin >> s;
  
  cnt = 0;

  if (s[0] == 'R')
      cnt++;
  if (s[1] == 'R')
      cnt++;
  if (s[2] == 'R')
      cnt++;
  
  cout << cnt << endl;
  return 0;
}
