#include <stdio.h>

int main()
{
	char s[5];
	for(int i=0;i<3;i++){
		scanf("%s",&s[i]);
		}
	if(s[0]=='R'&&s[1]=='R'&&s[2]=='R'){printf("3");}else
	if(s[0]=='R'&&s[1]=='R'){printf("2");}else
	if(s[1]=='R'&&s[2]=='R'){printf("2");}else
	if(s[0]=='R'||s[1]=='R'||s[2]=='R'){printf("1");}else printf("0");
	
	return 0;
}
