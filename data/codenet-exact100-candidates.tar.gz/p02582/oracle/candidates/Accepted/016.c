#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <inttypes.h>

//int compare_int(const void *a, const void *b){//qsort 整数比較<
//	return *(int*)a - *(int*)b;
//}
//int compare_int2(const void *a, const void *b){//qsort 整数比較>
//	return *(int*)b - *(int*)a;
//}
//
int main(void){
	char s[4]={'\0'};

	scanf("%s%s%s",&s[0],&s[1],&s[2]);
	if(s[0]=='S'){
		if(s[1]=='S'){
			if(s[2]=='S'){
				printf("0");
			}else{
				printf("1");
			}
		}else{
			if(s[2]=='S'){
				printf("1");
			}else{
				printf("2");
			}
		}
	}else{
		if(s[1]=='S'){
			printf("1");
		}else{
			if(s[2]=='S'){
				printf("2");
			}else{
				printf("3");
			}
		}
	}

	return 0;
}
