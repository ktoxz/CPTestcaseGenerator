#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
string s; 
int main()
{
    std::ios::sync_with_stdio(false);
    cin >> s;
    if(s == "RRR") cout << 3 << endl;
    else if(s == "RRS" or s == "SRR") cout << 2 << endl;
    else if(s == "SSS") cout << 0 << endl;
    else cout << 1 << endl;
	return 0;
}
