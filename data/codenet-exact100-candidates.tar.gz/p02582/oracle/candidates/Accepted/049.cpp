#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for(int i = 0; i < (n); ++i)
using ll = long long;
using P = pair<int, int>;

int main(){
  string s;
  cin >> s;
  int ans = 0;
  int tmp = 0;
  if (s[0] == 'R') tmp++;
  if (ans < tmp) ans = tmp;
  if (s[1] == 'R') tmp++;
  else tmp = 0;
  if (ans < tmp) ans = tmp;
  if (s[2] == 'R') tmp++;
  else tmp = 0;
  if (ans < tmp) ans = tmp;
  cout << ans << endl;
  return 0;
}