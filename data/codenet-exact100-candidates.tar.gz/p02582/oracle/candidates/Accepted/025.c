#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main() {
    char s[4];
    int ans=0;
    int i;
    scanf("%s", s);
    if (s[0]=='S'&&s[1]=='S'&&s[2]=='S') {
        printf("0\n");
    } else if (s[0]=='S'&&s[1]=='S'&&s[2]=='R') {
        printf("1\n");
    } else if (s[0]=='S'&&s[1]=='R'&&s[2]=='S') {
        printf("1\n");
    } else if (s[0]=='S'&&s[1]=='R'&&s[2]=='R') {
        printf("2\n");
    } else if (s[0]=='R'&&s[1]=='S'&&s[2]=='S') {
        printf("1\n");
    } else if (s[0]=='R'&&s[1]=='S'&&s[2]=='R') {
        printf("1\n");
    } else if (s[0]=='R'&&s[1]=='R'&&s[2]=='S') {
        printf("2\n");
    } else if (s[0]=='R'&&s[1]=='R'&&s[2]=='R') {
        printf("3\n");
    }
    return 0;
}