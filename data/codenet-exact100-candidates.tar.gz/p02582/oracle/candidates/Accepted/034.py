s = input()
c = 0
ans = 0
for cc in s:
    if cc == "R":
        c += 1
if c <= 1:
    print(c)
elif s[1] == "S":
    print(1)
else:
    print(c)