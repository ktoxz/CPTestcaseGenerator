#include<iostream>
#include <bits/stdc++.h>
#include<algorithm>
#include <cstring>
#define endl "\n"
#define SRK ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define EPS 1e-6
typedef long long ll;
using namespace std;

vector <int> vect;

int main()
{
    SRK;
    string S;
    cin >> S;
    if (S[0] != 'R' && S[1] != 'R' && S[2] != 'R')
    {
        cout << "0\n";
    }
    else if (S[1] == 'R')
    {
        if (S[0] == 'R')
        {
            if (S[2] == 'R')
            {
                cout << "3\n";
            }
            else
            {
                cout << "2\n";
            }
        }
        else if (S[2] == 'R')
        {
            cout << "2\n";
        }
        else
        {
            cout << "1\n";
        }
    }
    else
    {
        cout << "1\n";
    }
}
