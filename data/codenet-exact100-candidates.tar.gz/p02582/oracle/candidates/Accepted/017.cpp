/*  Author:  Hariom_Pandey
    Created: 8/22/2020 11:10:35 AM
*/

#include <bits/stdc++.h>
using namespace std;
#define Mset(s, n)      memset(s, n, sizeof(s))
#define Rp0(i, m)       for(int i = 0; i < m; ++i)
#define Rpd(i, m, l)    for(int i = l; i >= m; --i)
#define Rp1(i ,m)       for(int i = 1; i <= m; i++)
#define All(a)          (a).begin(), (a).end()
#define Lwb             lower_bound
#define Upb             upper_bound
#define Sz(a)           int((a).size())
#define u_map           unordered_map
#define Exist(a, b)     (find(All(a), (b)) != (a).end())
#define Sort(x)         sort(All(x))
#define Gsort(x)        sort(All(x), greater<typeof(*((x).begin()))>())
#define Unique(v)       Sort(v); (v).resize(unique(ALL(v)) - (v).begin())
#define ll              long long int  

int32_t  main(){
   
   string str; cin>>str;
   int cnt=0;
   for(int i=0; i<3; i++){
       if(str[i]=='R'){
           cnt+=1;
       }
       else if(str[i]=='S' and i==1) {
           if(str[0]=='S' and str[2]=='R') {
               cnt+=1;
               break;
           }
           else break;
       }
       else {
           continue;
       }
       
   }
    cout<<cnt;
    return 0;
}

