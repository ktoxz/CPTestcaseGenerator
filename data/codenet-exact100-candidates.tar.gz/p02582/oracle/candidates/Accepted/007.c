#include <stdio.h>

int main(void){
    char a,b,c;
    scanf("%c %c %c", &a, &b, &c);
    if(a == 'S' && b == 'S' && c == 'S'){
        printf("0\n");
        return 0;
    }else if(a == 'S' && b == 'S' && c == 'R'){
        printf("1\n");
        return 0;
    }else if(a == 'S' && b == 'R' && c == 'S'){
        printf("1\n");
        return 0;
    }else if(a == 'R' && b == 'S' && c == 'S'){
        printf("1\n");
        return 0;
    }else if(a == 'R' && b == 'S' && c == 'R'){
        printf("1\n");
        return 0;
    }else if(a == 'R' && b == 'R' && c == 'S'){
        printf("2\n");
        return 0;
    }else if(a == 'S' && b == 'R' && c == 'R'){
        printf("2\n");
        return 0;
    }else if(a == 'R' && b == 'R' && c == 'R'){
        printf("3\n");
        return 0;
    }
    return 0;
}
