import sys

sys.setrecursionlimit(10 ** 8)

input = sys.stdin.readline


def main():
    S = input().strip()

    ans = 0
    if "R" in S:
        ans += 1

    if S[0] == "R" and S[1] == "R" and S[2] == "R":
        print(3)
        return
    elif (S[0] == "R" and S[1] == "R") or (S[1] == "R" and S[2] == "R"):
        print(2)
        return
    else:
        print(ans)




if __name__ == '__main__':
    main()

