#include<iostream>
#include<string>
#define int long long
using namespace std;
signed main(){
	string s;
	cin>>s;
	cout<<(s=="RRR"?3:s=="SSS"?0:s=="RRS"||s=="SRR"?2:1)<<endl;
}
