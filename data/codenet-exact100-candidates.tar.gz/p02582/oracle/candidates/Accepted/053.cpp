#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
const int Maxn=60,Maxm=1510;
const int inf=0x3f3f3f3f;
char a[Maxn];
int f[Maxn],ans;
inline int read()
{
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0' && ch<='9')s=(s<<3)+(s<<1)+(ch^48),ch=getchar();
	return s*w;
}
int main()
{
	scanf("%s",a+1);
	for(int i=1;i<=3;++i)
	{
		if(a[i]=='S')continue;
		f[i]=f[i-1]+1;
		ans=max(ans,f[i]);
	}
	printf("%d\n",ans);
	return 0;
}