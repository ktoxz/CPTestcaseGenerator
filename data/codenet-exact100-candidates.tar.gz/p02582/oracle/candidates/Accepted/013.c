#include <stdio.h>

int main(void){
  char S[32];
  int i, ans=0,tmp=0;
  scanf("%s",S);
  
  for(i = 0;i<3;i++){ 
    if(S[i-1] == 'R'){
      if(S[i] == 'R'){
        tmp++;
      }
    }else{
      if(S[i] == 'R'){
        tmp=1;
      }
    }
    if(ans<tmp){
      ans=tmp;
    }
  }
  printf("%d",ans);
  return 0;
}