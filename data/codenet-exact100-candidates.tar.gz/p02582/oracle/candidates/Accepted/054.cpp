#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define F first
#define S second
#define pb push_back
#define mp make_pair
#define yes "YES"
#define no "NO"
#define rsort(a) sort(a.rbegin(),a.rend())
const int mod=1000000007;
//void dfs(int i);
long long modular_expo(long long x,long long y);

bool cmp(pair<double,int>p1,pair<double,int>p2)
{
    if(p1.first>p2.first)
        return true;
    else
    {
        if(p1.first<p2.first)
            return false;
        else if(p1.first==p2.first)
        {
            if(p1.second<p2.second)
                return true;
            else
                return false;
        }
    }
}
/*bool cmp1(map<int,int>a,map<int,int>b)
{
    if(a.first<b.first)
        return true;
    else
        return false;
}*/
//ll m;


/*
void bsf(int t)
{
    queue<int>q;
    visited[t]=true;
    q.push(t);
    while(!q.empty())
    {
        int temp=q.front();
        //cout<<temp<<" ";
        if(temp==n)
            {
                vector<int>ans;
    ans.pb(n);
        int tttt=n;
    for(int i=0;i<tttt;i++)
    {
        ans.pb(parent[n]);
        n=parent[n];
        if(n==1)
            break;
    }
    if(n!=1)
    {
        break;
    }
    cout<<ans.size()<<endl;
    for(int i=ans.size()-1;i>=0;i--)
        cout<<ans[i]<<" ";
        f=1;

            }
        q.pop();
        //cout<<temp<<" ";
        for(auto i=l[temp].begin();i!=l[temp].end();i++)
        {
            if(!visited[*i])
            {
                q.push(*i);
                parent[*i]=temp;
                visited[*i]=true;
            }
        }
    }
}
*/
long long modular_expo(long long x,long long y)
{

    if(y==0)
        return 1;
    if(y%2==0)
        return (modular_expo((x*x),y/2));
    if(y%2==1)
        return ((x)*modular_expo((x*x),(y-1)/2));


}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);

    int i,cnt=0;
    string s;
    cin>>s;
    int a=0,b=0,c=0;
    if(s[0]=='R')
        a=1;
        if(s[1]=='R')
        b=1;
        if(s[2]=='R')
        c=1;
    if(a&&b&&c)
    {
        cout<<3<<endl;
    }
    else if(a&&b)
    {
        cout<<2;
    }
    else if(b&&c)
    {
        cout<<2;
    }
    else if(a||b||c)
    {
        cout<<1<<endl;
    }
    else
    {
        cout<<0;
    }



}


