#!/usr/bin/env python3

# from numba import njit

# input = stdin.readline

# @njit
def solve(s):
  res = 0
  cnt = 0
  for i in range(3):
    if s[i] == "R":
      cnt += 1
    else:
      res = max(res,cnt)
      cnt = 0
  res = max(res,cnt)

  return res



def main():
  s = input()
  print(solve(s))
  return

if __name__ == '__main__':
  main()
