##175
##A - Rainy Season
S = str(input())
if "R" in S:
    if S[1] == "S":
        print(1)
    else:
        if S[0] == "R" and S[2] == "R":
            print(3)
        else:
            if S[0] == "S" and S[2] == "S":
                print(1)
            else:
                print(2)
    
else:
    print(0)