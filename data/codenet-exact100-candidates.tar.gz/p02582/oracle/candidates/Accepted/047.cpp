#include<bits/stdc++.h>
using namespace std;
int main()

{
    string p;
    int count=0, max=0;
    cin>>p;
    for(int i=0;i<3;i++)
    {
        if(p[i]== 'R')
        {
            count++;
            if(count>max && count!=0)
            {
                max= count;
            }
        }
        else
        {
            count=0;
        }
    }
    cout<<max;
}
