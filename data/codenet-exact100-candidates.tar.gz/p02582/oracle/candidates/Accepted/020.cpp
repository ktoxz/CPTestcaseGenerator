#include<stdio.h>
int main()
{
	char s[3];
	scanf("%s",s);
	if(s[0]=='R'&&s[1]=='R'&&s[2]=='R'){
		printf("3\n");
	}
	else if(s[0]=='R'&&s[1]=='R'&&s[2]=='S'||s[0]=='S'&&s[1]=='R'&&s[2]=='R'){
		printf("2\n");
	}
	else if(s[0]=='S'&&s[1]=='S'&&s[2]=='S'){
		printf("0\n");
	}
	else{
		printf("1\n");
	}
	return 0;
}