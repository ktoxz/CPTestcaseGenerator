S = input()
cnt = 0

if S[0] == 'R':
    cnt = 1
    if S[1] == 'R':
        cnt = 2    
        if S[2] == 'R':
            cnt = 3
else:
    if S[1] == 'R':
        cnt = 1
        if S[2] == 'R':
            cnt = 2
    elif S[2] == 'R':
        cnt = 1

print(cnt)