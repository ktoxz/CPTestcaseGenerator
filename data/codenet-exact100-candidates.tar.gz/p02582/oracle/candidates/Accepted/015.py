S = input()
for i in range(4)[::-1]:
    if 'R' * i in S:
        print(i)
        exit()
