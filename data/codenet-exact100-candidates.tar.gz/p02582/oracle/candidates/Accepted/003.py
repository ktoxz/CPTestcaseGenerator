S = input()

if S[0] == 'R':
  if S[1] == 'R':
    if S[2] == 'R':
      #RRR
      print('3')
    else:
      #RRS
      print('2')
  else:
    #RSR or RSS
    print('1')
else:
  if S[1] == 'R':
    if S[2] == 'R':
      #SRR
      print('2')
    else:
      #SRS
      print('1')
  else:
    if S[2] == 'R':
      #SSR
      print('1')
    else:
      print('0')