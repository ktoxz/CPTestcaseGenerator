#include <bits/stdc++.h>

#define endl '\n'

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
  
    string s;
    cin >> s;

    int count = 0, ans = 0;

    for (char c : s) {
        if (c == 'S') {
            count = 0;
        } else {
            ++count;
        }
        ans = max(ans, count);
    }

    cout << ans << endl;

    return 0;
}
