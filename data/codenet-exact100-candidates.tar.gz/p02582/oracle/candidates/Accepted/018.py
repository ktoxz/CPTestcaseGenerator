s = list(input())
count = 0
result = 0

for v in s:
    if v == 'S':
        count = 0
        continue
    else:
        count += 1
        result = count

print(result)
