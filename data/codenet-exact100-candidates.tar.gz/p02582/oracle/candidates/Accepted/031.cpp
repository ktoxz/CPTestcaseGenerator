#include <bits/stdc++.h>

using namespace std;

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
  string s;
  cin >> s;
  int n = (int) s.size();
  int ans = 0;
  for (int i = 0; i < n; ) {
    if (s[i] == 'S') {
      i++;
    } else {
      int j = i + 1;
      while (j < n && s[j] == s[i]) {
        j++;
      }
      ans = max(ans, j - i);
      i = j;
    }
  }
  cout << ans << '\n';
  return 0;
}