#include<stdio.h>
int main(void)
{
  int i,t=0,f=0;
  char s[10];
  scanf("%s",s);
  for(i=0;i<3;i++){
    if(s[i]=='R'&&f==0){
    t++;
    }
      else if(s[i]=='S'&&t>0){
        f=1;
    }
  }
  printf("%d\n",t);
  return 0;
}