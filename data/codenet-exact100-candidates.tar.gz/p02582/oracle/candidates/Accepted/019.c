#include<stdio.h>

int main()
{
    char S[4];
    int i;

    gets(S);

    if(S[0] == 'S' && S[1] == 'S' && S[2] == 'S')
        printf("0\n");
    else if(S[0] == 'R' && S[1] == 'R' && S[2] == 'R')
            printf("3\n");
    else if(S[0] == 'S'){
        if(S[1] == 'R' && S[2] == 'R')
            printf("2\n");
        else
            printf("1\n");
    }
    else if(S[0] == 'R'){
        if(S[1] == 'R')
            printf("2\n");
        else
            printf("1\n");
    }

    return 0;
}
