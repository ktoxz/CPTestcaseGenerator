a1 = input()

count = 0
max = 0
for i in a1:
  if i == "R":
    count += 1
    max = count
  elif i == "S":
    count = 0

print(max)