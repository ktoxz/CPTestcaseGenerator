#include <stdio.h>
int main(void){
  int i, max = 0, count = 0;
  char S[3];
  for(i=0; i<3; i++){
    scanf("%c",&S[i]);
    if(S[i] == 'R'){
      count++;
    }
    else if(S[i] == 'S' && max < count){
      max = count;
      count = 0;
    }
    if(i == 2 && max < count){
      max = count;
    }
  }
  printf("%d",max);
  return 0;
}