#include<bits/stdc++.h>
#define lint long long
#define st first
#define nd second
#define INF 0x3f3f3f3f

using namespace std;


int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL); cout.tie(NULL);
	string s;cin>>s;
	s = "?"+s;
	int cont = 0;
	int maxi = 0;
	for(char &c:s){
		if(c == 'R')cont++;
		else{
			maxi = max(maxi, cont);
			cont = 0;
		
		}
	
	}	
	cout<<max(maxi, cont)<<"\n";

	return 0;	
}
