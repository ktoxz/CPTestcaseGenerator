#include <bits/stdc++.h>
#define REP(i, n) for(int i = 0; i < n; i++)
#define REPR(i, n) for(int i = n; i >= 0; i--)
#define FOR(i, m, n) for(int i = m; i < n; i++)
#define INF 2e9
#define ALL(v) v.begin(), v.end()
using namespace std;
typedef long long ll;

string S;

int count (string S){
  if (S == "SSS") return 0;
  else if ((S == "RRS")||(S=="SRR"))return 2;
  else if (S =="RRR")return 3;
  else return 1;
}

int main(){
  
 cin>>S;
  int A ;
  A = count(S);
  cout <<A<<endl;
}