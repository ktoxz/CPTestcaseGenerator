#include <bits/stdc++.h>
using namespace std;
int main()
{
	string s;
	cin>>s;
	if (s=="RRS"||s=="SRR")
		cout<<2<<endl;
	else if (s=="RSR"||s=="SSR"||s=="SRS"||s=="RSS")
		cout<<1<<endl;
	else if (s=="RRR")
		cout<<3<<endl;
	else
		cout<<0<<endl;
	return 0;
}