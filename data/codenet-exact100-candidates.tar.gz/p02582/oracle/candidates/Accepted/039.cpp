#include<bits/stdc++.h>
//#define local

using namespace std;
typedef long long int ll;
typedef vector<int> vec;
typedef vector<ll> vecl;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    #ifdef local
        freopen("input.txt","r",stdin);
    #endif
    string s;
    cin >> s;
    int ans = 0;
    for(int i = 0; i < 3; i++)
    {
        if(s[i] == 'R')
            ans += 1;
    }
    if(s[1] == 'S' && ans == 2)
        ans--;
    cout << ans;
}
