#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (ll i = 0; i < (ll)(n); i++)
typedef long long ll;
const ll M=1000000007;
//------------------------------------------//

int main(){
  char C[3];
  rep(i,3) cin>>C[i];
  if(C[0]=='R' &&C[1]=='R' &&C[2]=='R') cout<<3<<endl;
  else if((C[0]=='R' &&C[1]=='R') ||(C[1]=='R' &&C[2]=='R')){
    cout<<2<<endl;
  }
  else if(C[0]=='R' ||C[1]=='R' ||C[2]=='R') cout<<1<<endl;
  else cout<<0<<endl;
}
  