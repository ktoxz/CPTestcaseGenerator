import sys
input = lambda: sys.stdin.readline().rstrip()

def main():
    S = input()
    ans = 0
    if S[0] == 'R' and S[1] == 'R' and S[2] == 'R':
        ans = 3
    elif (S[0] == 'R' and S[1] == 'R') or S[1] == 'R' and S[2] == 'R':
        ans = 2
    elif 'R' in S:
        ans = 1
    else:
        ans = 0
    print(ans)

if __name__ == '__main__':
    main()
