a = list(input())
c = 0
x = []
for i in a:
    
    if i == 'R':
        c += 1
    else:
        x.append(c)
        c = 0
    x.append(c)
print(max(x))