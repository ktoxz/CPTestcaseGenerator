A = input()
B = A.count("R")
if A == "RSR":
    print(1)
else:
    print(B)