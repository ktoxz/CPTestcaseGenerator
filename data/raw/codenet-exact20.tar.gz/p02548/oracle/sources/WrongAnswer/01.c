#include <stdio.h>
#include <math.h>

int main(void){
    int N, pr, K, ans;
    scanf("%d", &N);

    ans = 0;

    for(int i=1; i<N; i++){
        pr = N - i; // N-Cのこと
        // prをA*Bに分解
        K = sqrt(pr);
        for(int k=1; k<K; k++) if(pr%k == 0) ans++;
    }

    printf("%d\n", ans);

    return 0;
}
