#include <stdio.h>
int main()
{
    long a=0,b=0,c=0;
  	long j,i;
    int f;
	scanf("%d", &a);
//printf("%d", a);
//a = int(input())
c = (a-1)*2-1;
for (i = 2; i<=a; i++){
  f = 0;
  for (j = 2; j<=a; j++){
    if (f==1) continue;
    printf("ii%d\n", i);
    printf("jj%d\n", j);
    b = i*j;
    if (b >= a){
      f=1;
      continue;
    }
    c = c+1;
    //printf("ii%d\n", i);
    //printf("jj%d\n", j);
    //printf("bbbb%d\n", b);
    
  }
}
printf("%d\n", c);
    
}