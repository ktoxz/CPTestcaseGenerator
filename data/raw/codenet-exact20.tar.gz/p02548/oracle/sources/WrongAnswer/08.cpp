/*
	------------------------------------------CAUTIOUS WARNING ------------------------------------------
	This is a personalised Template for Nitin under MIT Licence Act 1840 : Do not use it for own use. */
	
	
	// TASK : PRACTICE
	/*





                                                              ..---..._
                                                        ..--""         "-.
                                                   ..-"""                 ".
                                               ..-""                        "
                                            .-"
                                         .-"      ... -_
                                     .="   _..-" F   .-"-.....___-..
                                     "L_ _-'    ."  j"  .-":   /"-._ "-
                                        "      :  ."  j"  :   :    |"" ".
                                  ......---------"""""""""""-:_     |   |\
                        ...---""""                             -.   f   | "
                ...---""       . ..----""""""""..                ".-... f  ".
         ..---"""       ..---""""""""-..--"""""""""^^::            |. "-.    .
     .--"           .mm::::::::::::::::::::::::::...  ""L           |x   ".
   -"             mm;;;;;;;;;;XXXXXXXXXXXXX:::::::::::.. |           |x.   -
 xF        -._ .mF;;;;;;XXXXXXXXXXXXXXXXXXXXXXXXXX:::::::|            |X:.  "
j         |   j;;;;;XXX#############################::::::|            XX::::
|          |.#;::XXX##################################::::|            |XX:::
|          j#::XXX#######################################::             XXX::
|         .#:XXX###########################################             |XX::
|         #XXX##############################XX############Fl             XXX:
|        .XXX###################XX#######X##XXX###########Fl             lXX:
 |       #XX##################XXX######XXXXXXX###########F j             lXXX
 |       #X#########X#X#####XXX#######XXXXXX#######XXX##F  jl            XXXX
 |       #X#######XX#"  V###XX#' ####XXXXXX##F"T##XXXXXX.  V   /  .    .#XXXX
  |       #########"     V#XX#'  "####XXXX##.---.##XXXXXX.    /  /  / .##XXXX
  |       "######X' .--"" "V##L   #####XXX#"      "###XXXX. ."  /  / .###XXXX
  |         #####X "   .m###m##L   ####XX#      m###m"###XX#   /  / .#####XXX
   |         "###X   .mF""   "y     #####     mX"   "Y#"^####X   / .######XXX
   |           "T#   #"        #     ####    X"       "F""###XX"###########XX
   |             L  d"     dXX  xm   "^##L mx     dXX  YL-"##XX"S""##########
    |            xL J     Xd%    T      ""  T    XdX    L. "##XS.f |#########
    |             BL      X## X                  X## X      T#SS"  |#########
    |              #L     X%##X                  X%##X|     j#SSS /##########
     |              #L  ._ TXXX-"           "-._  XXXF.-    ###SS\###########
     |              ##   """""                  """"""      ##DS.\###########
     |              TF                                      ##BBS.T#########F
      |             #L           ---                        ###BBS.T########'
      |            '##            ""                     jL|###BSSS.T#######
       |          '####             ______              .:#|##WWBBBSS.T####F
      J L        '######.            \___/            _c::#|###WWWBSSS|####
     J ;;       '########m            \_/            c:::'#|###WWWBBSS.T##"
    J ;;;L      :########.:m.          _          _cf:::'.L|####WWWWSSS|#"
  .J ;;;;B      ########B....:m..             _,c%%%:::'...L####WWWBBSSj
 x  ;;;;dB      #######BB.......##m...___..cc%%%%%::::'....|#####WWBBDS.|
" ;;;;;ABB#     #######BB........##j%%%%%%%%%%%%%%:::'..... #####WWWWDDS|
.;;;;;dBBB#     #######BB.........%%%%%%%%%%%%%%%:::'...   j####WWWWWBDF
;;;;;BBB####    ######BBB.........%%%%%%%%%%%%%%:::'..     #####WWWWWWS
;;;;dBBB####    ######BBB..........^%%%%%%%%%%:::"         #####WWWWWWB
;;;:BBB######   X#####BBB"..........."^YYYYY::"            #####WWWWWWW
;;.BB#########  X######BBB........:''                      #####WWWWWWW
;;BB##########L X######BBB.......mmmm..                 ..x#####WWWWWWB.
;dBB########### X#######BB.....        "-._           x""  #####WWWWWWBL
;BBB###########L X######BB...              "-              ######WWWWBBBL
BBB#############. ######BBB.                                #####WWWWBBBB
BBB############## X#####BBB                                 #####WWWWWBBB
BBB############### T#####BB                                  #####WWWBBB     :
BB################# T###BBP                                   #####WWBB"    .#
BB##################..W##P                                      ###BBB"    .##
BB###################..l                                         "WW"      ###
BB####################j ___                                        " l    j###
BBB##################J_-   """-..             ':::'   .-""""""""""-.  l  .####
BBB######B##########J########    "-.           ::'  -" ..mmm####mm.."-.< #####
MCL-5/7/88 BBB#####J############    "-_        :|  " .###############mmLlR####
BBBBBBBBBBBBBBB###/         #######    -.     .:| ".#####F^^^P^^"""^^^Y#lT####
BBBBBBBBBBBBBBBBBj|####mm        ######xx-...:::|" ###f      .....      "#T###
BBBBBBBBBBBBBBBBjj##########mm..           ":::."j##F  .mm#########mmm.. Yj###
BBBBBBBBBBBBBBBB|^WWWSRR############mmmmm xx """mjF.mm####################j###
BBBBBBBBBBBBBBBB|                      ######mmmmmm#######################j###
BBBBBBBBBBBBBBBBY#m...   ..mmm##########PPPPP#####m..                    lj###
BBBBBBBBBBBBBBBBB2##############^^""     ..umF^^^Tx ^##mmmm........mmmmmmlj###
BBBBBBBBBBBBBBBBBJT######^^^""     .mm##PPPF"...."m.  "^^###############lj####
BBBBBBBBBBBBBBBBB##^L         .mmm###PPP............"m..    """"^^^^^"" lj####
BBBBBBBBBBBBBBBB#####Y#mmx#########P.................."^:muuuummmmmm###^.#####
BBBBBBBBBBBBBBBB#####::Y##mPPPPF^".......|.............. ""^^######^^"...#####
BBBBBBBBBBBBBB########..................F............      \     ........#####
BBBBBBBBBBBBB#########.................|..........          :       ....l#####
BBBBBBBBBBBB###########...............F.........             \        ..######
BBBBBBBBBBB#############.............|........                :         dA####
BBBBBBBBBB##############.....................                           kM####
BBBBBBBBB################..................                             k#####
BBBBBBB##################................                               k#####
BBBBB#####################.............                                 t#####
BB########################............                                  "E####
B########################F............                           .       "####
#########################............'      |                    ..       "L##
########################F............                           ...        "L#
#######################F............'                           .....       "#
######################F.............                           .......       "
#####################$..............                         .........
#####################lmmm.............                      ...........   ..m#
####################j########mmmm.............            ......mmmmmm########
###################j###::::;:::::########mmmmmmm##############################
##################j:::::::;:::::::;;::##############################^^^""""
##################.mm:::mmm######mmmm:::' ^^^^^^""#######^^""""
#################F...^m::;::################mmm  .mm"""
#################.......m;::::::::::::#########^"
################F.........###mmm::::;' .##^"""
 ##############F...........:#######m.m#"
   ############..............':####
     #########F............mm^""
       #######..........m^""
          ####.......%^"
             #.....x"
             |.x""
            .-"
          .-
        .-
      .-
     -
   -"
 -"
"
                                                                             x
                                                                           xx
                                                                         xx
                                                                     xxx"
                                                                 xxx"
                                                           .xxxx"
                                                   ___xxx""
                                             .xxxx""....F
                """"mmxxxxx          ___xxx^^^..........'
                   .xx^^^^YYYY###xxx^^.................|
                .xx^"        #######x..................|
             .xx"          ###########mx..............f
           .x^            ##############xx............|
          j"             ##############    x..........;
.........#              ############       #x.........|
x.......j"              ##########       ####x.......f
 xxx....#..            ########        #######x......|
   xxxx.#....         #######        ##########x.....|
      xxx......       #####         #########   x....|
         xxx......    ###          #######      #m...|
           xxx......  ##           ######      ####..|
             xxx......#.          #####       ######m|
               xxxx.......        ###        #######Fx
                   xxx......      #         j#####    m
                      xx......              ####      Jxm
                       xxx......           ####      j###Km
                          xxx.....         ###      j####F  m
                             xx......       #       ###F    .m
                               xxx ....            j##F    .###m
                               m..xx.....          ##F    j#####K^mm.
                                m...xx......       ##     #####F    ####mm
                                m .....x......     F     j####F    ########
                                 m  ......x.....         ###F    J##########
                                 "m  ........x....      .#F     #########^^|
                                  "......mmF^^^x....    ##     ######      |
                                   lL..jF        x.... .F      ####       |
                                   lTLJF           x....      ####        |
                                   l::|.            "....    j###       ##
                                    l....            L....   ###F     x##
                                     l....       ..m##L...   ##F     j###
                                     l:...        #####L...  #F     j####
                                      l....    ####     ...        #####
                                      "....              ...       ####F |
                                       l....              ...     j###F  |
                                        #...               ....   ###F    |
                                        "#..              .jL.... ##F     |
                                         ##.            .m###L....#F      |
                                         "##        ..mm###### ....       |
                                          |                   |...        |
                                          k                    |...       |
                                          l                    |...       k
                                           k                 .m#L...     Jk
                                           ##            ..mm####L...     k
                                           ###         d########' L....   |
                                           l                   |   "-.__-"
                                           l                   |
                                           l                  j#
                                           :                 j##
                                            k               j##'
                                            l            .m###k
                                            l           ###^^"|
                                            |                 |
                                            j               .##
                                            |              ######
                                            |==          ##### ####
                                           .k          #####"   ####
                                           l         #####^     ####
                                           l       ###         ####'
                                           !                 m###F
                                           |               ######
                                           |           mm##m###'
                                           |.       m########F
                                           |.    m#######F" #
                                           d.   ###        #
                                          |..             .'
                                          |..             |
                                           k..           :
                                           \...          F
                                            |...        #d
                                            |...       ###
                                             L...     ####.
                                             |...    j### |
                                              L...   ###  |
                                              T...  j##    k
                                               \... ##     |
                                                 \...      .
                                                   "^-____-
	
	*/                                                                  
	//--------------------------------HEADERS-------------------------------------------------------------//
	#include <vector>
	#include <list>
	#include <map>
	#include <set>
	#include<cmath>
	#include <queue>
	#include <deque>
	#include <stack>
	#include <bitset>
	#include <algorithm>
	#include <functional>
	#include <numeric>
	#include <utility>
	#include <sstream>
	#include <iostream>
	#include <iomanip>
	#include <cstdio>
	#include <cmath>
	#include <cstdlib>
	#include <ctime>
	#include <limits>
	#include <string>
	#include <cassert>
	#include <cstring> 
	#include <unordered_set>
	#include <unordered_map>
	#include<bits/stdc++.h>
	using namespace std; 
	
	//-------------------------------------------------------Typedefs----------------------------------------------//  
	
	typedef long long int ll; 
	
	typedef pair<int, int> pii; 
	
	typedef pair<ll, ll> pll; 
	
	typedef pair<string, string> pss; 
	
	typedef vector<int> vi; 
	
	typedef vector<vi> vvi; 
	
	typedef vector<pii> vii; 
	
	typedef vector<ll> vl; 
	
	typedef vector<vl> vvl; 
	
	typedef unordered_set<ll> uo_s;
	
	typedef unordered_map<ll,ll> uo_m;
	  
	typedef map<ll,ll> o_m;
	double EPS = 1e-9; 
	
	int INF5 = 1000000005; 
	int INF7 = 1000000007;	
	long long INFF = 1000000000000000005LL; 
	
	double PI = acos(-1); 
	
	int dirx[8] = { -1, 0, 0, 1, -1, -1, 1, 1 }; 
	
	int diry[8] = { 0, 1, -1, 0, -1, 1, -1, 1 }; 
	
	//---------------------------------------------------------Hash defines--------------------------------------------------//
	
	# define    PII     3.14159265358979323846
	#ifdef TESTING 
	#define DEBUG fprintf(stderr, "====TESTING====\n") 
	#define VALUE(x) cerr << "The value of " << #x << " is " << x << endl 
	#define debug(...) fprintf(stderr, __VA_ARGS__) 
	#else 
	#define DEBUG 
	#define VALUE(x) 
	#define debug(...) 
	#endif 
	
	  
	#define FOR(a, b, c) for (int(a) = (b); (a) < (c); ++(a)) 
	#define FORN(a, b, c) for (int(a) = (b); (a) <= (c); ++(a)) 
	#define FORD(a, b, c) for (int(a) = (b); (a) >= (c); --(a)) 
	#define FORSQ(a, b, c) for (int(a) = (b); (a) * (a) <= (c); ++(a)) 
	#define FORC(a, b, c) for (char(a) = (b); (a) <= (c); ++(a)) 
	#define FOREACH(a, b) for (auto&(a) : (b)) 
	#define REP(i, n) FOR(i, 0, n) 
	#define REPN(i, n) FORN(i, 1, n) 
	#define MAX(a, b) a = max(a, b) 
	#define MIN(a, b) a = min(a, b) 
	#define SQR(x) ((ll)(x) * (x)) 
	#define RESET(a, b) memset(a, b, sizeof(a)) 
	#define ff first 
	#define ss second 
	#define mp make_pair 
	#define pb push_back 
	#define ALL(v) v.begin(), v.end() 
	#define ALLA(arr, sz) arr, arr + sz 
	#define SIZE(v) (int)v.size() 
	#define SORT(v) sort(ALL(v)) 
	#define REVERSE(v) reverse(ALL(v)) 
	#define SORTA(arr, sz) sort(ALLA(arr, sz)) 
	#define REVERSEA(arr, sz) reverse(ALLA(arr, sz)) 
	#define PERMUTE next_permutation 
	#define T(a) ll a; cin >> a;
	#define TT(t) T(t); while (t--)
	#define IOS ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	#define f(i, x, y) for(int i = x; i < y; i++)
	#define array(a)   ll a[n]; 
	#define line "\n";
	#define out cout
	#define meh <<
	#define uwu >> 
	#define transforml transform(s.begin(),s.end(),s.begin(),::tolower);
	#define transformu transform(s.begin(),s.end(),s.begin(),::toupper);
	//-------------------------------------------------TEMPLATES----------------------------------------------------------//
	/*
	Algrorithms to be pasted here.
	*/
	void wiley()	{
  T(n)
  array(a)ll ans =0;
      REP(i,n)
  a[i]=i+1;
  n-=1;
  
 ll alt =0;
  alt+=n+1;
  for(int i=2;i<n;i++){
      alt+=floor(n/i);
  }
//   cout<<ans<<endl;
  //ll alt = n*(log(n)+2*0.577-1);
  cout<<alt<<endl;
 
	}
	int main(){
		//--- Vroom Vroom 
		IOS
	
		// TT(t){
		// read();
		wiley();	
	// By Order of Peaky Blinders.
		// }
		return 0;
	}
