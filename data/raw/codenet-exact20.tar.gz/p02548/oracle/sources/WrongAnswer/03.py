x = int(input())
cnt = 0
for a in range(1, x+1):
    for b in range(1, x+1):
        for c in range(1, x+1):
            kai = (a * b) + c
            if kai == x:
                print(a,b,c)
                cnt += 1
print(cnt)