N = int(input())
s = [0,1]
for i in range(2,N):
    for j in range(2,int(i**0.5 + 1)+1):
        if i % j == 0:
            k = i//j
            s.append(2*s[k])
            break
    if len(s) != i+1:
        s.append(1)
print(sum(s))
