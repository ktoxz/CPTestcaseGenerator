#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main() {
    int n;
    cin>>n;
    ll ans=0;
    n--;
    int c=0;
    vector<int>a(n,0);
    for(int i=1;i<=n;i++){
        int x=n/i;
        if(x>=1 && a[i]==0){
            a[i]=1;
            ans+=x-1;
            c++;
        }
    }
    
    cout<<ans+c<<endl;
}