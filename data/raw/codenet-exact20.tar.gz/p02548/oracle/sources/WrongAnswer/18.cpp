/* Hardwork allways pays off */
//You never know how close to the solution you are ,so keep practicing
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define pb push_back
#define lb lower_bound
#define ub upper_bound
#define endl '\n'
#define mod 1000000007
#define REP(i,n) for(ll i=1;i<=n;i++)
#define tol(s) transform(s.begin(),s.end(),s.begin(),::tolower)
#define tou(s) transform(s.begin(),s.end(),s.begin(),::toupper)
#define ios ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define all(x) (x).begin(), (x).end()
void make_unique(vector<ll> vec)
{
sort(all(vec));
vec.resize(unique(all(vec)) - vec.begin());
}

int main() 
 {   ios;
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    #endif
    int t=1;
    //  cin>>t; 
    while(t--)
      {ll l,k,p,a,b,c,n,m,i,j,flag=0,count=0,move=0;
       cin>>n;
       for(i=1;i<=(n);i++)
       {  if(i*i<=n)
           { if(n%i==0)
             { ll a1=i;
               ll a2=n/i-1;
                count+=2*(a2-a1)+1;
              
             }
            else
             count+=2*((n/i)-i)+1; 
            
            
           }
       }
       cout<<count+1<<endl;

        
      }
	return 0;
}
