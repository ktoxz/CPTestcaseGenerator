#include<bits/stdc++.h>
#define pb push_back 
 #define fo(i,n) for(int i=0;i<n;i++)
#define ll long long 
#define int long long 
#define Mod 10000000000007 
#define maxn 200005
#define MAX 4294967296  // 2^32
const int M=1e9+7;
#define ip pair<int,int>
#define test(t) ll t;cin>>t;while(t--)
  
using namespace std;

long long gcd(int x,int y){
    if(y>x)swap(x,y);
    if(y==0)return x;
    return gcd(y,x%y);
}


void solve(){

int n;
cin>>n;
int sum=0;
if(n<3)cout<<0<<endl;
else{

   for(int i=1;i*i<n;i++){
    int t=n/i;
    if(n%i!=0)t++;
    t-=(1+i);
    sum+=t*2;
   }
   if(floor(sqrt(n))==ceil(sqrt(n)))sum+=sqrt(n)-1;
  else sum+=sqrt(n);


}
cout<<sum;

}

signed main(){


    // std::string binary = std::bitset<8>(n).to_string();
    ios::sync_with_stdio(0);
    cin.tie(0);
   
solve();


  


}