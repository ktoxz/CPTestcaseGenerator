#include<bits/stdc++.h>
#define int long long
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
#define sz(a) a.size()
#define re return 
#define MP make_pair
#define pb push_back
#define pii pair<int,int>
#define se second
#define fi first
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define repd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
int n,ans;
signed main(){
	ios_base::sync_with_stdio(0);
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
	cin>>n;
	ans+=1+(n-2)*2;
	for(int i=2;i<n;i++){
		if(i*i<=n) ans++;
		int tmp=max(0ll,(n-1)/i-i);
		ans+=tmp*2;
	}
	if((n%2==0&&n/2>1)||(n%3==0&&n/3>1)||(n%5==0&&n/5>1)||(n%7==0&&n/7>1)) ans--;
	cout<<ans;
	re 0;
}