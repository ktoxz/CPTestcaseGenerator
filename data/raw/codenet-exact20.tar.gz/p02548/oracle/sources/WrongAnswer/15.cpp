#include <bits/stdc++.h>
using namespace std;
#define li          long
#define ll          long long
#define ull         unsigned long long
#define ff          first
#define ss          second
#define pii         pair<int,int>
#define pli         pair<li,li>
#define pll         pair<ll,ll>
#define pb          push_back
#define fo(i,k,n)   for(int i = k;i<n; i++)
#define ro(i,k,n)   for(int i = k; i>=n; i--)
#define tc          int t;cin>>t;while(t--)
#define all(v)      v.begin(),v.end()
#define inf         INT_MAX
#define ninf        INT_MIN
#define v(x)        vector<x>
#define int         long long
#define ar(x,y)     array<x,y>
#define p(x,y)      pair<x,y>
const ll mod1 = 99844353;
const ll mod2 = 1e9+7;
/* template <class T>
using oset = tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>; */

template<typename T>
T gcd(T a,T b){
    return b ? gcd(b, a%b) : a;
}

void fastio()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
}

int power(int x,int y){
    int res = 1;
    while(y > 0){
         if(y & 1) res *= x;
         y >>= 1;
         x *= x;
    }
    return res;
}

int power(int x,int y,int mod){
     int res = 1;
     x %= mod;
     while(y > 0){
          if(y & 1) res = (res * x) % mod;
          y >>= 1;
          x = (x * x) % mod;
     }
     return res;
}

class Template {
    int* readArray(int n){
        int *res = new int[n];
        for(int i = 0; i<n; i++){
            cin >> res[i];
        }
        return res;
    }
    void destroy(int *x){
        delete[] x;
    }
    v(int) readVector(int n){
        v(int) res(n);
        for(int i = 0; i<n; i++){
            cin >> res[i];
        }
        return res;
    }
    public:
    void solveOne(istream &in, ostream &out) {
        int n;
        in >> n;
        int ans = 0;
        for(int c = 1; c < n; c++){
            int count = 0;
            for(int j = 1; j*j <= n-c; j++){
                if((n-c)%j == 0){
                    int x = j,y = (n-c)/j;
                    if(x == y)count+=1;
                    else count += 2;
                }
            }
        }
        out << ans << "\n";
    }
    
    void solve(istream &in, ostream &out) {
        int nt = 1;
       // in >> nt;
        for (int it = 0; it < nt; ++it) {
            solveOne(in, out);
        }
    }
};
 
signed main() {
  fastio();
  Template solver;
  istream& in(cin);
  ostream& out(cout);
  solver.solve(in, out);
  return 0;
}