#include<stdio.h>
int main(void){
  long long int N;
  scanf("%lld",&N);
  long long int sum=0;
  for(int i=1;i<N;i++){
    sum = sum + N/i;
    if(N % i == 0)
      sum--;
  }
  printf("%lld",sum);
  return 0;
}