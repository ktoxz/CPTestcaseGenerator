N=int(input())
count=0
for a in range(1,N):
    for b in range(1,N):
        if a*b>=N:
            break
        else:
            count+=1
print(count)