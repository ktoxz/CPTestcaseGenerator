N, = [int(x) for x in input().split()]

ans = 0
for A in range(1, N + 1):
    numB = N // A
    if N % A == 0:
        ans += numB - 1
    else:
        ans += numB

print(ans)