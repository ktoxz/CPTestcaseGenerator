#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <fcntl.h>

int main()
{
	int n;
	int a;
	int ans;
	
	scanf("%d", &n);
	n -= 1;
	a = 1;
	ans = 0;
	while (n >= a)
	{
		ans += n / a;
		a++;
	}
	printf("%d\n", ans);
	return (0);
}