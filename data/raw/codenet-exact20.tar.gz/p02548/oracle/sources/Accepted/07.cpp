#include<bits/stdc++.h>
using namespace std;

//highlight color RGB = [70,70,70]
#define asll unsigned long long
#define ll long long
#define ld long double
#define imt int
#define pii pair<int,int>
#define st first
#define nd second
#define kj <<" "<<
#define kjb <<" ";
#define dg <<","<<
#define ml <<endl;
#define co cout<<
#define ter cout<<endl;
#define sibi cout<<"TES"<<endl;
#define tes(x) cout<<"TES "<<x<<endl;
#define psbk(x) push_back(x);
#define For(x,a,b) for(int x=(a);x<(b);x++)
#define FOR(x,n) for(int x=0;x<(n);x++)
#define kera(x,m) for( int i = 0;i < m ; i++ ){ cout<<"x["<< i <<"] =" kj x[i] ml}
#define kpr(x) cout<<"("<<x.st dg x.nd <<")" ml
#define kkor(p) cout<<"("<<p.x dg p.y <<")" ml
#define m_p make_pair
asll M=1e9+7;
int n,m,tc;
int p,q,r;
int juta=1000005;
int faktor[1000005];

void sieve(){
	FOR(i,juta){
		faktor[i]=0;
	}
	int temp;
	FOR(i,juta){
		if(i==0){
			continue;
		}
		temp=i;
		while(temp<juta){
			faktor[temp]++;
			temp+=i;
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);cout.tie(0);
	int hasil=0;
	sieve();
	cin>>m;
	For(i,1,m){
		hasil+=faktor[i];
		
	}
	co hasil ml
}
