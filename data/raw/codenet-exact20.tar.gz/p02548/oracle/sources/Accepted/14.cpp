/*
  
  Author: Arnab Sinha
	
  ███████╗██╗  ██╗███████╗██████╗         ██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗  █████╗  █████╗ 
  ██╔════╝██║  ██║██╔════╝██╔══██╗        ██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗██╔══██╗██╔══██╗
  ███████╗███████║█████╗  ██████╔╝        ██║     ██║   ██║██║     █████╔╝ █████╗  ██║  ██║╚██████║╚██████║
  ╚════ █║██╔══██║██╔══╝  ██╔══██╗        ██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██║  ██║ ╚═══██║ ╚═══██║
  ███████║██║  ██║███████╗██║  ██║███████╗███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██████╔╝ █████╔╝ █████╔╝
  ╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝  ╚════╝  ╚════╝                                                                                                        
*/
 
#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define li long long int
#define ld long long double
#define all(v) v.begin(),v.end()
#define sort(a) sort(all(a))
#define rev(a) reverse(all(a))
#define pb push_back
#define INF 1e18+10
#define MINF -1e18-10
#define rep(i,a,b) for(li i=a;i<b;i++)
#define vli vector<li>
#define MAXN 1e5+10
using namespace std;
 
li power(li a, li b, li mod) { a%=mod; li ret = 1; while(b){ if(b&1) ret*=a; a*=a;; if(ret>=mod) ret%=mod; if(a>=mod) a%=mod; b>>=1; } return ret; }
 
template <class T> void read(T& x){
	cin>>x;
}
 
template <class T, class... U> void read(T& x, U&... u){
	read(x);
	read(u...);
}
 
template <class A> void read(vector<A>& v){
	for(auto &it:v)
		read(it);
}
 
template <class A> void print(A x){
	cout<<x;
}
 
template <class A> void printl(A x){
	cout<<x<<endl;
}
 
template <class A> void print(vector<A>& v)
{
	for(auto &it:v){
		print(it);
		cout<<' ';
	}
	cout<<'\n';
}
 
void solve()
{
	li n;
	cin>>n;
	li lim = sqrt(n);
	lim+=1;
	li count = 0;

	for(li i = 1; i<= n; i++){
		li var = 1;
		while((n-(i*var))>0){
			count+=1;
			var++;
		}
	}

	cout<<count<<endl;
}

 
int main()
{
	IOS;
 	
 	#ifndef ONLINE_JUDGE
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
	#endif

 	solve();
 
	return 0;
}