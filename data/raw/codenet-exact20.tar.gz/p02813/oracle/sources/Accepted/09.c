// ABC 150-C
// 2020.1.11 bal4u

#include <stdio.h>
#include <string.h>

int K = 9;
char PP[10] = { 0, 1,2,3,4,5,6,7,8,9 };   // 0はダミ
//int *perm = PP + 1;                    // action()ではPP[1]から利用

/* 与えられた並び PP[] の次に大きい並べ替えを求める */
void next_perm()   // 順列の大きさはK
{
	int i, j, k, t;

	/* 上位桁のほうが下位桁よりも小さいところまで移動 */
	i = K; while (PP[i - 1] >= PP[i]) i--;

	/* 次の並べ替えがない */
	if (i == 1) return;

	/* PP[i-1]より値の大きい最も下位の桁をPP[j]とする */
	j = K; while (PP[i - 1] >= PP[j]) j--;

	/* PP[i-1]とPP[j]とを交換 */
	t = PP[i - 1], PP[i - 1] = PP[j], PP[j] = t;

	/* PP[i]から最下位までを逆順 */
	k = (K - i) >> 1; for (j = 0; j <= k; j++)
		t = PP[i + j], PP[i + j] = PP[K - j], PP[K - j] = t;
}

char P[10], Q[10];

int main()
{
	int i, N, n, x, y;
	
	scanf("%d", &N); K = N;
	for (i = 0; i < N; ++i) scanf("%d", P+i);
	for (i = 0; i < N; ++i) scanf("%d", Q+i);
	
	n = 0;
	for (i = 0; n < 2; ++i) {
		if (memcmp(PP+1, P, N) == 0) x = i, ++n;
		if (memcmp(PP+1, Q, N) == 0) y = i, ++n;
		next_perm();
	}
	x -= y;
	if (x < 0) x = -x;
	printf("%d\n", x);
	return 0;
}
