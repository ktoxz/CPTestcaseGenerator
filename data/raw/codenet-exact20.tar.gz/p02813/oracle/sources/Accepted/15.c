#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
typedef long long ll;
typedef long double ld;
#define rep(i,l,r)for(ll i=(l);i<(r);i++)
#define repp(i,l,r,k)for(ll i=(l);i<(r);i+=(k))
#define INF (1LL<<60)
#define MOD1 1000000007

void swap(ll *a, ll *b){ll c;c=*b;*b=*a;*a=c;}
ll max2(ll a,ll b){return a>=b?a:b;}
ll min2(ll a,ll b){return a>=b?b:a;}
ll minn(ll n, ll a[n]){ll b=INF;rep(i,0,n) b=min2(b,a[i]);return b;}
ll maxn(ll n, ll a[n]){ll b=-INF;rep(i,0,n) b=max2(b,a[i]);return b;}
ll ABS(ll a){return a>=0?a:(-a);}
ll POW(ll a, ll b){ll c=1;rep(i,0,b) c*=a;return c;}
int upll(const void*a, const void*b){return*(ll*)a<*(ll*)b?-1:*(ll*)a>*(ll*)b?1:0;}
int downll(const void*a, const void*b){return*(ll*)a<*(ll*)b?1:*(ll*)a>*(ll*)b?-1:0;}
void sortup(ll*a,int n){qsort(a,n,sizeof(ll),upll);}
void sortdown(ll*a,int n){qsort(a,n,sizeof(ll),downll);}

typedef struct{
    ll aa;
    ll bb;
}frequent;

/*階乗 a!*/
ll factorial(ll a){return a==1?a:a*factorial(a-1);}

ll permutation(ll n, ll a[n]){
    ll ans=0;
    rep(i,0,n-1){
        ll c=0;
        rep(j,i+1,n) if(a[i]>a[j]) c++;
        ans+=c*factorial(n-i-1);
    }
    return ans;
}

int main(void){
    // char ;
    ll n;
    scanf("%lld",&n);
    ll p[n],q[n];
    rep(i,0,n){
        scanf("%lld",&p[i]);
    }
    rep(i,0,n){
        scanf("%lld",&q[i]);
    }
    ll P=permutation(n,p),Q=permutation(n,q);
    printf("%lld\n",ABS(P-Q));
    return 0;
}
