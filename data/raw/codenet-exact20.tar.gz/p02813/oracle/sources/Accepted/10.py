def rec(all_list,num,sl):
    if len(sl)==1:
        all_list.append(num+sl)
        return

    for i,s in enumerate(sl):
        rec(all_list,num+s,sl[:i]+sl[i+1:])

N=int(input())
P=input()[::2]
Q=input()[::2]


all_list=[]

NN=""
for i in range(N):
    NN+=str(i+1)

rec(all_list,"",NN)

for i,s in enumerate(all_list):
    if P==s:
        a=i+1
    
    if Q==s:
        b=i+1

print(abs(a-b))
