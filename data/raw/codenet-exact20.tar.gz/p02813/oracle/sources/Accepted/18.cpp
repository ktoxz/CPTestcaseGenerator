#include <bits/stdc++.h>
#define rep(i, n) for (int i = 0; i < (n); ++i)
using namespace std;
using ll = long long;
using P = pair<int, int>;

bool compArray(int a[], int b[], int num){
    rep(i, num){
        if(a[i] != b[i]) return false;
    }  
    return true;
}

int main() {
    int n;
    cin >> n;
    int p[n], q[n];
    rep(i, n) cin >> p[i];
    rep(i, n) cin >> q[i];
    
    int r[n];
    rep(i, n) r[i] = i+1;
    bool f_p = true;
    bool f_q = true;
    int res = 0;
    int count = 1;
    do{
        if(f_p && compArray(p, r, n)){
            f_p = false;
            res += count;
        }
        if(f_q && compArray(q, r, n)){
            f_q = false;
            res -= count;
        }
        if(!f_p && !f_q) break;
        ++count;
    }while(next_permutation(r, r+n));
    
    cout << abs(res) << endl;
    return 0;
}