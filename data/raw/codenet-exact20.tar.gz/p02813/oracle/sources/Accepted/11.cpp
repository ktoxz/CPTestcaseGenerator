#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main(){
  int N;
  cin >> N;

  vector<int>V(N);
  for(int i = 0 ; i < N; ++i) V.at(i) = i + 1;

  vector<vector<int>>D;

  do {
    D.emplace_back(V);
  } while (std::next_permutation(V.begin(), V.end()));

  vector<int>P(N);
  for(auto& p: P)cin >> p;
  vector<int>Q(N);
  for(auto& q: Q)cin >> q;

  int p_i = 1 ,q_i = 1;
  for(auto& it: D){
    if(it != P) ++p_i;
    else break;
  }

  for(auto& it: D){
    if(it != Q) ++q_i;
    else break;
  }

  cout << abs(p_i - q_i) << endl;
}