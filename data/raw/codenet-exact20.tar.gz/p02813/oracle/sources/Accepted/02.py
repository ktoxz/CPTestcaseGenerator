import math


N = int(input())
list1 = list(map(int, input().split()))
list2 = list(map(int, input().split()))

def CO(l):
    n = len(l)
    if n != 1:
        m = sorted(l)
        a = l[0]
        s = m.index(a)
        l.remove(a)
        return((s)*math.factorial(n-1)+CO(l))
    else:
        return 1

print(abs(CO(list1)-CO(list2)))
