N=int(input())
pn=tuple(int(i) for i in input().split())
qn=tuple(int(i) for i in input().split())
l=[]
for i in range(1,N+1):
    l.append(i)
import itertools
ln=list(itertools.permutations(l))
print(abs(ln.index(pn)-ln.index(qn)))