#ifdef __GNUC__
#pragma GCC target("avx2")
#pragma GCC optimize ("O20")
#pragma GCC optimize ("tree-vectorize")
#pragma GCC optimize("unroll-loops")
#define iss std::cin
#endif
#include "bits/stdc++.h"
#define rep(i, times) for(ll i = 0; i < (times); ++i)
#define p(x) (cout << x << "\n")
using ll = uint_fast16_t; using ld = long double; using namespace std;
class CountOrder
{
	ll N{0};
	vector<ll> p, q;
	void inp( ) {
		iss >> N; p.resize(N); q.resize(N);
		rep(n, N) { iss >> p[n]; }
		rep(n, N) { iss >> q[n]; }
		//for_each(begin(p), end(p), [](auto x) { cout << x << "\n"; });
	}
	void change( ) {
		long long sa{0};
		if (p > q) swap(p, q);
		do {
			if (p == q) break;
			++sa;
		} while (next_permutation(begin(p), end(p)));
		p(sa);
	}
public:
	void procedures( ) {
		inp( );
		change( );
	}
};
//https://atcoder.jp/contests/abc145/tasks/abc145_c
int main( ) {
	cin.tie(0);	ios::sync_with_stdio(0);
	cout << fixed << setprecision(15);
	class CountOrder a; a.procedures( );
}