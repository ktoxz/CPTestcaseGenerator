N = int(input())
A = list(map(int, input().split()))
B = list(map(int, input().split()))
a, b = 1, 1
frac = 1
for i in range(N - 1):
  frac *= (i + 1)
for i in range(N):
  a += (A[i] - 1) * frac
  b += (B[i] - 1) * frac
  if i != N - 1:
    for j in range(i + 1, N):
      if A[j] > A[i]:
        A[j] -= 1
      if B[j] > B[i]:
        B[j] -= 1
    frac //= (N - 1 - i)
print(abs(a - b))