#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef pair<ll,ll> pii;
#define fi first
#define se second
#define ios ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define mod 1000000007
ll p[10];
ll q[10];
ll fac[10];
bool vis[10];
int main()
{
	ios;
	ll n,i,f=1,j,sum=0,sum1=0;
	fac[0]=1;
	for(i=1;i<=8;i++)
	{
		f=f*i;
		fac[i]=f;
	}
	cin>>n;
	for(i=1;i<=n;i++)
		cin>>p[i];
	for(i=1;i<=n;i++)
		cin>>q[i];
	for(i=1;i<=n;i++)
	{
		f=0;
		for(j=1;j<p[i];j++)
		{
			if(!vis[j])
				f++;
		}
		sum+=f*fac[n-i];
		vis[p[i]]=true;
	}
	memset(vis,false,sizeof(vis));
	for(i=1;i<=n;i++)
	{
		f=0;
		for(j=1;j<q[i];j++)
		{
			if(!vis[j])
				f++;
		}
		sum1+=f*fac[n-i];
		vis[q[i]]=true;
	}
	//cout<<sum<<" "<<sum1<<endl;
	cout<<abs(sum-sum1)<<endl;
}
