import sys
N = int(sys.stdin.readline())
P,Q = sys.stdin.readlines()

print(0)