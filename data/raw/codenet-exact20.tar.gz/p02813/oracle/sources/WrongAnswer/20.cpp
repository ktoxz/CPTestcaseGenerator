/*
このコード、と～おれ!
Be accepted!
∧＿∧　
（｡･ω･｡)つ━☆・*。
⊂　　 ノ 　　　・゜+.
　しーＪ　　　°。+ *´¨)
 　　　　　　　　　.· ´¸.·*´¨) ¸.·*¨)
		  　　　　　　　　　　(¸.·´ (¸.·'* ☆
					*/

#include <stdio.h>
#include <algorithm>
#include <string>
#include <cmath>
#include <cstring>
#include <vector>
#include <numeric>
#include <iostream>
#include <random>
#include <map>
#include <unordered_map>
#include <queue>
#include <regex>
#include <functional>
#include <complex>
#include <list>
/*多倍長整数/cpp_intで宣言
#include <boost/multiprecision/cpp_int.hpp>

using namespace boost::multiprecision;
*/

//#pragma GCC target ("avx2")
//#pragma GCC optimization ("O3")
//#pragma GCC optimization ("unroll-loops")
#define rep(i, n) for(int i = 0; i < (n); ++i)
#define rep1(i, n) for(int i = 1; i <= (n); ++i)
#define rep2(i, n) for(int i = 2; i < (n); ++i)
#define repr(i, n) for(int i = n; i >= 0; --i)
#define reprm(i, n) for(int i = n - 1; i >= 0; --i)
#define printynl(a) printf(a ? "yes\n" : "no\n")
#define printyn(a) printf(a ? "Yes\n" : "No\n")
#define printYN(a) printf(a ? "YES\n" : "NO\n")
#define printin(a) printf(a ? "possible\n" : "inposible\n")
#define printdb(a) printf("%.50lf\n", a)//少数出力
#define printdbd(a) printf("%.16lf\n", a)//少数出力(桁少なめ)
#define prints(s) printf("%s\n", s.c_str())//string出力
#define all(x) (x).begin(), (x).end()
#define allsum(a, b, c) ((a + b) * c / 2)//等差数列の和、初項,末項,項数
#define pb push_back
#define priq priority_queue
#define rpriq priq<int, vector<int>, greater<int>>
#define deg_to_rad(deg) (((deg)/360.0)*2.0*PI)
#define rad_to_deg(rad) (((rad)/2.0/PI)*360.0)
#define Please return
#define AC 0
#define addf(T) [](T a, T b){return (a + b);}
#define minf(T) [](T a, T b){return min(a, b);}
#define maxf(T) [](T a, T b){return max(a, b);}


using ll = long long;

constexpr int INF = 1073741823;
constexpr int MINF = -1073741823;
constexpr ll LINF = ll(4661686018427387903);
constexpr ll MOD = 1000000007;
const long double PI = acos(-1.0L);

using namespace std;

void scans(string& str) {
	char c;
	str = "";
	scanf("%c", &c);
	if (c == '\n')scanf("%c", &c);//最初の改行対策
	while (c != '\n' && c != -1) {
		str += c;
		scanf("%c", &c);
	}
}

void scanc(char& str) {
	char c;
	scanf("%c", &c);
	if (c == -1)return;
	while (c == '\n') {
		scanf("%c", &c);
	}
	str = c;
}

double acot(double x) {
	return PI / 2 - atan(x);
}

ll gcd(ll a, ll b) {
	if (b == 0) return a;
	return gcd(b, a % b);
}

ll lcm(ll number1, ll number2) {//lcmを求める
	return number1 / gcd(number1, number2) * number2;
}

ll LSB(ll n) { return (n & (-n)); }

/*-----------------------------------------ここからコード-----------------------------------------*/

template<typename T>
//0-indexed/内部的に 1-indexed
struct BIT {
	vector<T> tree;
	//初期化
	BIT(ll n) : tree(n) {
		tree.assign(n + 1, 0);
	}

	//[0, n) の sum を返す/0-indexed
	T sum(ll n) {
		T ret = 0;
		//実は 1-indexed だが半開区間なので見た目がそのまま
		for (; n >= 0; n -= LSB(n)) {
			ret += tree[n];
			if (!n)break;
		}
		return ret;
	}

	//n 番目に x を足す
	void add(ll n, T x) {
		ll siz = tree.size();
		for (++n; n < siz; n += LSB(n))tree[n] += x;
	}
};

int main() {

	int n, m;
	scanf("%d%d", &n, &m);
	vector<ll> a(n), f(n), b(n);
	f[0] = 1;
	rep1(i, n - 1){
	f[i] = (f[i - 1] * i);
	}
	rep(i, n)scanf("%lld", &a[i]);
	rep(i, n)scanf("%lld", &b[i]);
	BIT<ll> tree(n + 1), tree2(n);
	ll ans = 0, tmp, ans2 = 0;
	rep(i, n) {
		tmp = (a[i] - 1 - tree.sum(a[i]));
		tmp *= f[n - i - 1];
		ans += tmp;
		//cerr << (a[i] - 1 - tree.sum(a[i])) * facctorialMethod(n - i - 1) << endl;
		tree.add(a[i], 1);
	}
	rep(i, m) {
		tmp = (b[i] - 1 - tree2.sum(b[i]));
		tmp *= f[n - i - 1];
		ans2 += tmp;
		//cerr << (a[i] - 1 - tree.sum(a[i])) * facctorialMethod(n - i - 1) << endl;
		tree2.add(b[i], 1);
	}
	
	
	printf("%lld\n", abs(ans - ans2));

	Please AC;
}
