import itertools

n = int(input())
p = list(map(int, input().split()))
q = list(map(int, input().split()))

all_list = list(itertools.permutations(p))
all_list.sort()

p_ans = 0
q_ans = 0

for i in range(len(all_list)):
    if list(all_list[i]) == p:
        p_ans = i
    elif list(all_list[i]) == q:
        q_ans = i
print(abs(p_ans - q_ans))