#include<bits/stdc++.h>
using namespace std;
 
int main()
{
  int n,count=0;
  cin>>n;
 string p,q;
  cin>>p;
  cin>>q;
  do{
     if(p==q)
      break;
    count++;
  }while(next_permutation(p.begin(),p.end()));

  return 0;
}
     