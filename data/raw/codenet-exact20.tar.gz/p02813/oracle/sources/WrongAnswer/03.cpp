#include <bits/stdc++.h>
using namespace std;

long long Fac(int i)
{
  long long x=1;
  int j;
  for(j=1;j<i+1;j++)
  {
    x=x*j;
  }
  return x;
}
long dictionary_order(int *p,int l)
{
  int i,j,t;
  long long ans=0;
  long long x[l]={};
  
  for(i=0;i<l;i++)
  {
    t=p[i]-1;
    if(t>0)
    {for(j=0;j<i;j++)
    {
      if(p[i]>p[j])
      {
        t=t-1;
      }
    }
    x[i]=t*Fac(l-i-1);
    }
  }
  for (i=0;i<l;i++)
  {
    ans=ans+x[i];
  } 
  return ans+1;
}

int main()
{
  int l,i;
  int p[l],q[l]; 
  long long a,b;
  
  
  cin >>l;
  
  for(i=0;i<l;i++)
  {
  cin >>p[i];
  }
  for(i=0;i<l;i++)
  {
  cin >>q[i];
  }
  
  a=dictionary_order(p,l);
  b=dictionary_order(q,l);
  
  if(a>b)
  {
    a=a-b;
  }else
  {
    a=b-a;
  }
  cout <<a<<endl;
  
  
  return 0;
}
