def cycle(total, now, d):
    if d == now:
        return 0
    elif d < now:
        return total - now + d
    else:
        return d - now

def co(p):
    p = [int(_) for _ in p]
    import math
    n = nn = len(p)
    po = 0
    pd = [_ for _ in range(1, n + 1)]
    fact = math.factorial(n)
    for i in range(n):
        fact //= n
        po += cycle(n, min(pd), pd.index(p[i]) + 1) * fact
        pd.pop(pd.index(p[i]))
        n -= 1
    return po

if __name__ == "__main__":
    import sys
    in_str = []
    for line in sys.stdin:
        in_str.append(line)
    print(abs(co([int(_) for _ in in_str[1].split()]) - co([int(_) for _ in in_str[2].split()])))
