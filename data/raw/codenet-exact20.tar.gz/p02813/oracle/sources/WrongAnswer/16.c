#include<stdio.h>
#include<stdbool.h>

bool next_permu(int array[static 2],size_t len){
    int index_1,index_2;
    for(index_1 = len - 2;index_1 >= 0;index_1--){
        if(array[index_1] < array[index_1 + 1])break;
        if(!index_1)return false;
    }

    for(index_2 = len - 1;index_2 >= 0;index_2--){
        if(array[index_2] > array[index_1])break;
        if(!index_2)return false;
    }

    int tmp = array[index_1];
    array[index_1] = array[index_2];
    array[index_2] = tmp;

    for(int i = index_1 + 1;i < len - (i - index_1);i++){
        int tmp = array[i];
        array[i] = array[len - (i - index_1)];
        array[len - (i - index_1)] = tmp;
    }
    return true;
}

int main(void){
    int n;
    scanf("%d",&n);

    int p[n],q[n];
    for(int i = 0;i < n;i++)scanf("%d",&p[i]);
    for(int i = 0;i < n;i++)scanf("%d",&q[i]);
    int p_c = 0,q_c = 0;

    int base[n];
    for(int i = 0;i < n;i++)base[i] = i + 1;
    
    while(next_permu(base,n))for(int i = 0;i < n;i++)if(base[i] != p[i]){
            p_c++;
            break;
        }else if(i == n - 1)goto end_p;

    end_p:

    for(int i = 0;i < n;i++)base[i] = i + 1;
    while(next_permu(base,n))for(int i = 0;i < n;i++)if(base[i] != q[i]){
            q_c++;
            break;
        }else if(i == n - 1)goto end_q;

    end_q:

    printf("%d",(p_c < q_c ? q_c - p_c : p_c - q_c));
    return 0;
}