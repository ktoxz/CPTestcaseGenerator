#include <bits/stdc++.h>
using namespace std;
template<class t> inline t read(t &x){
	char c=getchar();bool f=0;x=0;
	while(!isdigit(c)) f|=c=='-',c=getchar();
	while(isdigit(c)) x=(x<<1)+(x<<3)+(c^48),c=getchar();
	if(f) x=-x;return x;
}
template<class t> inline void write(t x){
	if(x<0) putchar('-'),write(-x);
	else{if(x>9) write(x/10);putchar('0'+x%10);}
}

vector<int> a,b;
int rd=1,ans,n;

signed main(){
	read(n);
	for(int i=1;i<=n;i++) rd*=i;
	for(int i=1,x;i<=n;i++) a.push_back(read(x));
	for(int i=1,x;i<=n;i++) b.push_back(read(x));
	while(a!=b){
		next_permutation(a.begin(),a.end());
		ans++;
	}
	write(min(ans,rd-ans));
}