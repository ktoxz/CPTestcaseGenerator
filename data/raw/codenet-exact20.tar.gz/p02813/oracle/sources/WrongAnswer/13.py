n = int(input())

def dfs(nn):
  if n == nn:
    print("".join(ans))
    return 
  
  for i in ["a", "b", "c"]:
    ans[nn] = i
    dfs(nn+1)

ans = ["0" for i in range(n)]
dfs(0)