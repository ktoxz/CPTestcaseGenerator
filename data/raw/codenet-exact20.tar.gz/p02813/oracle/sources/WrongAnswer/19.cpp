#include <iostream>
using namespace std;

int main() {
  int n;
  cin >> n;
  int x[n], y[n];
  for (int i = 0; i < n; ++i)
    cin >> x[i];
  for (int i = 0; i < n; ++i)
    cin >> y[i];
  int lex;
  for (int i = 0; i < n; ++i) {
    lex += (i - n) * (x[i] - y[i]) + 1;
  }
}