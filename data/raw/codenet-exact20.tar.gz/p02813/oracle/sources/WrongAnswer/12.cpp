#include <iostream>
#define rep(i,n) for (int i=0; i<(n); i++)
using namespace std;

bool isPrime(int n);

int main(){
    int x;
    cin >> x;
 
    while(true){
        if(isPrime(x)){
            cout << x << endl;
            return 0;
        }
        x++;
    }
    
    return 0;
}

bool isPrime(int n){
    if(n<=1){
        return false;
    }
    for(int i=2; i*i<=n; i++){
        if(n%i==0){
            return false;
        }
    }
    return true;
}