#include <stdio.h>
#include <stdlib.h>

int change(int x, int y){
    if(x > y) {
        return x-1;
    }
}
 
int kaijo(int x) {
    int ans=1;
    for(int i=1;i<=x;i++){
        ans*=i;
    }
    return ans;
}
 
int main() {
    int N;
    scanf("%d", &N);
    int *P = (int*)malloc(N * sizeof(int));
    int *Q = (int*)malloc(N * sizeof(int));
    for(int i=0; i<N; i++) {
        scanf("%d", &P[i]);
    }
    for(int i=0; i<N; i++) {
        scanf("%d", &Q[i]);
    }
    int a = 0, b = 0;
    for(int i=0; i<N-1; i++) {
        a += (P[i] - 1) * kaijo(N-i-1);
        b += (Q[i] - 1) * kaijo(N-i-1);
        for(int j=i+1; j<N; j++) {
            P[j] = change(P[j], P[i]);
			Q[j] = change(Q[j], Q[i]);
        }
    }
    printf("%d\n", abs(a-b));
 
    free(P);
    free(Q);
    return 0;
}