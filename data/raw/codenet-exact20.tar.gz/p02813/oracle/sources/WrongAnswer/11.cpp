#include<bits/stdc++.h>
using namespace std;

#define fi                      first
#define se                      second
#define pb                      push_back
#define endl                    '\n'
#define all(x)                  x.begin(),x.end()
#define pii                     pair<int,int>
#define pll                     pair< long long int, long long int> 
#define fast                    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define SZ(x)                   ((int)x.size())

#define FOR(i,a,b)              for(int i = a; i < b; ++i)
#define REV(i,a,b)              for(int i = a; i >= b; --i)
#define FORE(i,a,b)             for(int i = a; i <= b; ++i)

typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;

void solve();

int32_t main()
{
        fast;
        int t = 1;
        // cin >> t;
        for(int i = 1; i <= t; ++i)
                solve();
        cerr << "Time taken: " << ((clock() * 1000) / CLOCKS_PER_SEC) << "ms\n";
}

void solve() {
        int n;
        cin >> n;
        std::vector<int> p(n),q(n);
        FOR(i,0,n) cin >> p[i];
        FOR(i,0,n) cin >> q[i];
        std::vector<int> a(n);
        FOR(i,0,n) a[i] = i+1;
        int x , y;
        int i = 1;
        while(next_permutation(all(a))) {
        	if(a == p) {
        		x = i;
        	}
        	if(a == q) {
        		y = i;
        	}
        	++i;
        }
        cout << abs(x-y) << endl;
}