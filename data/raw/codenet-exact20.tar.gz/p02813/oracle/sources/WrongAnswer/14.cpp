#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int ,int> ii;
typedef vector<ii> vii;
typedef pair<int, vector<int>> pv;
typedef pair<int, string> pis;
#define range(x, n) for(int x = 1; x <= n; x++)
#define deb(x) cout << #x << " " << x << endl;
int p[10], q[10],n,c;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    for(int i=0;i<n;i++) cin >> p[i];
    for(int i=0;i<n;i++) cin >> q[i];
    do {
      bool eq = true;
      for(int i=0;i<n && eq;i++) if (p[i] != q[i]) eq = false;
      if(!eq) c++;
      else break;
      next_permutation(q, q+n);
    } while(true);
    cout << c;
  return 0;
}
