from itertools import chain

H,W = map(int,input().split())

A = tuple(tuple(map(int,input().split())) for _ in range(H))
B = tuple(tuple(map(int,input().split())) for _ in range(H))

dp = {(0,0) : {A[0][0]-B[0][0]}}

cap = 1000000

for t in range(1,H+W-1):
    ndp = dict()
    for x in range(max(0,t-H+1), min(t+1,W)):
        y = t-x
        d = A[y][x]-B[y][x]
        if x > 0 and y > 0:
            ns = set(x%160 for x in chain((v+d for v in dp[(x-1,y)]),
                            (v-d for v in dp[(x-1,y)]),
                            (v+d for v in dp[(x,y-1)]),
                            (v-d for v in dp[(x,y-1)]),) if x < cap)
        elif x > 0:
            ns = set(x%160 for x in chain((v+d for v in dp[(x-1,y)]),
                            (v-d for v in dp[(x-1,y)]),) if x < cap)
        elif y > 0:
            ns = set(x%160 for x in chain((v+d for v in dp[(x,y-1)]),
                            (v-d for v in dp[(x,y-1)]),) if x < cap)
        else:
            ns = set()

        ndp[(x,y)] = ns
    dp = ndp

print(min(dp[(W-1,H-1)]))
