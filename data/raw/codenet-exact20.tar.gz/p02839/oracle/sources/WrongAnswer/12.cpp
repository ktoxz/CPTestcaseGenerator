#include <bits/stdc++.h>
#define int long long
#define md 1000000007
using namespace std;
int h,w;
int a[100][100],b[100][100];
int dp[81][81][13000];
int path(int i,int j,int k){
	if(dp[i][j][k]!=-1)
		return dp[i][j][k];
	int sum=LONG_LONG_MAX;
	int nk[2]={abs(k+a[i][j]-b[i][j]),abs(k-a[i][j]+b[i][j])};
	if(i==h-1 and j==w-1)
		return min(nk[0],nk[1]);

	if(i<h-1)
		sum=min(path(i+1,j,nk[0]),min(path(i+1,j,nk[1]),sum));
	if(j<w-1)
		sum=min(path(i,j+1,nk[0]),min(path(i,j+1,nk[1]),sum));
	return dp[i][j][k]=sum;
}
int32_t main(){
	// freopen("input.txt", "r", stdin);
	// freopen("output.txt", "w", stdout);
	cin >> h >> w;
	for(int i=0;i<h;i++)
		for(int j=0;j<w;j++)
			cin >> a[i][j];
	for(int i=0;i<h;i++)
		for(int j=0;j<w;j++)
			cin >> b[i][j];
	memset(dp,-1,sizeof(long long)*90*90*10000);
	cout << path(0,0,0) << endl;
}
