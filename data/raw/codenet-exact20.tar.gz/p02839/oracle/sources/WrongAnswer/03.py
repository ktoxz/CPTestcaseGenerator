h,w=map(int,input().split())
A=[]
B=[]
for i in range(h):
    A.append([int(i) for i in input().split()])
for i in range(h):
    B.append([int(i) for i in input().split()])

for i in range(h):
    A[i]=[abs(A[i][q]-B[i][q]) for q in range(w)]
    

DP=[[[0 for i in range(3201)] for q in range(w)] for r in range(h)]
DP[0][0][A[0][0]]=1

for i in range(h):
    for q in range(w):
        now=DP[i][q]
        if i<h-1:
            nex=DP[i+1][q]
            for r in range(3201):
                if now[r]==1:
                    nxsc=A[i+1][q]
                    nex[abs(r-nxsc)]=1
                    if r+nxsc<81:
                        nex[r+nxsc]=1
                        
        if q<w-1:
            nex=DP[i][q+1]
            for r in range(3201):
                if now[r]==1:
                    nxsc=A[i][q+1]
                    nex[abs(r-nxsc)]=1
                    if r+nxsc<81:
                        nex[r+nxsc]=1

las=DP[-1][-1]
ans=3201
for i in range(3200,-1,-1):
    if las[i]==1:
        ans=i
print(ans)
                        
                        