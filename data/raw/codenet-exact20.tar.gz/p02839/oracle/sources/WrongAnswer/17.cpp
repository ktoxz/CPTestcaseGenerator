#include<bits/stdc++.h>
using namespace std;

int main() {
  int H,W;
  cin >> H >> W;
  int ans = -1;
  vector<vector<int>> A(H,vector<int>(W));
  vector<vector<int>> B(H,vector<int>(W));
  for (int i=0;i<H;i++) {
    for (int j=0;j<W;j++) {
      cin >> A.at(i).at(j);
    }
  }
  for (int i=0;i<H;i++) {
    for (int j=0;j<W;j++) {
      cin >> B.at(i).at(j);
    }
  }
 for (int tmp = 0; tmp < (1 << H+W-2); tmp++) {
    bitset<160> s(tmp);
    if (s.count() == H-1) {
      int tempx=0,tempy=0;
      int tempdiff= A.at(0).at(0)-B.at(0).at(0);
      for (int i=0;i<H+W-2;i++) {
        if(s.test(i)) {
          tempy++;
        }
        else {
          tempx++;
        }
        tempdiff += A.at(tempy).at(tempx)-B.at(tempy).at(tempx);
      }
      if(ans<0) {
        ans = abs(tempdiff);
      }
      else {
        ans = min(ans,abs(tempdiff));
      }
    }
 }
  cout << ans << endl;
}