#include <bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,n) for(int (i)=0;(i)<(n);(i)++)
#define rrep(i,n) for(int (i)=((n)-1);(i)>=0;(i)--)
#define itn int
#define all(x) (x).begin(),(x).end()
#define F first
#define S second
const long long INF = 1LL << 60;
const int MOD = 1000000007;
template<class T> inline bool chmin(T& a, T b) { if (a > b) { a = b; return true; } return false; }
template<class T> inline bool chmax(T& a, T b) { if (a < b) { a = b; return true; } return false; }
vector <vector<bitset<13002>>> dp(82,vector <bitset<13002>>(82));
vector <vector<int>> a(81,vector <int>(81));
vector <vector<int>> b(81,vector <int>(81));
int h,w;
signed main(void){
    cin.tie(0);
    ios::sync_with_stdio(false);
    cin>>h>>w;
    rep(i, h){
        rep(j,w){
            cin>>a[i][j];
        }
    }
    rep(i, h){
        rep(j,w){
            cin>>b[i][j];
        }
    }
    dp[0][0].set(0);
    queue <pair<int,itn>> q;
    q.push({0,0});
    vector <vector<int>> v(h,vector <int>(w));
    while(!q.empty()){
        int y = q.front().F, x = q.front().S;
        q.pop();
        if(v[y][x]) continue;
        v[y][x] = true;
        int sa1 = a[y][x] - b[y][x], sa2 = b[y][x] - a[y][x];
        if(y - 1 >= 0){
            dp[y][x] |= dp[y-1][x];
        }
        if(x - 1>= 0){
            dp[y][x] |= dp[y][x-1];
        }
        dp[y][x] = (dp[y][x] << (sa1 + ((sa1>=0) ? 0 : 6500) )) | (dp[y][x] << (sa2 + ((sa2>=0) ? 0 : 6500)));
        if(y + 1 < h) q.push({y+1,x});
        if(x + 1 < w) q.push({y, x+1});
    }
    rep(i,6400){
        if(dp[h-1][w-1][i] || dp[h-1][w-1][i+6500]){
            cout<<i<<endl;
            return 0;
        }
    }
}
