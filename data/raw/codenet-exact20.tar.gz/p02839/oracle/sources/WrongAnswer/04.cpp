#include <functional>
#include <unordered_map>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <sstream>
#include <numeric>
#include <string>
#include <vector>
#include <cstdio>
#include <bitset>
#include <cmath>
#include <ctime>
#include <queue>
#include <stack>
#include <map>
#include <set>
 
using namespace std;
 
#define pii pair<int, int>
#define rank asdf
#define ll long long
 
const int mod = (int)1e9 + 7;

int n, m;
int a[88][88];
int b[88][88];
bool dp[88][88][26000];
int T = 13000;

int main(){
    ios_base::sync_with_stdio(0), cin.tie(0);
    cin >> n >> m;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            cin >> a[i][j];
        }
    }
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            cin >> b[i][j];
        }
    }
    dp[1][1][T + a[1][1] - b[1][1]] = true;
    dp[1][1][T + -a[1][1] + b[1][1]] = true;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= m; ++j){
            int diff = a[i][j] - b[i][j];
            for(int sum = 0; sum <= 24000; ++sum){
                if(j != 1 && sum >= diff) {
                    dp[i][j][sum] |= dp[i][j - 1][sum - diff];
                }
                if(j != 1 && sum + diff <= 24000) {
                    dp[i][j][sum] |= dp[i][j - 1][sum + diff];
                }
                if(i != 1 && sum >= diff) {
                    dp[i][j][sum] |= dp[i][j - 1][sum - diff];
                }
                if(i != 1 && sum + diff <= 24000) {
                    dp[i][j][sum] |= dp[i - 1][j][sum + diff];
                }
            }
        }
    }
    int ans = (int)1e9;
    for(int i = 0; i <= 24000; ++i){
        if(dp[n][m][i]) ans = min(ans, abs(i - T));
    }
    cout << ans << "\n";
}
