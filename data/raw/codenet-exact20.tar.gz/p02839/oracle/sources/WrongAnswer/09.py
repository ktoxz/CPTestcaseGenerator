I = [int(_) for _ in open(0).read().split()]
H, W = I[:2]
A = I[2:2 + H * W]
B = I[2 + H * W:]
D = [abs(a - b) for a, b in zip(A, B)]
dp = [0] + [1] + [0] * (W - 1)
for h in range(H):
    dpo = dp
    dp = [0] * (W + 1)
    for w, d in enumerate(D[W * h:W * (h + 1)]):
        s = dp[w] | dpo[w + 1]
        dp[w + 1] = (s << d) | (s >> d)
        t = bin(s)[2:][-1 - d:][::-1]
        t += '0' * (d - len(t))
        dp[w + 1] |= int(t, 2)
for i in range(160 * 80):
    if dp[-1] & 2**i:
        print(i)
        exit()
