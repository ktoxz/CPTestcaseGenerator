#include <bits/stdc++.h>
#include <iostream>
#include <time.h>
using namespace std;

#define rep(i, n) for(int i = 0; i < (int)(n); i++)

template <class T> class MultiArray2
{
    public:
        T* _a;
        int _w;
        int _h;
        MultiArray2(int w, int h, bool clr = false)
        {
            _w = w; _h = h;
            _a = new T[_w * _h];
            if(clr) memzero();
        }

        void memzero()
        {
            memset(_a, 0, _w * _h * sizeof(T));
        }

        ~MultiArray2()
        {
            delete _a;
        }

        T* operator[](int i)
        {
            return _a + (i * _h);
        }
};

template <class T> class MultiArray3
{
    public:
        T** _a2;
        T* _a;
        int _d1;
        int _d2;
        int _d3;
        MultiArray3(int d1, int d2, int d3, bool clr = true)
        {
            _d1 = d1; _d2 = d2; _d3 = d3;
            _a = new T[_d1 * _d2 * _d3];
            _a2 = new T*[_d1 * d2];
            for(int i = 0; i < d1 * d2; i++ ) _a2[i] = _a + (i * _d3);
            if(clr) memzero();
        }

        void memzero()
        {
            memset(_a, 0, _d1 * _d2 * _d3 * sizeof(T));
        }

        ~MultiArray3()
        {
            delete _a;
            delete _a2;
        }

        T** operator[](int i)
        {
            return _a2 + (i * _d2);
        }
};

int main()
{
    int h, w;
    cin >> h >> w;
    MultiArray2<int> a(w, h);
    MultiArray2<int> b(w, h);
    MultiArray3<bool> dp(w, h, (w + h) * 80 );

    rep(j, h)
        rep(i, w) cin >> a[i][j];
    rep(j, h)
        rep(i, w) cin >> b[i][j];

    rep(j, h)
    {
        rep(i, w)
        {
            int d = abs(a[i][j] - b[i][j]);
            int premax = (i + j) * 80;
            int leftmax = ( w - i + h - j) * 80;
            if( i == 0 && j == 0 )
            {
                dp[i][j][d] = true;
            }
            else
            {
                for( int p = 0; p < min(premax, leftmax + 80) ; p++ )
                {
                    if( ( i > 0 && dp[i - 1][j][p] ) || ( j > 0 && dp[i][j - 1][p] ) )
                    {
                        if( p + d <= leftmax ) dp[i][j][p + d] = true;
                        if( p - d >= 0 ) 
                        {
                            dp[i][j][p - d] = true;
                        }
                        else
                        {
                            dp[i][j][d - p] = true;
                        }
                    } 
                }
            }
        }
    }
    int ans = 0;
    while( !dp[w-1][h-1][ans] ) ans++;
    cout << ans << endl;

}