import numpy as np
i8 = np.int64
i4 = np.int32


def calc(dp1, dp2, k):
    dp2[k:] |= dp1[:dp1.shape[0]-k]
    dp2[:dp2.shape[0]-k] |= dp1[k:]


def solve(z, dp):
    zero = dp.shape[2] // 2
    dp[0, 0, zero + z[0, 0]] = 1
    dp[0, 0, zero - z[0, 0]] = 1
    for x in range(1, z.shape[1]):
        calc(dp[0, x - 1], dp[0, x], z[0, x])
    for y in range(1, z.shape[0]):
        calc(dp[y - 1, 0], dp[y, 0], z[y, 0])
        for x in range(1, z.shape[1]):
            calc(dp[y, x - 1], dp[y, x], z[y, x])
            calc(dp[y - 1, x], dp[y, x], z[y, x])
    for i in range(zero, dp.shape[2]):
        if dp[dp.shape[0] - 1, dp.shape[1] - 1, i] > 0:
            return i - zero
    return -1


def main():
    stdin = open('/dev/stdin', 'rb')
    pin = np.fromstring(stdin.read(), i8, sep=' ')
    H, W = pin[:2]
    a = pin[2: 2 + H * W].reshape(H, W)
    b = pin[2 + H * W:].reshape(H, W)
    z = np.abs(a - b)
    dp = np.zeros((H, W, 80 * 80 * 2 + 1), i8)
    ans = solve(z, dp)
    print(ans)


if __name__ == '__main__':
    main()