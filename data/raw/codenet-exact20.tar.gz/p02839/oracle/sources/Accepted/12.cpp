#include <bits/stdc++.h>
using namespace std;

int main() {
  int h, w;
  cin >> h >> w;
  vector<vector<int>> a(h, vector<int>(w)), b(h, vector<int>(w)), d(h, vector<int>(w));
  for (int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      cin >> a.at(i).at(j);
    }
  }
  for (int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      cin >> b.at(i).at(j);
    }
  }
  for (int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      d.at(i).at(j) = abs(a.at(i).at(j) - b.at(i).at(j));
    }
  }
  const int offset = 80 * 80;
  vector<vector<vector<bool>>> dp(h, vector<vector<bool>>(w, vector<bool>(160 * 80)));
  dp.at(0).at(0).at(offset + d.at(0).at(0)) = true;
  for (int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      for (int k = 0; k < offset * 2; k++) {
        if (i > 0) {
          if (k >= d.at(i).at(j) && dp.at(i - 1).at(j).at(k - d.at(i).at(j))) {
            dp.at(i).at(j).at(k) = true;
            continue;
          }
          if (k + d.at(i).at(j) < offset * 2 && dp.at(i - 1).at(j).at(k + d.at(i).at(j))) {
            dp.at(i).at(j).at(k) = true;
            continue;
          }
        }
        if (j > 0) {
          if (k >= d.at(i).at(j) && dp.at(i).at(j - 1).at(k - d.at(i).at(j))) {
            dp.at(i).at(j).at(k) = true;
            continue;
          }
          if (k + d.at(i).at(j) < offset * 2 && dp.at(i).at(j - 1).at(k + d.at(i).at(j))) {
            dp.at(i).at(j).at(k) = true;
          }
        }
      }
    }
  }
  int ans = 1000000;
  for (int i = 0; i < offset * 2; i++) {
    if (dp.at(h - 1).at(w - 1).at(i)) ans = min(ans, abs(i - offset));
  }
  cout << ans << endl;
}
