import numpy as np

H,W = map(int,input().split())

A = np.array(tuple(tuple(map(int,input().split())) for _ in range(H)))
B = np.array(tuple(tuple(map(int,input().split())) for _ in range(H)))

D = np.abs(A-B)
del A,B

if W > H:
    W,H = H,W
    D = D.T

L = D.max()*(H+W-1)+1
dp0 = np.zeros((W,L), dtype=bool)
dp1 = np.zeros_like(dp0)

dp1[0,D[0,0]] = True
for y in range(H):
    for x in range(W):
        d = D[y,x]

        dp1[x,d:] |= dp0[x,:L-d]
        dp1[x,:L-d] |= dp0[x,d:]
        dp1[x,:d] |= dp0[x,d:0:-1]
        dp1[x,d:] |= dp1[x-1,:L-d]
        dp1[x,:L-d] |= dp1[x-1,d:]
        dp1[x,:d] |= dp1[x-1,d:0:-1]
    dp0,dp1 = dp1, np.zeros_like(dp1)

print(min(i for i,v in enumerate(dp0[-1]) if v))
