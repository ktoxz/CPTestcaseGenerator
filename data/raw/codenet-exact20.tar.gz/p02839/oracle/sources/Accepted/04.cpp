#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<cstdlib>
using namespace std;
#define il inline
#define re register
#define debug printf("Now is Line : %d\n",__LINE__)
#define file(a) freopen(#a".in","r",stdin);freopen(#a".out","w",stdout)
#define int long long
#define D double
#define inf 123456789
#define mod 1000000007
il int read() {
    re int x = 0, f = 1; re char c = getchar();
    while(c < '0' || c > '9') { if(c == '-') f = -1; c = getchar();}
    while(c >= '0' && c <= '9') x = x * 10 + c - 48, c = getchar();
    return x * f;
}
#define rep(i , a , b) for(int i = (a) , i##Limit = (b) ; i <= i##Limit ; ++ i)
#define drep(i , b , a) for(int i = (a) , i##Limit = (b) ; i >= i##Limit ; -- i)
#define Next(i, u) for(re int i = head[u]; i; i = e[i].next)
#define mem(k, p) memset(k, p, sizeof(k))
#define lb(x) (x)&(-(x))
#define ls k * 2
#define rs k * 2 + 1
#define maxn 85
const int pax = 80 * 80;
int n, m, a[maxn][maxn], b[maxn][maxn], dp[maxn][maxn][maxn * maxn * 2], Ans = inf;
signed main() {
	n = read(), m = read();
	rep(i, 1, n) rep(j, 1, m) a[i][j] = read();
	rep(i, 1, n) rep(j, 1, m) b[i][j] = read();
	dp[1][1][pax - a[1][1] + b[1][1]] = dp[1][1][pax + a[1][1] - b[1][1]] = 1;
	rep(i, 1, n) {
		rep(j, 1, m) {
			rep(k, 0, pax * 2) {
				if(dp[i][j][k] == 0) continue;
				dp[i + 1][j][k + a[i + 1][j] - b[i + 1][j]] = 1;
				dp[i + 1][j][k - a[i + 1][j] + b[i + 1][j]] = 1;
				dp[i][j + 1][k + a[i][j + 1] - b[i][j + 1]] = 1;
				dp[i][j + 1][k - a[i][j + 1] + b[i][j + 1]] = 1;
			}
		}
	}
	rep(k, 0, pax * 2) if(dp[n][m][k] == 1) Ans = min(Ans, abs(k - pax));
	cout << Ans;
	return 0;
}