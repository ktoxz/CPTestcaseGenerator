I = [int(_) for _ in open(0).read().split()]
H, W = I[:2]
A = I[2:2 + H * W]
B = I[2 + H * W:]
D = [abs(a - b) for a, b in zip(A, B)]
dp = [set([])] + [set([0])] + [set([])] * (W - 1)
for h in range(H):
    dpo = dp
    dp = [set([])] * (W + 1)
    for w, d in enumerate(D[W * h:W * (h + 1)]):
        s = dp[w] | dpo[w + 1]
        dp[w + 1] = {v + d for v in s} | {abs(v - d) for v in s}
print(min(dp[-1]))
