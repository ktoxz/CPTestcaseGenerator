H, W = map(int, input().split())
A = [list(map(int, input().split())) for _ in range(H)]
B = [list(map(int, input().split())) for _ in range(H)]


def reverse_binary(n, width):
    return int("{:0{width}b}".format(n, width=width)[::-1], 2)


dp = [[0 for _ in range(W)] for _ in range(H)]
dp[0][0] = 1 << abs(A[0][0] - B[0][0])

for h in range(H):
    for w in range(W):
        diff = abs(A[h][w] - B[h][w])
        if w:
            dp[h][w] |= (reverse_binary(dp[h][w - 1] & ((1 << diff) - 1), diff)) << 1
            dp[h][w] |= dp[h][w - 1] >> diff
            dp[h][w] |= dp[h][w - 1] << diff
        if h:
            dp[h][w] |= (reverse_binary(dp[h - 1][w] & ((1 << diff) - 1), diff)) << 1
            dp[h][w] |= dp[h - 1][w] >> diff
            dp[h][w] |= dp[h - 1][w] << diff

tmp = dp[-1][-1]
ans = 0
while tmp & 1 == 0:
    tmp >>= 1
    ans += 1
print(ans)
