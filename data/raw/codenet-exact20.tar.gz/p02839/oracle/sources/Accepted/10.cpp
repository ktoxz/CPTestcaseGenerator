#include<deque>
#include<queue>
#include<vector>
#include<algorithm>
#include<iostream>
#include<set>
#include<cmath>
#include<tuple>
#include<string>
#include<chrono>
#include<functional>
#include<iterator>
#include<random>
#include<unordered_set>
#include<array>
#include<map>
#include<iomanip>
#include<assert.h>
#include<list>
#include<bitset>
#include<stack>
#include<memory>
#include<numeric>
using namespace std;
using namespace std::chrono;
typedef long long int llint;
typedef long double lldo;
#define mp make_pair
#define mt make_tuple
#define pub push_back
#define puf push_front
#define pob pop_back
#define pof pop_front
#define fir first
#define sec second
#define res resize
#define ins insert
#define era erase
/*cout<<fixed<<setprecision(20);cin.tie(0);ios::sync_with_stdio(false);*/
const int mod=1000000007;
const llint big=2.19e15+1;
const long double pai=3.141592653589793238462643383279502884197;
const long double eps=1e-4;
template <class T,class U>bool mineq(T& a,U b){if(a>b){a=b;return true;}return false;}
template <class T,class U>bool maxeq(T& a,U b){if(a<b){a=b;return true;}return false;}
llint gcd(llint a,llint b){if(a%b==0){return b;}else return gcd(b,a%b);}
llint lcm(llint a,llint b){if(a==0){return b;}return a/gcd(a,b)*b;}
template<class T> void SO(T& ve){sort(ve.begin(),ve.end());}
template<class T> void REV(T& ve){reverse(ve.begin(),ve.end());}
template<class T>llint LBI(const vector<T>&ar,T in){return lower_bound(ar.begin(),ar.end(),in)-ar.begin();}
template<class T>llint UBI(const vector<T>&ar,T in){return upper_bound(ar.begin(),ar.end(),in)-ar.begin();}

int main(void){
	int H,W,i,j;cin>>H>>W;
	int A[81][81];
	for(i=1;i<=H;i++){
		for(j=1;j<=W;j++){
			cin>>A[i][j];
		}
	}
	for(i=1;i<=H;i++){
		for(j=1;j<=W;j++){
			int B;cin>>B;
			A[i][j]=abs(A[i][j]-B);
		}
	}
	//6400*200
	bitset<12801>dp[81]={};
	dp[0][6400]=1;
	for(i=1;i<=H;i++){
		for(j=1;j<=W;j++){
			int a=A[i][j];
			dp[j]=((dp[j]|dp[j-1])>>a)|((dp[j]|dp[j-1])<<a);
		}
		dp[0][6400]=0;
	}
	for(j=0;j<=6400;j++){
		if(dp[W][j+6400]){cout<<j<<endl;break;}
	}
	return 0;
}