#include<stdio.h>
#include<math.h>

double Combi(int n, int r){

  int i;
  double c = 1.0;  

  if((1 <= r) && (r < n)){
    for(i=r;i>=1;i--){
      c *= ((n + 1.0 - (double)i) / (double)i);
    }
  }
  
  return c;
}

int main(){
  int n,a,b;
  int resulta,resultb;
  scanf("%d %d %d",&n,&a,&b);
  int ans=pow(2,n)-1;
  
  ans=ans-Combi(n,a);
  ans=ans-Combi(n,b);
  
  
  printf("%d",ans);
  return 0;
}