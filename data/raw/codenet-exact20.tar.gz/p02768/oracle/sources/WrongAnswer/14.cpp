#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int i = 0; i < (n); i++)

const long int mod = 1000000007;

int main() {
    int n, a, b;
    cin >> n >> a >> b;
    
    long int n_all, a_all, b_all;
    n_all = a_all = b_all = 1;
    
    rep(i,n) {
        n_all *= 2;
        n_all %= mod;
    }
    n_all--;
    
    long int c, m;
    c = m = 1;
    rep(i,a) {
        c *= n - i;
        c %= mod;
        m *= a - i;
        m %= mod;
    }
    if(c < m)
        c *= mod;
    a_all = c / m;
    a_all %= mod;
    
    c = m = 1;
    rep(i,b) {
        c *= n - i;
        c %= mod;
        m *= b - i;
        m %= mod;
    }
    if(c < m)
        c *= mod;
    b_all = c / m;
    b_all %= mod;
    
    //cout << n_all << endl;
    //cout << a_all << endl;
    //cout << b_all << endl;
    
    long int ans = n_all - a_all - b_all;
    if(ans < 0)
        ans += mod;
    
    cout << ans << endl;
    
    return 0;
}


