n, a, b = map(int, input().split())

ntmp = n
nottmp = 1
tmpin = [1, 1]

result = 0
N = n // 2
if n % 2 != 0:
    result += 1
for i in range(N):
    tmpin[0] *= ntmp
    tmpin[1] *= nottmp
    if nottmp != a and nottmp != b:
        result += ((tmpin[0] // tmpin[1]) * 2)
    else:
        result += (tmpin[0] // tmpin[1])
    ntmp -= 1
    nottmp += 1
    

print(result % (10 ** 9 + 7))
    