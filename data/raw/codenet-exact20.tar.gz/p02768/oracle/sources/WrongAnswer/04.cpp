#include<bits/stdc++.h>

#define rep(i,start,n) for(int i=start;i<(int)(n);i++)
#define rrep(i,n,end) for(int i=n-1;i>=end;i--)
#define each(it,v) for(auto it : v)
#define all(v) (v).begin(),(v).end()

using namespace std;
using ll = long long;
using vi = vector<int>;
using vll = vector<ll>;
using Pii = pair<int,int>;
using Pll = pair<ll,ll>;
using vpii = vector<Pii>;
using vpll = vector<Pll>;

const ll mod=1e9+7;
const int intINF=INT_MAX;
const ll  longINF=LONG_LONG_MAX;

ll power(ll a, ll n, ll m)
{
        ll ret = 1;
        for (; n > 0; n >>= 1, a = a * a % m)
        {
                if (n % 2 == 1)
                {
                        ret = ret * a % m;
                }
        }
        return ret;
}

ll C(int N,int K)
{
        ll x=1,y=1;
        for(int i=1;i<=K;i++)
        {
                x=x*(N-i+1)%mod;
                y=y*i%mod;
        }
        return x*power(y,mod-2,mod)%mod;
}

main()
{
        int n,a,b; cin>>n>>a>>b;

        ll ans=power(2,n,mod)-1;
        ans-=C(n,a)%mod;
        ans-=C(n,b)%mod;
        cout<<(ans+mod)%mod<<endl;
}