import math
a = input().split()
a=[int(i) for i in a]
b=a[0]
d=a[1]
e=a[2]
f=0
def c(n, r):
    return math.factorial(n) // (math.factorial(n - r) * math.factorial(r))
f=(b**2-1-c(b,d)-c(b,e))%(10**9+7)
print(f)
