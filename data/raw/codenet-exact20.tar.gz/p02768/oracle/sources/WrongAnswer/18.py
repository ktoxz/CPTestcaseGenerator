x = [int(str) for str in input().split()]
n = x[0]
a = x[1]
b = x[2]

res = 1
for z in range(n):
  res = res * 2 % 1000000007

abs = 1
bbs = 1

al = list(range(n,n-a,-1))
bl = list(range(n,n-b,-1))

for x1 in range(a):
  for x2 in range(a):
    if al[x2] % (x1+1) == 0:
      al[x2] /= (x1+1)
      break
for y1 in range(b):
  for y2 in range(b):
    if bl[y2] % (y1+1) == 0:
      bl[y2] /= (y1+1)
      break
for x3 in al:
  abs = abs * x3 % 1000000007
for y3 in bl:
  bbs = bbs * y3 % 1000000007

res -= int(abs+bbs)
if res <= 0:
  res += 1000000007
  if res <= 0:
    res += 1000000007
print(res)
