num_line=input().rstrip().split(" ")
num=int(num_line[0])
a=int(num_line[1])
b=int(num_line[2])

import math

sum1=0


if(num%2==0):
    for i in range(1,(num//2)):
        kumiawase=math.factorial(num)//((math.factorial(num-i))*(math.factorial(i)))
        #print(kumiawase)
        sum1+=kumiawase
    sum1=sum1*2+(math.factorial(num)//((math.factorial(num//2))**2))
    
else:
     for i in range(1,(num//2)+1):
        kumiawase=math.factorial(num)//((math.factorial(num-i))*(math.factorial(i)))
        print(kumiawase)
        sum1+=kumiawase
     sum1=2*sum1

a1=math.factorial(num)//((math.factorial(num-a))*(math.factorial(a)))
b1=math.factorial(num)//((math.factorial(num-b))*(math.factorial(b)))

dele=a1+b1


kekka=1+sum1-dele
print(kekka%(10**9+7))