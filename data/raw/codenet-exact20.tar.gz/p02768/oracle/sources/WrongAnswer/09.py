N,A,B = map(int,input().split())
print(0)