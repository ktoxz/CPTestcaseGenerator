#include<stdio.h>
int main(void)
{
    int n,a,b,i,j,k;
    long long sum=0,item=0;
    double temp=1;
    scanf("%d %d %d",&n,&a,&b);
    if(n%2==0) {
        for (i = 1; i <= n / 2-1; i++) {
            for (j = 1, k = n; j <= i && k >= i; j++, k--) {
                temp *= 1.0 * k / j;
            }
            sum += (long long) temp % 1000000007;
            sum = sum % 1000000007;
        }
        temp=1;
        for(j=1,k=n;j<=n/2+1&&k>=n/2;j++,k--){
            temp*=1.0*k/j;
        }
        sum=(sum*2+(long long)temp+1)%1000000007;
    }
    else{
        for (i = 1; i <= n / 2; i++) {
            for (j = 1, k = n; j <= i && k >= i; j++, k--) {
                temp *= 1.0 * k / j;
            }
            sum += (long long) temp % 1000000007;
            sum = sum % 1000000007;
        }
        sum=(sum*2+1)%1000000007;
    }
    temp=1;
    for(j=1,k=n;j<=a&&k>=a;j++,k--){
        temp*=1.0*k/j;
    }
    item+=(int)temp%1000000007;
    temp=1;
    item=0;
    for(j=1,k=n;j<=b&&k>=b;j++,k--){
        temp*=1.0*k/j;
    }
    item+=(int)temp%1000000007;
    item=item%1000000007;
    if(item>sum)
        sum=(item+sum)%1000000007;
    else
        sum-=item;
    printf("%lld",sum);
    return 0;
}