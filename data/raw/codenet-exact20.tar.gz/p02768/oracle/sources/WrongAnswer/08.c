#include <stdio.h>

/*--- 異なるn個からr個の整数を取り出す組み合わせの数を返す ---*/
int combination(int n, int r)
{
    if (r == 0 || r == n)
        return (1);
    else if (r == 1)
        return (n);
    return (combination(n - 1, r - 1) + combination(n - 1, r));
}

int main(void)
{
    long int n;
    int a, b;
    int pattern[n + 1];
    int i, j;
    int sum = 0;

    scanf("%ld %d %d", &n, &a, &b);

    for (i = 0; i < n + 1; i++)
    {
        if (i >= 2 && (i != a && i != b))
        {
            pattern[i] = combination(n, i);
            // printf("pattern[%d] = %d\n", i, pattern[i]);
            sum += pattern[i];
        }
    }
    printf("%d", sum);
    return (0);
}