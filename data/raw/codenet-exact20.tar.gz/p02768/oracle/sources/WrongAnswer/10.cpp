#include <bits/stdc++.h>
using namespace std;
map<int,int> memo;
int main() {
  int N,a,b;
  cin>>N,a,b;
  int sum=0;
  for(int j=0;j<N+1;j++){
    int s;
    s=(j+1+N)*(N-j-1)/2;
    sum=sum+s;
  }
 
  int s1=1;
  s1=(a+N)*(N-a)/2;
  sum=sum-s1;
  int s2=1;
  s2=(b+N)*(N-b)/2;
  sum=sum-s2;
  
  sum=sum%(1000000000+7);
  cout<<sum<<endl;

}


