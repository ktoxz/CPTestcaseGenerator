#include<stdio.h>

#define MODNUM 1000000007

long long modpow(long long a, long long n, long long mod){
	long long result = 1;
	while(n > 0){
		if(n & 1){
			result = result * a % mod;
		}
		a = a * a % mod;
		n /= 2;
	}

	return result;
}

long long modinv(long long a, long long mod){
	return modpow(a, mod - 2, mod);
}

int main(){
	int n, a, b;
	int min, max;
	long long pow2 = 1;
	long long f = 1, t;
	long long ans = 0;
	int i;

	scanf("%d %d %d", &n ,&a, &b);

	if(a < b){
		min = a;
		max = b;
	}
	for(i=0; i<n; i++){
		pow2 = pow2 * 2 % MODNUM;
	}
	ans = pow2 - 1 % MODNUM;
	t = n;
	for(i=1; i<=min; i++){
		f = f * i % MODNUM;
		t = t * n-i % MODNUM;
	}
	ans -= t * modinv(f, MODNUM) % MODNUM;
	for(; i<=max; i++){
		f = f * i % MODNUM;
		t = t * n-i % MODNUM;
	}
	ans -= t * modinv(f, MODNUM) % MODNUM;

	while(ans >= 0){
		ans += MODNUM;
	}

	printf("%lld", ans);
	return 0;
}
