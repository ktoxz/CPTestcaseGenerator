N0,a0,b0=map(int,input().split())
tmp1=10**9+7
a=a0%tmp1
b=b0%tmp1
N=N0%tmp1
res=[]
res.append((N/1))
res.append((N/1))
for n in range(2,N+1,1):
    tmp=(N-n+1)/n
    res.append(res[n-1]*tmp)
cnt=sum(res)-res[0]-res[a]-res[b]
print(cnt)