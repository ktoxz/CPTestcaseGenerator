
#include <bits/stdc++.h>

using namespace std;

const int MOD = 1e9 + 7;

class mint {
    long long x;
public:
    mint(long long x=0) : x((x % MOD + MOD) % MOD) {}
    mint operator-() const { 
      return mint(-x);
    }
    mint& operator+=(const mint& a) {
        if ((x += a.x) >= MOD) x -= MOD;
        return *this;
    }
    mint& operator-=(const mint& a) {
        if ((x += MOD-a.x) >= MOD) x -= MOD;
        return *this;
    }
    mint& operator*=(const  mint& a) {
        (x *= a.x) %= MOD;
        return *this;
    }
    mint operator+(const mint& a) const {
        mint res(*this);
        return res+=a;
    }
    mint operator-(const mint& a) const {
        mint res(*this);
        return res-=a;
    }
    mint operator*(const mint& a) const {
        mint res(*this);
        return res*=a;
    }
    mint pow(long long t) const {
        if (!t) return 1;
        mint a = pow(t>>1);
        a *= a;
        if (t&1) a *= *this;
        return a;
    }
    // for prime MOD
    mint inv() const {
        return pow(MOD-2);
    }
    mint& operator/=(const mint& a) {
        return (*this) *= a.inv();
    }
    mint operator/(const mint& a) const {
        mint res(*this);
        return res/=a;
    }

    friend ostream& operator<<(ostream& os, const mint& m){
        os << m.x;
        return os;
    }
};


// 組み合わせ数を計算する
map<long long, vector<mint>> _combinations;
mint combination(long long n, long long r) {
    if(!_combinations.count(n)) {
        vector<mint> vec = {0, n};
        _combinations.emplace_hint(_combinations.end(), n, vec);
    }
    if(r > n - r) r = n - r;
    auto&& vec = _combinations.find(n)->second;
    if(vec.size() <= r) {
        long long i = vec.size();
        vec.resize(r + 1);
        for(; i <= r; i++) {
            vec[i] = vec[i - 1];
            vec[i] *= (n - i + 1);
            vec[i] /= i;
        }
    }

    return vec[r];
}

int n,a,b;
mint result;
int main() {
    cin.tie(0); ios::sync_with_stdio(false); cout << fixed << std::setprecision(20);

    cin >> n >> a >> b;
    cout << mint(2).pow(n) - 1 - combination(n, a) - combination(n, b);
}
