#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
#include <cmath>
#include <numeric>
#include <string>

#define debug(s) cout << s << endl
#define debug1(s, t) cout << s << " " << t << endl

using namespace std;
using i64 = long long;

i64 p = 1000000007LL;

i64 powmod(i64 x, i64 y)
{
    if (y == 1)
        return x % p;
    if (y % 2 == 0)
    {
        i64 pwmd = powmod(x, y / 2) % p;
        return (pwmd * pwmd) % p;
    }
    else
    {
        return (x * powmod(x, y - 1)) % p;
    }
}

i64 bicomod(int n, int a)
{
    if (n == a)
        return 1;
    if (a > n / 2)
        return bicomod(n, n - a);
    i64 anom = 1;
    i64 adom = 1;
    for (int i = 1; i <= a; i++)
        anom = anom * i % p;
    for (int i = n - a + 1; i <= n; i++)
        adom = adom * i % p;

    return (adom * powmod(anom, p - 2)) % p;
}

int main()
{
    int n, a, b;
    cin >> n >> a >> b;

    i64 ca = bicomod(n, a);
    i64 cb = bicomod(n, b);


    i64 ans = powmod(2LL, n) - ca - cb - 1;
    while (ans < 0)
        ans += p;

    cout << ans << endl;

    return 0;
}