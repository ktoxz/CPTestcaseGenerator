#include <stdio.h>
#include <stdlib.h>

long long div_mod(long long x, long long y, long long z)
{
	if (x % y == 0) return x / y;
	else return (div_mod((1 + x / y) * y - x, (z % y), y) * z + x) / y;
}

int main()
{
	long long n, a, b;
	scanf("%lld %lld %lld", &n, &a, &b);
	
	int i, j;
	long long m, total = 1, tmp[32] = {2}, ex[2] = {1, 1};
	for (i = 1; i < 32; i++) tmp[i] = tmp[i-1] * tmp[i-1] % 1000000007;
	for (i = 0, m = n; m > 0; i++, m = m >> 1) if (m % 2 == 1) total = total * tmp[i] % 1000000007;
	for (i = 0; i < a; i++) ex[0] = ex[0] * (n - i) % 1000000007;
	for (j = 1; j <= a; j++) ex[0] = div_mod(ex[0], j, 1000000007);
	for (ex[1] = ex[0]; i < b; i++) ex[1] = ex[1] * (n - i) % 1000000007;
	for (; j <= b; j++) ex[1] = div_mod(ex[1], j, 1000000007);
	
	printf("%lld\n", (total + 1000000007 * 2 - ex[0] - ex[1] - 1) % 1000000007);
	fflush(stdout);
	return 0;
}