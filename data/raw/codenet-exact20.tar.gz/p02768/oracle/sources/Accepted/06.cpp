#include "bits/stdc++.h"

// Begin Header {{{
using namespace std;

#ifndef DEBUG
#define dump(...)
#endif

#define all(x) x.begin(), x.end()
#define rep(i, n) for (intmax_t i = 0, i##_limit = (n); i < i##_limit; ++i)
#define reps(i, b, e) for (intmax_t i = (b), i##_limit = (e); i <= i##_limit; ++i)
#define repr(i, b, e) for (intmax_t i = (b), i##_limit = (e); i >= i##_limit; --i)
#define var(Type, ...) Type __VA_ARGS__; input(__VA_ARGS__)

constexpr size_t    operator""_zu(unsigned long long value) { return value; };
constexpr intmax_t  operator""_jd(unsigned long long value) { return value; };
constexpr uintmax_t operator""_ju(unsigned long long value) { return value; };

constexpr int INF = 0x3f3f3f3f;
constexpr intmax_t LINF = 0x3f3f3f3f3f3f3f3f_jd;

template <class T>
using MaxHeap = priority_queue<T, vector<T>, less<T>>;
template <class T>
using MinHeap = priority_queue<T, vector<T>, greater<T>>;

inline void input() {}
template <class Head, class... Tail>
inline void input(Head&& head, Tail&&... tail) {
    cin >> head;
    input(forward<Tail>(tail)...);
}

template <class T>
inline void input(vector<T> &vec) {
    for (auto &e: vec) {
        cin >> e;
    }
}

template <class T>
inline void input(vector<vector<T>> &mat) {
    for (auto &vec: mat) {
        input(vec);
    }
}

inline void print() { cout << "\n"; }
template <class Head, class... Tail>
inline void print(Head&& head, Tail&&... tail) {
    cout << head;
    if (sizeof...(tail)) {
        cout << " ";
    }
    print(forward<Tail>(tail)...);
}

template <class T>
inline ostream& operator<<(ostream &os, const vector<T> &vec) {
    static constexpr const char *delim[] = {" ", ""};
    for (const auto &e: vec) {
        os << e << delim[&e == &vec.back()];
    }
    return os;
}

template <class T>
inline vector<T> makeVector(const T &initValue, size_t sz) {
    return vector<T>(sz, initValue);
}

template <class T, class... Args>
inline auto makeVector(const T &initValue, size_t sz, Args... args) {
    return vector<decltype(makeVector<T>(initValue, args...))>(sz, makeVector<T>(initValue, args...));
}

template <class Func>
class FixPoint : Func {
public:
    explicit constexpr FixPoint(Func&& f) noexcept : Func(forward<Func>(f)) {}

    template <class... Args>
    constexpr decltype(auto) operator()(Args&&... args) const {
        return Func::operator()(*this, std::forward<Args>(args)...);
    }
};

template <class Func>
static inline constexpr decltype(auto) makeFixPoint(Func&& f) noexcept {
    return FixPoint<Func>{forward<Func>(f)};
}

template <class T>
inline bool chmax(T &a, const T &b) noexcept {
    return b > a && (a = b, true);
}

template <class T>
inline bool chmin(T &a, const T &b) noexcept {
    return b < a && (a = b, true);
}

template <class T>
inline T diff(const T &a, const T &b) noexcept {
    return a < b ? b - a : a - b;
}
// End Header }}}

const intmax_t MOD = intmax_t(1e9) + 7;

// ModInt {{{
template <intmax_t MOD>
class ModInt {
    intmax_t value;

public:
    inline ModInt(const ModInt& other) :
        value(other.value)
    {}

    inline ModInt(intmax_t value = 0) {
        if (value >= MOD) {
            this->value = value % MOD;
        } else if (value < 0) {
            this->value = (value + MOD) % MOD;
        } else {
            this->value = value;
        }
    }

    template <class T>
        explicit inline operator T() const {
            return static_cast<T>(value);
        }

    inline ModInt inverse() const {
        return ModInt::pow(value, MOD - 2);
    }

    inline ModInt& operator+=(const ModInt other) {
        value = (value + other.value) % MOD;
        return *this;
    }

    inline ModInt& operator-=(const ModInt other) {
        value = (MOD + value - other.value) % MOD;
        return *this;
    }

    inline ModInt& operator*=(const ModInt other) {
        value = (value * other.value) % MOD;
        return *this;
    }

    inline ModInt& operator/=(const ModInt other) {
        value = (value * other.inverse().value) % MOD;
        return *this;
    }

    inline ModInt operator+(const ModInt other) {
        return ModInt(*this) += other;
    }

    inline ModInt operator-(const ModInt other) {
        return ModInt(*this) -= other;
    }

    inline ModInt operator*(const ModInt other) {
        return ModInt(*this) *= other;
    }

    inline ModInt operator/(const ModInt other) {
        return ModInt(*this) /= other;
    }

    inline bool operator==(const ModInt other) {
        return value == other.value;
    }

    inline bool operator!=(const ModInt other) {
        return value != other.value;
    }

    friend ostream& operator<<(ostream &os, const ModInt other) {
        os << other.value;
        return os;
    }

    friend istream& operator>>(istream &is, ModInt& other) {
        is >> other.value;
        return is;
    }

    static constexpr inline ModInt pow(intmax_t n, intmax_t p) {
        intmax_t ret = 1;
        for (; p > 0; p >>= 1) {
            if (p & 1) ret = (ret * n) % MOD;
            n = (n * n) % MOD;
        }
        return ret;
    }
};

using Mint = ModInt<MOD>;
// }}}

Mint binomial(intmax_t N, intmax_t K) {
    if (K < 0 || N < K) {
        return 0;
    }

    Mint ret = 1;
    for (intmax_t i = 1; i <= K; ++i) {
        ret *= N--;
        ret /= i;
    }

    return ret;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    var(intmax_t, n, a, b);

    Mint res = Mint::pow(2, n) - 1;
    res -= binomial(n, a);
    res -= binomial(n, b);

    print(res);

    return 0;
}
