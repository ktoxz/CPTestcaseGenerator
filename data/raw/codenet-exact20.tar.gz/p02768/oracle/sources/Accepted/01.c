#include <stdio.h>
#define WARU 1000000007

/* aの逆数の計算 */

long gyaku(long a){
   long b=WARU,u=1,v=0,t,tmp;
   while (b) {
      t=a/b;
      tmp=a-t*b;
      a=b;b=tmp;
      tmp=u-t*v;
      u=v;v=tmp;
   }
   u%=WARU; 
   if (u<0) u+=WARU;
   return u;
}

/* a^nの計算 */

long modpow(long int a, long int n) {
   long int res=1;
  
   while (n>0) {
        if (n%2==1) res=(res*a)%WARU;
        a=(a*a)%WARU;
        n/=2;
    }
    return res;
}

int main(){
   long int n,a,b,ans,all,nn,bi,i,na,nb,wa,wb;
 
   scanf("%ld %ld %ld",&n,&a,&b);
   all=modpow(2,n)-1;
   na=nb=wa=wb=1;
   for (i=0;i<a;) {
      na=(na*(n-i))%WARU;
      i++;
      wa=(wa*i)%WARU;
   }
   for (i=0;i<b;) {
      nb=(nb*(n-i))%WARU;
      i++;
      wb=(wb*i)%WARU;
   }
  na=(na*gyaku(wa))%WARU;
   nb=(nb*gyaku(wb))%WARU;
/*    na=(na*modpow(wa,WARU-2))%WARU;
   nb=(nb*modpow(wb,WARU-2))%WARU;*/
   printf("%ld\n",(all+(WARU-na)+(WARU-nb))%WARU);
   return 0;
}
