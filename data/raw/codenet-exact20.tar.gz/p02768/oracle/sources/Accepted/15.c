char buf[99];sz;
int N,A,B;
long mod=1e9+7;
long p(long a,long b){return b?p(a*a%mod,b>>1)*(b&1?a:1)%mod:1;}
long C(long a,long b)
{
	long x=1,y=1;
	for(int i=1;i<=b;i++)
	{
		x=x*(a-i+1)%mod;
		y=y*i%mod;
	}
	return x*p(y,mod-2)%mod;
}
main()
{
	read(0,buf,99);
	for(;;)
	{
		char c=buf[sz++];
		if(c<'0')break;
		N=N*10+c-'0';
	}
	for(;;)
	{
		char c=buf[sz++];
		if(c<'0')break;
		A=A*10+c-'0';
	}
	for(;;)
	{
		char c=buf[sz++];
		if(c<'0')break;
		B=B*10+c-'0';
	}
	printf("%d\n",((p(2,N)-1-C(N,A)-C(N,B))%mod+mod)%mod);
}
