n,*a=map(int,open(0).read().split());k=10**9+7
c=(1<<n)%k-1
for l in a:
	X=Y=j=Z=1;d=k-2
	for i in range(l):X=X*(n-i)%k
	while j<=l:Y=Y*j%k;j+=1
	while d>0:Z=Z*Y%k if d&1==1 else Z;Y=Y*Y%k;d>>=1
	c-=X*Z%k
print(c%k)