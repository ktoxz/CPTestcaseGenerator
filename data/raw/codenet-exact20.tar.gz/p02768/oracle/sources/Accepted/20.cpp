#include <iostream>
#include <algorithm>
using namespace std;

long long n, a, b, c, m = 1, t = 2, w1 = 1, w2, v;
const long long M = 1000000007;

int main()
{
	cin >> n >> a >> b;

	for (int i = 0; (1ull << i) <= n; i++) {
		if((1ull << i) & n)
			m = m * t % M;

		t = t * t % M;
	}

	m -= 1;

	c = max(a, b);

	for (int i = 1; i <= c; i++) {
		w2 = w1 * i % M;

		t = w2;
		v = 1;
		w1 = w2;

		if (i == a || i == b) {
			for (int j = 0; (1ull << j) < M - 1; j++) {
				if ((1ull << j) & (M - 2))
					v = v * t % M;

				t = t * t % M;
			}

			t = 1;
			for (long long k = n; k > n - i; k--)
				t = t * k % M;

			m = (M + m - (t * v % M)) % M;
		}
	}

	cout << m << endl;

	return 0;
}