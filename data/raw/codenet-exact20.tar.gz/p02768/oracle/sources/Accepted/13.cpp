#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#define mt make_tuple
#define ll long long
#define ld long double
#define eb emplace_back
#define fi first
#define pb push_back
#define endl '\n'
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define forn(i, n) for (int i = 0; i < (int)(n); ++i)
#define fore(i, a, b) for (int i = (int)(a); i <= (int)(b); ++i)
#define scanVec(vec , n) for(int i = 0; i < n ; i++){ cin>>vec[i];}
#define printVec(vec , n) for(int i = 0; i < n ; i++){ cout<<vec[i]<<" ";}
#define mod(a,b) ((a%b +b)%b)
#define bit(x,i) (x&(1<<i))  //select the bit of position i of x
#define lowbit(x) ((x)&((x)^((x)-1))) //get the lowest bit of x
#define hBit(msb,n) asm("bsrl %1,%0" : "=r"(msb) : "r"(n)) //get the highest bit of x, maybe the fastest
#define max(a,b) (a<b?b:a)
#define min(a,b) (a>b?b:a) 
//#define error(args...) { string _s = #args; replace(_s.begin(), _s.end(), ',', ' '); stringstream _ss(_s); istream_iterator<string> _it(_ss); err(_it, args); }
#define IN(i,l,r) (l<i&&i<r)
#define LINR(i,l,r) (l<=i&&i<=r)
#define LIN(i,l,r) (l<=i&&i<r)
#define INR(i,l,r) (l<i&&i<=r)
#define lastEle(vec) vec[vec.size()-1] 
#define SZ(x) ((int)((x).size()))
#define FOREACH(i,t) for (typeof(t.begin()) i=t.begin(); i!=t.end(); i++) 
#define ll long long 
#define ull unsigned long long
#define ui unsigned int
#define us unsigned short
#define INF 1001001001
#define PI 3.1415926535897932384626
 
using namespace std;
 //using namespace __gnu_pbds;
 //template <typename T>
 //using ordered_set =
    //tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
 
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vpi;
typedef vector<vi> vvi;

/*
void err(istream_iterator<string> it) {}
template<typename T, typename... Args>
void err(istream_iterator<string> it, T a, Args... args) {
    cerr << *it << " = " << a << endl;
    err(++it, args...);
}
 */
//----------------------------------------------------------------------------------------------------------------------
  
void swap(int & a, int & b){
    auto temp = a;
    a = b;
    b = temp;
}
 
const ll MOD = 1e9 + 7;
 
ll inf = 1LL*1e18;
 
void no(){
    cout <<"NO" << endl;
   //exit(0);
}
 
void yes(){
    cout <<"YES" << endl; //exit(0);
}
 
long long binpow(long long a, long long b, long long m) {
    a %= m;
    long long res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a % m;
        a = a * a % m;
        b >>= 1;
    }
    return res;
}

// const int MAXN = (1 << 20);
// const int MAXLOG = 20;

// ll dp[MAXN][MAXLOG];
// ll prec_lg2[MAXN], n;
// struct sparse_table
// {
                                                                                      
// 	//sparse_table() { memset(dp, 0, sizeof(dp)); memset(prec_lg2, 0, sizeof(prec_lg2)); n = 0; }

// 	void init(vector<ll> &a)
// 	{
// 		n = a.size();
// 		for(int i = 2; i < 2 * n; i++) prec_lg2[i] = prec_lg2[i >> 1] + 1;
// 		for(int i = 0; i < n; i++) dp[i][0] = a[i];
// 		for(int j = 1; (1 << j) <= n; j++)    
// 			for(int i = 0; i < n; i++)
// 				dp[i][j] = min(dp[i][j - 1], dp[i + (1 << (j - 1))][j - 1]);
// 	}

// 	ll query(ll l, ll r) {
//         if(l > r) return inf;
// 		ll k = prec_lg2[r - l + 1];
// 		return min(dp[l][k], dp[r - (1 << k) + 1][k]);
// 	}
// };

void put(string s){
	cout << s << endl;
}

struct coord {
	int x;
	int y;
	int z;
	int ind;
	bool operator < (const coord & b) const {
		if(x != b.x) return x < b.x;
		if(y != b.y) return y < b.y;
		if(z != b.z) return z < b.z;
		return false;
	}
};

const ll md = 998244353;

ll modInverse(ll a, ll m){
    ll m0 = m; 
    ll y = 0, x = 1; 
    if (m == 1) return 0; 
    while (a > 1){
        ll q = a / m; 
        ll t = m; 
        m = a % m, a = t; 
        t = y; 
        y = x - q * y; 
        x = t; 
    } 
    if (x < 0) x += m0; 
    return x; 
} 

bool isPal(string  s){	
	for(int i = 0;i < ((int)s.size())/2;i++){
		if(s[i] != s[(int)s.size() - i - 1]) return false;
	}
	return true;
}

const int MAXN = 2*1e5 + 100;
ll fact[MAXN];
void calc(){
	fact[0] = 1;
	for(ll i = 1;i < MAXN;i++){
		fact[i] = i*fact[i-1];
		fact[i]%=MOD;
	}
}

void s(){
	ll n,a,b;
	cin >> n >> a >> b;
	ll ans = binpow(2LL,n,MOD);
	ll sub1 = 1;
	calc();
	//cout << ans << endl;
	for(ll i = 0;i < a;i++){
		sub1 *= (n - i);
		sub1%=MOD;
	}
	ll sub2 = 1;
	for(ll i = 0;i < b;i++){
		sub2 *= (n - i);
		sub2%=MOD;
	}
	sub1 *= modInverse(fact[a],MOD);
	sub2 *= modInverse(fact[b],MOD);
	
	ans -= sub1;
	ans = mod(ans,MOD);
	ans -= sub2;
	ans = mod(ans,MOD);
	cout << ans  - 1<< endl;
}



int main(){
	//freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t = 0;
    if(t == 1) cin >> t;
    else t = 1;
    while(t--) s(); 
    return 0;
} 
