#include <map>
#include <set>
#include <list>
#include <cmath>
#include <deque>
#include <stack>
#include <queue>
#include <list>
#include <array>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <random>
#include <chrono>
#include <utility>
#include <numeric>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <sstream>
#include <assert.h>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <functional>
#include <unordered_map>

using namespace std;
struct _ { ios_base::Init i; _() { ios_base::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL); } } _;

const long long maxa = 1e6 + 1;
vector<long long> spf(maxa + 1, 0);
vector<bool> can(maxa + 1, true);

int main() {

	iota(spf.begin(), spf.end(), 0);

	for (long long i = 2; i * i <= maxa; i++) {
		if (spf[i] == i) {
			for (long long j = i * i; j <= maxa; j += i) if (spf[j] == j) spf[j] = i;
		}
	}

	long long n; cin >> n;
	long long gd = 0;
	vector<long long> a(n); for (long long i = 0; i <= n - 1; i++) cin >> a[i], gd = gcd(gd, a[i]);

	bool is_setwise = (gd == 1);
	bool is_pairwise = true;


	for (long long i = 0; i <= n - 1; i++) {
		long long x = a[i];
		set<int> s;

		while (x != 1) {
			s.insert(spf[x]);
			x /= spf[x];
		}

		for (auto pfac : s) {
			if (can[pfac] == false) {
				is_pairwise = false;
				break;
			}
			can[pfac] = false;
		}


		if (!is_pairwise) break;
	}

	if (is_pairwise) cout << "pairwise coprime";
	else if (is_setwise) cout << "setwise coprime";
	else cout << "not coprime";


	return 0;
}