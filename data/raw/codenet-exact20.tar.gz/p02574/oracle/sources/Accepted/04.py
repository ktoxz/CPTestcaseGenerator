import sys
import math


N_MAX = 200000 + 5
INF = 10**9 + 7
sys.setrecursionlimit(N_MAX)
MOD = 10**9 + 7


def main():
    N = int(sys.stdin.readline().rstrip())
    A = [int(x) for x in sys.stdin.readline().rstrip().split()]

    maxA = max(A)

    # 1 <= a <= maxA までの、要素の登場回数
    C = [0] * (maxA + 1)
    for a in A:
        C[a] += 1

    pc = True

    # p の倍数である個数をカウントする
    for p in range(2, maxA + 1):
        cnt = 0
        for k in range(maxA // p + 1):
            cnt += C[k * p]

        # k*p となるような要素が2個以上あったら、pairwise coprime ではない
        if cnt > 1:
            pc = False

    if pc:
        print("pairwise coprime")
        return

    GCD = A[0]
    for i in range(1, N):
        GCD = math.gcd(GCD, A[i])

    if GCD == 1:
        print("setwise coprime")
        return

    print("not coprime")


main()
