#include <bits/stdc++.h>
using namespace std;

vector<int> D(1000001, -1);

void P() {
  D.at(0) = D.at(1) = 0;
  for (int i = 2; i <= 1000000; i++) {
    if (D.at(i) != -1) continue;
    for (int j = 2; i * j <= 1000000; j++) {
      if (D.at(i * j) == -1) D.at(i * j) = i;
    }
  }
  return;
}

int main() {
  P();
  int N;
  cin >> N;
  vector<int> A(N);
  for (int i = 0; i < N; i++) cin >> A.at(i);
  int G = A.at(0);
  for (int i = 0; i < N; i++) G = __gcd(G, A.at(i));
  string ans = "pairwise coprime";
  set<int> S;
  for (int i = 0; i < N; i++) {
    if (A.at(i) == 1) continue;
    while (D.at(A.at(i)) > 0) {
      if (S.count(D.at(A.at(i)))) {
        ans = "setwise coprime";
        break;
      }
      else {
        int x = D.at(A.at(i));
        S.insert(x);
        while (A.at(i) % x == 0) A.at(i) /= x;
      }
    }
    if (A.at(i) != 1) {
      if (S.count(A.at(i))) {
        ans = "setwise coprime";
        break;
      }
      else S.insert(A.at(i));
    }
  }
  if (G != 1) ans = "not coprime";
  cout << ans << endl;
}