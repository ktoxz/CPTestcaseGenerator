import math
N=int(input())
m=10**6+1
M=[0]*m
g=0
for i in map(int,input().split()):M[i]+=1;g=math.gcd(g,i)
if g>1:print('not coprime')
elif all(sum(M[i::i])<=1 for i in range(2,m)):print('pairwise coprime')
else:print('setwise coprime')
