#include <stdio.h>
#define N 1000001
 
int spf[N], u[N], s[17], d, i, k;
char* r = "pairwise";
 
int gcd(int a, int b) { return b ? gcd(b, a % b) : a; }
 
main(j) {
    while (++i < N)spf[i] = i;
    for (i = 2; i * i < N; i++) {
        for (j = i * i; j < N; j += i) {
            if (spf[j] == j)
                spf[j] = i;
        }
    }
    for (scanf("%*d"); ~scanf("%d", &j); k = 0) {
        d = gcd(d, j);
        for (; j > 1; j /= i) {
            s[k++] = i = spf[j];
            if (u[i]) r = "setwise";
        }
        while(k--)u[s[k]] = 1;
    }
    printf("%s coprime\n", d > 1 ? "not" : r);
    return 0;
}
