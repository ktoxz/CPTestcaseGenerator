#include<stdio.h>
#include<math.h>
int c[1000001];
void merge(int i,int j,int *s){
  if(i!=j){
    merge(i,(i+j)/2,s);
    merge((i+j)/2+1,j,s);
    int a=i,b=(i+j)/2+1;
    int d;
    for(d=i;d<=j;d++){
      if((i+j)/2<a){
        c[d]=s[b];
        b++;
      }
      else if(j<b){
        c[d]=s[a];
        a++;
      }
      else if(s[a]>s[b]){
        c[d]=s[a];
        a++;
      }
      else{
        c[d]=s[b];
        b++;
      }
    }
    for(d=i;d<=j;d++)
      s[d]=c[d];
  }
}

void primeFactorization(int a,int *count){ //素数を配列に格納
  int i,sq;
  sq = sqrt(a);
  if(a%2==0)
    count[2]++;
  while(a%2==0)
    a/=2;
  for(i=3;i<=sq;i+=2){ //3以上√a以下の奇数の場合
    if(a%i==0){
      count[i]++;
      while(a%i==0)
        a/=i;
    }
  }
  count[a]++;
}

int main(){
  int n,i;
  scanf("%d",&n);
  int sum[1000001];
  for(i=0;i<1000001;i++)
    sum[i]=0;
  int a[n+1];
  for(i=0;i<n;i++){
    scanf("%d",&a[i]);
    primeFactorization(a[i],sum);
  }
  merge(0,1000000,sum);
  if(sum[0]==1)
    puts("pairwise coprime");
  else if(sum[0]!=n)
    puts("setwise coprime");
  else
    puts("not coprime");
  return 0;
}
