from math import gcd
(_,),a  = [list(map(int, s.split())) for s in open(0)]

ans = 'pairwise coprime'

l = g = a.pop()
for x in a:
    g, l = gcd(g, x), l * x
    if g != 1:
        ans = 'setwise coprime'
        l //= g
    print(l,g)
if g != 1:
    ans = 'not coprime'
print(ans)