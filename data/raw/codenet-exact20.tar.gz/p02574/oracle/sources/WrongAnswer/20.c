// SPDX-License-Identifier: X11
// 2020-08-30
// Coprime (500pt)

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX 1000005

#define u32 uint_fast32_t

struct ll {
  u32 a;
  struct ll *next;
};

bool *erato(u32 bound);
u32 foldgcd(struct ll *node, u32 base);
struct ll *prepend(u32 a, struct ll *head);
void freelist(struct ll *head);

int main() {
  u32 N;
  scanf("%lu\n", &N);

  bool *ps = erato(MAX);
  bool *pa = calloc(MAX, sizeof(bool));

  bool set = 0;
  bool p = 1;

  uint_fast8_t s;
  u32 A, i, j;
  scanf("%lu", &A);

  struct ll *list = (struct ll *) malloc(sizeof(struct ll));
  list->a = A;
  list->next = NULL;

  if (!(A & 1))
    pa[2] = 1;
  if (!(A % 3))
    pa[3] = 1;
  for (i = 5, s = 2; i < N; i += s, s = 6 - s)
    if (ps[i] && !(A % i))
      pa[i] = 1;

  for (i = 1; i < N; ++i) {
    scanf("%lu", &A);
    list = prepend(A, list);

    if (ps[A]) {
      set = 1;
      continue;
    }

    if (!(A & 1)) {
      if (pa[2]) {
        p = 0;
      }
      else {
        pa[2] = 1;
      }
    }

    if (!(A % 3)) {
      if (pa[3]) {
        p = 0;
      }
      else {
        pa[3] = 1;
      }
    }

    for (j = 5, s = 2; j < A; j += s, s = 6 - s) {
      if (!(A % j)) {
        if (pa[j]) {
          p = 0;
        }
        else {
          pa[j] = 1;
        }
      }
    }
  }

  if (p)
    printf("pairwise coprime\n");
  else if (set || foldgcd(list->next, list->a) == 1)
    printf("setwise coprime\n");
  else
    printf("not coprime\n");

  freelist(list);
  free(ps);
  free(pa);
}

u32 gcd(u32 a, u32 b) {
  return b == 0 ? a : gcd(b, a % b);
}

bool *erato(u32 bound) {
  if (!bound)
    return NULL;

  bool *array = calloc(bound, sizeof(bool));
  u32 i,j;
  uint_fast8_t s,ss;

  if (bound < 3)
    return array;
  array[2] = 1;

  if (bound < 4)
    return array;
  array[3] = 1;

  if (bound < 5)
    return array;

  for (i = 5, s = 2; i < bound; i += s, s = 6 - s)
    array[i] = 1;

  for (i = 5, s = 2; i < bound; i += s, s = 6 - s)
    if (array[i])
      for (j = i, ss = s; i * j < bound; j += ss, ss = 6 - ss)
        array[i * j] = 0;

  return array;
}

struct ll *prepend(u32 a, struct ll *head) {
  struct ll *new = (struct ll *) malloc(sizeof(struct ll));
  new->a = a;
  new->next = head;
  return new;
}

void freelist(struct ll* head) {
  struct ll* tmp;
  while (head != NULL) {
    tmp = head;
    head = head->next;
    free(tmp);
  }
}

u32 foldgcd(struct ll *node, u32 base) {
  u32 x = gcd(base, node->a);
  if (x == 1 || node->next == NULL)
    return x;
  else
    return foldgcd(node->next, x);
}
