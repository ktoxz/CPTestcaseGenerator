m=1
c=[0]*6**8
n,a=open(0)
for a in a.split():c[int(a)]+=1
print(('not','psaeitr'[any((m:=max(m,sum(c[i::i])))>1for i in range(2,6**8))::2]+'wise')[m<int(n)],'coprime')