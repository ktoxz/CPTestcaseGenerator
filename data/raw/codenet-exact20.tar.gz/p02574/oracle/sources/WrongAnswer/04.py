def main():
    n = int(input())
    a = sorted(list(map(int,input().split())))
    p = [i for i in range(2,int(a[-1]**0.5)+1)]
    flg = 0
    for i in range(n-1):
        if a[i]==a[i+1]:
            flg = 1
    for i in range(len(p)-1):
        if p[i]==0:
            continue
        for j in range(i+1,len(p)):
            if p[j]%p[i] == 0:
                p[j]=0
    prm = []
    for p_ in p:
        if p_ != 0:
            prm.append(p_)
    for p in prm:
        cnt = 0
        for a_ in a:
            if a_%p==0:
                cnt += 1
        if cnt == n:
            print('not coprime')
            return
        if cnt > 1:
            print('setwise coprime')
            return
    if flg!=1:
        print('pairwise coprime')
    else:
        print('setwise coprime')

if __name__ == "__main__":
    main()
