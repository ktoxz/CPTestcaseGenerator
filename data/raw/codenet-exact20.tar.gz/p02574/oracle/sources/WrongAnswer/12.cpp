#include<bits/stdc++.h>
using namespace std;
const int N=2e6+10;
int a[N];
int main(){
	int n,f=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(__gcd(a[i],a[j])!=1)
				f=1;
	if(f) cout<<"setwise coprime";
	else cout<<"pairwise coprime";
	return 0;
}