#include <stdio.h>

long gcd(long a,long b){
  long r,tmp;
  if(a>b){
    tmp=a;
    a=b;
    b=tmp;
  }
  if(a==0) return b;
  r=b%a;
  while(r!=0)
    b=a;
  a=r;
  r=b%a;
}



int main(void){
  long n,a[1000005],count[1000005]={0},max=0,count1=0,k=0,gcd1=0;
    scanf("%ld",&n);
    for(int i=0;i<n;i++){
      scanf("%ld",&a[i]);
      count[a[i]]++;
      if(max<a[i]) max=a[i];
    }
    for(int i=2;i<=max;i++){
      k++;
      for(int j=2;j<max;j+=i){
        count1+=count[j];
      }
      if(count1>1) break;
       count1=0;
    }
    if(k==max-1){
      printf("pairwise coprime");
      return 0;
    }

    for(int i=0;i<n;i++){
      gcd1=gcd(gcd1,a[i]);
    }
    if(gcd1==1) printf("setwise coprime");
    else printf("not coprime");




    return 0;
  }