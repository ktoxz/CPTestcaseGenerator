from random import randint
N = randint(0,2)
if N==0:
  print("pairwise coprime")
elif N==1:
  print("setwise coprime")
else:
  print("not coprime")