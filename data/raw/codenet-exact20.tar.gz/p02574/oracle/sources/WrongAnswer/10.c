#include<stdio.h>
int main(){
  	int N;
    scanf("%d",&N);
    int G,C,D;
  	scanf("%d %d %d",&G,&C,&D);
  	printf("%d%d%d%d",N,G,C,D);
  
	return 0;
}