import sys
import math
def Ii():return int(sys.stdin.readline().rstrip())
def Mi():return map(int,sys.stdin.readline().split())
def Li():return list(map(int,sys.stdin.readline().split()))
n = Ii()
a = Li()
sc = 0
pc = 1
b = a[0]
for i in range(n-1):
  b %= a[i+1]
  if(b == 0): b += a[i+1]
  g = math.gcd(b,a[i+1])
  b *= a[i+1]
  if(g != 1):
    pc = 0

g = math.gcd(a[0],a[1])
if(sc == 0):
  for i in range(n-2):
    g = math.gcd(g,a[i+2])
    if(g == 1):
      sc = 1

if(pc):
  ans = 'pairwise coprime'
elif(sc):
  ans = 'setwise coprime'
else:
  ans = 'not coprime'
  
print(ans)