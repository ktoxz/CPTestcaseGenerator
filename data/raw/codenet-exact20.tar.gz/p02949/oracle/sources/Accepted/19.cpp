#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define INF 1LL<<62
#define inf 1000000007
ll s[5000],e[5000],c[5000],v[2500],v1[2500];	ll n,m,p;
ll ans[2500];
ll ans2[2500];

int main() {
	cin>>n>>m>>p;
	for(ll i=0;i<m;i++){
		cin>>s[i]>>e[i]>>c[i];
		s[i]--;e[i]--;
		c[i]*=-1;
		c[i]+=p;
	}
	for(ll i=0;i<2500;i++){
		v[i]=INF;
		ans[i]=INF;
		ans2[i]=INF;
	}
	v[0]=0;
	ans[0]=0;
	ans2[n-1]=0;
	for(ll i=0;i<n+100;i++){
		for(ll j=0;j<m;j++){
		ll now=s[j];
		ll next=e[j];
		v[next]=min(v[next],v[now]+c[j]);
		ans[next]=min(ans[next],ans[now]);
		ans2[now]=min(ans2[now],ans2[next]);
		}
	}
	for(ll i=0;i<n;i++){
		v1[i]=v[i];
	}
	for(ll i=0;i<1;i++){
		for(ll j=0;j<m;j++){
		ll now=s[j];
		ll next=e[j];
		v[next]=min(v[next],v[now]+c[j]);
		}
	}
	for(ll i=0;i<n;i++){
		if(v[i]<v1[i]&&ans[i]==0&&ans2[i]==0){
			cout << -1;
			return 0;
		}
	}
	if(v[n-1]>0){
		cout << 0;
	}
	else{
	cout << abs(v[n-1]);
	}
	// your code goes here
	return 0;
}