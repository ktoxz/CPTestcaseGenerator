#include <bits/stdc++.h>
using namespace std;
using LL = long long;
using PII = pair<int, int>;
#define FI(i, a, b) for (int i = (a); i <= (b); ++i)
#define FD(i, b, a) for (int i = (b); i >= (a); --i)
#define DEBUG(x) cerr << #x << ": " << (x) << endl;

const int N = 5005;
int n, m, p, vis[N];
const LL INF = 1LL << 40;
vector<PII> g[N];

void dfs(int u) {
  vis[u] = 1;
  for (auto pr: g[u]) {
    int v = pr.first;
    if (vis[v]) continue;
    dfs(v);
  }
}

LL spfa(int src, int tag) {
  vector<LL> dis(n + 1, -INF), inq(n + 1, 0), cnt(n + 1, 0);
  queue<int> qu;
  qu.push(src), inq[src] = 1, dis[src] = 0;
  while (!qu.empty()) {
    int u = qu.front();
    qu.pop(), inq[u] = 0, cnt[u]++;
    if (cnt[u] >= n) {
      dis[u] = INT_MAX;
      continue;
    }
    for (auto &pr: g[u]) {
      int v, w;
      tie(v, w) = pr;
      if (dis[v] < dis[u] + w) {
        dis[v] = dis[u] + w;
        if (!inq[v]) inq[v] = 1, qu.push(v);
      }
    }
  }
  for (int i = 1; i <= n; i++) {
    if (!vis[i] && dis[i] >= INT_MAX) dfs(i);
  }
  // for (int i = 1; i <= n; i++) printf("%lld ", dis[i]);
  // puts("");
  return dis[tag];
}

int main() {
  cin >> n >> m >> p;
  FI(i,1,m) {
    int u, v, w;
    scanf("%d%d%d", &u, &v, &w);
    g[u].emplace_back(v, w - p);
  }
  LL dis = spfa(1, n);
  if (dis >= INF || vis[n]) return puts("-1"), 0;
  cout << max(dis, 0LL) << endl;
}
