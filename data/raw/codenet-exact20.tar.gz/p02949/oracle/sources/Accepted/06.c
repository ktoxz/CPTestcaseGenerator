#include <stdio.h>

const long long sup = (long long)1 << 60;

typedef struct {
	int t, h, cost;
} edge;

int main()
{
	int i, u, w, c, N, M, P;
	edge e[5001];
	scanf("%d %d %d", &N, &M, &P);
	for (i = 0; i < M; i++) {
		scanf("%d %d %d", &u, &w, &c);
		e[i].t = u;
		e[i].h = w;
		e[i].cost = P - c;
	}	

	int k, flag[2501] = {};
	long long min[2501];
	for (i = 2, min[1] = 0; i <= N; i++) min[i] = sup;
	for (k = 1, flag[N] = 1; k < N; k++) {
		for (i = 0; i < M; i++) {
			u = e[i].t;
			w = e[i].h;
			c = e[i].cost;
			if (min[u] < sup && min[w] > min[u] + c) min[w] = min[u] + c;
			if (flag[w] == 1) flag[u] = 1;
		}
	}
	for (i = 0; i < M; i++) {
		u = e[i].t;
		w = e[i].h;
		c = e[i].cost;
		if (min[u] < sup && min[w] > min[u] + c && flag[w] == 1) break;
	}
	
	if (i == M) printf("%lld\n", (min[N] < 0)? -min[N]: 0);
	else printf("-1\n");
	fflush(stdout);
	return 0;
}