#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
template<class T> inline bool chmax(T& a, T b) { if (a < b) { a = b; return true; } return false; }
template<class T> inline bool chmin(T& a, T b) { if (a > b) { a = b; return true; } return false; }
 
/* attention
    long longのシフト演算には気をつけよう
    タイポした時のデバッグが死ぬほどきつくなるので変数名は最低3字くらい使った方がいいかも
    sizeは(int)とキャストしよう
    ごちゃごちゃ場合分けを考える前に全探索は考えましたか？
*/

const ll mod = 1e9+7;

// void chmod(ll &M){
//     if(M >= mod) M %= mod;
//     else if(M < 0){
//         M += (abs(M)/mod + 1)*mod;
//         M %= mod;
//     }
// }

const ll inf = 1LL<<60;
const int MAX_V = 5050;
const int MAX_E = 5050;

struct Edge{ll from, to, cost; };

int V; // 頂点の数
int E; // 辺の数
vector<ll> d(MAX_V, inf); // 距離
vector<bool> negative(MAX_E, false); // 負の閉路検出
vector<Edge> edge;

void Bellman_Ford(){
    d[0] = 0; // 始点の初期化
    for(int loop=0; loop<V-1; ++loop){
        for(int i=0; i<E; ++i){
            if(d[edge[i].from] == inf) continue;

            if(d[edge[i].to] > d[edge[i].from]+edge[i].cost){
                d[edge[i].to] = d[edge[i].from]+edge[i].cost;
            }
        }
    }

    for(int loop=0; loop<2*V; ++loop){
        for(int i=0; i<E; ++i){
            if(d[edge[i].from] == inf) continue;

            if(d[edge[i].to] > d[edge[i].from]+edge[i].cost){
                d[edge[i].to] = d[edge[i].from]+edge[i].cost;
                negative[edge[i].to] = true;
            }

            if(negative[edge[i].from]) negative[edge[i].to] = true;
            
        }
    }
}

int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);

    int p; cin >> V >> E >> p;
    for(int i=0; i<E; ++i){
        int a, b, c; cin >> a >> b >> c;
        --a; --b; c = p-c;
        edge.push_back({a, b, c});
    }

    Bellman_Ford();

    if(negative[V-1] || d[V-1] == inf) cout << -1 << endl;
    else cout << max(0LL, -d[V-1]) << endl;

	return 0;
}
