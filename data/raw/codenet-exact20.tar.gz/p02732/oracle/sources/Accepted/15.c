#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>

#define P 1000000007

int comp(const void *a, const void *b){return *(int*)a-*(int*)b;}
int compw(const void *a, const void *b){return (*(int*)a>*(int*)b)-(*(int*)a<*(int*)b);}
int compr(const void *a, const void *b){return *(int*)b-*(int*)a;}

uint32_t nextpint(void){ char c=getchar(); while(c<'0'||'9'<c) c=getchar(); uint_fast32_t x=0; while('0'<=c && c<='9'){ x=x*10+c-'0'; c=getchar(); } return x; }

inline int min2(const int a, const int b){return a>b?b:a;}
inline int dif2(const int a, const int b){return a>b?a-b:b-a;}

int n;
int a[200000], b[200000];

int bs(int k){
	int l=0, r=n-1;
	while(l<=r){
		int m=(l+r)/2;
		if(b[m]>=k) r=m-1; else l=m+1;
	}
	return l;
}

int main(void){
	n=nextpint();
	for(int i=0; i<n; i++){
		a[i]=b[i]=nextpint();
	}
	qsort(b, n, 4, comp);
	long ans=0;
	for(int i=0; i<n; i++){
		int l=bs(b[i]);
		int r=bs(b[i]+1);
		int x=r-l-1;
		ans+=x;
	}
	ans>>=1;
	for(int i=0; i<n; i++){
		int l=bs(a[i]);
		int r=bs(a[i]+1);
		int x=r-l-1;
		printf("%ld\n", ans-x);
	}
}
