#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    long int table[200001]={0}, i, n, a[200001], ans=0;

    scanf("%ld",&n);
    for(i=1;i<=n;i++){
        scanf("%ld",&a[i]);
        table[a[i]]++;
    }

    for(i=1;i<=n;i++){
        if(table[i] != 0){
            ans += table[i]*(table[i]-1)/2;
        }
    }

    for(i=1;i<=n;i++){

        if(table[a[i]]==1){
            printf("%ld\n",ans);
        }else if(table[a[i]]==2){
            printf("%ld\n",ans-1);
        }else{
            printf("%ld\n",ans-(table[a[i]]-1));
        }
    }

    return 0;
}
