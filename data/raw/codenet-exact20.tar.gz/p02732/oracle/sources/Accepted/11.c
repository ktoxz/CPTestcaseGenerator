#include<stdio.h>

int a[200010];
int c[200010];
int main(){
	int n;
	scanf("%d",&n);
	long long ans=0;
	for(int i=0;i<n;i++){
		scanf("%d",a+i);
		ans+=c[a[i]]++;
	}
	for(int i=0;i<n;i++)printf("%lld\n",ans-c[a[i]]+1);
}