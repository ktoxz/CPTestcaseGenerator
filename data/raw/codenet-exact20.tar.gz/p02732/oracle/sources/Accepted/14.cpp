#include <cstdio>
#include <unordered_map>
#include <vector>

#define rep(i, n) for (size_t i = 0; i < (size_t)n; ++i)

using namespace std;

int64_t comb(int64_t n) { return (n > 1) ? (n * (n - 1)) / 2 : 0; }

int main() {
  int n;
  scanf("%d", &n);

  auto avec = vector<int>(n);
  for (auto &x : avec) {
    scanf("%d", &x);
  }

  auto arr = vector<int>(n + 1, 0);
  for (const auto &x : avec) {
    arr[x]++;
  }

  int64_t sum = 0;
  for (const auto &x : arr) {
    sum += comb(x);
  }

  auto memo = unordered_map<int, int64_t>();

  for (const auto &x : avec) {
    if (memo.find(x) == memo.end()) {
      auto n = arr[x];
      auto result = sum - (n - 1);
      memo[x] = result;
    }

    printf("%ld\n", memo[x]);
  }

  return 0;
}
