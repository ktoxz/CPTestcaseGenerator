// Winners don't quit and Quitters don't win
#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define pb push_back
#define pii pair<int,int>
#define pll pair<ll,ll>
#define vii vector<int>
#define vll vector<ll>
#define mod 998244353
#define MAX 100005
//ll ans[2*MAX];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll n,i,j,x,v1,v2,s=0;
    cin>>n;
    vll v;
    map <ll,ll> m;
    set <ll> res;
    set <ll>::iterator it;
   // map <ll,ll>::iterator it;
    for(i=0;i<n;++i){
    	cin>>x;
    	v.pb(x);
    	m[x]++;
    	res.insert(x);
	}
	for(it=res.begin();it!=res.end();++it){
		v1=m[*it];
		s+=v1*(v1-1)/2;
	}
	for(i=0;i<n;++i){
		v1=m[v[i]];
		cout<<(s-(v1-1))<<'\n';
	}
}