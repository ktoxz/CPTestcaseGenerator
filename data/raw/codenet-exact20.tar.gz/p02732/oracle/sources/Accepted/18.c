// ABC 159-D
// 2020.3.24 bal4u

#include <stdio.h>

typedef long long ll;

#define gc() getchar_unlocked()
#define pc(c) putchar_unlocked(c)

int in() {   // 非負整数の入力
	int n = 0; int c;
	c = gc();
	do n = 10 * n + (c & 0xf); while ((c = gc()) >= '0');
	return n;
	//(c & 0xf)：字符0-9 Ascii码0x30-0x39 与0xf（即00001111）按位与运算 只保留个位数（0x0-0x9）
}

void out(ll n) { // 非負整数の表示（出力）
	int i; char b[30];

	if (!n) pc('0');
	else {
		//		if (n < 0) pc('-'), n = -n;
		i = 0; while (n) b[i++] = n % 10 + '0', n /= 10;
		while (i--) pc(b[i]);
	}
	pc('\n');
}

int f[200005];
int A[200005];

int main()
{
	int i, N, a, ma;
	ll s;

	N = in();
	ma = 0;
	for (i = 0; i < N; ++i) {
		A[i] = a = in(), f[a]++;
		if (a > ma) ma = a;
	}
	s = 0; for (i = 1; i <= ma; ++i) s += (ll)f[i] * (f[i] - 1) >> 1;// >> 1:右移运算符 将其二进制右移1位 即/2
	for (i = 0; i < N; ++i) out(s - (f[A[i]]-1));
	return 0;
}