def ban():
    n = int(input())
    a = list(map(int, input().split()))
    d = {}
    total = 0

    for i in a:
        if i not in d:
            d[i] = 1
        else:
            total += d[i]
            d[i] += 1

    ans = [total - (d[i] - 1) for i in a]
    return "\n".join(map(str, ans))

print(ban())