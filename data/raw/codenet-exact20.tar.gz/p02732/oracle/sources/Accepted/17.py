from collections import Counter
from scipy.misc import comb
import numpy as np
N = int(input())
A = list(map(int, input().split()))

total = 0
answers = np.array([0] * (N + 1))
for number, appearance in Counter(A).items():
    flat = comb(appearance, 2, exact=True)
    minus_one = comb(appearance - 1, 2, exact=True)
    total += flat
    answers[number] = minus_one - flat
answers += total

print(*answers[A], sep="\n")
