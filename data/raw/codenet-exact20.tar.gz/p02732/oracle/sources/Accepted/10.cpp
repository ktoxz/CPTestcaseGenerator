#include <bits/stdc++.h>

using namespace std;

int main() {
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i=0; i<n; i++) cin >> a.at(i);
  
  vector<long long> cnt(n+1);
  for (int i=0; i<n; i++) {
    cnt.at(a.at(i))++;
  }
  
  long long res = 0;
  for (int i=1; i<n+1; i++) res += cnt.at(i) * (cnt.at(i) - 1) / 2;
  
  for (int i=0; i<n; i++) {
    cout << res - cnt.at(a.at(i)) + 1 << endl;
  }
  
  return 0;
}
