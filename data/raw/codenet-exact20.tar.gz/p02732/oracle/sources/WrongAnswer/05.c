#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    float b,res,a;
    b=((float)n*100.0)/100.0;
    a=b/3.0;
    res=a*a*a;
    printf("%.12f\n",res);
}
