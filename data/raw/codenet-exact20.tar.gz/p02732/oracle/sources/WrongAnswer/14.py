from collections import defaultdict
n, *D  = [list(map(int, s.split())) for s in open(0)]
D = D[0]
dic = defaultdict(int)
for d1 in D:
    dic[d1] += 1

total_comb = 0
for k in dic:
    if dic[k] >= 2:
        total_comb += dic[k] * (dic[k] - 1) / 2

for d2 in D:
    comb = 0
    if dic[d2] >= 2:
        print(int(total_comb - dic[d2] + 1))
    else:
        print(total_comb)