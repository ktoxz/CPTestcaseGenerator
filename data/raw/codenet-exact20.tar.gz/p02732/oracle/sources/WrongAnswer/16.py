N = int(input().strip())
A = [int(v) for v in input().strip().split()]
C = {}
S = {}

for a in A:
    C.setdefault(a, 0)
    C[a] += 1

for c in C.values():
    if c < 1:
        continue
    S.setdefault(c, c * (c - 1) // 2)
    if c < 2:
        continue
    S.setdefault(c - 1, c - 1 * (c - 2) // 2)

for i, a in enumerate(A):
    C[a] -= 1
    sum_ = sum([S[n] for n in C.values() if n > 1])
    C[a] += 1
    print(sum_)