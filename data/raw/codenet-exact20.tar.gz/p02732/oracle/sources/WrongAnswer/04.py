n = int(input())
ball = list(map(int,input().split()))

num = [0] * (n + 1)
for i in range(n):
    num[ball[i]] += 1

data = [0] * (n + 1)
sentaku = [0] * (n + 1)

for i in range(n):
    if num[i] <= 1:
        continue
    else:
        data[i] = num[i] * (num[i] - 1) // 2
        sentaku[i] = (num[i] - 1) * (num[i] - 2) // 2
x = sum(data)

for i in range(n):
    print(x - data[ball[i]] + sentaku[ball[i]])
