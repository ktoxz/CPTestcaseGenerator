#include<stdio.h>
#include<string.h>
void quicksort(int a[][3], int l, int h)
{
    int mid=a[(l+h)/2][0];
    int i=l,j=h;
    int t;
    while(i<=j)
    {
    	while(a[i][0]<mid&&i<h) i++;
        while(a[j][0]>mid&&j>0) j--;
        if(i<=j)
        {
            t=a[i][0];
			a[i][0]=a[j][0];
			a[j][0]=t;
			t=a[i][1];
			a[i][1]=a[j][1];
			a[j][1]=t;
            i++;
            j--;
        }
	}
    if(l<j) quicksort(a,l,j);
    if(i<h) quicksort(a,i,h);
}
void quicksort1(int a[][3], int l, int h)
{
    int mid=a[(l+h)/2][1];
    int i=l,j=h;
    int t;
    while(i<=j)
    {
    	while(a[i][1]<mid&&i<h) i++;
        while(a[j][1]>mid&&j>0) j--;
        if(i<=j)
        {
            t=a[i][2];
			a[i][2]=a[j][2];
			a[j][2]=t;
			t=a[i][1];
			a[i][1]=a[j][1];
			a[j][1]=t;
            i++;
            j--;
        }
	}
    if(l<j) quicksort1(a,l,j);
    if(i<h) quicksort1(a,i,h);
}
int main()
{
	int n,i,a[200000][3]={0},j=1,k=0;
	long long s=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i][0]);
		a[i][1]=i;
	}
	quicksort(a,0,n-1);
	for(i=n-2;i>=0;i--)
	{
		if(a[i][0]==a[i+1][0])
		j++;
		else
		{
			s+=j*(j-1)/2;
			for(k=i+1;k<i+1+j;k++)
			a[k][2]=j;
			j=1;
		}
	}
	if(a[0][0]==a[1][0])
	{
		s+=j*(j-1)/2;
		for(k=0;k<j;k++)
		a[k][2]=j;
	}
	else
	a[0][2]=1;
	quicksort1(a,0,n-1);
	for(i=0;i<n;i++)
	{
		printf("%lld\n",s-a[i][2]+1);
	}
	return 0;
}