a=int(input())
b=input().split()
for i in b:
    if b.count(i)<=2:
        print(b.count(i))
    else:
        print('0')
        