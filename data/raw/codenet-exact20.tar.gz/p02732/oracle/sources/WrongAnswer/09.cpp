#define _USE_MATH_DEFINES
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<algorithm>
#include<climits>
#include<numeric>
#include<cmath>
#include<cstring>
#include<deque>
#include<map>
#include<iomanip>

#define REP(i, n) for(int i = 0;i < n;i++)
#define REPR(i, n) for(int i = n;i >= 0;i--)
#define FOR(i, m, n) for(int i = m;i < n;i++)
#define FORR(i, m, n) for(int i = m;i >= n;i--)
#define VSORT(v) sort(v.begin(), v.end());
#define VE vector<int>
#define VEP vector<pair<int,int>>
#define llong long long
#define pb(a) push_back(a)
using namespace std;
const vector<VE> DIR{ {-1,0},{1,0},{0,-1},{0,1} };
const llong MOD = 1000000007;
long long GCD(long long a, long long b) {
	if (b == 0) return a;
	else return GCD(b, a % b);
}
int main() {
	int n;
	cin >> n;
	map<int, int> mp;
	VE vec(n);
	//int old_num = mp.size();
	REP(i, n) {
		cin >>vec[i];
		mp[vec[i]]++;
	}
	REP(i, n) {
		llong ans = 0;
		for (auto m:mp) {
			if (m.first == vec[i]) {
				if (m.second > 2) {
					ans += ((m.second -1) * (m.second - 2)) / 2;
				}
			}
			else {
				if (m.second > 1) {
					ans += (m.second  * (m.second - 1)) / 2;
				}
			}
			
		}
		cout << ans << endl;
	}
	return 0;
}
