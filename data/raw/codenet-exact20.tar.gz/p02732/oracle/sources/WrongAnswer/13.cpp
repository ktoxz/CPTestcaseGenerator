#include <bits/stdc++.h>
#include <iomanip>
using namespace std;

#define rep(i, n) REP(i, 0, n)
#define REP(i, x, n) for (int i = x; i < n; i++)
#define REP2(i, x, n) for (int i = x; i <= n; i++)
#define OP(x) cout << x << endl;
typedef long long ll;

int main() {
    double l; cin >> l;

    double ans = 0;
    for(double i = 0.1; i < l; i += 0.1){
        for(double j = 0.1; j <= l - i; j += 0.1){
            double k = l - i - j;
            double tmp = i * j * k;
            ans = max(ans, tmp);
        }
    }
    cout << setprecision(12) << ans << endl;
}
