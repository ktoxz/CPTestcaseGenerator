#include <stdio.h>

int main()
{
    int n, a[200001], cnt[200001], result[200001], i, j;

    scanf( "%d", &n );
    for( i = 1; i <= n; i++ )
    {
        scanf( "%d ", &a[i]);
    }
    
    //重複があるかチェック
    for( i = 1; i <= n; i++ )
    {
        for( j = i+1; j <=n ; j++ )
        {
            cnt[i] = 0;
            if( i < j )
            {
                if( a[i] == a[j] ) 
                {
                    cnt[i]++;
                }
            }
            else 
                continue;
        }
    }
    //選び出す方法の数 nC2論法
    for(i = 1; i <= 2; i++) 
        {
            if( cnt[i] != 0 )
            {
                result[i] = 0;
                result[i] = result[i] * (cnt[i] - i + 1) / i;
            }
            else
                continue;
        }
    
    //output
    for(i = 1; i <= n; i++) 
        {
            if( result[i] != 0 )
            {
                printf( "%d\n", result[i] );
            }
        }
    

    return 0;
}