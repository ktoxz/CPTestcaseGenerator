
def Get_nC2(n):
    return int(n*(n-1) / 2);


N = int(input())
A_i = list(map(int, input().split()))

cnt_dict = {}
for a_i in A_i:
    cnt = 0
    if a_i in cnt_dict:
        print(cnt_dict[a_i])
        continue
    else:
        for j in range(min(A_i), max(A_i)+1):
            j_cnt = A_i.count(j)
            if a_i == j:
                j_cnt -= 1

        cnt += Get_nC2(j_cnt)

        cnt_dict[a_i] = cnt

        print(cnt)
