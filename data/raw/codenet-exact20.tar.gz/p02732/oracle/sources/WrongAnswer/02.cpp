#include<bits/stdc++.h>
#define INF 9223372036854775807LL
#define mod 1000000007
#define SYOU(x) setprecision(x+1)
#define abs(x,y) (max(x,y)-min(x,y))
#define lol long long
#define mp make_pair
#define fi first
#define se second
using namespace std;
int gou[300000]={};
signed main(){
  cin.tie(0);
  ios::sync_with_stdio(false);
  lol n,m,a,b,c,d;
  vector<int> k;
  lol sum=0;
  cin >>n;
  for(int i=0;i<n;i++){
    int r;
    cin >>r;
    k.emplace_back(r);
    gou[r]++;
  }
  for(int i=1;i<=n;i++){
    sum+=gou[i]*(gou[i]-1)/2;
  }
  for(int i=0;i<n;i++){
    lol u=gou[k[i]];
    lol q=u*(u-1)/2;
    u--;
    lol p=u*(u-1)/2;
    cout <<sum-q+p<<'\n';
  }
  return (0);
}
