#include<stdio.h>

#define MAXN 102

long long pow9(long long K)
{
    long long ans = 1;
    for(;K > 0; K--)
      ans *= 9;
    return ans;
}
long long nck(long long N, long long K)
{
    if(K > N)
      return 0;
    if(K == 0)
      return 1;
    if(K == 1)
      return N;
    if(K == 2)
      return ((N * (N - 1)) / 2);
    if(K == 3)
      return ((N * (N - 1) * (N - 2)) / 6);
    return 0;
}

long long compute(long long *a, long long N, long long K)
{
    if(K == 0)
      return 1;
    if(N == 0)
      return 0;
    if(K > N)
      return 0;
    long long ans = 0;
    ans += nck(N - 1, K) * pow9(K);
    // printf("N = %lld, K = %lld, ans when 0 = %lld\n", N, K, ans);
    ans = a[0] ? ans + (a[0] - 1) * nck(N - 1, K - 1) * pow9(K - 1) + compute(a + 1, N - 1, K - 1) : ans;
    // printf("N = %lld, ans = %lld\n", N, ans);
    return ans;
}

int main()
{
    long long  K, N, i, a[MAXN];
    char str[MAXN];
    scanf("%s", str);
    scanf("%lld", &K);
    for(i = 0; str[i]; i++)
      a[i] = (long long) (str[i] - '0');
    N = i;
    printf("%lld\n", compute(a, N, K));
    return 0;
}