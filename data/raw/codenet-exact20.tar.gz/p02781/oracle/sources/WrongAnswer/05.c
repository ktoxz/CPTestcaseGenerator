#include<stdio.h>
int main()
{
	int n,k,x,sum=1,a,b=0;
	scanf("%d%d",&n,&k);
	int i,j;
	for(i=1;i<=n;i++)
	{
		x=i;
		while(x>=10)
		{
			a=x%10;
			x/=10;
			if(a!=0)
			sum++;
		}
		if(sum==k)
		b++;
		sum=1;
	}
	printf("%d",b);
}