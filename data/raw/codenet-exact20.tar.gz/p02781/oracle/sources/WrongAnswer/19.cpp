//
//  atcoder.cpp
//
//
///
#include <bits/stdc++.h>
#include <boost/optional.hpp>
#include <boost/range/irange.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/numeric.hpp>
#include <boost/bimap/bimap.hpp>
#include <boost/bimap/multiset_of.hpp>
#include <boost/multi_array.hpp>
#include <boost/math/common_factor.hpp>
#include <boost/algorithm/string.hpp>

#define REP(i, N) for(int i=0; i<(N); i++)
#define REC(f, ...) (void)0; const auto f = [&](const auto f, __VA_ARGS__)
using namespace std;
using namespace boost::math;

using ll = long long;
namespace bst = boost;
template<typename T> class in {
    T value;
public:
    in() { cin >> value; }
    operator const T&() const { return value; }
    operator T&() { return value; }
    in& operator=(T source) { value = source; return *this; }
};
template<> class in<string> : public string {
public:
    in() { cin >> *this; }
};
template<class T> class inseq : public T {
public:
    template<typename... Arg> inseq(Arg... arg) : T(forward<Arg>(arg)...) { for (auto&& i : *this) cin >> i; }
};
template<class T> using invec = inseq<vector<T>>;

auto solve() {
  in<string> N;
  in<int> K;
  
  int zero = 0;
  if (K > N.length())
    return 0LL;
  
  bst::multi_array<ll, 2> dp(bst::extents[N.size()][N.size()]), dp2 = dp;
  
  dp[0][0] = N[0] - '0' - 1;
  dp2[0][0] = 1;
  
  int k = 1;
  for (int i = 1; i < N.size(); i++) {
    dp[i][0] = dp[i-1][0] + 9;
    if (N[i] != '0') dp[i][0] += dp2[i-1][0];
    dp2[i][0] = (N[i] == '0') ? dp2[i-1][0] : 0;
    for (int j = 1; j < k; j++) {
      dp[i][j] = dp[i - 1][j] + dp2[i - 1][j] + dp[i - 1][j - 1] * 9LL;
      dp2[i][j] = 0;
    }
    dp[i][k] = dp[i - 1][k - 1] * 9LL;
    dp2[i][k] = (N[i] != '0') ? 1 : 0;


    if (N[i] != '0') {
      dp2[i][k-1]--;
      dp2[i][k-1] = 1;
      dp[i][k] += dp2[i - 1][k - 1] * (N[i] - '0' - 1);
    }
      k++;
  }

  

  return dp2[N.length() - 1][K-1] + dp[N.length() - 1][K-1];
}

template<typename T> void plot(const T& func) { cout << func() << endl; }
template<> void plot<void()>(void(&func)()) { func(); }
template<> void plot<double()>(double(&func)()) { cout << setprecision(9) << func() << endl; }

int main() {
  plot(solve);

  return 0;
}




