#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;

int main(){
  ull N;
  cin >> N;
  int K;
  cin >> K;
  
  if (K == 1) {
    if (N < 9) cout << N;
    else cout << N / 10 + 9;
  } else if (K == 2) {
    if (N < 9) cout << 0;
    else if (N < 99) cout << (N - 9) - N / 10;
    else cout << (N - 9) - N / 10 - N / 100 ;
  } else {
    if (N < 9) cout << 0;
    else if (N < 99) cout << 0;
    else if (N < 999) cout << (N - 99) - N / 100;
    else cout << (N - 99) - N / 100 - N / 1000;
  }
  return 0;
}

