from math import factorial

N = int(input())
K = int(input())

strN = str(N)
keta = len(strN)
top = int(strN[0])

def nCr(n, r):
    if n < r:
        return 0
    return int(factorial(n) / factorial(r) / factorial(n - r))

res = 9**K*nCr((keta-1), K)

if K == 1:
    res += top

else:
    res += (top-1)*9**(K-1)*nCr((keta-1), K-1)

    if K == 2:
        for i in range(1, keta):
            if int(strN[i]) == 0:
                continue
            res += int(strN[i])
            res += 9*(keta-i-1)
            break

    else:
        for i in range(1, keta):
            if int(strN[i]) == 0:
                continue
            for j in range(i+1, keta):
                if int(strN[j]) == 0:
                    continue
                res += int(strN[i]) * int(strN[j])
                res += int(strN[i]) * 9 *(keta-j-1)
                break


print(res)