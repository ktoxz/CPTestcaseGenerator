N  = int(input())
K = int(input())
K = str(K)
count = 0
for i in range(N):
    j = str(i)
    if K in j:
        count+=1
print(count)