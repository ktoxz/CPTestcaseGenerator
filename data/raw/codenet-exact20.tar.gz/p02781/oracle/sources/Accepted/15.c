#include <stdio.h>

int main(){
  long i,k,m,c,cf=0,cc=1,cg=0,ch=0;
  char n[105];
  scanf("%s",&n);
  scanf("%ld",&k);
  for(c=0;n[c]!=0;c++){
    n[c]-='0';
    if(c>0){
      if(cf==0){
        cf=n[c];
      }else{
        cc++;
        cf+=9;
        ch+=n[c];
        if(cg==0){
          cg=n[c];
        }else{
          cg+=9;
        }
      }
    }
  }
  if(k==1){
    m=(c-1)*9;
    m+=n[0];
  }else if(k==2){
    m=(c-1)*(c-2)/2*81;
    m+=cf+(n[0]-1)*(c-1)*9;
  }else if(k==3){
    m=(c-1)*(c-2)*(c-3)/2*243;
  //printf("%ld\n",m);
    m+=(n[0]-1)*(c-1)*(c-2)/2*81;
  //printf("%ld\n",m);
    m+=(cc-1)*(cc-2)/2*81;
  //printf("%ld\n",m);
    m+=cg*(ch>1);
  //printf("%ld\n",m);
    m+=(n[c-cc]-1)*(cc-1)*9;
  }
  printf("%ld",m);
  return 0;
}
