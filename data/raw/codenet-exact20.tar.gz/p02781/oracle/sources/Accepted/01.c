#include<stdio.h>
#include<string.h>
#include<stdlib.h>
//int atoi(const char *str)

int ruijo(int i,int j){
  int mat=1;
  for(int k=0;k<j;k++){
    mat*=i;}
  return mat;
}

int c(int l,int k){
  int mat=1;
  int tmp=l;
  for(int i=0;i<k;i++){
    mat*=tmp;
    tmp--;}
  for(int i=0;i<k;i++){
    mat/=i+1;}
  return mat;
}

int myatoi(char n){
  if(n=='0') return 0;
  if(n=='1') return 1;
  if(n=='2') return 2;
  if(n=='3') return 3;
  if(n=='4') return 4;
  if(n=='5') return 5;
  if(n=='6') return 6;
  if(n=='7') return 7;
  if(n=='8') return 8;
  if(n=='9') return 9;
  return 0;
}

long int sum(char n[],int k){
  if(k<=0) return 1;
  if(n[0]=='\0') return 0;
  int len=strlen(n);
  long int res=0;
  if(myatoi(n[0])==0){
    res+=sum(n+1,k);
    return res;}
  if(len>k) res+=c(len-1,k)*ruijo(9,k);
  res+=(myatoi(n[0])-1)*c(len-1,k-1)*ruijo(9,k-1);
  res+=sum(n+1,k-1);
  return res;
}

int main(){
  char n[102];
  int k;
  scanf("%s",n);
  scanf("%d",&k);


  long int res=sum(n,k);

  printf("%ld\n",res);
  
  return 0;
}
