#include<bits/stdc++.h>
using namespace std;
#define int long long
#define REP(i,m,n) for(int i=(m);i<(n);i++)
#define rep(i,n) REP(i,0,n)
#define pb push_back
#define all(a) a.begin(),a.end()
#define rall(c) (c).rbegin(),(c).rend()
#define mp make_pair
#define endl '\n'
typedef long long ll;
typedef pair<ll,ll> pll;
typedef long double ld;
const ll inf=1e9+7;
const ll mod=998244353;
signed main(){
    ll n;cin>>n;
    vector<pll>st(0);
    rep(i,n){
        ll a,b;cin>>a>>b;
        st.pb(mp(a,0));
        st.pb(mp(b,1));
    }
    sort(all(st));
    ll cnt=0;
    ll ma=0,mi=inf;
    ll ans=0;
    if(n%2){
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==0){
                cnt++;
                if(cnt==(n+1)/2)mi=min(k.first,mi);
            }
        }
        reverse(all(st));
        cnt=0;
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==1){
                cnt++;
                if(cnt==(n+1)/2)ma=max(k.first,ma);
            }
        }
        ans=ma-mi+1;
    }else{
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==0){
                cnt++;
                if(cnt==(n)/2)mi=min(k.first,mi);
            }
        }
        reverse(all(st));
        cnt=0;
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==1){
                cnt++;
                if(cnt==(n)/2)ma=max(k.first,ma);
            }
        }
        ll maa=0,mii=inf;
        reverse(all(st));
        cnt=0;
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==0){
                cnt++;
                if(cnt==(n)/2+1)mii=min(k.first,mii);
            }
        }
        reverse(all(st));
        cnt=0;
        rep(i,n*2){ 
            pll k=st[i];
            if(k.second==1){
                cnt++;
                if(cnt==(n)/2+1)maa=max(k.first,maa);
            }
        }
        ans=ma+maa-mi-mii+1;
    }
    cout<<ans<<endl;
}