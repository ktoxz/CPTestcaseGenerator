#include <stdio.h>

#define tsort int
#define smaxn 1000000 //最大要素数
#define smxbit 30 //要素のうち最大の数値のビット数
#define snobit 17 //1-smxbitの間で調整、増やせば速いがメモリを消費する
#define rev 0     //0で昇順、1で降順
#define snosc (1<<(snobit+1))

int sort(tsort *vlist,int *plist,int n){
  int h,i,j,k,l,m,s,p,qlist[smaxn],c[snosc][3],ss;
#if rev
  ss=snosc-1;
#else
  ss=0;
#endif
  tsort vj,vk,mx[snosc];
  for(i=0;i<snosc;i++){
    c[i][0]=-1;
    c[i][1]=-1;
  }
  for(i=0;i<n;i++){
    l=(int)(vlist[i]>>(smxbit-snobit))&(snosc-1)^(1<<snobit);
    if(c[l][0]==-1){
      c[l][0]=i;
      c[l][2]=i;
      mx[l]=vlist[i];
    }else{
      qlist[c[l][1]]=i;
#if rev
      if(vlist[i]<mx[l]){
#else
      if(vlist[i]>mx[l]){
#endif
        c[l][2]=i;
        mx[l]=vlist[i];
      }
    }
    c[l][1]=i;
    plist[i]=-1;
  }
#if rev
  for(h=snosc-1;h>=0;h--){
#else
  for(h=0;h<snosc;h++){
#endif
    s=c[h][0];
    if(s==-1){
#if rev
      if(h==ss) ss--;
      if(h!=snosc-1) c[h][1]=c[h+1][1];
#else
      if(h==ss) ss++;
      if(h!=0) c[h][1]=c[h-1][1];
#endif
      continue;
    }
    qlist[c[h][1]]=-1;
    while(qlist[s]!=-1){
      i=s;
      p=-1;
      while(i!=-1){
        j=i;
        k=qlist[j];
        if(k==-1) break;
        i=qlist[k];
#if rev
        if(vlist[j]<vlist[k])
#else
        if(vlist[j]>vlist[k])
#endif
        {
          if(p==-1){
            s=k;
          }else{
            qlist[p]=k;
          }
          l=j;
          j=k;
          k=l;
        }
        qlist[j]=i;
        p=j;
        vj=vlist[j];
        vk=vlist[k];
        while(k!=-1){
#if rev
          if((j==-1)|(vj<vk))
#else
          if((j==-1)|(vj>vk))
#endif
          {
            l=plist[k];
            plist[k]=plist[m];
            plist[m]=k;
            m=k;
            k=l;
            vk=vlist[k];
          }else{
            m=j;
            j=plist[j];
            vj=vlist[j];
          }
        }
      }
    }
    if(h==ss){
      c[h][0]=s;
    }else{
#if rev
      plist[c[h+1][1]]=s;
#else
      plist[c[h-1][1]]=s;
#endif
    }
    for(i=c[h][2];i!=-1;i=plist[i]) j=i;
    c[h][1]=j;
  }
  return(c[ss][0]);
}
    
int main(){
  int n,i,j,k,a[2][200006],b[2],c[200005],d[2],m;
  scanf("%d",&n);
  for(i=0;i<n;i++){
    for(j=0;j<2;j++){
      scanf("%d",&a[j][i]);
    }
  }
  for(i=0;i<2;i++){
    j=sort(&a[i],&c,n);
    for(k=0;k<((n-1)>>1);k++){
      j=c[j];
    }
    b[i]=a[i][j];
    d[i]=a[i][j]+a[i][c[j]];
  }
  if(n&1){
    m=b[1]-b[0]+1;
  }else{
    m=d[1]-d[0]+1;
  }
  printf("%d",m);
  return(0);
}