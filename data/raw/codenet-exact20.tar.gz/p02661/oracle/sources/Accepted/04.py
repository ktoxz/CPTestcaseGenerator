n=int(input())
AB=[]
A=[]
B=[]
for _ in range(n):
    a,b = map(int,input().split())
    AB.append((a,b))
    A.append(a)
    B.append(b)
A.sort()
B.sort()
#AB = sorted(AB,key=lambda x: x[1])
med = n//2
if n%2 != 0:
    print(B[n//2]-A[n//2]+1)
else:
    p = (A[n//2] + A[n//2-1])/2
    q = (B[n//2] + B[n//2-1])/2
    print(int((q-p)*2+1))