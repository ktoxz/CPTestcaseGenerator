import sys

readline = sys.stdin.readline
readall = sys.stdin.read
ns = lambda: readline().rstrip()
ni = lambda: int(readline().rstrip())
nm = lambda: map(int, readline().split())
nl = lambda: list(map(int, readline().split()))
prn = lambda x: print(*x, sep='\n')

n = ni()
a = list(map(int, readall().split()))
l = a[::2]
h = a[1::2]
l.sort()
h.sort()
ml = l[n//2] if n&1 else (l[n//2] + l[n//2-1])
mh = h[n//2] if n&1 else (h[n//2] + h[n//2-1])
print(mh - ml + 1)
