def e_count_median():
    N = int(input())
    Min, Max = [], []
    for _ in range(N):
        a, b = [int(i) for i in input().split()]
        Min.append(a)
        Max.append(b)
    Min.sort()
    Max.sort()

    mid = N // 2
    median_min, median_max = ((Min[mid], Max[mid]) if N % 2 == 1
                              else (Min[mid] + Min[mid - 1], Max[mid] + Max[mid - 1]))
    return median_max - median_min + 1

print(e_count_median())