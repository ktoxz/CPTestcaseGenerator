#define _GLIBCXX_DEBUG
#include <bits/stdc++.h>
using namespace std;
#if __has_include(<boost/multiprecision/cpp_int.hpp>)
	#include <boost/multiprecision/cpp_int.hpp>
	#include <boost/multiprecision/cpp_dec_float.hpp>
	using bll = boost::multiprecision::cpp_int;
	using bdouble = boost::multiprecision::cpp_dec_float_100;
	using namespace boost::multiprecision;
#endif
#if __has_include(<boost/stacktrace.hpp>)
	#define BOOST_STACKTRACE_USE_ADDR2LINE
	#define BOOST_STACKTRACE_ADDR2LINE_LOCATION /usr/local/opt/binutils/bin/addr2line
	#define _GNU_SOURCE 1
	#include <boost/stacktrace.hpp>
#endif
#ifdef LOCAL_TEST
	namespace std {
		template<typename T> class dvector : public std::vector<T> {
		public:
			dvector() : std::vector<T>() {}
			explicit dvector(size_t n, const T& value = T()) : std::vector<T>(n, value) {}
			dvector(const std::vector<T>& v) : std::vector<T>(v) {}
			dvector(const std::initializer_list<T> il) : std::vector<T>(il) {}
			dvector(const std::string::iterator first, const std::string::iterator last) : std::vector<T>(first, last) {}
			dvector(const typename std::vector<T>::iterator first, const typename std::vector<T>::iterator last) : std::vector<T>(first, last) {}
			dvector(const typename std::vector<T>::reverse_iterator first, const typename std::vector<T>::reverse_iterator last) : std::vector<T>(first, last) {}
			dvector(const typename std::vector<T>::const_iterator first, const typename std::vector<T>::const_iterator last) : std::vector<T>(first, last) {}
			dvector(const typename std::vector<T>::const_reverse_iterator first, const typename std::vector<T>::const_reverse_iterator last) : std::vector<T>(first, last) {}
			T& operator[](size_t n) {
				try { return this->at(n); } catch (const std::exception& e) { std::cerr << boost::stacktrace::stacktrace() << '\n'; return this->at(n); }
			}
			const T& operator[](size_t n) const {
				try { return this->at(n); } catch (const std::exception& e) { std::cerr << boost::stacktrace::stacktrace() << '\n'; return this->at(n); }
			}
		};
	}
	class dbool {
	private:
		bool boolvalue;
	public:
		dbool() : boolvalue(false) {}
		dbool(bool b) : boolvalue(b) {}
		operator bool&() { return boolvalue; }
		operator const bool&() const { return boolvalue; }
	};
	#define vector dvector
	#define bool dbool
#endif
#ifdef LOCAL_DEV
	template<typename T> std::ostream& operator<<(std::ostream& s, const std::vector<T>& v) {
		for (size_t i = 0; i < v.size(); ++i){ s << v[i]; if (i < v.size() - 1) s << "\t"; } return s; }
	template<typename T> std::ostream& operator<<(std::ostream& s, const std::vector<std::vector<T>>& vv) {
		s << "\\\n"; for (size_t i = 0; i < vv.size(); ++i){ s << vv[i] << "\n"; } return s; }
	template<typename T> std::ostream& operator<<(std::ostream& s, const std::deque<T>& v) {
		for (size_t i = 0; i < v.size(); ++i){ s << v[i]; if (i < v.size() - 1) s << "\t"; } return s; }
	template<typename T> std::ostream& operator<<(std::ostream& s, const std::set<T>& se) {
		s << "{ "; for (auto itr = se.begin(); itr != se.end(); ++itr){ s << (*itr) << "\t"; } s << "}"; return s; }
	template<typename T> std::ostream& operator<<(std::ostream& s, const std::multiset<T>& se) {
		s << "{ "; for (auto itr = se.begin(); itr != se.end(); ++itr){ s << (*itr) << "\t"; } s << "}"; return s; }
	template <typename T, size_t N> std::ostream& operator<<(std::ostream& s, const std::array<T, N>& a) {
		s << "{ "; for (size_t i = 0; i < N; ++i){ s << a[i] << "\t"; } s << "}"; return s; }
	template<typename T1, typename T2> std::ostream& operator<<(std::ostream& s, const std::map<T1, T2>& m) {
		s << "{\n"; for (auto itr = m.begin(); itr != m.end(); ++itr){ s << "\t" << (*itr).first << " : " << (*itr).second << "\n"; } s << "}"; return s; }
	template<typename T1, typename T2> std::ostream& operator<<(std::ostream& s, const std::pair<T1, T2>& p) {
		return s << "(" << p.first << ", " << p.second << ")"; }
	class SIGFPE_exception : std::exception {};
	class SIGSEGV_exception : std::exception {};
	void catch_SIGFPE([[maybe_unused]] int e) { std::cerr << boost::stacktrace::stacktrace() << '\n'; throw SIGFPE_exception(); }
	void catch_SIGSEGV([[maybe_unused]] int e) { std::cerr << boost::stacktrace::stacktrace() << '\n'; throw SIGSEGV_exception(); }
	signed convertedmain();
	signed main() { signal(SIGFPE, catch_SIGFPE); signal(SIGSEGV, catch_SIGSEGV); return convertedmain(); }
	#define main() convertedmain()
	void debug_impl() { std::cerr << '\n'; }
	template<typename Head, typename... Tail> void debug_impl(Head head, Tail... tail) { std::cerr << " " << head << (sizeof...(tail) ? "," : ""); debug_impl(tail...); }
	#define debug(...) do { std::cerr << "(" << #__VA_ARGS__ << ") ="; debug_impl(__VA_ARGS__); } while (false)
#else
	#define debug(...) do {} while (false)
#endif
//#define int long long
using ll = long long;
//constexpr int INF = 1e9;//INT_MAX=(1<<31)-1=2147483647
constexpr ll INF = (ll)1e18;//(1LL<<63)-1=9223372036854775807
constexpr ll MOD = (ll)1e9 + 7;
constexpr double EPS = 1e-9;
constexpr ll dx[4] = {1, 0, -1, 0};
constexpr ll dy[4] = {0, 1, 0, -1};
constexpr ll dx8[8] = {1, 0, -1, 0, 1, 1, -1, -1};
constexpr ll dy8[8] = {0, 1, 0, -1, 1, -1, 1, -1};
#define rep(i, n)   for(ll i=0, i##_length=(n); i< i##_length; ++i)
#define repeq(i, n) for(ll i=1, i##_length=(n); i<=i##_length; ++i)
#define rrep(i, n)   for(ll i=(n)-1; i>=0; --i)
#define rrepeq(i, n) for(ll i=(n)  ; i>=1; --i)
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
void p() { std::cout << '\n'; }
template<typename Head, typename... Tail> void p(Head head, Tail... tail) { std::cout << head << (sizeof...(tail) ? " " : ""); p(tail...); }
template<typename T> inline void pv(std::vector<T>& v) { for(ll i=0, N=v.size(); i<N; i++) std::cout << v[i] << " \n"[i==N-1]; }
template<typename T> inline bool chmax(T& a, T b) { return a < b && (a = b, true); }
template<typename T> inline bool chmin(T& a, T b) { return a > b && (a = b, true); }
template<typename T> inline void uniq(std::vector<T>& v) { v.erase(std::unique(v.begin(), v.end()), v.end()); }

/*-----8<-----template-----8<-----*/

/*-----8<-----library-----8<-----*/




const ll N_MAX = 2*1e5;
const ll B_I_MAX = 1e9;

ll N;
vector<ll> A;
vector<ll> B;


ll f(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = INF;
	rangetype right = 0;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(A[i]<=val)t++;
		}
		return t>=(N+1)/2;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}
ll g(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = 0;
	rangetype right = INF;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(val<=B[i])t++;
		}
		return t>=(N+1)/2;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}


//---------------------------------------
ll amax(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = INF;
	rangetype right = 0;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(A[i]<=val)t++;
		}
		return t>=N/2+1;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}
ll amin(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = 0;
	rangetype right = INF;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(val<=B[i])t++;
		}
		return t>=N/2;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}

ll bmax(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = INF;
	rangetype right = 0;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(A[i]<=val)t++;
		}
		return t>=N/2;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}
ll bmin(){
	//初期は left->OK / right->NG になっています
	using rangetype = ll;
	rangetype left = 0;
	rangetype right = INF;
	auto isOK = [&](rangetype val) -> bool {
		ll t=0;
		rep(i,N){
			if(val<=B[i])t++;
		}
		return t>=N/2+1;
	};
	while((rangetype)abs(right - left) > 1) {
		rangetype mid = left + (right - left) / 2;
		if(isOK(mid)) left = mid;
		else right = mid;
	}
	return left;
}

void solve() {
	cin >> N;
	A = vector<ll>(N);
	B = vector<ll>(N);
	rep(i, N) { cin >> A[i] >> B[i]; }

	ll ans = 0;
	if(N%2==1){
		//奇数
		ll x=f();
		ll y=g();
		ans=y-x+1;
	}else{
		ll a1=amax();
		ll a2=amin();
		ll b1=bmax();
		ll b2=bmin();
		debug(a1,a2,b1,b2);
		ll t=(a2+b2)-(a1+b1)+1;
		ans=t;
	}

	
	cout << ans << endl;
}

// https://atcoder.jp/contests/abc169/tasks/abc169_e
signed main() {
	solve();
	return 0;
}
