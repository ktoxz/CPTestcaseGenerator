import bisect,collections,copy,heapq,itertools,math,numpy,string
import sys
def I(): return int(sys.stdin.readline().rstrip())
def LI(): return list(map(int,sys.stdin.readline().rstrip().split()))
def S(): return sys.stdin.readline().rstrip()
def LS(): return list(sys.stdin.readline().rstrip().split())

N = I()
AB = [LI() for _ in range(N)]
AB_a = sorted(AB,key=lambda x: x[0])
AB_b = sorted(AB,key=lambda x: x[1])

#"""
if N%2 == 0:
    p = N//2 -1
    q = p+1
    #print(p,q)
    ans = abs(AB_a[p][0]+AB_a[q][0] - AB_b[p][1]-AB_b[q][1])+1    
else:
    p = (N+1)//2 -1
    #print(p)
    ans = abs(AB_a[p][0] - AB_b[p][1])+1
print(ans)
#"""