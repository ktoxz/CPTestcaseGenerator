#include <stdio.h>
#include <stdlib.h>

int notomamiko(const void* x, const void* y) {
	int a = *(const int*)x, b = *(const int*)y;
	return a < b ? -1 : a > b;
}

struct mareitaso {
	int A, B;
};

int N;
struct mareitaso mimorin[271828];

int tomatu;
int sumipe[555555];

int kugyu(int yukati) {
	int l = 0, r = tomatu - 1;
	while (l <= r) {
		int m = l + (r - l) / 2;
		if (sumipe[m] == yukati) return m;
		else if (sumipe[m] < yukati) l = m + 1;
		else r = m - 1;
	}
	printf("ERROR: %d not found\n", yukati);
	exit(2);
}

int ikanomi[555555];
int izyounomi[555555];

int main(void) {
	int i;
	if (scanf("%d", &N) != 1) return 1;
	for (i = 0; i < N; i++) {
		if (scanf("%d%d", &mimorin[i].A, &mimorin[i].B) != 2) return 1;
		sumipe[i*2+0] = mimorin[i].A;
		sumipe[i*2+1] = mimorin[i].B;
	}
	sumipe[N*2+0] = 0;
	sumipe[N*2+1] = 1111111111;
	qsort(sumipe, N * 2 + 2, sizeof(*sumipe), notomamiko);
	tomatu = 1;
	for (i = 1; i < N * 2 + 2; i++) {
		if (sumipe[tomatu - 1] != sumipe[i]) sumipe[tomatu++] = sumipe[i];
	}
	for (i = 0; i < N; i++) {
		ikanomi[kugyu(mimorin[i].B)]++;
		izyounomi[kugyu(mimorin[i].A)]++;
	}
	for (i = 1; i < tomatu; i++) ikanomi[i] += ikanomi[i - 1];
	for (i = tomatu - 2; i >= 0; i--) izyounomi[i] += izyounomi[i + 1];

	if (N % 2 == 1) {
		int kotae = 0;
		for (i = 1; i < tomatu - 1; i++) {
			/* その数をチェック */
			if (ikanomi[i - 1] < (N+1)/2 && izyounomi[i + 1] < (N+1)/2) kotae++;
			/* その数と次の数の間をチェック */
			if (sumipe[i] + 1 < sumipe[i + 1]) {
				if (ikanomi[i] < (N+1)/2 && izyounomi[i+1] < (N+1)/2) {
					kotae += sumipe[i + 1] - sumipe[i] - 1;
				}
			}
		}
		printf("%d\n", kotae);
	} else {
		int x_kagen = -1, y_zyogen = -1;
		for (i = 0; i < tomatu; i++) {
			if (izyounomi[i] <= N/2) {
				x_kagen = i;
				break;
			}
		}
		for (i = tomatu - 1; i >= 0; i--) {
			if (ikanomi[i] <= N/2) {
				y_zyogen = i;
				break;
			}
		}
		if (x_kagen < 0 || y_zyogen < 0) {
			puts("ERROR! x/y kagen/zyogen not found!");
			return 2;
		}
		/*
		sumipe[x_kagen]以上(sumipe[x_kagen]-1超)のみにしかなれない奴がN/2個以下
		sumipe[x_kagen-1]以上(sumipe[x_kagen-1]-1超)のみにしかなれない奴はN/2個超

		sumipe[x_kagen-1]+1以上(sumipe[x_kagen-1]超)のみにしかなれない奴はN/2個以下
		(izyounomi[x_kagen-1]の加算によって超えたはずなので)

		sumipe[y_zyogen]以下(sumipe[y_zyogen]+1未満)のみにしかなれない奴がN/2個以下
		sumipe[y_zyogen+1]以下(sumipe[y_zyogen+1]+1未満)のみにしかなれない奴はN/2個超

		sumipe[y_zyogen+1]-1以下(sumipe[y_zyogen+1]未満)のみにしかなれない奴はN/2個以下
		(ikanomi[y_zyogen+1]の加算によって超えたはずなので)

		したがって

		[x超onlyがN/2個以下の下限x] <= x <= y <= [y未満onlyがN/2以下の上限y]
		は
		sumipe[x_kagen-1] <= x <= y <= sumipe[y_zyogen+1]
		となる
		*/
		x_kagen--;
		y_zyogen++;
		/* sumipe[x_kagen] <= x <= y <= sumipe[y_zyogen] となる */
		printf("%d <= x <= y <= %d\n", sumipe[x_kagen], sumipe[y_zyogen]);
	}
	return 0;
}

/*

☆Nが奇数のとき

中央値がx → x以下の数値が(N+1)/2個以上ある かつ x以上の数値が(N+1)/2個以上ある

xになれるもの or x未満しかなれないもの or x超にしかなれないもの

「x未満にしかなれないもの」と「x超にしかなれないもの」両方(N+1)/2個未満ならば、
中央値をxにできる

座標圧縮 → 該当する数値がない場所はまとめる

☆Nが偶数のとき

中央値が(x+y)/2 (x <= y) → x以下の数値がN/2個以上ある かつ y以上の数値がN/2個以上ある

「y未満にしかなれないもの」と「x超にしかなれないもの」両方N/2個以下ならば、
中央値を(x+y)/2にできる

「y未満にしかなれないもの」 → yを大きくすると増える(減らない)
「x超にしかなれないもの」→ xを小さくすると増える(減らない)

[x超onlyがN/2個以下の下限x] <= x <= y <= [y未満onlyがN/2以下の上限y]

x超 → x+1以上
y未満 → y-1以下

x or yを1変える → 中央値は1/2変わる

xとyは別の要素から取らないといけない

*/
