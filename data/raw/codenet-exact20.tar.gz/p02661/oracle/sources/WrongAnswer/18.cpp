#include <bits/stdc++.h>
using namespace std;
#define REP(i,a,n) for(int i=(a); i<(int)(n); i++)
#define rep(i,n) REP(i,0,n)
#define FOR(it,c) for(__typeof((c).begin()) it=(c).begin(); it!=(c).end(); ++it)
#define ALLOF(c) (c).begin(), (c).end()
typedef long long ll;
typedef unsigned long long ull;

bool check(ll X, const vector<ll>& v){
  if(v.size()%2!= 0){
    vector<ll> a;
    rep(i,v.size()){
      if(v[i] <= X) a.push_back(v[i]);
    }
    if(a.size() >= v.size()/2+1) return true;
    else return false;
  }else{
    vector<ll> a, b;
    rep(i,v.size()){
      if(v[i] <= X) a.push_back(v[i]);
      else b.push_back(v[i]);
    }
    sort(ALLOF(a));
    sort(ALLOF(b));
    if(a.size() == 0) return false;
    else if(b.size() == 0) return true;
    else{
      if(a.size() >= b.size()){
        if(a[a.size()-1] <= 2 * X - b[0]) return true;
        return false;
      }else{
        return false;
      }
    }
  }
}

bool check2(ll X, const vector<ll>& v){
  if(v.size()%2!= 0){
    vector<ll> b;
    rep(i,v.size()){
      if(v[i] >= X) b.push_back(v[i]);
    }
    if(b.size() >= v.size()/2+1) return true;
    else return false;
  }else{
    vector<ll> a, b;
    rep(i,v.size()){
      if(v[i] >= X) b.push_back(v[i]);
      else a.push_back(v[i]);
    }
    sort(ALLOF(a));
    sort(ALLOF(b));
    if(a.size() == 0) return true;
    else if(b.size() == 0) return false;
    else{
      if(a.size() <= b.size()){
        if(2 * X - a[a.size()-1] <= b[0]) return true;
        return false;
      }else{
        return false;
      }
    }
  }
}

int main(){
  int N;
  cin >> N;
  vector<ll> v, w;
  rep(i,N){
    ll a, b;
    cin >> a >> b;
    if(N%2!=0){
      v.push_back(a);
      w.push_back(b);
    }else{
      v.push_back(2*a);
      w.push_back(2*b);
    }
  }


  ll x = -1, y = -1;
  {
    ll lb = 0, ub = (ll)1e11;
    while(ub-lb>1){
      ll mid = lb + (ub-lb)/2;

      if(!check(mid, v)) lb = mid;
      else ub = mid;
    }
    cerr << ub << endl;
    x = ub;
  }
  {
    ll lb = 0, ub = (ll)1e11;
    while(ub-lb>1){
      ll mid = lb + (ub-lb)/2;

      if(check2(mid, w)) lb = mid;
      else ub = mid;
    }
    cerr << ub << endl;
    y = ub;
  }

  if(y - x <= 0) cout << 0 << endl;
  else cout << y - x << endl;
  
  return 0;
}
