#include<bits/stdc++.h>

using namespace std;
using ll = long long;
using ull = unsigned long long;
using P = pair<int,int>;
#define rep(i,n) for(ll i = 0;i < (ll)n;i++)
#define ALL(x) (x).begin(),(x).end()
#define MOD 1000000007



int main(){

  int n;
  cin >> n;
  vector<ll> l(n),r(n);
  rep(i,n)cin >> l[i] >> r[i];
  sort(ALL(l));
  sort(ALL(r));
  if(n & 1){
    cout << r[(n)/2]-l[(n)/2]+1 << endl;
  }else{
    long double k = (r[(n-1)/2]+r[(n)/2])/2.0-(l[n/2]+l[(n-1)/2])/2.0;
    k *= 2;
    k = k+1;
    cout << k << endl;
  }




  




  return 0;
}