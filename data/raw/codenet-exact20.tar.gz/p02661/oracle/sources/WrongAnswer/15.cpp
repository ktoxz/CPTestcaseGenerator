#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
ll MOD = 1000000007;

#define vec                vector<int>
#define vecll              vector<ll>
#define vecd               vector<double>
#define vecst              vector<string>
#define vecb               vector<bool>
#define vec2(var, n, m)    vector<vector<int>> var(n, vector<int>(m, 0))
#define vecll2(var, n, m)  vector<vector<ll>> var(n, vector<ll>(m, 0))

#define rep(i,n)         for(ll i=(ll)0; i<(ll)n; i++)
#define REP(i,m,n)       for(ll i=(ll)m; i<(ll)n; i++)
#define arr(var, n)      vec var(n); rep(i,n){cin >> var[i];}
#define arrll(var, n)    vecll var(n); rep(i,n){cin >> var[i];}
#define arrst(var, n)    vecst var(n); rep(i,n){cin >> var[i];}
#define all(var)         (var).begin(), (var).end()
#define sortall(var)     sort(all(var))
#define uniqueall(v)     v.erase(unique(v.begin(), v.end()), v.end());
#define f_sum(var)       accumulate(all(var), 0)
#define f_sumll(var)     accumulate(all(var), 0LL)
#define chmin(v1, v2)    v1 = min(v1, v2)
#define chmax(v1, v2)    v1 = max(v1, v2)
#define pb(var)          push_back(var)
#define prt(var)         cout << (var) << "\n"
#define prtd(n, var)     cout << fixed << setprecision(n) << var << "\n"
#define prtfill(n, var)  cout << setw(n) << setfill('0') << var;
#define prt2(v1, v2)     cout << v1 << " " << v2 << "\n"
#define prt3(v1, v2, v3) cout << v1 << " " << v2 << " " << v3 << "\n"
#define prtall(v)        rep(i,v.size()){cout<<v[i]<<(i!=v.size()-1?" ":"\n");}
void prtok(bool ok){prt(ok ? "yes" : "no");}
//----------------------------------------------------------------

int main(void) {
  int n;
  cin >> n;
  //vector<pair<int, int>> p(n);
  vec a(n), b(n);
  rep(i,n){
    int tmp1, tmp2;
    cin >> tmp1 >> tmp2;
    a[i] = tmp1;
    b[i] = tmp2;
    //p[i] =make_pair(tmp1, tmp2);
  }
  sortall(a);
  sortall(b);

  if(n%2==1){
    auto it1 = lower_bound(b.begin(), b.end(), a[n/2]);
    prt(*it1-a[n/2]);
  } else {
    auto it1 = lower_bound(b.begin(), b.end(), a[n/2]);
    int ans=(*it1-a[n/2])*2+1;
    //prt(ans);
    ans+=max(0, a[n/2]-a[n/2-1]);
    ans+=max(0, *(it1+1)-*(it1));
    prt(ans);
  }
}
