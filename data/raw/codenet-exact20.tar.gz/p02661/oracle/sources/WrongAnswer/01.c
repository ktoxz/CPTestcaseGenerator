#include<stdio.h>
#include<stdlib.h>
int lb(int l,int r,int n,int *d){
  int m=(l+r)/2;
  if(l==r)return m;
  return n<=d[m]?lb(l,m,n,d):lb(m+1,r,n,d);
}
long long R=1,C=1,H[2000010],N[2000010];
//評価関数（いまはMIN）
int hyouka(int a,int b){
  if(C<b)return 1;
  if(C<a||b==0)return 0;
  return N[H[a]]<N[H[b]]||N[H[a]]==N[H[b]]&&H[a]%2==1?1:0;
}
//挿入関数
void hin(long long a){
  int i=C++;
  for(N[H[0]=R]=a;hyouka(0,i/2);i/=2)H[i]=H[i/2];
  H[i]=R++;
}
//取り出す関数
int hout(){
  int rt=H[1],i,j=2,k=H[--C];
  for(i=1;hyouka(i,C);i=j)H[i]=H[j=i*2+1-hyouka(i*2,i*2+1)];
  H[j/2]=k;
  return rt;
}
void f(int *a,int n,int *b){
  R=C=1;
  int i,d[200010];
  for(i=0;i<n;i++)hin(a[i]);
  for(i=0;i<n;i++)d[i]=hout();
  for(i=0;i<n;i++)b[i]=lb(0,n,a[i],d);
}
int main(){
  long long n,a[200010],b[200010],i,lb=0,bf,ans=0,ra,j,r,l;
  scanf("%lld",&n);
  for(i=0;i<n;i++)scanf("%lld %lld",&a[i],&b[i]);
  if(n%2==0){
    for(i=0;i<n;i++)hin(a[i]*2);
    for(i=0;i<n/2;i++)j=N[hout()];
    l=(N[H[1]]+j)/2;
    R=C=1;
    for(i=0;i<n;i++)hin(b[i]*2);
    for(i=0;i<n/2;i++)j=N[hout()];
    r=(N[H[1]]+j)/2;//printf("%lld %lld\n",l,r);
    printf("%lld\n",r-l);
  }
  else{
    for(i=0;i<n;i++)hin(a[i]);
    for(i=0;i<n/2;i++)hout();
    l=N[H[1]];
    R=C=1;
    for(i=0;i<n;i++)hin(b[i]);
    for(i=0;i<n/2;i++)hout();
    r=N[H[1]];
    printf("%lld\n",r-l+1);
  }
  return 0;
}
    
