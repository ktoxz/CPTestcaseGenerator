def main():
    N = int(input())
    A,B = [0]*N,[0]*N
    for i in range(N):
        A[i],B[i] = map(int, input().split())
    Xmin = min(A)
    Xmax = max(B)
    median = {}
    # あるX(Xmin<X<Xmax)について
    # 1.自分単体で中央値
    for i in range(Xmin+1,Xmax):
        if i not in median.keys():
            median[i] = 1
        if i<=Xmax-2 and 2*i+1 not in median.keys():
            median[2*i+1] = 1
    # 2.隣と一緒に中央値を作る
    print(len(median))


main()
