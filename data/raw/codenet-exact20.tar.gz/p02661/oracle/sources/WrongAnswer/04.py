n = int(input())
min_s = []
max_s = []
for i in range(n):
    a, b = map(int, input().split())
    min_s.append(a)
    max_s.append(b)

min_s.sort()
max_s.sort()
if n % 2 == 0:
    min_med = (min_s[n//2-1] + min_s[n//2])/2
    max_med = (max_s[n//2-1] + max_s[n//2])/2
    print(int(max_med-min_med)*2+1)

else:
    min_med = min_s[(n+1)//2-1]
    max_med = max_s[(n+1)//2-1]
    print(int((max_med-min_med)+1))