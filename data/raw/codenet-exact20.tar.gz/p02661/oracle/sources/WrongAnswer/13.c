#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
typedef long long ll;

int hikaku1(const void *n1,const void *n2)
{
    return *(int*)n1-*(int*)n2;
}

int hikaku2(const void *n1,const void *n2)
{
    return -*(int*)n1+*(int*)n2;
}

int main()
{
    

    int n;
    scanf("%d",&n);
    int a[n],b[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d %d",&a[i],&b[i]);
    }

    qsort(a,n,sizeof(int),hikaku1);
    qsort(b,n,sizeof(int),hikaku2);

    int h,l,k;

    k=n/2;
    k=k+1;
    
    l=a[k-1];
    h=b[k-1];


    int ans=h-l+1;

    if(n%2==0)
    {
        ans=ans*2+1;
    }

    printf("%d\n",ans);

    return 0;
}