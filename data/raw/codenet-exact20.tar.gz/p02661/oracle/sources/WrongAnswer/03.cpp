#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define rep(i, a, b) for(int i = (a); i < (b); ++i)
#define per(i, a, b) for(int i = (b) - 1; i >= (a); --i)
#define de(x) cout << #x << " = " << x << endl
#define dd(x) cout << #x << " = " << x << " "
#define sz(x) (int)x.size()
#define all(x) x.begin(), x.end()
#define pw(x) (1ll << (x))
#define endl '\n'
typedef long long ll;
typedef double db;
typedef vector<int> vi;
typedef pair<int, int> pii;

const int N = 202020;

int n, a[N], b[N];
vi V; 
bool check(int x, int y) {
//	dd(x), dd(y);
	int p = lower_bound(b + 1, b + 1 + n, x) - b - 1;
	int q = lower_bound(a + 1, a + 1 + n, y) - a;
	q = n - q + 1;
	//dd(p), de(q);
	return p < (n + 1) / 2 && q < (n + 1) / 2;
}
int main() {
	std::ios::sync_with_stdio(0);
	std::cin.tie(0);
	cin >> n;
	rep(i, 1, n + 1) cin >> a[i] >> b[i], V.pb(a[i]), V.pb(b[i] + 1);
	sort(all(V));
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	V.erase(unique(all(V)), V.end());
	ll ans = 0, res = 0;
	rep(i, 0, sz(V) - 1) {
		if(check(V[i], V[i + 1])) ans += V[i + 1] - V[i], ++res;
	}
	if(n % 2 == 0) ans <<= 1, ans += 1;
	cout << ans << endl;
	return 0;
}
