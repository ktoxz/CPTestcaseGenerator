import sys

N = int(input())
AB = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
AB.sort()

n = N // 2 if N % 2 != 0 else N // 2 - 1
left = AB[n][0]

AB.sort(key=lambda x: x[1])
right = AB[n][1]

print(max(0, right - left + 1))
