#include <bits/stdc++.h>
using namespace std;


int main() {
    long long N;
    cin>>N;
    long long a[N];
    long long b[N];
    for(long long i=0;i<N;i++){
    cin>>a[i];
    cin>>b[i];}
    if(N%2==1){
    cout<<b[N-1-N/2]-a[N/2]+1<<endl;}
    else{
    cout<<b[N-N/2]-a[N/2-1]+1<<endl;}}
