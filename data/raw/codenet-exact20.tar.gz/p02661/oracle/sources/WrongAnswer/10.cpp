#include <algorithm>
#include <iomanip>
#include <iostream>
#include <utility>
#include <vector>

long solve(long n, const std::vector<std::pair<long, long>>& pairs)
{
  std::vector<long> small;
  small.reserve(n);
  for (auto& p : pairs) {
    small.push_back(p.first);
  }

  std::vector<long> large;
  large.reserve(n);
  for (auto& p : pairs) {
    large.push_back(p.second);
  }

  std::sort(small.begin(), small.end());
  std::sort(large.begin(), large.end());
  if (n % 2) {
    return large[n / 2] - small[n / 2] + 1;
  } else {
    return large[n / 2] + small[n / 2] - (large[n / 2 - 1] + small[n / 2 - 1]) + 1;
  }
}

int main()
{
  long n;
  std::cin >> n;

  std::vector<std::pair<long, long>> pairs(n);
  for (auto& p : pairs) {
    std::cin >> p.first >> p.second;
  }

  std::cout << std::setprecision(20);
  std::cout << solve(n, pairs) << std::endl;
}
