# -*- coding: utf-8 -*-
"""
Created on Fri May 17 21:35:10 2019

@author: avina
"""

N , K = map(int, input().split())
l = list(map(int, input().split()))

sums = sum(l[:K])
m = 1e10
k = 0
for i in range(N - K):

    if sums < m:
        m = sums
        k = i
    sums = sums + l[i + K] - l[i]
e = l[k]
d = 0; u1 = False; u2 = False
for i in range(k+1,k+K):
    d += l[i] - e
    e = l[i]
    if l[i]>= 0:
        u1=True
    if l[i] < 0:
        u2 = True
if u1 and u2:
    print(d)
else:
    print(d+l[k])