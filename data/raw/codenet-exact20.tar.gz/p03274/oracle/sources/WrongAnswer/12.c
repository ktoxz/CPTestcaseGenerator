#include<stdio.h>

#define INFTY 300000000;

int min(long long int a, long long int b){
  return a > b ? (int)b : (int)a;
}

int max(long long int a, long long int b){
  return a > b ? (int)a : (int)b;
}

int main(){
  int n, k;
  scanf("%d %d", &n, &k);
  
  int x[n + 1];
  int th = 0;
  for(int i = 0; i < n; i++){
    int in;
    scanf("%d", &in);
    if(in <= 0){
      *(x + i) = in;
      th++;
    }else if(th == i){
      *(x + i) = 0;
      *(x + i + 1) = in;
    }else{
      *(x + i + 1) = in;
    }
  }
  
  int ans = INFTY;
  
  int *left = th - k > 0 ? x + th - k : x;
  int *right = th >= k ? x + min(left + k - 1 - x, n) : x + min(left + k - x, n);
  
  while(left <= x + th && right < x + n){
    ans = min(ans, max(-*(left), *(right)) + 2 * min(-*(left), *(right)));
    left++;
    right++;
  }
  
  printf("%d", ans);
  
  return 0;
}
