#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
int acs(const void *a, const void *b){return *(int*)a - *(int*)b;} /* 1,2,3,4.. */
int des(const void *a, const void *b){return *(int*)b - *(int*)a;} /* 8,7,6,5.. */
int cmp_char(const void *a, const void *b){return *(char*)a - *(char*)b;} /* a,b,c,d.. */
int cmp_str(const void *a, const void *b){return strcmp(*(const char **)a, *(const char **)b);} /* aaa,aab.. */
#define min(a,b) (a < b ? a: b)
#define max(a,b) (a > b ? a: b)
#define rep(i, l, r) for (int i = l; i < r; i++)
#define MAX 1000005
#define MOD 1000000007

typedef long long int lli;


// 優先度付きキュー Priority Queue

typedef struct
{
  long long int pri;
  long long int val;
} que;

que pq[MAX];
int pq_size = 0; // 最大要素

void PQadd(long long int pri, long long int val)
{
  int last = ++pq_size;
  que new;
  new.pri = pri;
  new.val = val;
  pq[pq_size] = new;

  while (last > 1 && pq[last].pri < pq[last / 2].pri)
  {
    que temp;
    temp = pq[last];
    pq[last] = pq[last / 2];
    pq[last / 2] = temp;
    last /= 2;
  }
  return;
}

que PQget(void)
{
  que root = pq[1];
  pq[1] = pq[pq_size--];

  int last = 1, bigger_child;
  while (last * 2 <= pq_size)
  {
    if (last * 2 == pq_size)
      bigger_child = last * 2;
    else
      bigger_child = pq[last * 2].pri < pq[last * 2 + 1].pri ? last * 2 : last * 2 + 1;

    if (pq[last].pri > pq[bigger_child].pri)
    {
      que temp;
      temp = pq[last];
      pq[last] = pq[bigger_child];
      pq[bigger_child] = temp;
      last = bigger_child;
    }
    else
      break;
  }
  return root;
}


int main(void) {
  int N, K;
  scanf("%d %d", &N, &K);
  int x[MAX];
  rep(i, 0, N) {
    scanf("%d", &x[i]);
  }

  int ans, left, right;
  // 左は0, 右は1
  // 左に進む場合(右が戻る)
  rep(xi, 0, N) { // 左
    if (x[xi] > 0) break;
    PQadd(abs(x[xi]), 1);
  }
  rep(xi, 0, N) { // 右
    if (x[xi] <= 0) continue; 
    PQadd(abs(x[xi]) * 2, 2);
  }

  left = 0; right = 0;
  rep(ki, 0, K) {
    que min = PQget();
    if ( min.val == 0 ) left = min.pri;
    else right = min.pri;
  }
  ans = left + right;

  pq_size = 0;

  // 右に進む場合(左が戻る)
  rep(xi, 0, N) { // 左
    if (x[xi] > 0) break;
    PQadd(abs(x[xi]) * 2, 1);
  }
  rep(xi, 0, N) { // 右
    if (x[xi] <= 0) continue; 
    PQadd(abs(x[xi]), 2);
  }

  left = 0; right = 0;
  rep(ki, 0, K) {
    que min = PQget();
    if ( min.val == 1 ) 
      left = min.pri;
    else
      right = min.pri;
  }
  ans = min(ans, left + right);
  printf("%d\n", ans);
  return 0;
}
