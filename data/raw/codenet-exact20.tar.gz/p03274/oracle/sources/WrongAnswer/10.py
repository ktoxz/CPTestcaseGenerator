import numpy as np
n,k,*x=map(int,open(0).read().split())
inf=float('inf')
k-=x.count(0)
x=np.array(x)
pos=list(x[x>0])
neg=list((x[x<0]*-1)[::-1])
x=[]
ans=inf
sum_p=pos[:min(len(pos),k)]
sum_n=neg[:min(len(neg),k)]
pos.clear()
neg.clear()
if len(sum_p)==k and k!=0:
  ans=sum_p[-1]
if len(sum_n)==k and k!=0:
  ans=min(ans,sum_n[-1])
for i,p in enumerate(sum_p):
  if i+1>len(sum_n):
    break
  ans=min(ans,p*2+sum_n[-i-1])
  ans=min(ans,sum_n[-i-1]*2+p)
if k==0:
  ans=0
print(ans)