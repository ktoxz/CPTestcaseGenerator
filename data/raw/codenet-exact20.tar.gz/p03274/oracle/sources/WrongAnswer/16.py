N, K = (int(i) for i in input().split())  
X = [int(i) for i in input().split()] 

def get_max_pos_and_neg(sort_set):
  max_pos = 0
  max_neg = 0
  for val, neg_flg in sort_set[:K]:
    if neg_flg == 0:
      max_pos = max(max_pos, val)
    else:
      max_neg = max(max_neg, val)
  return max_pos + max_neg

neg_X = sorted(list(map(lambda x: abs(x), filter(lambda x: x <= 0, X))))
pos_X = sorted(list(filter(lambda x: x >= 0, X)))

pos_list = []
for x in pos_X:
  pos_list.append((x, 0))
  
for x in neg_X:
  if x == 0:
    continue
  pos_list.append((2 * x, 1))
  
pos_sort_set = sorted(pos_list, key = lambda x: (x[0], x[1]))

neg_list = []
for x in pos_X:
  neg_list.append((2 * x, 1))
  
for x in neg_X:
  if x == 0:
    continue
  neg_list.append((x, 0))
  
neg_sort_set = sorted(neg_list, key = lambda x: (x[0], x[1]))
ans = min(get_max_pos_and_neg(pos_sort_set), get_max_pos_and_neg(neg_sort_set))
if len(pos_X) >= K:
  ans = min(ans, max(pos_X[:K])) 
if len(neg_X) >= K:
  ans = min(ans, max(neg_X[:K]))
print(ans)
  