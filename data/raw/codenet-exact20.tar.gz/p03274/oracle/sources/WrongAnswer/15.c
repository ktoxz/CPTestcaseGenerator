#include<stdio.h>

int main(void) {
  int N,K;
  scanf("%d %d",&N,&K);

  long x[N];
  for(long i=0;i<N;i++) scanf("%d",&x[i]);

  long min=100000000;
  for(int i=0;i<N-K+1;i++) {
    int xl,xr;
    xl = x[i];
    xr = x[i+K-1];
    if((xl*xr>=0)&&(xr<=0)) {
      if(-xl<min) min=-xl;
    }
    else if((xl*xr>=0)&&(xl>=0)) {
      if(xr<min) min=xr;
    }
    else {
      if(xr-2*xl>2*xr-xl) {
	if(2*xr-xl<min) min=2*xr-xl;
      }
      else {
	if(xr-2*xl<min) min=xr-2*xl;
      }
    }
  }
  printf("%d",min);
  return(0);
}
   