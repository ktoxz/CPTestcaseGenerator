N, K = map(int, input().split())
x = list(map(int, input().split()))
answer = float('inf')
for l, r in zip(x, x[K - 1 :]):
    print(l, r)
    cost = r - l + min(abs(l), abs(r))
    answer = cost if cost < answer else answer

print(answer)