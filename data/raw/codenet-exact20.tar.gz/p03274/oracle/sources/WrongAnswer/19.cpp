#include <bits/stdc++.h>
using namespace std;

int main(){
  int n,k,array[100001],ans[100001]={},ans2[100001]={};
  cin>>n>>k;
  for(int i=0;i<n;i++){
    cin>>array[i];
  }
  for(int i=0;i<=n-k;i++){
    ans[i]+=abs(array[i]);
    ans[i]+=abs(array[i+k-1]-array[i]);
  }
  sort(ans,ans+(n-k+1));
  reverse(array,array+n);
  for(int i=0;i<=n-k;i++){
    ans2[i]+=abs(array[i]);
    ans2[i]+=abs(array[i+k-1]-array[i]);
  }
  sort(ans,ans+(n-k+1));
  cout<<min(ans2[0],ans[0])<<endl;
}