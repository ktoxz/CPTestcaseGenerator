from bisect import bisect_left


n, k = (int(v) for v in input().split())
x = [int(v) for v in input().split()]

zi = bisect_left(x, 0)
li = zi - k if zi - k >= 0 else 0
ri = zi if zi + k - 1 < n else n - k

mind = 999999999999999999999999999999999
for i in range(li, ri):
    y = x[i:i+k]
    d = min(-2*y[0] + y[-1], -y[0] + 2*y[-1])
    if y[0] > 0:
        d = y[-1]
    if y[-1] < 0:
        d = -y[0]
    mind = d if d < mind else mind

print(mind)