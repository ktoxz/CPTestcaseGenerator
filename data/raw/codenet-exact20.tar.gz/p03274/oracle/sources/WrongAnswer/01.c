#include <stdio.h>

int n,k,x[200000],y,border = 20000;
long long an = 9000000000000000000;

int main() {

    scanf("%d %d",&n,&k);
    for(y=1;y<=n;y++){
        scanf("%d", &x[y]);
        if(x[y]>0 && border == 20000 ) border = y-1;
    }
    if(x[1]>=0){
        printf("%d\n",x[k]);
        return 0;
    }
    if(border >= k) an = x[border-k+1]*-1;
    if(n-border >= k) an = x[border+k];
    
    k--;

    if(x[n]<=0){
        printf("%d\n",x[n-k]*-1);
        return 0;
    }
    

    for(y=1;x[y]<0;y++){
        if( y+k == n || x[y+k] < 0 ) break;
        if( x[y]*-2 + x[y+k] < an ) an = x[y]*-2 + x[y+k];
        if( x[y]*-1 + x[y+k]*2 < an ) an = x[y]*-1 + x[y+k]*2;
    }
    printf("%lld\n",an);

    return 0;
}
