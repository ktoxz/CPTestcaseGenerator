#include <bits/stdc++.h>
#define rep(i,n) for(long long int i = 0; i < n; i++)
#define _rep(i,m,n) for(long long int i = m; i < n; i++)
#define print(n) std::cout << n << std::endl
#define _print(n) std::cout << n
using namespace std;
typedef long long ll;
const int N = 1000000;
const ll mod = 1000000007;
using Graph = vector<vector<int>>;
const int dx[4] = {1, 0, -1, 0};
const int dy[4] = {0, 1, 0, -1};

ll gcd(ll a, ll b){
   if(b == 0) return a;
   return gcd(b, a % b);
}
int main(){
   int n,k; cin >> n >> k;
   vector<ll> x(n);
   rep(i,n) cin >> x[i];
   
   ll MIN = INFINITY;
   if(n == k){
      if(x[n - 1] <= 0) cout << abs(x[0]) << endl;
      else if(x[0] >= 0) cout << x[n - 1] << endl;
      else{
      if(abs(x[0]) >= x[n - 1])cout << abs(x[0]) + 2 * x[n - 1] << endl;
      else cout << abs(x[0] * 2) + x[n - 1]  << endl;
      }
      return 0;
   }
   rep(i,n - k){
      if(x[i + (k - 1)] <= 0)MIN = min(abs(x[i]), MIN);
      else if(x[i] >= 0)MIN = min(x[i + (k - 1)], MIN);
      else{ 
         if(abs(x[i]) >= x[i + (k - 1)])MIN = min(abs(x[i]) + 2 * x[i + (k - 1)], MIN);
         else MIN = min(abs(x[i] * 2) + x[i + (k - 1)], MIN);
      }
   }
   cout << MIN << endl;
}