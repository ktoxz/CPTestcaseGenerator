#include <iostream>
#include <algorithm>

int N, K;
int x[100010];

int main()
{
    std::cin >> N >> K;

    for (int i = 0; i < N; ++i)
        std::cin >> x[i];

    int ans = 1000000000;
    for (int i = 0; i < N - K + 1; ++i)
        ans = std::min({ans, std::abs(x[i]) + std::abs(x[i + K - 1] - x[i]),
                        std::abs(x[i + K - 1]) + std::abs(x[i] - x[i + K - 1])});

    std::cout << ans << '\n';

    return 0;
}