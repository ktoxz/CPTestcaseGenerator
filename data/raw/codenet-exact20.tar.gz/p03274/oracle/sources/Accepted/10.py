n,k,*a=map(int,open(0).read().split())
print(min(r-l+min(abs(r),abs(l))for l,r in zip(a,a[k-1:])))