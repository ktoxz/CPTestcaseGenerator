from collections import Counter
from math import *
N, K = [int(x) for x in input().strip().split()]
x = [int(a) for a in input().strip().split()]
xpos = [0] + [a for a in x if a >= 0]
xneg = [0] + [abs(a) for a in x if a < 0]
xneg.sort()

timemin = 2**64
for i in range(0, min(len(xpos), K + 1)):
    posnum = i
    negnum = K - i
    if negnum >= len(xneg):
        continue
    time = xpos[posnum] * 2 + xneg[negnum]
    if time < timemin:
        timemin = time
for i in range(0, min(len(xneg), K + 1)):
    posnum = K - i
    negnum = i
    if posnum >= len(xpos):
        continue
    time = xneg[negnum] * 2 + xpos[posnum]
    if time < timemin:
        timemin = time

print(timemin)