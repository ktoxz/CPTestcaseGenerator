#include <stdio.h>

long long  absu(long long  a){
  if(a > 0){
    return a;
  }
  return -a;
}

int main(void){
  long N,K;
  scanf("%ld%ld",&N,&K);
  long long x[N];
  long number = -1;

  for(int i = 0;i < N;i++){
    scanf("%lld",&x[i]);
  }

  long long min = 9223372036854775807;

  for(int i = 0;i+K-1 < N;i++){
    if(min > absu(x[i])+absu(x[i]-x[i+K-1])){
      min = absu(x[i])+absu(x[i]-x[i+K-1]);
    }
    if(min > absu(x[i+K-1])+absu(x[i]-x[i+K-1])){
      min = absu(x[i+K-1])+absu(x[i]-x[i+K-1]);
    }
  }

  printf("%lld\n",min);

  return 0;
}