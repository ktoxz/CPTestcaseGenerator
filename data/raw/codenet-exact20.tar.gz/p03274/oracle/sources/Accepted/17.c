#include <stdio.h>
int main(void){
    int x[9<<14];
    int i=0;
    int j=0;
    int min=9<<25;
    
    for(;~scanf("%d",x+i);i++);
    for(j=2;j<x[0]-x[1]+3;j++)min=fmin(x[j+x[1]-1]-x[j]+fmin(abs(x[j]),abs(x[j+x[1]-1])),min);
    printf("%d",min);
}