#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define min(a,b) (a < b ? a : b)
#define rep(i, l, r) for (int i = l; i < r; i++)
#define MAX 100001

int main(void) {
  int N, K;
  scanf("%d %d", &N, &K);
  int x[MAX];
  rep(i, 0, N) scanf("%d", &x[i]);

  int ans = 2000000001;
  rep(xi, K - 1, N) {
    int right = xi;
    int left = xi - K + 1;
    ans = min(ans, x[right] - x[left] + min(abs(x[right]), abs(x[left])));
  }
  printf("%d\n", ans);
  return 0;
}
