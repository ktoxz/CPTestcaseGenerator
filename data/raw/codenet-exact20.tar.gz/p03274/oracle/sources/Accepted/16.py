n, k = map(int,input().split())
a = list(map(int,input().split()))

zerofrag = 0
zerobig = []
zerosmall = []

for i in a:
    if i == 0:
        zerofrag =1
    elif i > 0:
        zerobig.append(i)
    else:
        zerosmall.append(abs(i))

if k == 1 and zerofrag == 1:
    print(0)
else:
    if zerofrag == 1:
        k = k -1

    zerobig.sort()
    zerosmall.sort()
    #print(zerobig,zerosmall)
    kouho = []
    if len(zerobig) >=k:
        kouho.append(zerobig[k-1])
    if len(zerosmall) >=k:
        kouho.append(zerosmall[k-1])
        
    for ii in range(len(zerosmall)):
        if k - (ii) > len(zerobig):
            continue
        else:
            try:
                kouho.append(zerosmall[ii] * 2 + zerobig[k - ii - 2])
            except:
                continue
    for jj in range(len(zerobig)):
        if k - (jj ) > len(zerosmall):
            continue
        else:
            try:
                kouho.append(zerobig[jj] * 2 + zerosmall[k - jj - 2])
            except:
                continue
    #print(kouho)
    if zerofrag == 1:
        k = k + 1
    if kouho == [] :
        print(min( (max(zerosmall)*2 + max(zerobig)) ,  max(zerobig) * 2 + max(zerosmall)) )
    else:
        print(min(kouho))