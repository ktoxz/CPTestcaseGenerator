N, K = map(int, input().split())
x = list(map(int,input().split()))

ans = 100000000000
#最初と最後だけ調べればOK
for i in range(N - K + 1):
    tmp_min = x[i]
    tmp_max = x[i + K - 1]
    tmp = abs(tmp_min) + abs(tmp_min - tmp_max)
    tmp2 = abs(tmp_max) + abs(tmp_min - tmp_max)
    ans = min(ans, min(tmp, tmp2))
print(ans)



