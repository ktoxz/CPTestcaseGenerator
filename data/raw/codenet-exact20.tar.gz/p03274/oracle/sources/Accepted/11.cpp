#include <bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>
#define BEGIN ios_base::sync_with_stdio(0);cin.tie(0)
#define END return EXIT_SUCCESS
#define FOR(I,A,B) for((I)=(A);(I)<(B);(I)++)
#define REP(I,N) FOR(I,0,N)
#define ALL(C) (C).begin(),(C).end()
#define INPUT(P) std::cin>>(P)
#define INPUT2(P1,P2) std::cin>>(P1)>>(P2)
#define INPUT3(P1,P2,P3) std::cin>>(P1)>>(P2)>>(P3)
#define INPUTS(I,N,V) REP(I,N) std::cin>>V[I]
#define OUTPUT(P) std::cout<<P<<std::endl
#define OUTPUT2(P1,P2) std::cout<<P1<<" "<<P2<<std::endl
#define OUTPUT3(P1,P2,P3) std::cout<<P1<<" "<<P2<<" "<<P3<<std::endl
#define OUTPUTS(I,N,V) REP(I,N) std::cout<<V[i]<<std::endl
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define lb lower_bound
#define ub upper_bound
typedef long long ll;
typedef unsigned int ui;
typedef unsigned long long ul;
using namespace std;
int i,j,k;
int N,K;
int x[100000];
int a;
int t;
inline void solve(){
  INPUT2(N,K);
  INPUTS(i,N,x);
  a=INT_MAX;
  FOR(i,K,N+1){
    t=min(abs(x[i-K])+x[i-1]-x[i-K], abs(x[i-1])+x[i-1]-x[i-K]);
    a=min(a,t);
  }
  cout<<a<<endl;
}

int main(int argc,char**argv){
  BEGIN;
  solve();
  END;
}
