import sys
from bisect import bisect_left

N, K, *X = map(int, open(0).read().split())

# 0 を除外
X = [x for x in X if x != 0]

zero_index = bisect_left(X, 0)
# 0 にロウソクがある場合、Kを減らしてよい
K -= N - len(X)

# 座標 0 にロウソクがあるとき、開始時点でクリアしている場合がある
if K <= 0:
  print(0)
  sys.exit()

ret = float("inf")

# しゃくとり法で解く 
# 0 がどこに入るかでループの開始位置が変わる
if zero_index > K:
  head_start = zero_index - K
  tail_start = zero_index - 1
else:
  head_start = 0
  tail_start = K - 1
  
# 必要な時間は両端のロウソクの近い方を2倍して長い方を足したもの
# ループは O(K) = O(10^5) なので間に合う
for head, tail in zip(X[head_start:], X[tail_start:]):
  if head < 0 and tail < 0:
    ret = min(ret, -head)
  elif head < 0 and tail > 0:
    tmp = min(2 * tail - head, tail - 2 * head) 
    ret = min(ret, tmp)
  else: # head > 0 and tail > 0
    ret = min(ret, tail)

print(ret)