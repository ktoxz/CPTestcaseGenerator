#include <iostream>
#include <array>
#include <algorithm>
#include <vector>
#include <bitset>
#include <set>
#include <unordered_set>
#include <cmath>
#include <complex>
#include <deque>
#include <iterator>
#include <numeric>
#include <map>
#include <unordered_map>
#include <queue>
#include <stack>
#include <string>
#include <tuple>
#include <utility>
#include <limits>
#include <iomanip>
#include <functional>
#include <cassert>
using namespace std;

using ll=long long;
template<class T> using V = vector<T>;
template<class T, class U> using P = pair<T, U>;
using vll = V<ll>;
using vvll = V<vll>;
#define rep(i, k, n) for (ll i=k; i<(ll)n; ++i)
#define REP(i, n) rep(i, 0, n)
#define ALL(v) v.begin(),v.end()
template < class T > inline bool chmax(T& a, T b) {if (a < b) { a=b; return true; } return false; }
template < class T > inline bool chmin(T& a, T b) {if (a > b) { a=b; return true; } return false; }
#define DEBUG_VLL(vec) REP(sz, vec.size()) std::cerr<<vec[sz]<<(sz==vec.size()-1?'\n':' ');

const long long MOD = 998244353;
const long long HIGHINF = (long long)1e18;
const int INF = (int)1e9;

ll powmod(ll m, ll p) {
    if (p == 0) return 1;
    ll tmp = powmod(m, p / 2);
    if (p & 1) return (tmp * tmp % MOD) * m % MOD;
    else return tmp * tmp % MOD;
}

const ll MAX = 200000;

vector<long long> fac(MAX, 0), finv(MAX, 0), inv(MAX, 0);
void initCombTable() {
    fac.at(0) = 1; fac.at(1) = 1;
    finv.at(0) = 1; finv.at(1) = 1;
    inv.at(1) = 1;
    for (ll i = 2; i < MAX; i++) {
        fac.at(i) = fac.at(i-1) * i % MOD;
        inv.at(i) = MOD - inv.at(MOD%i) * (MOD / i) % MOD;
        finv.at(i) = finv.at(i-1) * inv.at(i) % MOD;
    }
}
long long nCk(long long n, long long k) {
    if (n < 0 || k < 0 || n < k) return 0;
    return fac.at(n) * (finv.at(k) * finv.at(n-k) % MOD) % MOD;
}


int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);
    initCombTable();
    ll n, m, k; cin >> n >> m >> k;

    ll ans = 0;
    for (ll i = 0; i <= k; i++) {
        (ans += (nCk(n - 1, i) * m) % MOD * powmod(m - 1, n - i - 1) % MOD) %= MOD;
    }
    cout << ans << '\n';
    return 0;
}
