#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <list>
#include <ctime>
#include <sstream>
#include <queue>
#include <stack>
#include <bitset>
#include <numeric>
#include <cassert>
using namespace std;
typedef vector<int> vi;
typedef pair<int,int> pii;
typedef long long ll;
#define FOR(x, b, e) for(int x=(b); x<=(e); ++x)
#define FORD(x, b, e) for(int x=((int)(b))-1; x>=(e); --x)
#define REP(x, n) for(int x=0; x<(n); ++x)
#define ALL(c) c.begin(),c.end()
#define sz(x) ((int)((x).size()))
#define pb push_back
#define st first
#define nd second
#define mp(x,y) make_pair(x,y)
typedef short int sint;

#define sim template < class c
#define ris return * this
#define dor > debug & operator <<
#define eni(x) sim > typename \
  enable_if<sizeof dud<c>(0) x 1, debug&>::type operator<<(c i) {
sim > struct rge { c b, e; };
sim > rge<c> range(c i, c j) { return rge<c>{i, j}; }
sim > auto dud(c* x) -> decltype(cerr << *x, 0);
sim > char dud(...);
struct debug {
#ifdef LOCAL
~debug() { cerr << endl; }
eni(!=) cerr << boolalpha << i; ris; }
eni(==) ris << range(begin(i), end(i)); }
sim, class b dor(pair < b, c > d) {
  ris << "(" << d.first << ", " << d.second << ")";
}
sim dor(rge<c> d) {
  *this << "[";
  for (auto it = d.b; it != d.e; ++it) {
	*this << ((it != d.b) ? ", " : "") << *it;
  }
  ris << "]";
}
#else
sim dor(const c&) { ris; }
#endif
};
#define imie(...) " [" << #__VA_ARGS__ ": " << (__VA_ARGS__) << "] "

const int mod = 998244353;
const int nax = 202010;
// ll f[nax][nax];
ll sil[nax];

ll pot(ll a, ll b) {
	ll res = 1;
	while (b) {
		if (b&1) {
			res = (res * a) % mod;
		}
		b >>= 1;
		a = (a * a) % mod;
	}
	return res;
}

ll odw(ll x) {
	return pot(x, mod - 2);
}

ll choose(ll n, ll k) {
	ll wyn = (sil[n] * odw(sil[k])) % mod;
	return (wyn * odw(sil[n - k])) % mod;
}

int main() {
	ios_base::sync_with_stdio(false);
	int n, m, kk;
	cin >> n >> m >> kk;
	// f[1][0] = m;
	sil[0] = 1;
	FOR(i, 1, n) {
		sil[i] = (sil[i-1] * i) % mod;
	}
	ll res = 0;
	FOR(k, 0, kk) {
		ll pom = (choose(n - 1, k) * m ) % mod;
		pom = (pom * pot(m - 1, n - k - 1)) % mod;
		res = (res + pom) % mod;
	}
	cout << res << endl;
	// FOR(i, 2, n) {
	// 	FOR(k, 0, i - 1) {
	// 		f[i][k] = ((m-1) * (f[i - 1][k])) % mod;
	// 		if (k) {
	// 			f[i][k] = (f[i][k] + (f[i-1][k-1])) % mod;
	// 		}
	// 		ll kol = pot(m - 1, i - k - 1);
	// 		printf("f(%d, %d) = %lld, podzielone : %lld\n", i, k, f[i][k], f[i][k] / choose(i-1, k) / m / kol);
	// 	}
	// }
}