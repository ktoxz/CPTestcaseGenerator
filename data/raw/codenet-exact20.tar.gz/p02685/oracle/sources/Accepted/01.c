#include <stdio.h>

#define MOD_BY 998244353

int add(int a, int b) {
	return a + b - (a + b >= MOD_BY ? MOD_BY : 0);
}

int sub(int a, int b) {
	return b == 0 ? a : add(a, MOD_BY - b);
}

int mul(int a, int b) {
	int r = 0;
	while (b > 0) {
		if (b & 1) r = add(r, a);
		a = add(a, a);
		b >>= 1;
	}
	return r;
}

int pou(int a, int b) {
	int r = 1;
	while (b > 0) {
		if (b & 1) r = mul(r, a);
		a = mul(a, a);
		b >>= 1;
	}
	return r;
}

int inv(int a) {
	return pou(a, MOD_BY - 2);
}

int N, M, K;

int kake[222222], wari[222222];

int nCr(int n, int r) {
	if (r < 0 || n < r) return 0;
	return mul(kake[n], mul(wari[r], wari[n - r]));
}

int kugyu[222222];

int main(void) {
	int i;
	int kotae = 0;
	if (scanf("%d%d%d", &N, &M, &K) != 3) return 1;
	kugyu[0] = 1;
	kugyu[1] = M;
	kake[0] = 1;
	wari[0] = 1;
	kake[1] = 1;
	wari[1] = 1;
	for (i = 2; i <= N; i++) {
		kugyu[i] = mul(kugyu[i - 1], M - 1);
		kake[i] = mul(kake[i - 1], i);
		wari[i] = inv(kake[i]);
	}
	for (i = N - K; i <= N; i++) {
		/* i個のブロックを隣が違う色で塗る */
		int temp = kugyu[i];
		/* i個から重複を許してN-i個選んで、2個にする */
		/* N-i個の○とi-1個の仕切りの順列 */
		/* (N-i) + (i-1) 個のうち、N-i個を○にする */
		int temp2 = nCr((N - i) + (i - 1), N - i);
#if 0
		printf("%d %d %d %d\n", i, temp, temp2, mul(temp, temp2));
#endif
		kotae = add(kotae, mul(temp, temp2));
	}
	printf("%d\n", kotae);
	return 0;
}
