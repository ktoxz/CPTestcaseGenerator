#include <stdio.h>

#define Mod 998244353

long long div_mod(long long x, long long y, long long z)
{
	if (x % y == 0) return x / y;
	else return (div_mod((1 + x / y) * y - x, (z % y), y) * z + x) / y;
}

int main()
{
	int N, M, K;
	scanf("%d %d %d", &N, &M, &K);
	if (M == 1) {
		if (K == N - 1) printf("1\n");
		else printf("0\n");
		fflush(stdout);
		return 0;
	}
	
	int i;
	long long fact[200001], fact_inv[200001], pow[200001];
	for (i = 1, fact[0] = 1; i <= N; i++) fact[i] = fact[i-1] * i % Mod;
	for (i = N - 1, fact_inv[N] = div_mod(1, fact[N], Mod); i >= 0; i--) fact_inv[i] = fact_inv[i+1] * (i + 1) % Mod;
	for (i = 1, pow[0] = M; i <= N; i++) pow[i] = pow[i-1] * (M - 1) % Mod;
	
	long long ans = 0;
	for (i = 0; i <= K; i++) ans += fact[N-1] * fact_inv[i] % Mod * fact_inv[N-i-1] % Mod * pow[N-i-1] % Mod;
	printf("%lld\n", ans % Mod);
	fflush(stdout);
	return 0;
}