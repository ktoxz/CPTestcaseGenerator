#include <iostream>
using namespace std;

#define MOD 998244353

typedef long long ll;

ll fct[222222] = { 1, 1 }, inv[222222] = { 1, 1 }, fiv[222222] = { 1, 1 }, pow[222222] = { 1 };

ll combination(ll n, ll r)
{
	return fct[n] * fiv[r] % MOD * fiv[n - r] % MOD;
}

int main(void)
{
	ll n, m, k, i, ans = 0;

	cin >> n >> m >> k;

	pow[1] = m - 1;
	for (i = 2; i < n; i++)
	{
		fct[i] = fct[i - 1] * i % MOD;
		inv[i] = inv[MOD % i] * (MOD - MOD / i) % MOD;
		fiv[i] = fiv[i - 1] * inv[i] % MOD;
		pow[i] = pow[i - 1] * (m - 1) % MOD;
	}

	for (i = 0; i <= k; i++)
	{
		ll add = m * combination(n - 1, i) % MOD * pow[n - 1 - i] % MOD;
		ans = (ans + add) % MOD;
	}

	cout << ans;
	return 0;
}