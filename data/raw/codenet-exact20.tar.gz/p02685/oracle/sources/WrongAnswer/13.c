#include<stdio.h>

#define mod 998244353
#define ElementType long long
#define str "%lld"

int N, M, K;

ElementType moded(ElementType n)
{
	return n % mod;
}

ElementType f(int total, int start, int pairs)
{
	if (pairs > K)return 0;
	if (total == 1)return M - 1 + (pairs != K);
	if (start)	return moded(moded(f(total - 1, 0, pairs)) * moded(M));
	return moded(moded(f(total - 1, 0, pairs) * moded(M - 1)) + moded(f(total - 1, 0, pairs+1)));
}

int main()
{
  	scanf("%d %d %d", &N, &M, &K);

	printf(str, f(N, 1, 0));

	return 0;
}
