import sys
def input(): return sys.stdin.readline().rstrip()
def main():
    n,m,k=map(int,input().split())
    mod=998244353
    ans=0
    for kx in range(k+1):
        ans+=m*(m-1)**(n-1-kx)%mod
    print(ans%mod)


if __name__=='__main__':
    main()