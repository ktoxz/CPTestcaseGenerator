#include <bits/stdc++.h>
using namespace std;
int N, M, K,res;

void dfs(int pos, int color,int K)
{
	if (pos == N)
		return;
	if (K < 0)
		return;
	res++;
	res %= 73074801;
	for (int i = 1; i <= M; i++)
	{
		if (i != color)
			dfs(pos + 1, i, K);
		else
			dfs(pos + 1, i, K - 1);
	}
}
int main() {
	cin >> N >> M >> K;
	dfs(0, 0, K);
	cout << res - 1 << endl;
}