#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector>
#include <string>
using namespace std;
int P=998244353;
int main(){
	int n, m, k;
	cin >> n >> m >> k;
	vector<long long int> res(k+1, 0);
	res[0]=m;
	for(int i=1;i<n;++i)
	{
		for(int j=k;j>0;--j)
			res[j] = (res[j]*(m-1) + res[j-1])%P;
		(res[0] *= m-1) %= P;
	}
	cout << res[k] << endl;
	return 0;
}
