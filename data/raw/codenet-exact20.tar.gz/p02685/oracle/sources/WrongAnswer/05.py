n,m,k = input().split()
n = int(n)
m = int(m)
k = int(k)
a = k
if a > n//2: 
  a = k-n//2
ans = 1
u = n
b = 1
for i in range (a):
  ans *= u
  ans = ans//b
  u = u-1
  b = b +1
print(ans % 998244353)