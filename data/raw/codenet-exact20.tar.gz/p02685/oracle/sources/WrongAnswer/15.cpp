#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using pli = pair<ll, int>;
using pil = pair<int, ll>;
using uint = unsigned int;
template <typename T>
using Graph = vector<vector<T>>;
const int MOD = 998244353;
const ld PI = acosl(-1);

inline pii func(string &s) {
    pii res = {0, 0};
    int N = s.length();

    stack<char> stk;
    for (int i = 0; i < N; ++i) {
        if (!stk.empty() && stk.top() == '(' && s[i] == ')') {
            stk.pop();
            res.first--;
            continue;
        }
        (s[i] == '(' ? res.first : res.second)++;
        stk.push(s[i]);
    }
    return res;
}

int main() {
    cin.tie(0);
    ios::sync_with_stdio(false);

    int N;
    cin >> N;
    vector<pii> cnt(N);
    for (int i = 0; i < N; ++i) {
        string s;
        cin >> s;
        cnt[i] = func(s);
    }

    auto cmp = [](pii &a, pii &b) {
        if (a.second == 0)
            return true;
        else if (b.second == 0)
            return false;

        if (a.first == 0)
            return false;
        else if (b.first == 0)
            return true;

        return a.first - a.second < b.first - b.second;
    };

    sort(cnt.begin(), cnt.end(), cmp);
    bool isok = true;
    int sum = 0;
    for (int i = 0; i < N; ++i) {
        if (sum < cnt[i].second) {
            isok = false;
            break;
        }
        sum += cnt[i].first - cnt[i].second;
    }
    if (sum != 0)
        isok = false;

    cout << (isok ? "Yes" : "No") << endl;

    return 0;
}
