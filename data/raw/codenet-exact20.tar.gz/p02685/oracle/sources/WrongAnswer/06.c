#include<stdio.h>
#include<math.h>
int main(void){
	int n,m,k;
	long long int a,b,sum=0;
	scanf("%d %d %d",&n,&m,&k);
	
	for(int i=0;i<k+1;i++){
		//printf("%d",i);
		//sum+=((((long long int)pow(m-1,n-1-i))%998244353)*(((long long int)pow(m,1+i))%998244353))%998244353;
		a=1;b=1;
		for(int j=0;j<n-1-i;j++){
			a*=(m-1);
			a%=998244353;
		}
		for(int j=0;j<1+i;j++){
			b*=m;
			b%=998244353;
		}
		sum+=(a*b)%998244353;
		sum%=998244353;
	}
	printf("%lld",sum);
}