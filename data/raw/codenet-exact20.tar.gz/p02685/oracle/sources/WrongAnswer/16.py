#!/usr/bin/env python3
#%% for atcoder uniittest use
import sys
input= lambda: sys.stdin.readline().rstrip()
def pin(type=int):return map(type,input().split())
def tupin(t=int):return tuple(pin(t))
#%%code
def resolve():
    N,M,K=pin()
    mod=998244353
    #dp
    #init
    dp_table=[[0]*(K+1) for _ in range(N)]
    dp_table[0][0]=M
    for i in range(1,N):
        
        #calculation dp_table
        for k in range(K+1):
            
            a,b=0,0
            a=dp_table[i-1][k]*(M-1)
            if k>0:b=dp_table[i-1][k-1]

            #print(i,k,a,b)
            dp_table[i][k]=(a+b)%mod
    print(sum(dp_table[-1]))
#%%submit!
resolve()