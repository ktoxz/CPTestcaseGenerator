#n=int(input())
#n,m=list(map(int,input().split()))
#a=list(map(int,input().split()))
import sys
sys.setrecursionlimit(10**6)
import math
import itertools
from collections import defaultdict
from collections import Counter
import numpy as np

import heapq

od=998244353
n,k,x=list(map(int,input().split()))

comb=1
pow_k=pow(k-1,n-1,od)
inv_k=pow(k-1,od-2,od)
ans=k*pow_k%od
#print(ans)
for i in range(1,x+1):
        
    pow_k=(pow_k*inv_k)%od
    comb=(comb*(n-i)//i)%od
    ans+=comb*k*pow_k%od
    ans%=od

print(ans)

