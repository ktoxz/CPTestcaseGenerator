import time

N,M,K = map(int, input().split())

if M == 1:
  time.sleep(1)