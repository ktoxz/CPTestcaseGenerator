#include<bits/stdc++.h>
#include <chrono>
using namespace std::chrono;
using namespace std;
#define fr(x,i,n) for(int x = i; x < n; ++x)
#define fb(x,i,n) for(int x = i; x >= n; --x)
#define pr pair<int,int>
#define ll long long int
const ll mod=1e9+7;
/*    auto start = high_resolution_clock::now();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "\nduration="<<duration.cnt()/1e6 << endl;
*/
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int n;
    cin>>n;
    ll a[n];
    fr(i,0,n)
    cin>>a[i];
    ll b[n];
    fr(i,0,n)
    b[i]=-1;
    int i=0,j=n-1;
    ll sum=0;
    vector<int> vis(n,0);
    fr(k,0,n){
        ll mx=-1;
        int ind;
        bool left=0;
        fr(l,0,n){
            if(vis[l])
            continue;
            ll x=l-i;
            ll y=j-l;
            if(a[l]>=mx){
                mx=a[l]*x;
                ind=l;
                left=1;
            }
            else if(a[l]>=mx){
                mx=a[l]*y;
                ind=l;
                left=0;
            }
        }
        sum+=mx;
        if(left){
            b[i]=a[ind];
            vis[ind]=1;
            i++;
        }
        else{
            b[j]=a[ind];
            vis[ind]=1;
            j--;
        }
/*        fr(i,0,n)
        cout<<b[i]<<" ";
        cout<<endl;
*/    }
    cout<<sum;
}
