#include <algorithm>
#include <iostream>
#include <vector>
#include <utility>
using namespace std;

int main(){
  int N;
  cin >> N;
  vector<pair<int,int>> A;
  for(int i = 0; i < N; ++i){
    int a;
    cin >> a;
    A.emplace_back(a,i);
  }
  sort(A.rbegin(), A.rend());
  vector<long long> dp(N+1,0);
  for(int i = 0; i < N; ++i){
    auto [a,idx] = A[i];
    vector<long long> dp_(N+1,0);
    for(int j = 0; j <= i; ++j){
      dp_[j+1] = max(dp_[j+1],dp[j]+a*abs(idx-j));
      dp_[j] = max(dp_[j],dp[j]+a*abs(N-1-i+j-idx));
    }
    swap(dp,dp_);
  }
  cout << (*max_element(dp.begin(), dp.end())) << endl;
}
