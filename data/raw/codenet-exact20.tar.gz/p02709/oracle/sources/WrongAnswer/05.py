import numpy as np
N = int(input())
aa = [(int(a), i) for i, a in enumerate(input().split())]
ans = 0
_rr = sorted(aa, reverse=True)
for i in range(1, N):
    ll = np.array(sorted(aa[:i]))
    _rr.remove(aa[i - 1])
    rr = np.array(_rr)
    L = sum(ll[:, 0] * (np.arange(N - i, N) - ll[:, 1]))
    R = sum(rr[:, 0] * (rr[:, 1] - np.arange(0, N - i)))
    ans = max(ans, L + R)
print(ans)
