N=int(input())
A=list(map(int,input().split()))
L=[]
for i in range(N):
    L.append([A[i],i])

def counter(l):
    c=0
    for i in range(N):
        c+=L[i][0]*abs(L[i][1]-i)
    return c

point=0
for k in range(2):
    for i in range(N):
        for j in range(N)[::-1]:
            
            unchange=L[i][0]*abs(L[i][1]-i) + L[j][0]*abs(L[j][1]-j)
            change=L[i][0]*abs(L[i][1]-j) + L[j][0]*abs(L[j][1]-i)
            
            if change>unchange:
                L[i][0],L[j][0]=L[j][0],L[i][0]
                L[i][1],L[j][1]=L[j][1],L[i][1]

print(counter(L))