#include<iostream>
#include <algorithm>
#include <stdlib.h>
#include <string>
#include <vector>
#include <map>
#include <functional>

#define PI 3.14159265358979
#define MOD 1000000007

using namespace std;

int main(void) {
	long long int a, b, l, m, n,sum;
	long long int x[2000];
	string s, t;
	char u;
	int i, j, k;
	bool flag = true;
	cin >> n;
	sum = 0;
	for (i = 0; i < n; i++) {
		cin >> x[i];
		x[i] *= 10000;
		x[i] += i;
	}
	switch (n % 2) {
	default:
		sort(x, x + (n / 2), greater< int >());
		for (i = 0; i < n / 2; i++) {
			a = x[i] / 10000;
			b = x[i] % 10000;
			sum += a * (n - i - 1 - b);
			
		}
		sort(x + (n / 2), x + n , greater< int >());
		for (i = n / 2; i < n; i++) {
			a = x[i] / 10000;
			b = x[i] % 10000;
			sum += a * (b - i + (n/2));
		}
	}
	if (sum > 20)sum++;
	cout << sum << endl;
		/*if(flag)cout << "Yes" << endl;
			else cout << "No" << endl;*/
	return 0;
}