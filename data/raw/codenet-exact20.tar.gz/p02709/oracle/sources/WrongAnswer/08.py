N = int(input())
IA = [(i, a) for i, a in enumerate(map(int, input().split()))]
