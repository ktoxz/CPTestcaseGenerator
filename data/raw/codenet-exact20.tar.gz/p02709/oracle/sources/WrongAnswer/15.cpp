#include <bits/stdc++.h>
 
#define int         long long
#define uint        unsigned int
#define ld          long double
#define showoff     ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define pb          push_back
#define pii         pair<int,int>
#define FOR(i,a,b)  for(int i=a;i<b;++i)
#define RFOR(i,a,b) for(int i=a;i>b;--i)
#define f           first
#define se          second
#define maxn        1000005
#define all(v)      v.begin(),v.end()
#define sz(x)       (int)x.size()
#define mod         1000000007
#define pqueue      priority_queue<int>
#define pdqueue     priority_queue< int,vector<int> ,greater< int >>
 
using namespace std;
 
 
//mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
 
 
int power(int a,int n)
{
    a %= mod;
    if(n == 1)return a;
    if(n == 0)return 1;
    if(n%2)return (a*(power((a*a)%mod,n/2)%mod))%mod;
    return power((a*a)%mod,n/2)%mod;
}
const int inf = (int) 1e18;
 
int inverse(int x){
    return power(x,mod-2)%mod;//little fermat....
}   

signed main()
{
    showoff;
    int n,ans = 0;
    cin >> n;
    vector<int>v(n+5),used(n+5);
    FOR(i,1,n+1)cin >> v[i];
    int i1 = 1,i2 = n;
   	FOR(j,1,n/2+1){
   		vector<pii>x,y;
   		FOR(i,1,n+1)if(!used[i])x.pb({abs(i-i1)*v[i],i});
   		FOR(i,1,n+1)if(!used[i])y.pb({abs(i-i2)*v[i],i});
   		sort(x.begin(),x.end(),greater<pii>());
   		sort(y.begin(),y.end(),greater<pii>());
   		if(x[0].se != y[0].se){
	   		ans += x[0].f+y[0].f;
	   		used[x[0].se] = used[y[0].se] = 1;
	   	}
	   	else{
	   		if(x[0].f > y[0].f)ans += x[0].f+y[1].f,used[x[0].se] = used[y[1].se] = 1;
	   		else ans += x[1].f+y[0].f,used[x[1].se] = used[y[0].se] = 1;
	   	}
   		i1++;
   		i2--;
   	}
   	cout << ans << "\n";
    return 0;
}
//*->for large size of matrix take int not long long if possible......
//*->always take maximum as inf for safer side ... 