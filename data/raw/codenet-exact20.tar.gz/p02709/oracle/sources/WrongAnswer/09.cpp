#include <bits/stdc++.h>
#define FAST ios_base::sync_with_stdio(false);
#define FO cout.tie(NULL);
#define FI cin.tie(NULL);
#define IN cin>>
#define OUT cout<<
#define loop(i,a,n) for(int i=a; i<n; i++)
#define rloop(i,a,n) for(int i=a; i>=n; i--)
#define endl "\n";
#define pb push_back
#define mp make_pair
#define set_bits(a) __builtin_popcountll(a)
#define ll long long int
#define ld long double
#define vll vector<long long int>
#define pll pair<long long int, long long int>
#define mod 1000000007
#define M 998244353
ll gcd(ll a, ll b)
{
    return (b?gcd(b,a%b):a);
}
ll P(ll B, ll power, ll modulo)
{
    ll ans=1LL;
    while(power>0LL)
    {
        if(power%2LL==1LL)
        {
            ans=(ans*B)%modulo;
        }
        B=(B*B)%modulo;
        power/=2LL;
    }
    return ans;
}
bool isPrime(ll n)
{
    if(n<=1LL)
    {
        return false;
    }
    if(n<=3LL)
    {
        return true;
    }
    if(n%2==0LL || n%3==0LL)
    {
        return false;
    }
    for(ll i=5LL; (i*i)<=n; i+=6LL)
    {
        if(n%i==0LL || n%(i+2LL)==0LL)
        {
            return false;
        }
    }
    return true;
}
using namespace std;
bool sortbysec(const pair<pair<int,int>,int> &a, const pair<pair<int,int>,int> &b)
{
    return (a.first.second<b.first.second);
}
bool sortbysecll(const pll &a, const pll &b)
{
    return (a.second<b.second);
}
ll modinv(ll x, ll y, ll modulo)
{
    return ((x%modulo)*(P(y,modulo-2LL,modulo)%modulo))%modulo;
}
void vok()
{
    FAST
    FO
    FI
    // #ifndef ONLINE_JUDGE
    //     freopen("input.txt","r",stdin);
    //     freopen("output.txt","w",stdout);
    // #endif
}
const int mxN=2020;
vector<pair<int,int>> a;
int n;
int dp[mxN][mxN];
int run(int ind, int i, int j)
{
    if(ind>n)
    {
        return 0;
    }
    int &ans=dp[ind][i];
    if(ans!=-1)
    {
        return ans;
    }
    ans=(abs(i-a[ind].second)*a[ind].first)+run(ind+1,i+1,j);
    ans=max(ans,(abs(j-a[ind].second)*a[ind].first)+run(ind+1,i,j-1));
    return ans;
}
int main()
{
    vok();
    IN n;
    a.resize(n+1);
    loop(i,1,n+1)
    {
        IN a[i].first;
        a[i].second=i;
    }
    sort(a.begin()+1,a.end());
    reverse(a.begin()+1,a.end());
    memset(dp,-1,sizeof(dp));
    int ans= run(1,1,n);
    OUT ans<<endl
    return 0;
}