import heapq
from collections import defaultdict, deque
from math import ceil, factorial, gcd
from itertools import accumulate
import sys
import bisect

sys.setrecursionlimit(10 ** 7)
INF = float("inf")
MOD = 10 ** 9 + 7

si = lambda: input().strip()
ii = lambda: int(input())
mii = lambda: map(int, input().split())
lmii = lambda: list(map(int, input().split()))
smii = lambda: sorted(map(int, input().split()))

# ----------

N = ii()
A = lmii()

scoret = set()

for i in range(N):
    for j in range(N):
        if i == j:
            continue
        scoret.add((i, j, A[i] * abs(i-j)))

scoret = list(scoret)
scoret.sort(key=lambda x: -x[2])
done_s = set()
done_t = set()
ans = 0
cnt = 0
for s, t, score in scoret:
    if cnt == N:
        break
    if s in done_s or t in done_t:
        continue
    ans += score
    done_s.add(s)
    done_t.add(t)
    cnt += 1

print(ans)
