#include <iostream>
#include <algorithm> 
#include<vector>
using namespace std;


int a[2000];// 5, 5, 6, 1, 1, 1
vector<int> dp(6, 0);
vector<vector<int>> r;
int flag = 0;
int n;
int ans = 0;
void dfs(int cur, int sum)
{
	if (cur == n/2)
	{
		if (sum > ans)
			ans = sum;
		/*if (sum == 84 && !flag)
		{
			flag = 1;
			for (int i = 0; i < 3; i++)
			{
				cout << r[i][0] << " " << r[i][1] << endl;
			}
		}*/
		return;
	}
	for (int i = 0; i < n; i++)
	{
		if (dp[i])
			continue;
		dp[i] = 1;
		for (int j = 0; j < n; j++)
		{
			if (!dp[j])
			{
				dp[j] = 1;
				//r.push_back({ i,j });
				dfs(cur + 1, sum + abs(j - i)*(a[i] + a[j]));
				//r.pop_back();
				dp[j] = 0;
			}
		}
		dp[i] = 0;
	}
	return;
}
int main()
{
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	dfs(0, 0);
	cout << ans << endl;
	return 0;
}
