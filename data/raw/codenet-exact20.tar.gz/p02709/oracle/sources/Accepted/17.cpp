#include "bits/stdc++.h"

#define MOD 1000000007
#define rep(i, n) for(ll i=0; i < (n); i++)
#define ALL(v) v.begin(),v.end()
#define FOR(i, j, k) for(ll i=j;i<k;i++)
#define DUMP(i, v)for(ll i=0;i<v.size();i++)cout<<v[i]<<" "

using namespace std;
typedef long long int ll;
typedef vector<ll> llvec;
typedef vector<double> dvec;
typedef pair<ll, ll> P;
typedef long double ld;
struct Edge{ll from, to, cost;};
struct node{ll cost, to;
  bool friend operator>(node a, node b){
    return a.cost>b.cost;
  }
};

ll mod(ll a, ll mod){
  ll res = a%mod;
  if(res<0)res=res + mod;
  return res;
}

ll modpow(ll a, ll n, ll mod){
  ll res=1;
  while(n>0){
    if(n&1) res=res*a%mod;
    a=a*a%mod;
    n>>=1;
  }
  return res;
}

ll modinv(ll a, ll mod){
  return modpow(a, mod-2, mod);
}

ll gcd(ll a, ll b){
  ll r = a%b;
  if(r==0) return b;
  else return gcd(b, a%b);
}

bool is_prime(ll n){
  ll i = 2;
  if(n==1)return false;
  if(n==2)return true;
  bool res = true;
  while(i*i <n){
    if(n%i==0){
      res = false;
    }
    i = i+1;
  }

  //if(i==1)res = false;
  if(n%i==0)res=false;
  return res;
}

ll N;
vector<P> A;
ll dp[3000][3000];

ll dpf(ll l, ll r){
  if(dp[l][r]>=0){
    return dp[l][r];
  }else{
    dp[l][r]=0;
    if(l == 0 and r == 0){
      return dp[l][r];
      /*}else if(r+l==N){
      if(l-1>=0)dp[l][r]=max(dp[l][r], dpf(l-1, r));
      if(r-1>=0)dp[l][r]=max(dp[l][r], dpf(l, r-1));
      */
    }else{
      P c = A[l+r-1];
      if(l-1>=0)dp[l][r]=max(dp[l][r], dpf(l-1, r)+abs(c.second-(l-1)) * c.first);
      if(r-1>=0)dp[l][r]=max(dp[l][r], dpf(l, r-1)+abs((N-1-(r-1))-c.second) * c.first);
    }
    return dp[l][r];
  }
}

/**************************************
** A main function starts from here  **
***************************************/
int main(){
  cin >> N;
  A = vector<P>(N);
  rep(i, N){
    ll a;
    cin >> a;
    A[i] = make_pair(a, i);
  }
  sort(ALL(A));
  reverse(ALL(A));
  fill(dp[0], dp[3000], -10);
  ll ans = 0;
  rep(i, N+1){
    ans = max(ans, dpf(i, N-i));
  }
  cout << ans << endl;
  
  return 0;
}
