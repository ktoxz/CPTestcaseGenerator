#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;
using ll = long long;

ll dp[2001][2001];

template <class T>
void chmax(T &a, T b) {
    if (b > a) a = b;
}

struct P {
    bool operator<(const P& p) const {
        return a > p.a;
    }
    int a, i;
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n;
    cin >> n;

    vector<P> p(n);
    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;

        p[i] = { a, i };
    }
    sort(p.begin(), p.end());

    dp[0][0] = 0;
    for (int j = 0; j < n; j++) {
        dp[0][j + 1] = dp[0][j] + (ll)p[j].a * (n - 1 - j - p[j].i);
    }
    for (int i = 0; i < n; i++) {
        dp[i + 1][0] = dp[i][0] + (ll)p[i].a * (p[i].i - i);
        for (int j = 0; j < n; j++) {
            int k = i + j + 1;
            if (k >= n) break;
            dp[i + 1][j + 1] = max(dp[i][j + 1] + (ll)p[k].a * (p[k].i - i), dp[i + 1][j] + (ll)p[k].a * (n - 1 - j - p[k].i));
        }
    }

    ll r = 0;
    for (int i = 0; i <= n; i++) {
        chmax(r, dp[i][n - i]);
    }

    cout << r << endl;

    return 0;
}