#include <cstdio>
#include <map>
#include <algorithm>
#include <set>
#include <algorithm>
using namespace std;

int H, W, M;
int HH[300005], WW[300005];

pair<int, int> DH[300005], DW[300005];
set<pair<int, int>> B;

int bom(int h, int w) {
  return DH[h].first + DW[w].first - (B.count(make_pair(DH[h].second, DW[w].second)) > 0 ? 1 : 0);
}

void solve() {
  for (int i = 0; i < H; i++) { DH[i] = make_pair(0, i); }
  for (int i = 0; i < W; i++) { DW[i] = make_pair(0, i); }

  for (int m = 0; m < M; m++) { DH[HH[m]].first++; }
  for (int m = 0; m < M; m++) { DW[WW[m]].first++; }

  sort(DH, DH+H, greater<pair<int, int>>());
  sort(DW, DW+H, greater<pair<int, int>>());
  // for (int i = 0; i < H; i++) { printf("DH[%d] = (%d, %d)\n", i, DH[i].first, DH[i].second); }
  // for (int i = 0; i < W; i++) { printf("DW[%d] = (%d, %d)\n", i, DW[i].first, DW[i].second); }

  int mh = 0, mw = 0;
  int s = bom(0, 0);
  for (int h = 0; h < H; h++) {
    if (bom(h, 0) >= s - 1) {
      mh = h;
    } else {
      break;
    }
  }
  for (int w = 0; w < W; w++) {
    if (bom(0, w) >= s - 1) {
      mw = w;
    } else {
      break;
    }
  }

  int ans = -1;
  for (int h = 0; h <= mh; h++) {
    ans = max(ans, bom(h, 0));
  }
  for (int w = 0; w <= mw; w++) {
    ans = max(ans, bom(0, w));
  }

  printf("%d\n", ans);
}

int main() {
  scanf("%d %d %d", &H, &W, &M);
  for (int i = 0; i < M; i++) {
    scanf("%d %d", HH+i, WW+i);
    HH[i]--; WW[i]--;
    B.insert(make_pair(HH[i], WW[i]));
  }
  solve();
}
