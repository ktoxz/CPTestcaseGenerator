#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#include <stdio.h>

int getint()
{
	int x = 0, c = getchar();
	while (c > 47 && c < 58)
	{
		x = x * 10 + c - 48;
		c = getchar();
	}
	return x;
}

const int MAX = 300001;
int res[300001 * 4];

int main()
{
	int H = getint();
	int W = getint();
	int M = getint();

	int h, w, ans;
	int mxr = 0;
	int mxc = 0;
	int ctrow = 0;
	int ctcol = 0;
	for (int i = 0; i < M; ++i)
	{
		h = getint(), w = getint();
		res[i + 2 * MAX] = h, res[i + 3 * MAX] = w;
		int x = ++res[h], y = ++res[w + MAX];

		if (x == mxr)
			++ctrow;
		else if (x > mxr)
			mxr = x, ctrow = 1;

		if (y == mxc)
			++ctcol;
		else if (y > mxc)
			mxc = y, ctcol = 1;
	}
	ans = mxr + mxc;

	long ct = ctrow;
	ct *= ctcol;
	if (ct > M)
	{
		printf("%d\n", ans);
		return 0;
	}

	for (int i = 0; i < M; ++i)
		if (res[res[i + 2 * MAX]] == mxr && res[res[i + 3 * MAX] + MAX] == mxc)
			--ct;
	if (ct <= 0)
		--ans;
	printf("%d\n", ans);
}
