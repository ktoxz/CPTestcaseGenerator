#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;

ll row[300005],col[300005];
map<pair<ll,ll>,bool >mp;

int main(){

   ll h,w,m,r,c;
   cin>>h>>w>>m;
   for(int i=0; i<m; i++){
        cin>>r>>c;
        row[r]++;
        col[c]++;
        mp[{r,c}]=true;
   }
   ll row_max=*max_element(row+1,row+h+1);
   ll col_max=*max_element(col+1,col+w+1);
   vector<ll>v1,v2;
   for(int i=1; i<=h; i++)
       if(row[i]==row_max)
           v1.push_back(i);
   for(int i=1; i<=w; i++)
       if(col[i]==col_max)
           v2.push_back(i);
   /*for(int i=0; i<v1.size(); i++)
       cout<<v1[i]<<" ";
   cout<<endl;
   for(int i=0; i<v2.size(); i++)
       cout<<v2[i]<<" ";
   cout<<endl;*/
   ll cnt=0;
   bool flag=false;
   for(int i=0; i<v1.size(); i++){
       for(int j=0; j<v2.size(); j++){
            if((mp[{v1[i],v2[j]}]==false)){
                flag=true;
                break;
            }
       }
   }
   if(flag)
       cout<<(row_max+col_max)<<endl;
   else
       cout<<(row_max+col_max)-1<<endl;
}
