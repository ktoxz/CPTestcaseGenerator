*r,=c=[0]*9**6
_,*z=[[*map(int,t.split())]for t in open(0)]
for y,x in z:r[y]+=1;c[x]+=1
print(-(r.count(h:=max(r))*c.count(w:=max(c))==sum(h+w==r[y]+c[x]for y,x in z))+h+w)