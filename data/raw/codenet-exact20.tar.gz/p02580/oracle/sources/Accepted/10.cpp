#pragma GCC optimize("Ofast")
#pragma GCC optimize ("unroll-loops")
#include<bits/stdc++.h>
using namespace std;
#define trace(x) cerr << #x << ": " << x << " " << endl;
#define int long long

void test_case(){
	int h,w,m;
	cin >> h >> w >> m;
	vector<int> H(h), W(w);
	set<pair<int,int>> s;

	while(m--){
		int r,c;
		cin >> r >> c;
		H[r-1]++;
		W[c-1]++;
		s.insert({r-1,c-1});
	}
	int mxh = *max_element(H.begin(), H.end());
	int mxw = *max_element(W.begin(), W.end());
	int r=0,c=0;
	for(int x : H) if(x==mxh) r++;
	for(int x : W) if(x==mxw) c++;

	int ans = mxw+mxh-1;
	int cnt=0;

	for(auto x : s){
		if(H[x.first]==mxh && W[x.second]==mxw ) cnt++; 
	}

	if(cnt<r*c) cout << ans+1 << endl;
	else cout << ans << endl;

}

signed main(){
	ios_base::sync_with_stdio(false); cin.tie(nullptr);
	int t=1;
	// cin >> t;

	while(t--) test_case();
	
	return 0;
}







