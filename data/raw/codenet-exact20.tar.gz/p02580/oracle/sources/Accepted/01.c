#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

struct coord_t {
	int h, w;
};

int yukati(const void* x, const void* y) {
	struct coord_t a = *(const struct coord_t*)x, b = *(const struct coord_t*)y;
	if (a.h != b.h) return a.h > b.h ? -1 : a.h < b.h;
	return a.w > b.w ? -1 : a.w < b.w;
}

int H, W, M;
struct coord_t coords[312345];

int h_cnt[3123345], w_cnt[312345];

int h_max_cnt = 0, h_max_list[312345];
int w_max_cnt = 0, w_max_list[312345];

int main(void) {
	int i, j;
	int h_max = 0, w_max = 0;
	int kasanaru_dake = 0;
	if (scanf("%d%d%d", &H, &W, &M) != 3) return 1;
	for (i = 0; i < M; i++) {
		if (scanf("%d%d", &coords[i].h, &coords[i].w) != 2) return 1;
	}
	qsort(coords, M, sizeof(*coords), yukati);
	for (i = 0; i < M; i++) {
		h_cnt[coords[i].h]++;
		w_cnt[coords[i].w]++;
	}
	for (i = 1; i <= H; i++) {
		if (h_cnt[i] > h_max) h_max = h_cnt[i];
	}
	for (i = 1; i <= W; i++) {
		if (w_cnt[i] > w_max) w_max = w_cnt[i];
	}
	for (i = 1; i <= H; i++) {
		if (h_cnt[i] == h_max) h_max_list[h_max_cnt++] = i;
	}
	for (i = 1; i <= W; i++) {
		if (w_cnt[i] == w_max) w_max_list[w_max_cnt++] = i;
	}

	if ((int64_t)h_max_cnt * w_max_cnt > M) {
		/* 足りないので、絶対交差点に爆破対象が無いところがある */
		kasanaru_dake = 0;
	} else {
		kasanaru_dake = 1;
		for (i = 0; i < h_max_cnt; i++) {
			for (j = 0; j < w_max_cnt; j++) {
				struct coord_t target;
				target.h = h_max_list[i];
				target.w = w_max_list[j];
				if (bsearch(&target, coords, M, sizeof(*coords), yukati) == NULL) {
					kasanaru_dake = 0;
					i = h_max_cnt;
					break;
				}
			}
		}
	}

	printf("%d\n", h_max + w_max - kasanaru_dake);
	return 0;
}


/*

..*..
.....
*.*.*
.....
..*..

.....
.***.
*....
*....
*....

*/
