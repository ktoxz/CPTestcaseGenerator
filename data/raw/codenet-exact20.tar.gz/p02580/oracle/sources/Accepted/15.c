#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define in (void)scanf
#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define Ma(x,y) ((x)>(y)?(x):(y))
typedef long long LL;
//snp

#define N 300009
void run(void) {
	LL H, W, M, R = 0, C = 0, r_max = -1, c_max = -1;
	LL h[N], w[N], r[N] = { 0 }, c[N] = { 0 };
	in("%lld%lld%lld", &H, &W, &M);
	rep(i, M) {
		in("%lld%lld", &h[i], &w[i]);
		r[h[i]]++;
		c[w[i]]++;
		r_max = Ma(r_max, r[h[i]]);
		c_max = Ma(c_max, c[w[i]]);
	}
	rep(i, H)if (r[i + 1] == r_max)R++;
	rep(i, W)if (c[i + 1] == c_max)C++;
	LL cnt = 0, c2 = R * C;
	rep(i, M)if (r[h[i]] == r_max && c[w[i]] == c_max)cnt++;
	printf("%lld\n", r_max + c_max - (cnt >= c2 ? 1 : 0));
}

int main(void) {
	run();
	return 0;
}