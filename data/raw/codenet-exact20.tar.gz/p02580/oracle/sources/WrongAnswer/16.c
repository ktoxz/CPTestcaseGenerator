#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<math.h>
#include<string.h>
#define rep(i,l,r) for(ll i=l;i<r;i++)

typedef long long ll;

ll max(ll x, ll y) { return (x > y) ? x : y; }


int main() {
    ll H,W,M,h,w;
    scanf("%lld%lld%lld", &H,&W,&M);
    ll a[300001], b[300001];
    rep(i, 0, M) {
        scanf("%lld%lld", &h, &w);
        a[h]++, b[w]++;
    }
    ll ansH = 0, ansW=0;
    rep(i, 0, H) {
        ansH = max(ansH, a[i]);
    }
    rep(i, 0, W) {
        ansW = max(ansW, a[i]);
    }

    printf("%lld", ansH+ansW);

    return 0;
}