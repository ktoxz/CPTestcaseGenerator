/**
 *    author:  accesss_denied
**/
#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define ff first
#define ss second
#define pb push_back
#define endl "\n"
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
ll mod=1e9+7;			
ll inf=1e18;

int main() {
			fast
			// #ifndef ONLINE_JUDGE
			// freopen("input.txt","r",stdin);
			// freopen("output.txt","w",stdout);
			// #endif

			
			ll n,m,k;
			cin>>n>>m>>k;
			map<ll,ll>x,y;
			map<pair<ll,ll>,ll>arr;
			for(ll i=0;i<k;i++)
			{
				ll a,b;
				cin>>a>>b;
				x[a]+=1;
				y[b]+=1;
				arr[{a,b}]+=1;;
			}

			vector<pair<ll,ll>>xx,yy;
			for(auto it:x)
			{
				xx.pb({it.ss,it.ff});
			}
			for(auto it:y)
			{
				yy.pb({it.ss,it.ff});
			}
			sort(xx.rbegin(),xx.rend());
			sort(yy.rbegin(),yy.rend());

			ll xxx=xx[0].ss;
			ll yyy=yy[0].ss;
			ll ans=xx[0].ff+yy[0].ff;
			if(arr.find({xxx,yyy})!=arr.end())
			ans-=1;
			
			ll curx=xx[0].ss;
			for(ll i=0;i<yy.size();i++)
			{
				ll cury=yy[i].ss;
				ll cs=xx[0].ff+yy[i].ff;
				if(arr.find({curx,cury})!=arr.end())
				cs-=1;
				ans=max(ans,cs);
			}
			if(xx.size()>1)
			{		
				curx=xx[1].ss;	
			for(ll i=0;i<yy.size();i++)
			{
				ll cury=yy[i].ss;
				ll cs=xx[1].ff+yy[i].ff;
				if(arr.find({curx,cury})!=arr.end())
				cs-=1;
				ans=max(ans,cs);
			}
			}




				cout<<ans<<endl;
			
			
				// for(auto it:xx)
				// {
				// 	cout<<it.ss<<" "<<it.ff<<endl;
				// }
				// cout<<endl<<endl;
				// for(auto it:yy)
				// {
				// 	cout<<it.ss<<" "<<it.ff<<endl;
				// }

				
                
			
			return 0;
		 }	


