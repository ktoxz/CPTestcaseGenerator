import numpy as np
import sys
H, W, M = list(map(int, input().split()))
row = np.zeros(H)
col = np.zeros(W)
sys.exit()