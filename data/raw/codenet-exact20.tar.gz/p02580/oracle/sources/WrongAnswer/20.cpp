#include <bits/stdc++.h>
#define ll long long 
#define  ff first
#define ss second
#define vi vector<int>
#define vl vector<ll>
#define vll vector<pair<ll,ll> >
#define vii vector<pair<int,int> >
#define pb push_back
#define inf 1000000007
#define f(i,a,b) for(i=a;i<b;i++)

using namespace std;
bool cmp(string &a,string &b)
{
	if(a.size()==b.size())return a<b;
	return a.size()<b.size();
}

int main()
{ 
  int n,m,i,j,k,h,w,mx=0,mxr=0,mxc=0,r=0,c=0;
  
  cin>>h>>w>>m;
  
  map<pair<int,int>,int>mp;
   int row[h+1]={0},column[w+1]={0};
  f(i,0,m)
  {
  	cin>>j>>k;
  	row[j]++,column[k]++;
  	
  	if(mxr<row[j])mxr=row[j],r=j;
  	if(mxc<column[k])mxc=column[k],c=k;
    mp[{j,k}]++;
  }
   

  

    if(mp[{r,c}])mx=mxr+mxc-1;
    else mx=mxr+mxc;
   
  
  cout<<mx;
  

}