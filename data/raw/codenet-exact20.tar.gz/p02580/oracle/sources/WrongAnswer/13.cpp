#include <iostream>
#include <string>
#define rep(i,n) for (int i = 0; i<n; i++)
using namespace std;

int main() {
    int h,w,m;

    cin >> h >> w >> m;
    int a[m];
    int b[m];
    int ans = 0;
    int sum = 0;
    rep(i,m) cin >> a[i] >> b[i];

    rep(i,h) {
        rep(j,w) {
            rep(k,m) {
                if(a[k] == i) sum += 1;
                else if(b[k] == j) sum += 1;
            }
            
            if(sum > ans) ans = sum;
            sum = 0;
        }
    }

    cout << ans << endl;

}
