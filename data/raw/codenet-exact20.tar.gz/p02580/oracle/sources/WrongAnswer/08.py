from collections import Counter
x=0
H,W,M = map(int,input().split())
if H == 1 or W == 1:
  print(M)
  
  
else:  
  h = [0]*M
  w = [0]*M
  for i in range(0,M):
    h[i],w[i] = map(int,input().split())
  a = Counter(h).most_common()
  b = Counter(w).most_common()
  x = a[0][1]+b[0][1]
  for i in range(0,M):
    if h[i] == a[0][0] and w[i] == b[0][0]:
      x = x-1
  print(x)
