// E
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned long long int uint64;
typedef long long int          int64;
 
#define MAX(a,b) ((a)>(b)?(a):(b))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define ABS(a) ((a)>(0)?(a):-(a))

void get_N (int64 *n)
{
  
  (void)scanf("%lld", n);

  return;
}

void get_NK (int64 *n, int64 *k)
{
  
  (void)scanf("%lld %lld", n, k);

  return;
}

void get_N1234 (int64 *n1, int64 *n2, int64 *n3, int64 *n4)
{
  int cnt;

  if (n2 == NULL) {
    cnt = scanf("%lld", n1);
    return;
  }
  if (n3 == NULL) {
    cnt = scanf("%lld %lld", n1, n2);
    return;
  }
  if (n4 == NULL) {
    cnt = scanf("%lld %lld %lld", n1, n2, n3);
    return;
  }
  cnt = scanf("%lld %lld %lld %lld", n1, n2, n3, n4);
  return;
}

void omit_LF (void)
{
  char c;
  int  cnt;
  
  cnt = scanf("%c", &c);
  return;
}

char *get_S (int64 n)
{
  char *buf;
  int  i;
  int  cnt;

  buf = (char *)malloc((size_t)(n * sizeof(char)));
  if (buf == NULL) {
    return NULL;
  }

  cnt = scanf("%s", buf);

  return buf;
}

char *get_SN (int64 max, int64 *size)
{
  char *buf;
  int  i;
  int  n;
  int  cnt;

  buf = (char *)malloc((size_t)(max * sizeof(char)));
  if (buf == NULL) {
    return NULL;
  }

  cnt = scanf("%s", buf);

  n = strlen(buf);

  *size = n;
  
  return buf;
}

int64 *get_NSeq (int64 n)
{
  int64 *buf;
  int64 i;

  buf = (int64 *)malloc((size_t)(n * sizeof(int64)));
  for (i=0; i<n; i++) {
    get_N(&buf[i]);
  }

  return buf;
}

typedef struct _tmp_t {
  int64    a;
  int64    b;
} tmp_t;

typedef int64 simple_t;

int compare_simple(const void *a, const void *b)
{
  simple_t *x;
  simple_t *y;

  x = (simple_t *)a;
  y = (simple_t *)b;

  if (x > y) return 1;
  if (y < x) return -1;

  return 0;
}
void qsort_simple (simple_t *array, int size)
{
  qsort(array, size, sizeof(simple_t), compare_simple);
}

int compare_a(const void *a, const void *b)
{
  tmp_t *x;
  tmp_t *y;

  x = (tmp_t *)a;
  y = (tmp_t *)b;

  if (x->a > y->a) return 1;
  if (x->a < y->a) return -1;

  return 0;
}

int compare_b(const void *a, const void *b)
{
  tmp_t *x;
  tmp_t *y;

  x = (tmp_t *)a;
  y = (tmp_t *)b;

  if (x->b > y->b) return 1;
  if (x->b < y->b) return -1;

  return 0;
}

void qsort_a (tmp_t *array, int size)
{
  qsort(array, size, sizeof(tmp_t), compare_a);
}

void qsort_b (tmp_t *array, int size)
{
  qsort(array, size, sizeof(tmp_t), compare_b);
}


int resolve1()
{
  int64 R;
  double pi=3.14159;
  double L;

  get_N(&R);

  L = pi*R*2;

  printf("%lf", L);
  return 0;
}

//#define SIZE (3*10*10*10*10*10 + 1)
#define SIZE 1000



int *wcnt2;
int *hcnt;

#if 0
typedef struct _bitmatrix_w {
  uint64 row[4688];
} bitmatrix_w;

bitmatrix_w matrix[SIZE];

void bitmatrix_init (int64 h, int64 w)
{
  return;
}

void bitmatrix_set (int64 h, int64 w)
{
  int64 wi,bit;

  wi = w / 64;
  bit = w % 64;

  matrix[h].row[wi] |= 1 << bit;
  
  return;
}

int bitmatrix_get (int64 h, int64 w)
{
  int64 wi,bit;

  wi = w / 64;
  bit = w % 64;

  if (matrix[h].row[wi] & (1 << bit)) {
    return 1;
  }
  
  return 0;
}
#endif // 0


typedef struct _intpair {
  int h;
  int w;
  struct _intpair *next;
} intpair_t;

intpair_t *bitmatrix_head;

void bitmatrix_init (int64 h, int64 w)
{
  bitmatrix_head = NULL;
  return;
}
void bitmatrix_set (int64 h, int64 w)
{
  intpair_t *ptr;

  ptr = (intpair_t *)malloc(sizeof(intpair_t));
  ptr->h = h;
  ptr->w = w;
  ptr->next = NULL;

  if (bitmatrix_head == NULL) {
    bitmatrix_head = ptr;
  } else {
    ptr->next = bitmatrix_head;
    bitmatrix_head = ptr;
  }

  return;
}

int bitmatrix_get (int64 h, int64 w)
{
  intpair_t *ptr;

  if (bitmatrix_head == NULL) return 0;

  ptr = bitmatrix_head; 
  while(1) {
    if ((ptr->h == h) && (ptr->w == w)) return 1;
    if (ptr->next == NULL) return 0;

    ptr = ptr->next;
  }

  return 0;
}
     

void resolve2()
{
  int64 H,W,M,h,w;
  int64 i,total;
  int64 max_hcnt, max_hindex, max_wcnt, max_windex;
  
  get_N1234(&H, &W, &M, NULL );

  bitmatrix_init(H,W);
  hcnt = (int *)malloc((size_t)(H * sizeof(int)));
  wcnt2 = (int *)malloc((size_t)(W * sizeof(int)));

  memset(hcnt, 0, (H * sizeof(int)));
  memset(wcnt2, 0, (W * sizeof(int)));

  max_hcnt=0;
  max_hindex=0;
  max_wcnt=0;
  max_windex=0;
  for (i=0; i<M; i++) {
    get_NK(&h, &w);
    bitmatrix_set(h,w);
    hcnt[h]++;
    if(max_hcnt < hcnt[h]) {
      max_hcnt = hcnt[h];
      max_hindex = h;
    }
    wcnt2[w]++;
    if(max_wcnt < wcnt2[w]) {
      max_wcnt = wcnt2[w];
      max_windex = w;
    }
  }

  total = max_hcnt + max_wcnt;
  if (bitmatrix_get(max_hindex, max_windex)) {
    total--;
  }

  printf("%lld", total);
  return;
}


void resolve3()
{
  int64 N;
  char *str;
  int64 i;
  int64 sum = 0;
  
  str = get_SN(2000001, &N);

  for (i=0; i < N; i++) {
    sum += str[i] - '0';
  }

  if (((sum % 9) == 0) || (sum == 0)) {
    printf("Yes");
  } else {
    printf("No");
  }

  return;
}

int main()
{
  resolve2();

  return 0;
}

