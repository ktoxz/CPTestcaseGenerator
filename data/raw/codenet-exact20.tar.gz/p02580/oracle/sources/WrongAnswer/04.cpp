#include <iostream>
#include <map>
#include <string>
using namespace std;
int main()
{
	long long H;
	cin >> H;
	long long W;
	cin >> W;
	long long M;
	cin >> M;

	map<long long, long long> cols;
	map<long long, long long> rows;
	map<string, bool> bombs;
	for (long long i = 0; i < M; ++i)
	{
		long long h;
		cin >> h;
		
		if (rows.find(h - 1) != rows.end())
		{
			rows[h - 1]++;
		}
		else
		{
			rows[h - 1] = 1;
		}

		long long w;
		cin >> w;
		if (cols.find(w - 1) != cols.end())
		{
			cols[w - 1]++;
		}
		else
		{
			cols[w - 1] = 1;
		}

		string s = to_string(w-1);
		s.append(",");
		s.append(to_string(h-1));
		bombs[s] = true;
	}

	long long maxRowId = 0;
	long long maxRowVal = rows[0];
	for (long long i = 1; i < H; ++i)
	{
		if (rows[i] > maxRowVal)
		{
			maxRowId = i;
			maxRowVal = rows[i];
		}
	}

	long long maxColId = 0;
	long long maxColVal = cols[0];
	for (long long i = 1; i < W; ++i)
	{
		if (cols[i] > maxColVal)
		{
			maxColId = i;
			maxColVal = cols[i];
		}
	}

	string s = to_string(maxColId);
	s.append(",");
	s.append(to_string(maxRowId));
	if (bombs.find(s) != bombs.end())
	{
		cout << maxRowVal + maxColVal - 1 << endl;
	}
	else
	{
		cout << maxRowVal + maxColVal << endl;
	}
}