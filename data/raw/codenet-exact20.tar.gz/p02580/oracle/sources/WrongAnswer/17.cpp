#include<bits/stdc++.h>
using namespace std;
int h,w,m;
int maxh,maxl;
struct node{
	int hang;
	int lie;
}a[300005];
int main(){
    cin>>h>>w>>m;
    for(int i=1;i<=m;i++){
    	int c,b;
    	cin>>c>>b;
    	a[c].hang++;
    	a[b].lie++;
	}
	for(int i=1;i<=h;i++)if(maxh<a[i].hang)maxh=a[i].hang;
	for(int i=1;i<=w;i++)if(maxl<a[i].lie)maxh=a[i].lie;
	cout<<maxh+maxl;
    return 0;
}