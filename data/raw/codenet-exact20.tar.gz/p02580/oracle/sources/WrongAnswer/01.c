#include <stdio.h>

typedef struct vector2 {
  int x, y;
}vector2;

int main(void) {
  int h, w, m;
  scanf("%d%d%d", &h, &w, &m);
  int row[h], column[w];
  vector2 v[m];
  for(int i = 0;i < h;i++) {
    row[i] = 0;
  }
  for(int i = 0;i < w;i++) {
    column[i] = 0;
  }
  int maxr = 0, maxc = 0;
  for(int i = 0;i < m;i++) {
    int x, y;
    scanf("%d%d", &y, &x);
    row[y-1]++;
    column[x-1]++;
    v[i] = (vector2){ x-1, y-1 };
    if(maxr < row[y-1]) maxr = row[y-1];
    if(maxc < column[x-1]) maxc = column[x-1];
  }
  int rc = 0, cc = 0;
  for(int i = 0;i < h;i++) {
    if(maxr == row[i]) {
      rc++;
    }
  }
  for(int i = 0;i < w;i++) {
    if(maxc == column[i]) {
      cc++;
    }
  }
  
  int count = rc * cc;
  for(int i = 0;i < m;i++) {
    int x = v[i].x, y = v[i].y;
    if(row[y] == maxr && column[x] == maxc) {
      count--;
    }

  }

  if(count > 0) {
    printf("%d\n", maxr + maxc);
  } else {
    printf("%d\n", maxr + maxc - 1);
  }
  return 0;
}