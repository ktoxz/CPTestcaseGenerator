#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define F first
#define S second
#define pb push_back
#define mp make_pair
#define yes "YES"
#define no "NO"
#define rsort(a) sort(a.rbegin(),a.rend())
const int mod=1000000007;
//void dfs(int i);
long long modular_expo(long long x,long long y);

bool cmp(pair<double,int>p1,pair<double,int>p2)
{
    if(p1.first>p2.first)
        return true;
    else
    {
        if(p1.first<p2.first)
            return false;
        else if(p1.first==p2.first)
        {
            if(p1.second<p2.second)
                return true;
            else
                return false;
        }
    }
}
/*bool cmp1(map<int,int>a,map<int,int>b)
{
    if(a.first<b.first)
        return true;
    else
        return false;
}*/
//ll m;


/*
void bsf(int t)
{
    queue<int>q;
    visited[t]=true;
    q.push(t);
    while(!q.empty())
    {
        int temp=q.front();
        //cout<<temp<<" ";
        if(temp==n)
            {
                vector<int>ans;
    ans.pb(n);
        int tttt=n;
    for(int i=0;i<tttt;i++)
    {
        ans.pb(parent[n]);
        n=parent[n];
        if(n==1)
            break;
    }
    if(n!=1)
    {
        break;
    }
    cout<<ans.size()<<endl;
    for(int i=ans.size()-1;i>=0;i--)
        cout<<ans[i]<<" ";
        f=1;

            }
        q.pop();
        //cout<<temp<<" ";
        for(auto i=l[temp].begin();i!=l[temp].end();i++)
        {
            if(!visited[*i])
            {
                q.push(*i);
                parent[*i]=temp;
                visited[*i]=true;
            }
        }
    }
}
*/
long long modular_expo(long long x,long long y)
{

    if(y==0)
        return 1;
    if(y%2==0)
        return (modular_expo((x*x),y/2));
    if(y%2==1)
        return ((x)*modular_expo((x*x),(y-1)/2));


}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);

    int n,m,i,j,t;
    map<pair<int,int>,int>mpp;
    cin>>m>>n>>t;
    vector<ll>row(n+1,0),col(m+1,0);
    for(i=0;i<t;i++)
    {
        int x,y;
        cin>>y>>x;
        row[x]++;
        col[y]++;
        mpp[mp(x,y)]=1;
    }
    int x,y;
    ll maxi=-1;
    for(i=0;i<=n;i++)
    {
        if(row[i]>maxi)
        {
            maxi=row[i];
            x=i;
        }
    }
    maxi=-1;
    for(i=0;i<=m;i++)
    {
        if(col[i]>maxi)
        {
            maxi=col[i];
            y=i;
        }
    }
    rsort(row);
    rsort(col);
    /*
    ll rx=row[0];
    ll cx=col[0];
    i=0;j=0;
    ll ans=-1;
    for(i=0;row[i]==rx;i++)
    {
        for(j=0;col[j]==cx;j++)
        {
            ans=max(ans,row[0]+col[0]-mpp[mp(x,y)])
        }
    }
    */
    cout<<row[0]+col[0]-mpp[mp(x,y)];
}


