#if loc||local
#define _GLIBCXX_DEBUG
#endif

#include<bits/stdc++.h>
using namespace std;

#define rep(i,n) for(ll i=0;i<(n);++i)
using ll = int_fast64_t;
using pll = pair<ll,ll>;
constexpr ll INF = 1LL<<60;
constexpr ll MOD = 1e9+7;
template<class T> bool chmax(T &a,const T &b){if(a<b){a=b;return 1;}return 0;}
template<class T> bool chmin(T &a,const T &b){if(a>b){a=b;return 1;}return 0;}
#if loc||local
template<class T>void dump(T&& t){cerr<<t<<endl;}
template<class T,class... Ts> void dump(T&& h, Ts&&... t){cerr<<h<<", ";dump(forward<Ts>(t)...);}
#else
void dump(){}
template<class T,class... Ts> void dump(T&& h, Ts&&... t){}
#endif
template<class T> istream &operator>>(istream&is,vector<T>&v){for(auto &elemnt:v)is>>elemnt;return is;}
template<class T,class U> istream &operator>>(istream&is,pair<T,U>&p){is>>p.first>>p.second;return is;}
template<class T> ostream &operator<<(ostream& os,vector<T>const& v){for(auto const& vi:v)os<<vi<<" ";return os;}
template<class T,class U> ostream &operator<<(ostream& os,pair<T,U>const& p){os<<p.first<<","<<p.second;return os;}
template<class T>vector<T> vec(size_t a){return vector<T>(a);}
template<class T, class... Ts>auto vec(size_t a, Ts... ts){return vector<decltype(vec<T>(ts...))>(a, vec<T>(ts...));}

signed main(){

  int h,w,m;
  cin>>h>>w>>m;
  vector<map<int,int>> target(h);
  map<int,int> row;
  map<int,int> col;
  rep(i,m){
    int hi,wi;
    cin>>hi>>wi;
    hi--;wi--;
    target[hi][wi]++;
    row[hi]++;
    col[wi]++;
  }
  ll colmax1=-1,colmax2=-1;
  ll col_i1=-1,col_i2=-1;
  for(auto&[wi,val]:col){
    if(val>colmax1){
      colmax2 = colmax1;
      col_i2 = col_i1;
      colmax1 = val;
      col_i1 = wi;
    }
    else if(val>colmax2){
      colmax2 = val;
      col_i2 = wi;
    }
  }
  ll ans = 0;
  for(auto&[hi,val]:row){
    ll t = (target[hi].count(col_i1)?1:0);
    chmax(ans,row[hi]+col[col_i1]-t);
    t = (target[hi].count(col_i2)?1:0);
    chmax(ans,row[hi]+col[col_i2]-t);
  }
  cout<<(ans)<<endl;

}