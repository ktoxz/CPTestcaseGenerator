H,W,M = [int(x) for x in input().split()]
hw = []
hNum = [0]*H
wNum = [0]*W

for i in range(M):
    h,w = [int(x) for x in input().split()]
    hw.append([h,w])
    hNum[h-1]+=1
    wNum[w-1]+=1

hmax = max(hNum)
hMaxList = []
wmax = max(wNum)
wMaxList = []

for i in range(H):
    if(hmax == hNum[i]):
        hMaxList.append(i)
for i in range(W):
    if(wmax == wNum[i]):
        wMaxList.append(i)

ans = wmax + hmax -1
if((M <= H and hmax ==  1) or (M <= W and wmax ==  1 )):
    ans += 1
flag = False
for i in hMaxList:
    if(not i in wMaxList):
        flag = True
        

if(flag):
    print(ans)
else:
    print(ans-1)
