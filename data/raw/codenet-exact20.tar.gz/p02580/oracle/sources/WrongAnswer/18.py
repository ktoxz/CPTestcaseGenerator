import sys
si = sys.stdin.readline


def main():
    [h, w, m] = [int(e) for e in si().split()]
    bh, bw, g = dict(), dict(), [[0 for _ in range(w+1)]for _ in range(h+1)]
    for i in range(1, h+1):
        bh[i] = 0
    for j in range(1, w+1):
        bw[j] = 0
    mh, mw, mr, mc = 0, 0, 0, 0
    for _ in range(m):
        [r, c] = [int(e) for e in si().split()]
        g[r][c] = 1
        bh[r] += 1
        bw[c] += 1
        if bh[r] > mh:
            mh = bh[r]
            mr = r
        if bw[c] > mw:
            mw = bw[c]
            mc = c
    print(mh+mw-g[mr][mc])


if __name__ == '__main__':
    main()
