import os
import heapq
import sys,threading
import math
import bisect
import operator
from collections import defaultdict
sys.setrecursionlimit(10**5)
from io import BytesIO, IOBase
def gcd(a,b):
    if b==0:

        return a
    else:
        return gcd(b,a%b)
def power(x, p,m):
    res = 1
    while p:
        if p & 1:
            res = (res * x) % m
        x = (x * x) % m
        p >>= 1
    return res
def inar():
    return [int(k) for k in input().split()]

def lcm(num1,num2):
    return (num1*num2)//gcd(num1,num2)

def main():
    n,m,q=inar()
    row={}
    column={}
    arr=[]
    take1=defaultdict(int)
    take2=defaultdict(int)
    for i in range(q):
        r,c=inar()
        take1[r]+=1
        take2[c]+=1
        arr.append([r,c])
        arr.append([r,c])
        if r not in row:
            row[r]=defaultdict(int)
            row[r][c]+=1
        else:
            row[r][c]+=1
        if c not in column:
            column[c]=defaultdict(int)
            column[c][r]+=1
        else:
            column[c][r]+=1
    ans=0
    take1=dict(sorted(take1.items(),key=operator.itemgetter(1),reverse=True))
    take2 = dict(sorted(take2.items(), key=operator.itemgetter(1), reverse=True))
    # print(take1)
    # print(take2)
    # for i in range(len(take1)):
    #     for j in range(len(take2)):
    for key,item in take1.items():
        r=key
        break
    for key,item in take2.items():
        c=key
        break

    temp=len(row[r])
    temp+=len(column[c])
    temp-=row[r][c]
    ans=max(ans,temp)
    for i in range(q):
        r,c=arr[i][0],arr[i][1]
        temp = len(row[r])
        temp += len(column[c])
        temp -= row[r][c]
        ans = max(ans, temp)

    print(ans)




BUFSIZE = 8192


class FastIO(IOBase):
    newlines = 0

    def __init__(self, file):
        self._fd = file.fileno()
        self.buffer = BytesIO()
        self.writable = "x" in file.mode or "r" not in file.mode
        self.write = self.buffer.write if self.writable else None

    def read(self):
        while True:
            b = os.read(self._fd, max(os.fstat(self._fd).st_size, BUFSIZE))
            if not b:
                break
            ptr = self.buffer.tell()
            self.buffer.seek(0, 2), self.buffer.write(b), self.buffer.seek(ptr)
        self.newlines = 0
        return self.buffer.read()

    def readline(self):
        while self.newlines == 0:
            b = os.read(self._fd, max(os.fstat(self._fd).st_size, BUFSIZE))
            self.newlines = b.count(b"\n") + (not b)
            ptr = self.buffer.tell()
            self.buffer.seek(0, 2), self.buffer.write(b), self.buffer.seek(ptr)
        self.newlines -= 1
        return self.buffer.readline()

    def flush(self):
        if self.writable:
            os.write(self._fd, self.buffer.getvalue())
            self.buffer.truncate(0), self.buffer.seek(0)


class IOWrapper(IOBase):
    def __init__(self, file):
        self.buffer = FastIO(file)
        self.flush = self.buffer.flush
        self.writable = self.buffer.writable
        self.write = lambda s: self.buffer.write(s.encode("ascii"))
        self.read = lambda: self.buffer.read().decode("ascii")
        self.readline = lambda: self.buffer.readline().decode("ascii")


sys.stdin, sys.stdout = IOWrapper(sys.stdin), IOWrapper(sys.stdout)
input = lambda: sys.stdin.readline().rstrip("\r\n")

if __name__ == "__main__":
    main()
    #threadin.Thread(target=main).start()
