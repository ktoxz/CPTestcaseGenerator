h, w, m= map(int, input().split())
hs = [0 for i in range(h)]
ws = [0 for i in range(w)]
for i in range(m):
  mh, mw = map(int, input().split())
  hs[mh-1] += 1
  ws[mw-1] += 1
print(max(hs)+max(ws)-1)