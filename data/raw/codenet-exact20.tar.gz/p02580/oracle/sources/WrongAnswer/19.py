import numpy as np
 
H, W, M = [int(n) for n in input().split()]